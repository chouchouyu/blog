package com.cmrh.goa.android.third;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.cm.android.apirouter.facade.annotation.Route;
import com.cm.android.apirouter.facade.annotation.Serviceid;

import static com.cmrh.goa.android.third.RouterConts.METHOD_GET_INSTANCE;

/**
 * BaseActivity ~!
 */
@Route(path = "/module3/BaseActivity")
public class BaseActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView image;

//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_base);
//
//        image = (ImageView) findViewById(R.id.imageView);
//        image.setOnClickListener(this);
//    }

    /**
     * LoginManager 方法的解释 啦啦啦啦啦啦啦aeua8euqoeuoa
     *
     * @return
     */
    @Serviceid(path = "change")
    public boolean changebg(){
//        image.setPivotX(image.getWidth()/2);
//        image.setPivotY(image.getHeight()/2);//支点在图片中心
//        image.setRotation(90);
        Log.d("test","change");
        return false;
    }

    @Override
    public void onClick(View view) {
        changebg();
    }
}
