package com.cmrh.goa.android.third;

/**
 * Created by wusm on 2017/9/26.
 */

public class RouterConts {
    public static final String GROUP_SECOND_MODULE= "/third";
    public static final String ROUTE_LAUNCH = GROUP_SECOND_MODULE+"/baseUI";
    public static final String ROUTE_LOGIN = GROUP_SECOND_MODULE+"/33333X";
    public static final String METHOD_GET_INSTANCE = "get33Instance";
    public static final String METHOD_SETTITLE = "setTitle";
//    public static final String METHOD_INJECT = "inject";
//    public static final String METHOD_CALLMETHOD = "methodCall";
}