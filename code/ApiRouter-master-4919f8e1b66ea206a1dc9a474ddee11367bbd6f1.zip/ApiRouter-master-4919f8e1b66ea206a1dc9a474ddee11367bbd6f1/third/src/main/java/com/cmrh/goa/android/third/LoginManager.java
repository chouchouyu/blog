package com.cmrh.goa.android.third;

import android.content.Context;


/**
 * 登录接口
 * Created by wusm on 2017/9/20.
 */

public abstract class LoginManager {

    /*
    private static final LoginManager ourInstance = new LoginManager();

    public static LoginManager getInstance() {
        return ourInstance;
    }

    private LoginManager() {
    }
    */

    /* 内部私有静态实例，目的是实现延迟加载 */
    private static class LoginHolder {
   //     private static LoginManager instance = new LoginImpl();
    }

    /**
     * 获取登录管理类实例
     *
     * @return
     */
    public static LoginManager getInstance() {
        return  null;
    }

    /**
     * 是否已登录
     *
     * @return
     */
    public abstract boolean isLogin();


    /**
     * 登录方式设置
     * @see SPKey#LOGINTYPE_GESTURE
     * @see SPKey#LOGINTYPE_PWD
     *
     * @param context
     * @param loginType
     */
    public abstract void setLoginType(Context context, int loginType);


    /**
     * 获取登录方式
     *
     * @see SPKey#LOGINTYPE_GESTURE
     * @see SPKey#LOGINTYPE_PWD
     * @param context
     * @return
     */
    public abstract int getLoginType(Context context);


    public abstract void showLoginActivity(Context context);


}
