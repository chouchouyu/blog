package com.cmrh.goa.android.third;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.cm.android.apirouter.facade.annotation.Route;
import com.cm.android.apirouter.facade.annotation.Serviceid;
import com.cm.android.apirouter.facade.template.IProvider;

import static com.cmrh.goa.android.third.RouterConts.METHOD_GET_INSTANCE;
import static com.cmrh.goa.android.third.RouterConts.ROUTE_LAUNCH;


/**
 * 这个是被调用的类
 * <p>
 * Created by susan on 2017/9/20.
 */
@Route(path = ROUTE_LAUNCH)
public class LoginApi implements IProvider {


    private Context mContext;


    @Override
    public void init(Context context) {
        this.mContext = context;
    }

    /**
     * LoginManager 方法的解释 啦啦啦啦啦啦啦aeua8euqoeuoa
     *
     * @return
     */
    @Serviceid(path = METHOD_GET_INSTANCE)
    public LoginManager getInstance() {
        return LoginManager.getInstance();
    }


    public void setLoginType(String jsonParam) {


    }

    /**
     * 方法的解释
     * {@link HelloService}
     *
     * @param name=SSSSXX,type=ArrayList,description=参数的解释,must=Y
     * @return 返回值的解释
     */
    @Deprecated
    @Serviceid(path = "setTitle")
    public boolean sayYES(String data) {
//        Log.d("LoginApi", data);
        Toast.makeText(mContext.getApplicationContext(), data, Toast.LENGTH_SHORT).show();
        return true;
    }
}
