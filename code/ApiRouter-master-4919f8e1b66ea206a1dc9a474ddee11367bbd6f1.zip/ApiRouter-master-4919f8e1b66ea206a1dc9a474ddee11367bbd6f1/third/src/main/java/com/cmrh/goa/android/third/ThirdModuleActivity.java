package com.cmrh.goa.android.third;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.cm.android.apirouter.facade.Postcard;
import com.cm.android.apirouter.facade.annotation.Autowired;
import com.cm.android.apirouter.facade.annotation.Route;
import com.cm.android.apirouter.facade.annotation.Serviceid;
import com.cm.android.apirouter.facade.callback.NavCallback;
import com.cm.android.apirouter.launcher.ApiRouter;

/**
 * TestModuleActivity 的commoent out ~!
 */
@Route(path = "/module3/123")
public class ThirdModuleActivity extends BaseActivity {

    @Autowired
    String wsm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_module);
//        ApiRouter.getInstance().inject(this);
        TextView textView = (TextView) findViewById(R.id.textView);
        textView.setText(this.getClass().getPackage().getName());
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("WSM", "key - >" + wsm);
        Toast.makeText(this, wsm, Toast.LENGTH_SHORT).show();
    }

    /**
     * LoginManager 方法的解释 啦啦啦啦啦啦啦aeua8euqoeuoa
     *
     * @return
     * @Serviceid(path = "change")
     * @Override public boolean changebg() {
     * Log.d("WSM", "key - >" + wsm);
     * Toast.makeText(this, wsm, Toast.LENGTH_SHORT).show();
     * return true;
     * }
     */
    public void clickBtn(View view) {
        ApiRouter.getInstance().build("module3", "BaseActivity", "change", "")
                .withString("wsm", "w")
                .navigation(this, new NavCallback() {
                    @Override
                    public void onFound(Postcard postcard) {
                        Log.d("ApiRouter-", "onFound");

                    }

                    @Override
                    public void onLost(Postcard postcard) {
                        Log.d("ApiRouter-", "onLost");
                    }

                    @Override
                    public void onArrival(Postcard postcard, Object returnObj) {
                        Log.d("ApiRouter-", "onArrival" + (Boolean) returnObj);
                        Log.d("ApiRouter-", "postcard" + postcard.toString());
                    }

                    @Override
                    public void onInterrupt(Postcard postcard) {
                        Log.d("ApiRouter-", "onInterrupt");
                    }
                });
    }
}
