package com.cm.android.apirouter.compiler.utils;

import com.cm.android.apirouter.compiler.Module;
import com.cm.android.apirouter.compiler.Module.ModuleListBean;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by wusm on 2017/9/27.
 */

public class GenerateJsonFileUtils {

    public static String getTempFileName(String version) {
        return tempFile+"_"+version+".json";
    }

    private static String tempFile = "temp_Android_API";

    public static void create(ModuleListBean moduleBean)   {
        String generateDirectory = moduleBean.getRootPath().substring(0,moduleBean.getRootPath().lastIndexOf(File.separator));
        File generateDirectoryFile = new File(generateDirectory+File.separator+"API");

        //first time to prepare Directory
        //{"version":"1.0","description":"","platform":"Android","moduleList":null}
        if(moduleBean.getRootPath().endsWith(File.separator+"app")){
            if(generateDirectoryFile.exists()){
//                clearAPIDir(generateDirectoryFile);
            }else {
                generateDirectoryFile.mkdir();
            }

            Module module = new Module();
            module.setDescription(moduleBean.getDescription());
            module.setVersion(moduleBean.getVersion());

            //create XX/API/temp_Android_API.json
            File file=new File(generateDirectoryFile.getAbsolutePath()+File.separator+getTempFileName(moduleBean.getVersion()));
            try {
                file.createNewFile();
                //GB2312
                BufferedWriter out = new BufferedWriter(new FileWriter(file));

                out.write(module.toString());
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void print(ModuleListBean moduleBean)   {
        Map<String,String> fileMap = new HashMap<>();
        String generateDirectory = moduleBean.getRootPath().substring(0,moduleBean.getRootPath().lastIndexOf(File.separator));
        File generateDirectoryFile = new File(generateDirectory+File.separator+"API");
        //generate moduleFile
        File moduleFile = new File(generateDirectoryFile.getAbsolutePath()+File.separator+"temp_"+moduleBean.getName()+"_"+moduleBean.getVersion()+".json");
        if(!generateDirectoryFile.exists()){
            return;
        }
        try {
            moduleFile.createNewFile();
            //GB2312
            BufferedWriter out = new BufferedWriter(new FileWriter(moduleFile));
            out.write(moduleBean.toString());

            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (File file : generateDirectoryFile.listFiles()){
            try {
                String encoding = "GB2312";
                if (file.isFile() && file.exists()) {
                    InputStreamReader read = new InputStreamReader(
                            new FileInputStream(file), encoding);
                    BufferedReader bufferedReader = new BufferedReader(read);
                    String lineTxt;
                    while ((lineTxt = bufferedReader.readLine()) != null) {
                        String jsonFileName = file.getName();
                        fileMap.put(jsonFileName,lineTxt);
                    }
                    read.close();

                    String tempStr = null;
                    String appVersion = null;
                    for (String  mapKey : fileMap.keySet()) {
                        if(mapKey.startsWith(tempFile)){
                            tempStr = fileMap.get(mapKey);
                            appVersion = mapKey.substring(mapKey.lastIndexOf("_"+1,mapKey.lastIndexOf(".")));
                        }
                    }

                    for (String  mapKey : fileMap.keySet()) {
                      if(mapKey.startsWith("temp_")&&mapKey.endsWith(".json") && !mapKey.startsWith(tempFile)){
                            String moduleStr  =  fileMap.get(mapKey);

                            if(tempStr.contains("\"moduleList\":null")){
                                tempStr = tempStr.replace("\"moduleList\":null","\"moduleList\":["+ moduleStr+"]");
                            }else {
                                tempStr = tempStr.substring(0,tempStr.length()-2).concat(",").concat(moduleStr).concat(tempStr.substring(tempStr.length()-2,tempStr.length()));
                            }
//                            if(mapKey.startsWith("temp_app_")&&mapKey.endsWith(".json")){
//  todo                              appVersion=mapKey.substring(mapKey.indexOf("app_")+4,mapKey.lastIndexOf("."));
//                            }
                        }
                    }
                    if(appVersion!=null){
                        File generateJsonFile=new File(generateDirectoryFile+File.separator+"Android_API_"+appVersion+".json");
                        try {
                            BufferedWriter out = new BufferedWriter(new FileWriter(generateJsonFile));
                            out.write(tempStr);
                            out.close();
                        } catch (IOException e) {
                        }
                    }


                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }

        }
    }
    private static void clearAPIDir(File apiDir){
        for (File file : apiDir.listFiles()){
            file.delete();
        }
    }

}