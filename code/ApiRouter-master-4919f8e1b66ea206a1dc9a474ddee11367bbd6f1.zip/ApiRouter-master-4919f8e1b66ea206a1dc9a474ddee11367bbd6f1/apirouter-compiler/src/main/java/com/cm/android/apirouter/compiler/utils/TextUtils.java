package com.cm.android.apirouter.compiler.utils;

/**
 * Created by wusm on 2017/9/12.
 */
public class TextUtils {

    public static boolean isEmpty(final CharSequence cs) {
        return cs == null || cs.length() == 0;
    }

    public static String splitStrGetClassName(String path) {
        if (isEmpty(path) || !path.startsWith("/")) {
            throw new HandlerException(Consts.TAG + "Extract the default group failed, the path is empty");
        }

        try {
            String defaultGroup = path.substring(path.indexOf("/", 1) + 1, path.length());
            if (isEmpty(defaultGroup)) {
                throw new HandlerException(Consts.TAG + "Extract the default group failed! There's nothing between 2 '/'!");
            } else {
                return defaultGroup;
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static String getMethodDoc(String methodDoc) {
        int methodDocEndIndex = methodDoc.length();
        if (methodDoc.contains("{@link")) {
            methodDocEndIndex = methodDoc.indexOf("{@link");
        } else {
            if (methodDoc.contains("@")) {
                methodDocEndIndex = methodDoc.indexOf("@");
            }
        }

        return methodDoc.substring(0, methodDocEndIndex).trim();
    }

}
