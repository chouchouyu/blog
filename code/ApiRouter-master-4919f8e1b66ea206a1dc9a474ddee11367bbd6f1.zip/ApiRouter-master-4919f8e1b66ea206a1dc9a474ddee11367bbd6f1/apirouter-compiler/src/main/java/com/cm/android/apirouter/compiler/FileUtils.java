package com.cm.android.apirouter.compiler;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by Administrator on 2017/3/1 0001.
 */

public class FileUtils {
    public static void print(String text) {
        File file=new File("C:\\Users\\wusm\\Desktop\\log.txt");
//        File file = new File("/Users/susan/Desktop/log.txt");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
            //GB2312
            FileWriter fileWriter = new FileWriter(file.getAbsoluteFile(), true);
            fileWriter.write(text + "\n");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    /*
        try {
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter  osw = new OutputStreamWriter(fos, "GB2312");
            osw.write(text);
            osw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
        */
    }
}
