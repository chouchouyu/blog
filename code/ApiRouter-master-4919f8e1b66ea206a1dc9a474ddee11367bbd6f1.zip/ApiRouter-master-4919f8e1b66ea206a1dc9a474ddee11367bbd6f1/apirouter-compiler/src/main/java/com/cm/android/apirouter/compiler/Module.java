package com.cm.android.apirouter.compiler;

import java.util.List;

/**
 * Created by wusm on 2017/9/13.
 */

public class Module {
//    public Module(String moduleName, String moduleRootPath, String moduleversion) {
//        this.moduleName = moduleName;
//        this.modulePath = modulePath;
//        this.version = moduleversion;
//    }


    /**
     * version : 0.1
     * platform : ios
     * description : this is a demo!
     * moduleList : [{"version":"1.2","description":"","name":"moduleA","serviceList":[{"description":"","name":"MethodA","methodList":[{"description":"","name":"","argList":[{"description":"","name":"","type":"","must":""}],"result":"MethodArgument","deprecated":"","replaceMethed":"","demo":"demoStr"}]}]}]
     */
    private String version;
    private String description;
    private List<ModuleListBean> moduleList;


    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<ModuleListBean> getModuleList() {
        return moduleList;
    }

    public void setModuleList(List<ModuleListBean> moduleList) {
        this.moduleList = moduleList;
    }

    public static class ModuleListBean {


        /**
         * version : 1.2
         * description :
         * name : moduleA
         * serviceList : [{"description":"","name":"MethodA","methodList":[{"description":"","name":"","argList":[{"description":"","name":"","type":"","must":""}],"result":"MethodArgument","deprecated":"","replaceMethed":"","demo":"demoStr"}]}]
         */
        private String rootPath;
        private String version;
        private String description;
        private String name;
        private List<ServiceListBean> serviceList;

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getRootPath() {
            return rootPath;
        }

        public void setRootPath(String rootPath) {
            this.rootPath = rootPath;
        }

        public List<ServiceListBean> getServiceList() {
            return serviceList;
        }

        public void setServiceList(List<ServiceListBean> serviceList) {
            this.serviceList = serviceList;
        }

        public static class ServiceListBean {
            /**
             * description :
             * name : MethodA
             * methodList : [{"description":"","name":"","argList":[{"description":"","name":"","type":"","must":""}],"result":"MethodArgument","deprecated":"","replaceMethed":"","demo":"demoStr"}]
             */

            private String description;
            private String name;
            private List<MethodListBean> methodList;

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public List<MethodListBean> getMethodList() {
                return methodList;
            }

            public void setMethodList(List<MethodListBean> methodList) {
                this.methodList = methodList;
            }

            public static class MethodListBean {


                /**
                 * description :
                 * name :
                 * argList : [{"description":"","name":"","type":"","must":""}]
                 * result : MethodArgument
                 * deprecated :
                 * replaceMethed :
                 * demo : demoStr
                 */

                private String description;
                private String name;
                private String returnType;
                private String returnDescription;
                private boolean deprecated;
                private String replaceMethed;
                private String demo;
                private List<ArgListBean> argList;

                public String getDescription() {
                    return description;
                }

                public void setDescription(String description) {
                    this.description = description;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getReturnType() {
                    return returnType;
                }

                public void setReturnType(String returnType) {
                    this.returnType = returnType;
                }

                public String getReturnDescription() {
                    return returnDescription;
                }

                public void setReturnDescription(String returnDescription) {
                    this.returnDescription = returnDescription;
                }

                public boolean getDeprecated() {
                    return deprecated;
                }

                public void setDeprecated(boolean deprecated) {
                    this.deprecated = deprecated;
                }

                public String getReplaceMethed() {
                    return replaceMethed;
                }

                public void setReplaceMethed(String replaceMethed) {
                    this.replaceMethed = replaceMethed;
                }

                public String getDemo() {
                    return demo;
                }

                public void setDemo(String demo) {
                    this.demo = demo;
                }

                public List<ArgListBean> getArgList() {
                    return argList;
                }

                public void setArgList(List<ArgListBean> argList) {
                    this.argList = argList;
                }

                public static class ArgListBean {
                    /**
                     * description :
                     * name :
                     * type :
                     * must :
                     */

                    private String description;
                    private String name;
                    private String type;
                    private String must;

                    public String getDescription() {
                        return description;
                    }

                    public void setDescription(String description) {
                        this.description = description;
                    }

                    public String getName() {
                        return name;
                    }

                    public void setName(String name) {
                        this.name = name;
                    }

                    public String getType() {
                        return type;
                    }

                    public void setType(String type) {
                        this.type = type;
                    }

                    public String getMust() {
                        return must;
                    }

                    public void setMust(String must) {
                        this.must = must;
                    }

                    @Override
                    public String toString() {
                        return "{"+
                                "\"description\":\"" + description + "\"" +
                                ",\"name\":\"" + name + "\"" +
                                ",\"type\":\"" + type + "\"" +
                                ",\"must\":\"" + must + "\"" +
                                '}';
                    }
                }

                @Override
                public String toString() {
                    String tempDemo;
                    if(demo==null){
                        tempDemo=null;
                    }else {
                        tempDemo ="\""+demo+"\"";
                    }
                    String tempReplaceMethed;
                    if(replaceMethed==null){
                        tempReplaceMethed=null;
                    }else {
                        tempReplaceMethed ="\""+replaceMethed+"\"";
                    }

                    String tempReturnDescription;
                    if(returnDescription==null){
                        tempReturnDescription=null;
                    }else {
                        tempReturnDescription ="\""+returnDescription+"\"";
                    }

                    String tempDescription;
                    if(description==null){
                        tempDescription=null;
                    }else {
                        tempDescription ="\""+description+"\"";
                    }

                    String tempName;
                    if(name==null){
                        tempName=null;
                    }else {
                        tempName ="\""+name+"\"";
                    }

                    String tempReturnType;
                    if(returnType==null){
                        tempReturnType=null;
                    }else {
                        tempReturnType ="\""+returnType+"\"";
                    }


                    return "{" +
                            "\"description\":"  + tempDescription + ','+
                            "\"name\":"  + tempName + ','+
                            "\"returnType\":"  + tempReturnType + ','+
                            "\"returnDescription\":"  + tempReturnDescription + ','+
                            "\"deprecated\":"  + deprecated + ','+
                            "\"replaceMethed\":"  + tempReplaceMethed + ','+
                            "\"demo\":"  + tempDemo + ','+
                            "\"argList\":"  + argList +
                            '}';
                }
            }

            @Override
            public String toString() {
                String tempDescription;
                if(description==null){
                    tempDescription=null;
                }else {
                    tempDescription ="\""+description+"\"";
                }


                String tempName;
                if(name==null){
                    tempName=null;
                }else {
                    tempName ="\""+name+"\"";
                }

                return "{" +
                        "\"description\":"  + tempDescription + ','+
                        "\"name\":"  + tempName + ','+
                        "\"methodList\":"  + methodList +
                        '}';
            }
        }

        @Override
        public String toString() {
            String tempDescription;
            if(description==null){
                tempDescription=null;
            }else {
                tempDescription ="\""+description+"\"";
            }


            String tempName;
            if(name==null){
                tempName=null;
            }else {
                tempName ="\""+name+"\"";
            }



            return  "{" +
                    "\"version\":"  + '\"'+ version + '\"' + ','+
                    "\"description\":"  + tempDescription+ ','+
                    "\"name\":"  + tempName + ','+
                    "\"serviceList\":"  + serviceList +
                    '}';
        }
    }

    @Override
    public String toString() {
        String tempDescription;
        if(description==null){
            tempDescription=null;
        }else {
            tempDescription ="\""+description+"\"";
        }

        return  "{" +
                "\"version\":"  + '\"'+ version + '\"' + ','+
                "\"description\":"  + tempDescription + ','+
                "\"platform\":"  + '\"'+ "Android" + '\"' + ','+
                "\"moduleList\":"  + moduleList +
                '}';
    }
}
