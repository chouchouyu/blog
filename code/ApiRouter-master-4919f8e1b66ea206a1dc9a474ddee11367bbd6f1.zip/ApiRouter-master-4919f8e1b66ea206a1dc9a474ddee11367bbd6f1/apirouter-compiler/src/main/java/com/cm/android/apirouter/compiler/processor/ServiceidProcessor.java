package com.cm.android.apirouter.compiler.processor;

import com.cm.android.apirouter.compiler.utils.Consts;
import com.cm.android.apirouter.compiler.utils.Logger;
import com.cm.android.apirouter.compiler.utils.TextUtils;
import com.cm.android.apirouter.compiler.utils.TypeUtils;
import com.cm.android.apirouter.facade.annotation.Serviceid;
import com.google.auto.service.AutoService;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.ParameterSpec;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Filer;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.Processor;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedOptions;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.TypeKind;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.util.Elements;
import javax.lang.model.util.Types;

import static com.cm.android.apirouter.compiler.utils.Consts.ANNOTATION_TYPE_SERVICEID;
import static com.cm.android.apirouter.compiler.utils.Consts.CALLMETHOD;
import static com.cm.android.apirouter.compiler.utils.Consts.CONTEXT;
import static com.cm.android.apirouter.compiler.utils.Consts.IMETHOD;
import static com.cm.android.apirouter.compiler.utils.Consts.KEY_MODULE_NAME;
import static com.cm.android.apirouter.compiler.utils.Consts.METHOD_CALLMETHOD;
import static com.cm.android.apirouter.compiler.utils.Consts.NAME_OF_SERVICEID;
import static com.cm.android.apirouter.compiler.utils.Consts.NAVIGATIONCALLBACK;
import static com.cm.android.apirouter.compiler.utils.Consts.POSTCARD;
import static com.cm.android.apirouter.compiler.utils.Consts.WARNING_TIPS;
import static javax.lang.model.element.Modifier.PUBLIC;

/**
 * Processor method annotation by serviceId helper
 *
 * @author wusm <a href="mailto:wusm@cmrh.com">Contact me.</a>
 * @version 1.0
 * @since 2017/2/20 下午5:56
 */
@AutoService(Processor.class)
@SupportedOptions(KEY_MODULE_NAME)
@SupportedSourceVersion(SourceVersion.RELEASE_7)
@SupportedAnnotationTypes({ANNOTATION_TYPE_SERVICEID})
public class ServiceidProcessor extends AbstractProcessor {
    private Filer mFiler;       // File util, write class file into disk.
    private Logger logger;
    private Types types;
    private TypeUtils typeUtils;
    private Elements elements;
    private Map<TypeElement, List<ExecutableElement>> parentAndChild = new HashMap<>();   // Contain field need autowired and his super class.
    private TypeMirror iProvider = null;

    @Override
    public synchronized void init(ProcessingEnvironment processingEnvironment) {
        super.init(processingEnvironment);
        mFiler = processingEnv.getFiler();                  // Generate class.
        types = processingEnv.getTypeUtils();            // Get type utils.
        elements = processingEnv.getElementUtils();      // Get class meta.

        typeUtils = new TypeUtils(types, elements);

        logger = new Logger(processingEnv.getMessager());   // Package the log utils.

        iProvider = elements.getTypeElement(Consts.IPROVIDER).asType();
        logger.info(">>> Serviceid Processor init. <<<");
    }

    @Override
    public boolean process(Set<? extends TypeElement> set, RoundEnvironment roundEnvironment) {

        if (CollectionUtils.isNotEmpty(set)) {
            try {
                logger.info(">>> Found method annotation by Serviceid , start... <<<");
                categories(roundEnvironment.getElementsAnnotatedWith(Serviceid.class));
                generateHelper();

            } catch (Exception e) {
                logger.error(e);
            }
            return true;
        }

        return false;
    }


    /**
     * Categories method, find his papa.
     *
     * @param elements Field need Serviceid
     */
    private void categories(Set<? extends Element> elements) throws IllegalAccessException {
        if (CollectionUtils.isNotEmpty(elements)) {
            for (Element element : elements) {
                TypeElement enclosingElement = (TypeElement) element.getEnclosingElement();

                //method
                ExecutableElement method = (ExecutableElement) element;


                if (method.getModifiers().contains(Modifier.PRIVATE)) {
                    throw new IllegalAccessException("The method annotation by serviceid CAN NOT BE 'private'!!! please check method ["
                            + element.getSimpleName() + "] in class [" + enclosingElement + "]");
                }

                if (parentAndChild.containsKey(enclosingElement)) {
                    parentAndChild.get(enclosingElement).add(method);
                } else {
                    List<ExecutableElement> childs = new ArrayList<>();
                    childs.add(method);
                    parentAndChild.put(enclosingElement, childs);
                }
            }

            logger.info("serviceid categories Map ready !");
        }
    }


    private void generateHelper() throws IOException, IllegalAccessException {
        TypeElement type_ICallMethod = elements.getTypeElement(CALLMETHOD);
        TypeElement type_IMethod = elements.getTypeElement(IMETHOD);

        // Build input param name.
        ParameterSpec objectParamSpec = ParameterSpec.builder(TypeName.OBJECT, "target").build();

        if (MapUtils.isNotEmpty(parentAndChild)) {
            for (Map.Entry<TypeElement, List<ExecutableElement>> entry : parentAndChild.entrySet()) {
                TypeElement parent = entry.getKey();
                TypeMirror tm = parent.asType();
                TypeElement type_CONTEXT = elements.getTypeElement(CONTEXT);
                TypeElement type_POSTCARD = elements.getTypeElement(POSTCARD);
                TypeElement type_NAVIGATIONCALLBACK = elements.getTypeElement(NAVIGATIONCALLBACK);

                // Build method : 'inject'
                MethodSpec.Builder injectMethodBuilder = MethodSpec.methodBuilder(METHOD_CALLMETHOD)
                        .addAnnotation(Override.class)
                        .addModifiers(PUBLIC)
                        .returns(void.class);
                if (types.isSubtype(tm, iProvider)) {
                    injectMethodBuilder.addParameter(ClassName.get(type_CONTEXT), "activityContext");
                }
                injectMethodBuilder.addParameter(objectParamSpec)
                        .addParameter(String.class, "serviceidPath")
                        .addParameter(String.class, "paramJson")
                        .addParameter(ClassName.get(type_POSTCARD), "postcard")
                        .addParameter(ClassName.get(type_NAVIGATIONCALLBACK), "callback")
                        .addStatement("$T substitute = ($T)target", ClassName.get(parent), ClassName.get(parent));


                //target.init();
                if (types.isSubtype(tm, iProvider)) {
                    injectMethodBuilder.addStatement("substitute.init(activityContext);");
                }


                List<ExecutableElement> childs = entry.getValue();

                String qualifiedName = parent.getQualifiedName().toString();
                String packageName = qualifiedName.substring(0, qualifiedName.lastIndexOf("."));
                String fileName = parent.getSimpleName() + NAME_OF_SERVICEID;

                logger.info(">>>serviceid Start process " + childs.size() + " field in " + parent.getSimpleName() + " ... <<<");

                TypeSpec.Builder helper = TypeSpec.classBuilder(fileName)
                        .addJavadoc(WARNING_TIPS).addModifiers(PUBLIC);
                if (types.isSubtype(tm, iProvider)) {
                    helper.addSuperinterface(ClassName.get(type_IMethod));
                } else {
                    helper.addSuperinterface(ClassName.get(type_ICallMethod));
                }


                CheckAnnotationLegalSpell(parent, childs);

                for (int i = 0; i < childs.size(); i++) {
                    ExecutableElement element = childs.get(i);
                    Serviceid serviceIdAnno = element.getAnnotation(Serviceid.class);

                    String methodAnnoPath = serviceIdAnno.path().toLowerCase();

                    String MethodName = element.getSimpleName().toString();
                    //returnType
                    TypeMirror returnTypeMirror = element.getReturnType();
                    //params
                    List<? extends VariableElement> variableElementsList = element.getParameters();

                    if (i == 0) {
                        if (returnTypeMirror.getKind().equals(TypeKind.VOID)) {
                            injectMethodBuilder.beginControlFlow("if($S .equals(serviceidPath))", methodAnnoPath);
                            if (isCallMethodHasParam(variableElementsList)) {
                                injectMethodBuilder.addCode("substitute." + MethodName + "(paramJson);\n");
                            } else {
                                injectMethodBuilder.addCode("substitute." + MethodName + "();\n");
                            }

                            injectMethodBuilder.addCode("callback.onArrival(postcard,null);\n");
                            injectMethodBuilder.endControlFlow();
                        } else {
                            injectMethodBuilder.beginControlFlow("if($S .equals(serviceidPath))", methodAnnoPath);
                            if (isCallMethodHasParam(variableElementsList)) {
                                injectMethodBuilder.addCode("callback.onArrival(postcard,substitute." + MethodName + "(paramJson));\n");
                            } else {
                                injectMethodBuilder.addCode("callback.onArrival(postcard,substitute." + MethodName + "());\n");
                            }
                            injectMethodBuilder.endControlFlow();
                        }

                    } else {
                        if (returnTypeMirror.getKind().equals(TypeKind.VOID)) {
                            injectMethodBuilder.beginControlFlow("else if($S .equals(serviceidPath))", methodAnnoPath);
                            if (isCallMethodHasParam(variableElementsList)) {
                                injectMethodBuilder.addCode("substitute." + MethodName + "(paramJson);\n");
                            } else {
                                injectMethodBuilder.addCode("substitute." + MethodName + "();\n");
                            }

                            injectMethodBuilder.addCode("callback.onArrival(postcard,null);\n");
                            injectMethodBuilder.endControlFlow();
                        } else {
                            injectMethodBuilder.beginControlFlow("else if($S .equals(serviceidPath))", methodAnnoPath);
                            if (isCallMethodHasParam(variableElementsList)) {
                                injectMethodBuilder.addCode("callback.onArrival(postcard,substitute." + MethodName + "(paramJson));\n");
                            } else {
                                injectMethodBuilder.addCode("callback.onArrival(postcard,substitute." + MethodName + "());\n");
                            }
                            injectMethodBuilder.endControlFlow();
                        }
                    }
                }

                injectMethodBuilder.beginControlFlow("else");
                injectMethodBuilder.addStatement("callback.onLost(postcard)");
                injectMethodBuilder.endControlFlow();

                helper.addMethod(injectMethodBuilder.build());
                // Generate serviceid helper
                JavaFile.builder(packageName, helper.build()).build().writeTo(mFiler);
                logger.info(">>> " + parent.getSimpleName() + " has been processed, " + fileName + " has been generated. <<<");
            }

            logger.info(">>>  serviceid processor stop. <<<");
        }
    }

    private boolean isCallMethodHasParam(List<? extends VariableElement> variableElementsList) {
        return variableElementsList.size() != 0 ? true : false;
    }

    private void CheckAnnotationLegalSpell(TypeElement parent, List<ExecutableElement> childs) throws IllegalAccessException {
        String subtemp = "";
        String temp = "";
        for (int i = 0; i < childs.size() - 1; i++) {
            ExecutableElement element = childs.get(i);
            temp = element.getAnnotation(Serviceid.class).path().toLowerCase();

            if (TextUtils.isEmpty(temp)) {
                throw new IllegalAccessException("Athene::Compiler >>> " + parent.getSimpleName() + ".java has a method annotation by @ServiceId(path = \"\" is undefined  ");
            }

            for (int j = i + 1; j < childs.size(); j++) {
                ExecutableElement subelement = childs.get(j);
                subtemp = subelement.getAnnotation(Serviceid.class).path().toLowerCase();
                if (temp.equals(subtemp)) {
                    throw new IllegalAccessException("Athene::Compiler >>> " + parent.getSimpleName() + ".java  method Annotation - @ServiceId(path = \"" + subtemp + "\")" + "  has duplicate definition  ");
                }
            }
        }
    }


}
