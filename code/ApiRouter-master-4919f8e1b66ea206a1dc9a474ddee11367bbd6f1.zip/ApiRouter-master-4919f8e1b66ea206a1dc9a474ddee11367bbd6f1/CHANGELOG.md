# ChangeLog #
###
去除showAcitvity的逻辑

对应的Annotation 0.1.1
compile 'com.cmrh:apirouter-api:0.2.1-SNAPSHOT’
annotationProcessor 'com.cmrh:apirouter-compiler:0.1.7-SNAPSHOT'

####
修改适应 Activity子父继承在调用时的判断逻辑不是简单的比较simpName
```
对应的Annotation 0.1.0
compile 'com.cmrh:apirouter-api:0.2.0-SNAPSHOT’
annotationProcessor 'com.cmrh:apirouter-compiler:0.1.6-SNAPSHOT'


### Version 1.3  ###
**IMP**
1. callmethod 在Activity内调用时，添加当前Activity和Destination判断，防止暴点

```
对应的Annotation 0.0.9
compile 'com.cmrh:apirouter-api:0.1.9-SNAPSHOT’
annotationProcessor 'com.cmrh:apirouter-compiler:0.1.5-SNAPSHOT'


### Version 1.2  ###
**IMP**
1. callmethod抛Exception走onLost方法 
2. 监听的Ativity生命周期 resume改create
```
对应的Annotation 0.0.8
compile 'com.cmrh:apirouter-api:0.1.8-SNAPSHOT’
annotationProcessor 'com.cmrh:apirouter-compiler:0.1.4-SNAPSHOT'
```

### Version 1.1  ###

**NEW**
1. 更改名称：`Athena`改成 `ApiRouter`
2. 引用方式  `gradle 3.0`

```
对应的Annotation 0.0.4
compile 'com.cmrh:apirouter-api:0.0.8-SNAPSHOT’
annotationProcessor 'com.cmrh:apirouter-compiler:0.0.6-SNAPSHOT'
```
3.请求方式更改成 `build(String moduleName, String serviceName, String methodName, String params)`
```
   compile 'com.cmrh:apirouter-parser:0.0.1-SNAPSHOT'
```


#TODO
1.方法调用有问题

### Version 1.0  ###

**NEW**
1. 在ApiRouter的基础上添加方法调用
2. 引用方式 `gradle 2.0`

```
对应的Annotation 0.0.4
compile 'com.cmrh:apirouter-api:0.0.7-SNAPSHOT'
annotationProcessor 'com.cmrh:apirouter-compiler:0.0.9-SNAPSHOT'
```




