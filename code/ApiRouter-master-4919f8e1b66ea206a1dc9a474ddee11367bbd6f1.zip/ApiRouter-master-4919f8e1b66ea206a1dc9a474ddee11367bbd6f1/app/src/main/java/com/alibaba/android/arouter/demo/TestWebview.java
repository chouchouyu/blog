package com.alibaba.android.arouter.demo;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

import com.cm.android.apirouter.facade.annotation.Route;

/**
 * "/test/webview"
 * https://m.aliyun.com/test/activity1?name=老王&age=23&boy=true&high=180
 */
@Route(path = "/test/webview")
public class TestWebview extends Activity {

    WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_webview);


        webview = (WebView) findViewById(R.id.webview);
        webview.loadUrl(getIntent().getStringExtra("url"));
    }
}
