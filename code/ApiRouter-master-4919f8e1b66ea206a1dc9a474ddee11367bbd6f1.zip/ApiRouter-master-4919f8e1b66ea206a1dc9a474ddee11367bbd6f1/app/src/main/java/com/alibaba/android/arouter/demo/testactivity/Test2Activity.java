package com.alibaba.android.arouter.demo.testactivity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.alibaba.android.arouter.demo.R;
import com.cm.android.apirouter.facade.Postcard;
import com.cm.android.apirouter.facade.annotation.Autowired;
import com.cm.android.apirouter.facade.annotation.Route;
import com.cm.android.apirouter.facade.annotation.Serviceid;
import com.cm.android.apirouter.facade.callback.NavCallback;
import com.cm.android.apirouter.launcher.ApiRouter;

/**
 * "/test/activity2"
 * https://m.aliyun.com/test/activity1?name=老王&age=23&boy=true&high=180
 */
@Route(path = "/test/activity2")
public class Test2Activity extends AppCompatActivity {

    @Autowired
    String key1;

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test2);

        button = (Button) findViewById(R.id.btn);
        String value = getIntent().getStringExtra("key1");
        if (!TextUtils.isEmpty(value)) {
            Toast.makeText(this, "exist param :" + value, Toast.LENGTH_LONG).show();
        }

        setResult(999);
    }

    boolean flag;

    public void click1(View view) {
        ApiRouter.getInstance().build("test", "activity2", "getStr", "")
                .navigation(this, new NavCallback() {
                    @Override
                    public void onFound(Postcard postcard) {
                        Log.d("ApiRouter-getStr", "onFound");
                    }

                    @Override
                    public void onLost(Postcard postcard) {
                        Log.d("ApiRouter-getStr", "onLost");
                    }

                    @Override
                    public void onArrival(Postcard postcard, Object returnObj) {
                        flag = (boolean) returnObj;
                        Log.d("ApiRouter-getStr", "onArrival" + (Boolean) returnObj);
                    }

                    @Override
                    public void onInterrupt(Postcard postcard) {
                        Log.d("ApiRouter-getStr", "onInterrupt");
                    }
                });


//        flag = getStr();
    }

    public void click2(View view) {
//        changeColor();

        ApiRouter.getInstance().build("test", "activity2", "changeColor", "")
                .navigation(this, new NavCallback() {
                    @Override
                    public void onFound(Postcard postcard) {
                        Log.d("ApiRouter-changeColor", "onFound");
                    }

                    @Override
                    public void onLost(Postcard postcard) {
                        Log.d("ApiRouter-changeColor", "onLost");
                    }

                    @Override
                    public void onArrival(Postcard postcard, Object returnObj) {
                        Log.d("ApiRouter-changeColor", "onArrival" + (Boolean) returnObj);
                    }

                    @Override
                    public void onInterrupt(Postcard postcard) {
                        Log.d("ApiRouter-changeColor", "onInterrupt");
                    }
                });
    }

    /**
     * 方法的解释
     * {@link HelloService}
     *
     * @param name=SSSSXX,type=ArrayList,description=参数的解释,must=Y
     * @return 返回值的解释
     */
    @Deprecated
    @Serviceid(path = "changeColor")
    public void changeColor() {
        Toast.makeText(this,"changeColor: "+flag,Toast.LENGTH_SHORT).show();
        if (flag) {
            button.setBackgroundColor(this.getResources().getColor(R.color.red));
        }
    }

    /**
     * 方法的解释
     * {@link HelloService}
     *
     * @param name=SSSSXX,type=ArrayList,description=参数的解释,must=Y
     * @return 返回值的解释
     */
    @Deprecated
    @Serviceid(path = "getStr")
    public boolean getStr() {
        return true;
    }
}
