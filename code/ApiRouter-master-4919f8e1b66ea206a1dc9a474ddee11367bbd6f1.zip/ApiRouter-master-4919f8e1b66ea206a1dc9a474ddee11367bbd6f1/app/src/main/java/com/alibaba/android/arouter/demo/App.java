package com.alibaba.android.arouter.demo;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;

import com.cm.android.apirouter.launcher.ApiRouter;

/**
 * Created by wusm on 2017/9/22.
 */

public class App extends Application {
    private static Context context;
    public static Context getContext() {
        return context;
    }
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(base);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        initApiRouter();
        context = getApplicationContext();
    }

    private void initApiRouter() {
//        if (BuildConfig.DEBUG) {
            ApiRouter.openLog();     // 打印日志
            ApiRouter.openDebug();   // 开启调试模式(如果在InstantRun模式下运行，必须开启调试模式！线上版本需要关闭,否则有安全风险)
//        }
        ApiRouter.init(this);
    }
}
