package com.alibaba.android.arouter.demo;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;

import com.cm.android.apirouter.facade.Postcard;
import com.cm.android.apirouter.facade.callback.NavCallback;
import com.cm.android.apirouter.launcher.ApiRouter;


public class SchemeFilterActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        直接通过ApiRouter处理外部Uri
        Uri uri = getIntent().getData();
        ApiRouter.getInstance().build(uri).navigation(this, new NavCallback() {

            @Override
            public void onArrival(Postcard postcard, Object returnObj) {

            }
        });
    }
}
