import org.junit.Test;

import static org.junit.Assert.*;

public class TestCaseTest {

    @Test
    public void test1() {
        String s = "com.cm.android.apirouter.routes.ApiRouter$$Root$$app";
        String compare= "com.cm.android.apirouter.routes.ApiRouter$$Root";
        assertTrue (s.startsWith(compare));
    }
}