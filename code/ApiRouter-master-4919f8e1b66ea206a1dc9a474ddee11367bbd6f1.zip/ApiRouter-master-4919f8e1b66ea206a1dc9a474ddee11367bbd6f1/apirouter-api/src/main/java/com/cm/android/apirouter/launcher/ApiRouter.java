package com.cm.android.apirouter.launcher;

import android.app.Application;
import android.content.Context;
import android.net.Uri;

import com.cm.android.apirouter.exception.InitException;
import com.cm.android.apirouter.facade.Postcard;
import com.cm.android.apirouter.facade.callback.NavigationCallback;
import com.cm.android.apirouter.facade.template.ILogger;
import com.cm.android.apirouter.utils.Consts;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * ApiRouter facade
 *
 * @author Alex <a href="mailto:zhilong.liu@aliyun.com">Contact me.</a>
 * @version 1.0
 * @since 16/8/16 14:36
 */
public final class ApiRouter {
    // Key of raw uri
    public static final String RAW_URI = "NTeRQWvye18AkPd6G";
    public static final String AUTO_INJECT = "wmHzgD4lOj5o4241";

    private volatile static ApiRouter instance = null;
    private volatile static boolean hasInit = false;
    public static ILogger logger;

    private ApiRouter() {
    }

    /**
     * Init, it must be call before used router.
     */
    public static void init(Application application) {
        if (!hasInit) {
            logger = _ApiRouter.logger;
            _ApiRouter.logger.info(Consts.TAG, "ApiRouter init start.");
            hasInit = _ApiRouter.init(application);

            if (hasInit) {
                _ApiRouter.afterInit();
            }

            _ApiRouter.logger.info(Consts.TAG, "ApiRouter init over.");
        }
    }

    /**
     * Get instance of router. A
     * All feature U use, will be starts here.
     */
    public static ApiRouter getInstance() {
        if (!hasInit) {
            throw new InitException("ApiRouter::Init::Invoke init(context) first!");
        } else {
            if (instance == null) {
                synchronized (ApiRouter.class) {
                    if (instance == null) {
                        instance = new ApiRouter();
                    }
                }
            }
            return instance;
        }
    }

    public static synchronized void openDebug() {
        _ApiRouter.openDebug();
    }

    public static boolean debuggable() {
        return _ApiRouter.debuggable();
    }

    public static synchronized void openLog() {
        _ApiRouter.openLog();
    }

    public static synchronized void printStackTrace() {
        _ApiRouter.printStackTrace();
    }

    public static synchronized void setExecutor(ThreadPoolExecutor tpe) {
        _ApiRouter.setExecutor(tpe);
    }

    public synchronized void destroy() {
        _ApiRouter.destroy();
        hasInit = false;
    }

    /**
     * The interface is not stable enough, use 'ApiRouter.inject();';
     */
    @Deprecated
    public static synchronized void enableAutoInject() {
        _ApiRouter.enableAutoInject();
    }

    public static boolean canAutoInject() {
        return _ApiRouter.canAutoInject();
    }

    /**
     * The interface is not stable enough, use 'ApiRouter.inject();';
     */
    @Deprecated
    public static void attachBaseContext() {
        _ApiRouter.attachBaseContext();
    }

    public static synchronized void monitorMode() {
        _ApiRouter.monitorMode();
    }

    public static boolean isMonitorMode() {
        return _ApiRouter.isMonitorMode();
    }

    public static void setLogger(ILogger userLogger) {
        _ApiRouter.setLogger(userLogger);
    }

    /**
     * Inject params and services.
     */
    public void inject(Object thiz) {
        _ApiRouter.inject(thiz);
    }

    /**
     * Build the roadmap, draw a postcard.
     *
     * @param path Where you go.
     */
    public Postcard build(String path) {
        return _ApiRouter.getInstance().build(path);
    }


    /**
     * Build the
     *
     * @param moduleName
     * @param serviceName
     * @param methodName
     * @param params
     * @return
     */
    public Postcard build(String moduleName, String serviceName, String methodName, String params) {
        return _ApiRouter.getInstance().build(moduleName, serviceName, methodName, params);
    }

    /**
     * Build the roadmap, draw a postcard.
     *
     * @param path  Where you go.
     * @param group The group of path.
     */
    @Deprecated
    public Postcard build(String path, String group) {
        return _ApiRouter.getInstance().build(path, group);
    }

    /**
     * Build the roadmap, draw a postcard.
     *
     * @param url the path
     */
    public Postcard build(Uri url) {
        return _ApiRouter.getInstance().build(url);
    }

    /**
     * Launch the navigation by type
     *
     * @param service interface of service
     * @param <T>     return type
     * @return instance of service
     */
    public <T> T navigation(Class<? extends T> service) {
        return _ApiRouter.getInstance().navigation(service);
    }

    /**
     * Launch the navigation.
     *
     * @param mContext    .
     * @param postcard    .
     * @param requestCode Set for startActivityForResult
     * @param callback    cb
     */
    public Object navigation(Context mContext, Postcard postcard, int requestCode, NavigationCallback callback) {
        return _ApiRouter.getInstance().navigation(mContext, postcard, requestCode, callback);
    }
}
