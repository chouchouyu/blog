package com.cm.android.apirouter.facade.template;


import android.content.Context;

import com.cm.android.apirouter.facade.Postcard;
import com.cm.android.apirouter.facade.callback.NavigationCallback;

/**
 * Created by wusm on 2017/9/6.
 */

public interface IMethod {
    void methodCall(Context activityContext, Object target, String serviceidPath, String paramJson, Postcard postcard, NavigationCallback callback);
}
