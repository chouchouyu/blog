package com.cm.android.apirouter.utils;

/**
 * Created by admin on 2018/6/11.
 */

public class Util {
    public static <T> T throwIfNull(T item) {
        if (item == null) {
            throw new NullPointerException();
        }
        return item;
    }

    public static void throwIfNot(boolean condition) {
        if (!condition) {
            throw new IllegalStateException();
        }
    }
}
