package com.cm.android.apirouter.launcher;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.Toast;

import com.cm.android.apirouter.core.ActivityTracker;
import com.cm.android.apirouter.core.InstrumentationHook;
import com.cm.android.apirouter.core.LogisticsCenter;
import com.cm.android.apirouter.exception.HandlerException;
import com.cm.android.apirouter.exception.InitException;
import com.cm.android.apirouter.exception.NoRouteFoundException;
import com.cm.android.apirouter.facade.Postcard;
import com.cm.android.apirouter.facade.callback.InterceptorCallback;
import com.cm.android.apirouter.facade.callback.NavigationCallback;
import com.cm.android.apirouter.facade.enums.RouteType;
import com.cm.android.apirouter.facade.service.AutowiredService;
import com.cm.android.apirouter.facade.service.DegradeService;
import com.cm.android.apirouter.facade.service.InterceptorService;
import com.cm.android.apirouter.facade.service.PathReplaceService;
import com.cm.android.apirouter.facade.template.ICallMethod;
import com.cm.android.apirouter.facade.template.ILogger;
import com.cm.android.apirouter.facade.template.IMethod;
import com.cm.android.apirouter.facade.template.IProvider;
import com.cm.android.apirouter.thread.DefaultPoolExecutor;
import com.cm.android.apirouter.utils.Consts;
import com.cm.android.apirouter.utils.DefaultLogger;
import com.cm.android.apirouter.utils.TextUtils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Vector;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * ApiRouter core (Facade patten)
 *
 * @author Alex <a href="mailto:zhilong.liu@aliyun.com">Contact me.</a>
 * @version 1.0
 * @since 16/8/16 14:39
 */
final class _ApiRouter {
    static ILogger logger = new DefaultLogger(Consts.TAG); // 日志工具
    private volatile static boolean monitorMode = false;
    private volatile static boolean debuggable = false;
    private volatile static boolean autoInject = false;
    private volatile static _ApiRouter instance = null;
    private volatile static boolean hasInit = false;
    private volatile static ThreadPoolExecutor executor = DefaultPoolExecutor.getInstance();
    private static Context mContext;

    private static InterceptorService interceptorService;

    private _ApiRouter() {
    }

    protected static synchronized boolean init(Application application) {
        mContext = application;

        // Hook activity tracking so that after ApiRouter is attached we can figure out what
        // activities are present.
        boolean isTrackingActivities = ActivityTracker.get().beginTrackingIfPossible(
                (Application) mContext.getApplicationContext());
        if (!isTrackingActivities) {
            logger.warning(Consts.TAG, "Automatic activity tracking not available on this API " +
                    "level, caller must invoke " +
                    "ActivityTracker methods manually!");
        }

        LogisticsCenter.init(mContext, executor);
        logger.info(Consts.TAG, "ApiRouter init success!");

        hasInit = true;

        // It's not a good idea.
        // if (Build.VERSION.SDK_INT > Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
        //     application.registerActivityLifecycleCallbacks(new AutowiredLifecycleCallback());
        // }
        return true;
    }

    /**
     * Destroy ApiRouter, it can be used only in debug mode.
     */
    static synchronized void destroy() {
        if (debuggable()) {
            hasInit = false;
            LogisticsCenter.suspend();
            logger.info(Consts.TAG, "ApiRouter destroy success!");
        } else {
            logger.error(Consts.TAG, "Destroy can be used in debug mode only!");
        }
    }

    protected static _ApiRouter getInstance() {
        if (!hasInit) {
            throw new InitException("ApiRouterCore::Init::Invoke init(context) first!");
        } else {
            if (instance == null) {
                synchronized (_ApiRouter.class) {
                    if (instance == null) {
                        instance = new _ApiRouter();
                    }
                }
            }
            return instance;
        }
    }

    static synchronized void openDebug() {
        debuggable = true;
        logger.info(Consts.TAG, "ApiRouter openDebug");
    }

    static synchronized void openLog() {
        logger.showLog(true);
        logger.info(Consts.TAG, "ApiRouter openLog");
    }

    @Deprecated
    static synchronized void enableAutoInject() {
        autoInject = true;
    }

    @Deprecated
    static boolean canAutoInject() {
        return autoInject;
    }

    @Deprecated
    static void attachBaseContext() {
        Log.i(Consts.TAG, "ApiRouter start attachBaseContext");
        try {
            Class<?> mMainThreadClass = Class.forName("android.app.ActivityThread");

            // Get current main thread.
            Method getMainThread = mMainThreadClass.getDeclaredMethod("currentActivityThread");
            getMainThread.setAccessible(true);
            Object currentActivityThread = getMainThread.invoke(null);

            // The field contain instrumentation.
            Field mInstrumentationField = mMainThreadClass.getDeclaredField("mInstrumentation");
            mInstrumentationField.setAccessible(true);

            // Hook current instrumentation
            mInstrumentationField.set(currentActivityThread, new InstrumentationHook());
            Log.i(Consts.TAG, "ApiRouter hook instrumentation success!");
        } catch (Exception ex) {
            Log.e(Consts.TAG, "ApiRouter hook instrumentation failed! [" + ex.getMessage() + "]");
        }
    }

    static synchronized void printStackTrace() {
        logger.showStackTrace(true);
        logger.info(Consts.TAG, "ApiRouter printStackTrace");
    }

    static synchronized void setExecutor(ThreadPoolExecutor tpe) {
        executor = tpe;
    }

    static synchronized void monitorMode() {
        monitorMode = true;
        logger.info(Consts.TAG, "ApiRouter monitorMode on");
    }

    static boolean isMonitorMode() {
        return monitorMode;
    }

    static boolean debuggable() {
        return debuggable;
    }

    static void setLogger(ILogger userLogger) {
        if (null != userLogger) {
            logger = userLogger;
        }
    }

    static void inject(Object thiz) {
        AutowiredService autowiredService = ((AutowiredService) ApiRouter.getInstance().build
                ("/apiRouter/service/autowired").navigation());
        if (null != autowiredService) {
            autowiredService.autowire(thiz);
        }
    }

    /**
     * Build postcard by path and default group
     */
    protected Postcard build(String path) {
        if (TextUtils.isEmpty(path)) {
            throw new HandlerException(Consts.TAG + "Parameter is invalid!");
        } else {
            PathReplaceService pService = ApiRouter.getInstance().navigation(PathReplaceService
                    .class);
            if (null != pService) {
                path = pService.forString(path);
            }
            return build(path, extractGroup(path));
        }
    }

    /**
     * Build postcard by uri
     */
    protected Postcard build(Uri uri) {
        if (null == uri || TextUtils.isEmpty(uri.toString())) {
            throw new HandlerException(Consts.TAG + "Parameter invalid!");
        } else {
            PathReplaceService pService = ApiRouter.getInstance().navigation(PathReplaceService
                    .class);
            if (null != pService) {
                uri = pService.forUri(uri);
            }
            return new Postcard(uri.getPath(), extractGroup(uri.getPath()), uri, null);
        }
    }


    /**
     * Build postcard by path and group
     */
    protected Postcard build(String path, String group) {
        if (TextUtils.isEmpty(path) || TextUtils.isEmpty(group)) {
            throw new HandlerException(Consts.TAG + "Parameter is invalid!");
        } else {
            PathReplaceService pService = ApiRouter.getInstance().navigation(PathReplaceService
                    .class);
            if (null != pService) {
                path = pService.forString(path);
            }
            return new Postcard(path, group);
        }
    }


    protected Postcard build(String moduleName, String serviceName, String methodName, String
            params) {
        StringBuffer sb = new StringBuffer();

        sb.append("/").append(moduleName)
                .append("/").append(serviceName);
        //TODO TextUtil.抽方法
        String path = sb.toString();

        if (!TextUtils.isEmpty(methodName)) {
            methodName = methodName.toLowerCase();
//            if (methodName.startsWith("show") || methodName.startsWith("showwithresult") &&
//                    !TextUtils.isEmpty(methodName)) {
//                methodName = null;
//            } else {
                sb.append("/").append(methodName);
//            }
        }


        sb.append("?data=").append(params);

//        return new Postcard(path, moduleName, Uri.parse(sb.toString()), null, methodName, params);
        return new Postcard(path, moduleName, null, null, methodName, params);

    }


    /**
     * Extract the default group from path.
     */
    private String extractGroup(String path) {
        if (TextUtils.isEmpty(path) || !path.startsWith("/")) {
            throw new HandlerException(Consts.TAG + "Extract the default group failed, the path " +
                    "must be start with '/' and contain more than 2 '/'!");
        }

        try {
            String defaultGroup = path.substring(1, path.indexOf("/", 1));
            if (TextUtils.isEmpty(defaultGroup)) {
                throw new HandlerException(Consts.TAG + "Extract the default group failed! " +
                        "There's nothing between 2 '/'!");
            } else {
                return defaultGroup;
            }
        } catch (Exception e) {
            logger.warning(Consts.TAG, "Failed to extract default group! " + e.getMessage());
            return null;
        }
    }

    static void afterInit() {
        // Trigger interceptor init, use byName.
        interceptorService = (InterceptorService) ApiRouter.getInstance().build
                ("/apiRouter/service/interceptor").navigation();
    }

    protected <T> T navigation(Class<? extends T> service) {
        try {
            Postcard postcard = LogisticsCenter.buildProvider(service.getName());

            // Compatible 1.0.5 compiler sdk.
            if (null == postcard) { // No service, or this service in old version.
                postcard = LogisticsCenter.buildProvider(service.getSimpleName());
            }

            LogisticsCenter.completion(postcard);
            return (T) postcard.getProvider();
        } catch (NoRouteFoundException ex) {
            logger.warning(Consts.TAG, ex.getMessage());
            return null;
        }
    }

    /**
     * Use router navigation.
     *
     * @param context     Activity or null.
     * @param postcard    Route metas
     * @param requestCode RequestCode
     * @param callback    cb
     */
    protected Object navigation(final Context context, final Postcard postcard, final int
            requestCode, final NavigationCallback callback) {

        try {
            LogisticsCenter.completion(postcard);
        } catch (NoRouteFoundException ex) {
            logger.warning(Consts.TAG, ex.getMessage());

            if (debuggable()) { // Show friendly tips for user.
                Toast.makeText(mContext, "There's no route matched!\n" +
                        " Path = [" + postcard.getPath() + "]\n" +
                        " Group = [" + postcard.getGroup() + "]", Toast.LENGTH_LONG).show();
            }

            if (null != callback) {
                callback.onLost(postcard);
            } else {    // No callback for this invoke, then we use the global degrade service.
                DegradeService degradeService = ApiRouter.getInstance().navigation(DegradeService
                        .class);
                if (null != degradeService) {
                    degradeService.onLost(context, postcard);
                }
            }

            return null;
        }

        //TODO isJSMethod
//        if (null != callback && !TextUtils.isJSMethod(postcard.getUri())) {
//            callback.onFound(postcard);
//        }

        if (null != callback) {
            callback.onFound(postcard);
        }


        if (!postcard.isGreenChannel()) {   // It must be run in async thread, maybe interceptor
            // cost too mush time made ANR.
            interceptorService.doInterceptions(postcard, new InterceptorCallback() {
                /**
                 * Continue process
                 *
                 * @param postcard route meta
                 */
                @Override
                public void onContinue(Postcard postcard) {
                    _navigation(context, postcard, requestCode, callback);
                }

                /**
                 * Interrupt process, pipeline will be destory when this method called.
                 *
                 * @param exception Reson of interrupt.
                 */
                @Override
                public void onInterrupt(Throwable exception) {
                    if (null != callback) {
                        callback.onInterrupt(postcard);
                    }

                    logger.info(Consts.TAG, "Navigation failed, termination by interceptor : " +
                            exception.getMessage());
                }
            });
        } else {
            return _navigation(context, postcard, requestCode, callback);
        }

        return null;
    }

    private Object _navigation(final Context context, final Postcard postcard, final int
            requestCode, final NavigationCallback callback) {
        final Context currentContext = null == context ? mContext : context;
        switch (postcard.getType()) {
            case ACTIVITY:

                // Build intent
                final Intent intent = new Intent(currentContext, postcard.getDestination());
                intent.putExtras(postcard.getExtras());

                // Set flags.
                int flags = postcard.getFlags();
                if (-1 != flags) {
                    intent.setFlags(flags);
                } else if (!(currentContext instanceof Activity)) {    // Non activity, need less
                    // one flag.
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                }

                // Navigation in main looper.
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestCode > 0) {  // Need start for result
                            ActivityCompat.startActivityForResult((Activity) currentContext,
                                    intent, requestCode, postcard.getOptionsBundle());
                        } else {
                            ActivityCompat.startActivity(currentContext, intent, postcard
                                    .getOptionsBundle());
                        }

                        if ((-1 != postcard.getEnterAnim() && -1 != postcard.getExitAnim()) &&
                                currentContext instanceof Activity) {    // Old version.
                            ((Activity) currentContext).overridePendingTransition(postcard
                                    .getEnterAnim(), postcard.getExitAnim());
                        }

                        if (null != callback) { // Navigation over.
                            callback.onArrival(postcard, null);
                        }
                    }
                });

                break;
            case PROVIDER:
                return postcard.getProvider();
            case BOARDCAST:
            case CONTENT_PROVIDER:
            case FRAGMENT:
                Class fragmentMeta = postcard.getDestination();
                try {
                    Object instance = fragmentMeta.getConstructor().newInstance();
                    if (instance instanceof Fragment) {
                        ((Fragment) instance).setArguments(postcard.getExtras());
                    } else if (instance instanceof android.support.v4.app.Fragment) {
                        ((android.support.v4.app.Fragment) instance).setArguments(postcard
                                .getExtras());
                    }

                    return instance;
                } catch (Exception ex) {
                    logger.error(Consts.TAG, "Fetch fragment instance error, " + TextUtils
                            .formatStackTrace(ex.getStackTrace()));
                }
            case METHOD:
//                try {
                final Activity activity = ActivityTracker.get().tryGetTopActivity();
                if (activity == null) {
                    return null;
                }
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (postcard.getFrom().compareTo(RouteType.ACTIVITY) == 0
                                    && postcard.getDestination().getClass().isInstance(activity)
                                //  || postcard.getDestination().getSimpleName().equals(activity
                                // .getClass().getSimpleName())
                                    ) {
                                //防止Ativity跳转不成功
                                ICallMethod iCallMethod = null;
                                iCallMethod = (ICallMethod) Class.forName(postcard
                                        .getGenerateMethodFilePath()).getConstructor()
                                        .newInstance();

                                iCallMethod.methodCall(activity, postcard.getMethodName(),
                                        postcard.getParams(), postcard, callback);
                            } else if (postcard.getFrom().compareTo(RouteType.PROVIDER) == 0) {
                                IMethod iCallMethod = (IMethod) Class.forName(postcard
                                        .getGenerateMethodFilePath()).getConstructor()
                                        .newInstance();
                                IProvider target = (IProvider) postcard.getDestination()
                                        .getConstructor().newInstance();
                                iCallMethod.methodCall(activity, target, postcard.getMethodName()
                                        , postcard.getParams(), postcard, callback);
                            }
                        } catch (InstantiationException e) {
                            e.printStackTrace();
                            callback.onLost(postcard);
                        } catch (IllegalAccessException e) {
                            e.printStackTrace();
                            callback.onLost(postcard);
                        } catch (InvocationTargetException e) {
                            e.printStackTrace();
                            callback.onLost(postcard);
                        } catch (NoSuchMethodException e) {
                            e.printStackTrace();
                            callback.onLost(postcard);
                        } catch (ClassNotFoundException e) {
                            e.printStackTrace();
                            callback.onLost(postcard);
                        }

                    }
                });
//                } catch (Exception e) {
//                    e.printStackTrace();
//                    callback.onLost(postcard);
//                }
                break;
            case SERVICE:
            default:
                return null;
        }

        return null;
    }


//    private boolean isTheSameActivity(Activity currentActivity,Class targetClazz){
//        targetClazz.getClass().isInstance(currentActivity)
//
//
//    }
}
