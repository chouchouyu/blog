package com.cm.android.apirouter.facade.template;


import com.cm.android.apirouter.facade.Postcard;
import com.cm.android.apirouter.facade.callback.NavigationCallback;

/**
 * Created by wusm on 2017/9/6.
 */

public interface ICallMethod {
    void methodCall(Object target, String serviceidPath, String paramJson, Postcard postcard, NavigationCallback callback);
}
