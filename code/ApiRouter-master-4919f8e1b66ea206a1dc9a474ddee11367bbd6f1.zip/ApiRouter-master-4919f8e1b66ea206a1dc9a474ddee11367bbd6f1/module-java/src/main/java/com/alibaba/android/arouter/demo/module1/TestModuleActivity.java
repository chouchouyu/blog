package com.alibaba.android.arouter.demo.module1;

import android.app.Activity;
import android.os.Bundle;

import com.cm.android.apirouter.facade.annotation.Route;


/**
 * "/module/1"
 * https://m.aliyun.com/test/activity1?name=老王&age=23&boy=true&high=180
 */
@Route(path = "/module/1")
public class TestModuleActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_module);
    }
}
