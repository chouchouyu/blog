package com.cm.android.apirouter.parser;

import android.net.Uri;

import java.util.HashMap;
import java.util.Map;

import static com.cm.android.apirouter.parser.Utils.ERROR;

/**
 * Created by admin on 2018/6/21.
 */

public class ApiRouterUri {

    private final static ApiRouterUri mInstance = new ApiRouterUri();

    //序列化器缓存
    public static ApiRouterUri getInstance() {
        return mInstance;
    }


    public UriElement parse(Uri uri) {
        UriElement uriElement = getUriElement(uri);
        ParserChain parserChain = getParser(uriElement);
        return parserChain.Parser();
    }

    Map<Uri, UriElement> mCacheList = new HashMap<>();

    private UriElement getUriElement(Uri uri) {
        UriElement uriElement = mCacheList.get(uri);
        if (null == uriElement) {
            uriElement = new UriElement(uri);
            mCacheList.put(uri, uriElement);
        } else {
            uriElement = mCacheList.get(uri);
        }
        return uriElement;
    }


    private ParserChain getParser(UriElement uriElement) {
        ParserChain parserChain = null;
        if (Utils.isAthena(uriElement)) {
            parserChain = new AthenaParser(uriElement);
        } else {
            throw new RuntimeException(ERROR + "uri.getScheme()无法解析 " + uriElement.getScheme());
        }
        return parserChain;
    }
}
