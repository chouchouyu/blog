package com.cm.android.apirouter.parser;

import android.text.TextUtils;

/**
 * Created by admin on 2018/6/22.
 */

class Utils {

    public static final String TAG = "ApiRouter-Parser :";
    public static final String ERROR = TAG + " ERROR! ";

    public static boolean isAthena(final UriElement element) {
        return (TextUtils.equals(element.getScheme(), "athena")) ? true : false;
    }
}
