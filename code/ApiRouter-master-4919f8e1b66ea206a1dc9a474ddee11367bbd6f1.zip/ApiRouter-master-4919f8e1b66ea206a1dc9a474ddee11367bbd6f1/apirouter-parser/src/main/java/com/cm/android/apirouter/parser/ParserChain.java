package com.cm.android.apirouter.parser;

interface ParserChain {

    UriElement Parser();
}
