package com.cm.android.apirouter.parser;

import static com.cm.android.apirouter.parser.Utils.ERROR;


/**
 * Created by admin on 2018/6/21.
 */

class AthenaParser implements ParserChain {

    private UriElement uriElement;

    public AthenaParser(UriElement uriElement) {
        this.uriElement = uriElement;
    }

    @Override
    public UriElement Parser() {
        String path = uriElement.getPath();
        String[] array = path.split("\\/");
        if (array.length != 3) {
            new RuntimeException(ERROR + uriElement.getUri() + "不满足Athena路由解析规则");
        } else {
            uriElement.setService(array[1]);
            uriElement.setMethod(array[2]);
        }
        return uriElement;
    }
}
