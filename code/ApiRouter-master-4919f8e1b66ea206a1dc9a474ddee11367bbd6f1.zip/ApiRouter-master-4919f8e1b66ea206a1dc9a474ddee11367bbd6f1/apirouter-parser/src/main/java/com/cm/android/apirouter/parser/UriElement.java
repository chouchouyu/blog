package com.cm.android.apirouter.parser;

import android.net.Uri;

import java.util.Set;

/**
 * Created by admin on 2018/6/22.
 */


public class UriElement {
    private Uri rawUri;
    private String scheme;
    private String encodedQuery;
    private Set<String> queryParameterNames;
    private String path;
    private String modlue;
    private String service;
    private String method;


    public UriElement(Uri uri) {
        this.rawUri = uri;
        this.scheme = uri.getScheme();
        this.encodedQuery = uri.getEncodedQuery();
        this.queryParameterNames = uri.getQueryParameterNames();
        this.modlue = uri.getHost();
        this.path = uri.getPath();
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public String getEncodedQuery() {
        return encodedQuery;
    }

    public void setEncodedQuery(String encodedQuery) {
        this.encodedQuery = encodedQuery;
    }

    public Set<String> getQueryParameterNames() {
        return queryParameterNames;
    }

    public void setQueryParameterNames(Set<String> queryParameterNames) {
        this.queryParameterNames = queryParameterNames;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getModlue() {
        return modlue;
    }

    public void setModlue(String modlue) {
        this.modlue = modlue;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public Uri getUri() {
        return rawUri;
    }

    public void setUri(Uri rawUri) {
        this.rawUri = rawUri;
    }

    @Override
    public String toString() {
        return "UriElement{" +
                "rawUri=" + rawUri +
                ", scheme='" + scheme + '\'' +
                ", encodedQuery='" + encodedQuery + '\'' +
                ", queryParameterNames=" + queryParameterNames +
                ", path='" + path + '\'' +
                ", modlue='" + modlue + '\'' +
                ", service='" + service + '\'' +
                ", method='" + method + '\'' +
                '}';
    }
}
