在每个 Moudle下的.gradle 添加:

    android { 
    		......
      	defaultConfig {
    		......
      	javaCompileOptions {
      		annotationProcessorOptions {
      		arguments = [moduleName: project.getName(), modulePath: project.getProjectDir().absolutePath]
    
      			}
    		}
      		......
    	}
    
      compileOptions {
	    sourceCompatibility JavaVersion.VERSION_1_7
	    targetCompatibility JavaVersion.VERSION_1_7
   		 }
    
    }
    
    
    dependencies {
    compile 'com.cmrh:apirouter-api:0.1.8-SNAPSHOT'
    annotationProcessor 'com.cmrh:apirouter-compiler:0.1.4-SNAPSHOT'
   compile 'com.cmrh:apirouter-annotation:0.0.8-SNAPSHOT'
    compile 'com.cmrh:apirouter-parser:0.0.1-SNAPSHOT'
 
    
    }

旧版本gradle插件(< 2.2)，可以使用apt插件
 build.gradle插件的配置方式
    apply plugin: 'com.neenbedankt.android-apt'
    
    buildscript {
    repositories {
    	jcenter()
    }
    
    dependencies {
    	classpath 'com.neenbedankt.gradle.plugins:android-apt:1.4'
    }
    }
    
    apt {
    arguments {
    	moduleName project.getName();
    }
    }
    
    dependencies {
    compile 'com.alibaba:arouter-api:x.x.x'
    apt 'com.alibaba:arouter-compiler:x.x.x'
    ...
    }


添加混淆规则(如果使用了Proguard)     #TODO 待改
混淆代码 ：
```
-keep public class com.cm.android.apirouter.routes.**{*;}
-keep class * implements  com.cm.android.apirouter.facade.template.ISyringe{*;}

# 如果使用了 byType 的方式获取 Service，需添加下面规则，保护接口
-keep interface * implements com.cm.android.apirouter.facade.template.IProvider
-keep interface * implements com.cm.android.apirouter.facade.template.ICallMethod

# 如果使用了 单类注入，即不定义接口实现 IProvider，需添加下面规则，保护实现IProvider, the following rules need to be added to protect the implementation
-keep class * implements com.cm.android.apirouter.facade.template.IProvider
-keep class * implements com.cm.android.apirouter.facade.template.ICallMethod

# If @Autowired is used for injection in non-Activity classes, add the following rules to prevent injection failures
-keepnames class * {
    @com.cm.android.apirouter.facade.annotation.Autowired <fields>;
}

# ApiRouter-parser
//-keep class com.cm.android.apirouter.parser.UriElement{*;}
-keep public class com.cm.android.apirouter.parser.ApiRouterUri{
   // public <fields>;
    public <methods>;
}
```
```

# 请不要尝试Kotlin~ #


# Athena-Android[![Build Status](https://travis-ci.org/chouchouyu/Athena-Android.svg?branch=master)](https://travis-ci.org/chouchouyu/Athena-Android)
有 startActivityForResult




对应

arouter-api `1.3.1`

arouter-compiler `1.1.4`

arouter-annotation  `1.0.4`

arouter-register `1.0.2`

commit `Mar 11,2018`


ApiRouter.getInstance()
                        .build("/test/activity2")
                        .navigation(this, 666);



                        @Override
                            protected void onActivityResult(int requestCode, int resultCode, Intent data) {
                                super.onActivityResult(requestCode, resultCode, data);

                                switch (requestCode) {
                                    case 666:
                        //                Log.e("activityResult", String.valueOf(resultCode));
                                        Log.e("activityResult", data.getExtras().get("three").toString());
                                        break;
                                    default:
                                        break;
                                }
                            }


                            Intent intent = new Intent();
                                    intent.putExtra("a","a");
                                    intent.putExtra("three", 1); //将计算的值回传回去
                                     setResult(666, intent);


                                     Fragment  支持

                                     private void showFragment(){
                                     //        BlankFragment blankFragment= new BlankFragment();
                                             BlankFragment blankFragment = (BlankFragment) ApiRouter.getInstance().build("/test/fragment").navigation();
                                             android.support.v4.app.FragmentManager manager = getSupportFragmentManager();
                                             android.support.v4.app.FragmentTransaction transaction = manager.beginTransaction();
                                             transaction.add(R.id.id_content, blankFragment).commit();
                                         }



                                         https://blog.csdn.net/soslinken/article/details/52184113

                                         https://blog.csdn.net/huang_yong_/article/details/72933991


                                         Postcard{uri=ApiRouter://third/baseUI/setTitle?data={"title":"信息列表"}&callbackID=callbackID_0_1511340591850, tag=null, mBundle=Bundle[{}], flags=-1, timeout=300, provider=null, greenChannel=false, optionsCompat=null, enterAnim=-1, exitAnim=-1, from=null, clazzName=null, methodName=null, params='null, isCustomization=false}
                                            RouteMeta{type=null, rawType=null, destination=null, path='/baseUI/setTitle', group='baseUI', priority=-1, extra=0, generateMethodFilePath=null}

                                         Postcard{uri=null, tag=null, mBundle=Bundle[{}], flags=-1, timeout=300, provider=null, greenChannel=false, optionsCompat=null, enterAnim=-1, exitAnim=-1, from=null, clazzName=/third/baseUI, methodName=setTitle, params='{"title":"信息列表"} , isCustomization=true}
                                         RouteMeta{type=null, rawType=null, destination=null, path='/third/baseUI/setTitle?data={"title":"信息列表"} ', group='third', priority=-1, extra=0, generateMethodFilePath=null}
Gradle Transform
https://blog.csdn.net/tscyds/article/details/78082861

如何使用Android Studio开发Gradle插件
https://blog.csdn.net/sbsujjbcy/article/details/50782830


使用Android Studio将开源库发布到Jcenter中央库
https://blog.csdn.net/sbsujjbcy/article/details/47100457

拥抱 Android Studio 之五：Gradle 插件开发
https://github.com/kevinho/Embrace-Android-Studio-Demo

Android动态编译技术:Plugin Transform Javassist操作Class文件
https://blog.csdn.net/yulong0809/article/details/77752098

配置Groovy开发环境(Windows)
https://www.jianshu.com/p/777cc61a6202

luckybilly/CC 组件化
https://github.com/luckybilly/CC/wiki

[译] Java、Kotlin、RN、Flutter 开发出来的 App 大小，你了解过吗？
https://juejin.im/post/5ab9bed76fb9a028dd4e3d24

预加载：页面启动速度优化利器
https://github.com/luckybilly/PreLoader/blob/master/README-zh-CN.md

使用ASM操作Java字节码，实现AOP原理
https://blog.csdn.net/catoop/article/details/50629921

asm学习笔记之生成接口
https://blog.csdn.net/aesop_wubo/article/details/48930913

Java字节码操纵框架ASM快速入门
https://blog.csdn.net/mn960mn/article/details/51418236

Android架构建设之组件化、模块化建设
https://blog.csdn.net/xinanheishao/article/details/79980286

mqzhangw/JIMU
https://github.com/mqzhangw/JIMU

业界首个支持渐进式组件化改造的Android组件化开源框架。
https://github.com/luckybilly/CC

cordova
http://cordova.axuer.com/docs/zh-cn/latest/guide/platforms/android/index.html

multiple-apk-generator
https://github.com/typ0520/multiple-apk-generator
解决android apk的批量打包,支持渠道号替换或者服务器地址替换(字符串替换)、资源替换、指定文件修改、修改包名
轻量级: 使用shell脚本编写，方便开发者修改实现逻辑
基于gradle打包apk

app-test-arch
https://github.com/hehonghui/app-test-arch

AutoRegister:一种更高效的组件自动注册方案(android组件化开发)
https://juejin.im/post/5a2b95b96fb9a045284669a9

Andromeda
https://github.com/iqiyi/Andromeda/blob/master/CHINESE_README.md

getCanonicalName()
T<T> callBack
context.getContentResolver()
ContentResolver接口可以访问ContentProvider提供的数据

教你接入阿里的Atlas组件化框架
https://mp.weixin.qq.com/s?__biz=MzIwMzYwMTk1NA%3D%3D&mid=2247489389&idx=1&sn=61d8d3e51b3395b777491fe36fe5bfe6

EventBus 利弊与源码解析
https://blog.csdn.net/superjimmy/article/details/45601515

[Gradle中文教程系列]-跟我学Gradle-5.3:依赖-管理依赖的版本(传递(transitive)\排除(exclude)\强制(force)\动态版本(+))
https://blog.csdn.net/pkaq_/article/details/53906668

开源Android容器化框架Atlas开发者指南
https://edu.aliyun.com/lesson_68_946?spm=5176.10731542.0.0.8v5STh#_946

----阿里推荐的-----
classLoader 双亲委派

Android应用程序资源的编译和打包过程分析 （作者的博客都可以看）
https://blog.csdn.net/luoshengyang/article/details/8744683

Gradle史上最详细解析
http://www.cnblogs.com/wxishang1991/p/5532006.html

Android Gradle 插件中文指南
http://www.open-open.com/lib/view/open1438153121331.html

https://github.com/mickyliu945/GradleCustomPlugin

https://docs.gradle.org/current/dsl/

Android应用启动、退出分析
https://www.jianshu.com/p/72059201b10a

CLASSLOADER 的工作机制
http://kaedea.com/2016/02/07/android-dynamical-loading-02-classloader/

插件化-资源处理
https://www.jianshu.com/p/96d5b83ca26c

Android 插件技术实战总结
https://mp.weixin.qq.com/s/1p5Y0f5XdVXN2EZYT0AM_A

Android插件化原理解析——概要
http://weishu.me/2016/01/28/understand-plugin-framework-overview/

https://github.com/kaedea/android-dynamical-loading/tree/develop/tech-dynamical-loading

----阿里推荐的-----
插件化踩坑之路——Small和Atlas方案对比 （有局限性）
https://blog.csdn.net/qq_34795285/article/details/77369071

Atlas源码
https://blog.csdn.net/m075097

Android中Hook Instrumentation的一些思考
https://blog.csdn.net/shifuhetudi/article/details/52078445

Android端应用秒开优化体验
http://zhengxiaoyong.me/2016/07/18/Android%E7%AB%AF%E5%BA%94%E7%94%A8%E7%A7%92%E5%BC%80%E4%BC%98%E5%8C%96%E4%BD%93%E9%AA%8C/
