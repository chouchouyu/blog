package com.cm.android.infors.request.modal;

import java.util.List;

public class JSAPMEvent {


    private List<BatchLogBean> batchLog;

    public List<BatchLogBean> getBatchLog() {
        return batchLog;
    }

    public void setBatchLog(List<BatchLogBean> batchLog) {
        this.batchLog = batchLog;
    }

    public static class BatchLogBean {
        /**
         * apmEventId : 4c563e39913fd3df09eebc0db24a09ca
         * appKey : 3f48d004b9cc434f992da3e7515155a0
         * deviceId : 299b3fec49d98280
         * browser : Chrome|76
         * occurTime : 1566639667756
         * pageHref : http://localhost:8082/#/spreadIndex
         * pageId : 2b798ac0cadb5a76cf451d67b5937386
         * sdkVersion : 3.2.4
         * userMsg :
         * event : {"error":{"otherError":{"message":"Cannot read property 'userId' of null"}}}
         */

        private String apmEventId;
        private String appKey;
        private String deviceId;
        private String browser;
        private long occurTime;
        private String pageHref;
        private String pageId;
        private String sdkVersion;
        private String userMsg;
        private EventBean event;

        public String getApmEventId() {
            return apmEventId;
        }

        public void setApmEventId(String apmEventId) {
            this.apmEventId = apmEventId;
        }

        public String getAppKey() {
            return appKey;
        }

        public void setAppKey(String appKey) {
            this.appKey = appKey;
        }

        public String getDeviceId() {
            return deviceId;
        }

        public void setDeviceId(String deviceId) {
            this.deviceId = deviceId;
        }

        public String getBrowser() {
            return browser;
        }

        public void setBrowser(String browser) {
            this.browser = browser;
        }

        public long getOccurTime() {
            return occurTime;
        }

        public void setOccurTime(long occurTime) {
            this.occurTime = occurTime;
        }

        public String getPageHref() {
            return pageHref;
        }

        public void setPageHref(String pageHref) {
            this.pageHref = pageHref;
        }

        public String getPageId() {
            return pageId;
        }

        public void setPageId(String pageId) {
            this.pageId = pageId;
        }

        public String getSdkVersion() {
            return sdkVersion;
        }

        public void setSdkVersion(String sdkVersion) {
            this.sdkVersion = sdkVersion;
        }

        public String getUserMsg() {
            return userMsg;
        }

        public void setUserMsg(String userMsg) {
            this.userMsg = userMsg;
        }

        public EventBean getEvent() {
            return event;
        }

        public void setEvent(EventBean event) {
            this.event = event;
        }

        public static class EventBean {
            /**
             * error : {"otherError":{"message":"Cannot read property 'userId' of null"}}
             */

            private ErrorBean error;

            public ErrorBean getError() {
                return error;
            }

            public void setError(ErrorBean error) {
                this.error = error;
            }

            public static class ErrorBean {
                /**
                 * otherError : {"message":"Cannot read property 'userId' of null"}
                 */

                private OtherErrorBean otherError;

                public OtherErrorBean getOtherError() {
                    return otherError;
                }

                public void setOtherError(OtherErrorBean otherError) {
                    this.otherError = otherError;
                }

                public static class OtherErrorBean {
                    /**
                     * message : Cannot read property 'userId' of null
                     */

                    private String message;

                    public String getMessage() {
                        return message;
                    }

                    public void setMessage(String message) {
                        this.message = message;
                    }
                }
            }
        }
    }
}
