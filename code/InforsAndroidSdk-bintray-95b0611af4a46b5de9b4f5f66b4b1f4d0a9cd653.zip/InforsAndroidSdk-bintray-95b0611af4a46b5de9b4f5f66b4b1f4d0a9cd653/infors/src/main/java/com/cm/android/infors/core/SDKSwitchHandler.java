package com.cm.android.infors.core;

import android.content.Context;
import android.content.SharedPreferences;

import com.cm.android.infors.core.report.Upload;
import com.cm.android.infors.request.modal.SdkSwitchRes;
import com.cm.android.infors.utils.SharedPreferencesFactory;

import static com.cm.android.infors.core.Consts.*;
import static com.cm.android.infors.utils.PrefUtils.*;

public class SDKSwitchHandler {

    public interface NetResponse {
        void onSuccess(SdkSwitchRes.BodyBean switchBean);

        void onFailure();
    }

    private SDKSwitchListener listener;

    public interface SDKSwitchListener {
        void onSwitchChange(SDKSwitchHandler sdkSwitchHandler);
    }

    private final Context context;
    private final InforsConfig config;


    public SDKSwitchHandler(Context context, InforsConfig config) {
        this.context = context;
        this.config = config;
    }

    public SDKSwitchHandler(Context context, InforsConfig config, SDKSwitchListener listener) {
        this(context, config);
        this.listener = listener;
    }

    public void getSwitchConfigFormNet(Context context, Upload upload) {
        upload.getSwith(context, config, new SDKSwitchHandler.NetResponse() {

            @Override
            public void onSuccess(SdkSwitchRes.BodyBean switchBean) {
                saveToSP(switchBean);
                listener.onSwitchChange(SDKSwitchHandler.this);
            }

            @Override
            public void onFailure() {
                setInforsEnable(true);
                setAutoTraceEnable(true);
                setHeatMapEnable(true);
                setViewEditorEnable(true);
                setBlockEnable(true);
                setCrashEnable(true);
                setHttpEnable(true);
                setLogPrintEnable(false);
                setLogUploadEnable(false);
                listener.onSwitchChange(SDKSwitchHandler.this);
            }
        });

    }


    public void saveToSP(SdkSwitchRes.BodyBean switchBean) {
        setInforsEnable(switchBean.isIsInforsEnable());
        setAutoTraceEnable(switchBean.isIsAutoTraceEnable());
        setHeatMapEnable(switchBean.isIsHeatMapEnable());
        setViewEditorEnable(switchBean.isIsViewEditorEnable());
        setBlockEnable(switchBean.isIsBlockEnable());
        setCrashEnable(switchBean.isIsCrashEnable());
        setHttpEnable(switchBean.isIsHttpEnable());
        setLogPrintEnable(switchBean.isPrintLogEnable());
        setLogUploadEnable(switchBean.isUploadLogEnable());
    }

    public void setInforsEnable(boolean inforsEnable) {
        saveBooleanSP(context, config, SP_SWITCH_INFORS, inforsEnable);
    }

    public void setAutoTraceEnable(boolean autoTraceEnable) {
        saveBooleanSP(context, config, SP_SWITCH_AUTOTRACE, autoTraceEnable);
    }

    public void setHeatMapEnable(boolean heatMapEnable) {
        saveBooleanSP(context, config, SP_SWITCH_HEATMAP, heatMapEnable);
    }

    public void setViewEditorEnable(boolean viewEditorEnable) {
        saveBooleanSP(context, config, SP_SWITCH_VIEWEDITOR, viewEditorEnable);
    }

    public void setHttpEnable(boolean httpEnable) {
        saveBooleanSP(context, config, SP_SWITCH_HTTP, httpEnable);
    }

    public void setBlockEnable(boolean blockEnable) {
        saveBooleanSP(context, config, SP_SWITCH_BLOCK, blockEnable);
    }

    public void setCrashEnable(boolean crashEnable) {
        saveBooleanSP(context, config, SP_SWITCH_CRASH, crashEnable);
    }

    public void setLogPrintEnable(boolean logPrintEnable) {
        saveBooleanSP(context, config, SP_SWITCH_LOG_PRINT, logPrintEnable);
    }

    public void setLogUploadEnable(boolean logUploadEnable) {
        saveBooleanSP(context, config, SP_SWITCH_LOG_UPLOAD, logUploadEnable);
    }


    public boolean isLogUploadEnable() {
        return getValue(SP_SWITCH_LOG_UPLOAD);
    }

    public boolean isLogPrintEnable() {
        return getValue(SP_SWITCH_LOG_PRINT);
    }

    public boolean isInforsEnable() {
        return getValue(SP_SWITCH_INFORS);
    }

    public boolean isAutoTraceEnable() {
        return getValue(SP_SWITCH_AUTOTRACE);
    }

    public boolean isHeatMapEnable() {
        return getValue(SP_SWITCH_HEATMAP);
    }

    public boolean isViewEditorEnable() {
        return getValue(SP_SWITCH_VIEWEDITOR);
    }

    public boolean isHttpEnable() {
        return getValue(SP_SWITCH_HTTP);
    }

    public boolean isBlockEnable() {
        return getValue(SP_SWITCH_BLOCK);
    }

    public boolean isCrashEnable() {
        return getValue(SP_SWITCH_CRASH);
    }


    private boolean getValue(String key) {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                config);
        SharedPreferences sharedPreferences = sharedPreferencesFactory.create();
        if (sharedPreferences.contains(key)) {
            return getBooleanFromSP(context, config, key);
        }
        return false;
    }
}
