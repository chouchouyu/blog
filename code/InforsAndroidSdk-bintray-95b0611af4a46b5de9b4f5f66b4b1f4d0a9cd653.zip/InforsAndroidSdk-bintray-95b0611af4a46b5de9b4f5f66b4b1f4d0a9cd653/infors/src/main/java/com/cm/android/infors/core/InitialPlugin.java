package com.cm.android.infors.core;

import android.app.Activity;
import android.app.Application;
import android.content.SharedPreferences;

import com.cm.android.infors.apm.trace.hacker.Hacker;
import com.cm.android.infors.core.events.ActivityTracker;
import com.cm.android.infors.core.plugin.Plugin;
import com.cm.android.infors.core.plugin.PluginListener;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.core.events.ProcessMonitor;
import com.cm.android.infors.core.report.Upload;
import com.cm.android.infors.request.modal.JSAPMEvent;
import com.cm.android.infors.request.modal.UserInfo;
import com.cm.android.infors.utils.DeviceUtils;
import com.cm.android.infors.utils.InforsUtil;
import com.cm.android.infors.utils.PrefUtils;
import com.cm.android.infors.utils.SharedPreferencesFactory;
import com.cm.android.infors.vieweditor.IViewEditor;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.util.*;

import static com.cm.android.infors.core.Consts.*;
import static com.cm.android.infors.utils.PrefUtils.*;

/**
 * 最初始的Plugin，采集基础数据
 * closeAutoTrace开关会影响部分数据的采集
 *
 * @author wusm
 */
public class InitialPlugin extends Plugin implements IViewEditor.OnSuccess, ProcessMonitor
        .Listener, ActivityTracker.Listener {
    private static final String TAG = "Infors.InitialPlugin";
    private final Upload upload;
    private InforsConfig mConfig;

    private ActivityTracker activityTracker = ActivityTracker.get();
    private ProcessMonitor processMonitor;

    public InitialPlugin(InforsConfig config, Upload upload, ProcessMonitor processMonitor) {
        mConfig = config;
        this.upload = upload;
        this.processMonitor = processMonitor;
    }

    Map<String, ActivityTimeStamp> activitymap;

    @Override
    public void init(Application app, PluginListener listener, SDKSwitchHandler dynamicConfig) {
        super.init(app, listener, dynamicConfig);
        upload.getConfigInfo(app, mConfig, this);

        activitymap = new LinkedHashMap<>();

    }

    @Override
    public void start() {
        super.start();
        if (!isSupported()) {
            return;
        }
        reportLaunchEvent();
        reportDevice();

        activityTracker.registerListener(this);
        processMonitor.registerListener(this);

    }


    @Override
    public void stop() {
        super.stop();
        if (!isSupported()) {
            return;
        }
        processMonitor.unregisterListener(this);
        activityTracker.registerListener(this);
    }

    @Override
    public void destroy() {
        super.destroy();

    }

    public static String getTAG() {
        return InitialPlugin.TAG;
    }

    public void reportUserInfo(UserInfo userInfo) {
        UserInfo user;
        String vid, describe;
        if (null == userInfo) {
            describe = vid = "logout";
            DetectIssue(null, vid, describe);
            removeSpUserId();
            return;
        } else {
            describe = vid = TYPE_USER;
            user = userInfo;
        }
        saveToSP(user.getUserid());
        DetectIssue(user, vid, describe);
    }

    public void DetectIssue(UserInfo user, String vid, String describe) {
        Gson gson = new Gson();
        JsonObject userObj;
        if (user == null) {
            userObj = new JsonObject();
        } else {
            userObj = gson.fromJson(gson.toJson(user), JsonObject.class);
        }
        userObj.addProperty(ReportField.vid.name(), vid);
        userObj.addProperty(ReportField.describe.name(), describe);

        Issue issue = new Issue(TYPE_USER, userObj, this);
        this.onDetectIssue(issue);
    }

    private void saveToSP(String userid) {
        saveStringSP(getApplication(), mConfig, Consts.SP_USERINFO, userid);
    }

    private void removeSpUserId() {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory
                (getApplication(),
                        mConfig);
        SharedPreferences prefs = sharedPreferencesFactory.create();
        PrefUtils.remove(prefs, Consts.SP_USERINFO);
    }


    public void reportTraceEvent(String vid, String describe, Map<String, String> property,
                                 String appkey) {
        Map<String, Object> map = new HashMap<String, Object>();
        for (String key : property.keySet()) {
            map.put(key, property.get(key));
        }

        Issue issue = new Issue(TYPE_TRACK, vid, describe, map, this, appkey);
        this.onDetectIssue(issue);
    }

//    private void setAppLaunchTime() {
//        mConfig.setAppLaunchTime(System.currentTimeMillis());
//    }


    private void reportLaunchEvent() {
        long startTime = Hacker.sApplicationCreateBeginTime;
        long endTime = Hacker.sApplicationCreateEndTime;
        if (0 != startTime) {
            if (isNEWLaunch(startTime) && InforsUtil.isInMainProcess(this.getApplication())) {
                Logger.d("===修改时间戳====startTime" + startTime);
                saveLongSP(getApplication(), mConfig, SP_TO_BACKGROUND, startTime);
                Map<String, Object> map = new HashMap<String, Object>();
                map.put(ReportField.localIP.name(), DeviceUtils.getInstance(getApplication())
                        .getIPAddress());
                map.put(ReportField.appLoadTime.name(), System.currentTimeMillis() - startTime);
                map.put(ReportField.timestamp.name(), startTime);
                map.put(ReportField.osVersion.name(), InforsUtil.getOSVersion(getApplication()));
                map.put(ReportField.carrierName.name(), DeviceUtils.getInstance(getApplication())
                        .operatorToCarrier());
                mConfig.setAppLaunchTime(this.getApplication(), startTime);
                InforsUtil.setConnection(getApplication(), false);
                Issue issue = new Issue(TYPE_LAUNCH, map, this);
                issue.setTimestamp(startTime);
                this.onDetectIssue(issue);
            }
        }

    }

    private void reportDevice() {
        if (InforsUtil.isInMainProcess(this.getApplication())) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(ReportField.deviceType.name(), mConfig.getDeviceType(getApplication()));
            Issue issue = new Issue(TYPE_DEVICE, map, this);
            this.onDetectIssue(issue);
        }
    }

    @Override
    public void onSuccess(String response) {
        Logger.i(" cfg json ->  ", response);
        saveStringSP(getApplication(), mConfig, Consts.SP_PC_CFG, response);
    }


    @Override
    public void onActivityCreate(Activity activity) {
        ActivityTimeStamp activityTimeStamp = new ActivityTimeStamp();
        activityTimeStamp.setStartTime(System.currentTimeMillis());
        activitymap.put(activity.getClass().getCanonicalName(), activityTimeStamp);
    }

    @Override
    public void onActivityStart(Activity activity) {
    }

    @Override
    public void onActivityResume(Activity activity) {
        if (activitymap.containsKey(activity.getClass().getCanonicalName())) {
            ActivityTimeStamp activityTimeStamp = activitymap.get(activity.getClass()
                    .getCanonicalName());
            activityTimeStamp.setResumeTime(System.currentTimeMillis());
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(ReportField.title.name(), activity.getTitle().toString());
            map.put(ReportField.pageTitle.name(), activity.getTitle().toString());
            map.put(ReportField.pageLoadTime.name(), activityTimeStamp.getResumeTime() -
                    activityTimeStamp.getStartTime());
            map.put(ReportField.pageId.name(), activity.getClass()
                    .getCanonicalName());
            Issue issue = new Issue(TYPE_PAGEVIEW, activity.getClass().getCanonicalName(),
                    activity.getClass().getCanonicalName(), map, this);
            onDetectIssue(issue);
        }
    }

    @Override
    public void onActivityPause(Activity activity) {
    }

    @Override
    public void onActivityStop(Activity activity) {
        if (activitymap.containsKey(activity.getClass().getCanonicalName())) {
            activitymap.remove(activity.getClass().getCanonicalName());
        }
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        Logger.d("pagev -onActivityDestroyed" + activity.getClass().getCanonicalName());

    }

    @Override
    public void onActivityForegroundToBackground(Activity activity) {
        if (getDynamicConfig().isAutoTraceEnable()) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(ReportField.lastActivity.name(), activity.getClass().getCanonicalName());
            Issue issue = new Issue(TYPE_PAGE_PAUSE, "进入后台",
                    "Android 进入后台事件", map, this);
            onDetectIssue(issue);
        }
        upload.uploadEvents(activity.getApplication());
    }

    @Override
    public void onActivityBackgroundToForeground(Activity activity) {
        long savetime = getLongFromSP(getApplication(), mConfig, SP_TO_BACKGROUND);
        long currentTime = System.currentTimeMillis();
        if (currentTime - savetime > 300000) {//5分钟
            Logger.d("===修改时间戳====后台来前台" + currentTime);
            saveLongSP(getApplication(), mConfig, SP_TO_BACKGROUND, currentTime);
        }
        if (getDynamicConfig().isAutoTraceEnable()) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(ReportField.firstActivity.name(), activity.getClass().getCanonicalName());
            Issue issue = new Issue(TYPE_PAGE_RESUME, "进入前台",
                    "Android进入前台事件", map, this);
            onDetectIssue(issue);
        }
    }


    private boolean isNEWLaunch(long timeStamp) {
        Long saveTime = new Long(mConfig.getAppLaunchTime(this.getApplication()));
        Long currentTime = new Long(timeStamp);
        if (saveTime == currentTime) {
            return false;
        } else {
            return true;
        }
    }

    class ActivityTimeStamp {
        private long startTime;
        private long resumeTime;

        public long getStartTime() {
            return startTime;
        }

        public void setStartTime(long startTime) {
            this.startTime = startTime;
        }

        public long getResumeTime() {
            return resumeTime;
        }

        public void setResumeTime(long resumeTime) {
            this.resumeTime = resumeTime;
        }
    }

    public void webAPMReport(JSAPMEvent jsAPMEvent) {
        upload.webAPMReport(jsAPMEvent);
    }

    public void web4APMReport(JsonObject jsonObject) {
        upload.web4APMReport(jsonObject);
    }

}