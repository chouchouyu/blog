package com.cm.android.infors.vieweditor;

import android.content.Context;

import com.cm.android.infors.core.InforsConfig;
import com.cm.android.infors.core.ReportField;
import com.cm.android.infors.utils.DeviceId;
import com.cm.android.infors.utils.InforsUtil;
import com.google.gson.JsonObject;

import java.util.HashMap;
import java.util.Map;

import static com.cm.android.infors.vieweditor.IViewEditor.MessageType.DEVICE;
import static com.cm.android.infors.vieweditor.IViewEditor.MessageType.PAGE;

/**
 * 可视化 websocket通讯
 *
 * @author wusm
 * {
 * "messageType" : "deviceInfo/pageInfo",
 * "deviceId" : "aaaaa",
 * "deviceName" : "sad",
 * "appName" : "dasdas",
 * "body" : {
 * "viewTree" : "html...../none",
 * "imgUrl" : "none"
 * }
 * }
 * <p>
 * 第一次的时候messageType=deviceInfo,上报设备信息，body可以不填
 * 后面的messageType都是pageInfo,然后body也要填
 * <p>
 * <p>
 * {"msg":"sdk connected success !!!"}
 * {
 * "messageType": "deviceInfo",
 * "deviceId": "deviceId",
 * "deviceName": "sad",
 * "appName": "dasdas"
 * }
 * <p>
 * {"msg":"reported device info success !!!"}
 */
public class WsJsonFactory {

    String DeviceId;
    String deviceName;
    String appName;

    public WsJsonFactory(Context context, InforsConfig config) {
        DeviceId = com.cm.android.infors.utils.DeviceId.getDeviceId(context, config);
        deviceName = config.getDeviceType(context);
        appName = config.getAppName(context);
    }

    public String getDeviceInfoJson() {
        return jsonFactory(DEVICE, null, null);

    }

    /**
     * 通讯时数据拼接
     *
     * @param msgType
     * @param viewTree
     * @param picUrl
     * @return
     */
    public String jsonFactory(String msgType, String viewTree, String picUrl) {
        JsonObject object = new JsonObject();
        object.addProperty(ReportField.messageType.name(), msgType);
        object.addProperty(ReportField.deviceId.name(), DeviceId);
        object.addProperty(ReportField.deviceName.name(), deviceName);
        object.addProperty(ReportField.appName.name(), appName);
        if (msgType.equals(PAGE)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(ReportField.viewTree.name(), viewTree);
            map.put(ReportField.imgUrl.name(), picUrl);
            object.add("body", InforsUtil.mapToJson(map));
        }
        return object.toString();
    }

}
