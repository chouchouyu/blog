package com.cm.android.infors.vieweditor.listener;

import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import com.cm.android.infors.Infors;
import com.cm.android.infors.apm.network.HttpPlugin;
import com.cm.android.infors.core.InforsConfig;
import com.cm.android.infors.core.InitialPlugin;
import com.cm.android.infors.core.plugin.Plugin;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.core.events.ActivityTracker;
import com.cm.android.infors.core.ReportField;
import com.cm.android.infors.core.report.Upload;
import com.cm.android.infors.vieweditor.WsHandler;

import java.util.HashMap;
import java.util.Map;

import static com.cm.android.infors.core.Consts.*;

/**
 * 监听点击事件-热力图
 * 监听两指按压事件 -可视化埋点的启动
 *
 * @author wusm
 */
public class WindowCallbackListener {
    private final ActivityTracker mActivityTracker = ActivityTracker.get();
    private final InforsConfig mConfig;
    private final Upload upload;

    public WindowCallbackListener(InforsConfig config, Upload upload) {
        mActivityTracker.registerListener(mListener);
        this.mConfig = config;
        this.upload = upload;
    }

    long lastDownTime;

    private final ActivityTracker.Listener mListener = new ActivityTracker.Listener() {

        @Override
        public void onActivityCreate(Activity activity) {
        }

        @Override
        public void onActivityStart(Activity activity) {
        }

        @Override
        public void onActivityResume(final Activity activity) {
            onActivityCreate(activity);
            if (!isReactNativeActivity(activity)) {
                Window localWindow = activity.getWindow();
                if (localWindow == null) {
                    return;
                }

                localWindow.setCallback(new SimpleWindowCallback(localWindow.getCallback()) {
                    @Override
                    public boolean dispatchTouchEvent(MotionEvent event) {

                        InitialPlugin plugin = Infors.getInstance().getPluginByClass
                                (InitialPlugin.class);
                        if (plugin != null) {
                            if (event.getPointerCount() == 2) {

                                if (plugin.getDynamicConfig().isHeatMapEnable() && plugin
                                        .getDynamicConfig().isViewEditorEnable() && plugin
                                        .getDynamicConfig().isAutoTraceEnable()) {
                                    if (event.getAction() == MotionEvent.ACTION_POINTER_2_DOWN) {
                                        lastDownTime = System.currentTimeMillis();
                                    } else if (event.getAction() == MotionEvent.ACTION_POINTER_UP) {
                                        if (System.currentTimeMillis() - lastDownTime > 3000) {
                                            startWebSocket();
                                        }
                                    }
                                }

                            } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
                                if (plugin.getDynamicConfig().isHeatMapEnable() && plugin
                                        .getDynamicConfig().isAutoTraceEnable()) {
                                    onTouchDown(plugin, activity, event);
                                }
                            }
                        }

                        return super.dispatchTouchEvent(event);
                    }
                });
            }
        }

        @Override
        public void onActivityPause(Activity activity) {
        }

        @Override
        public void onActivityStop(Activity activity) {
        }

        @Override
        public void onActivityDestroyed(Activity activity) {
        }

    };


    /**
     * 判断是否是RN页面， sdk不处理RN页面。
     *
     * @param element
     * @return
     */
    private boolean isReactNativeActivity(Activity element) {
        boolean flag = false;
        ViewGroup decorView = (ViewGroup) element.getWindow().peekDecorView();
        ViewGroup rootView = decorView.findViewById(android.R.id.content);
        for (int m = 0; m < rootView.getChildCount(); m++) {
            if (rootView.getChildAt(m).getClass().getName().startsWith("com.facebook.react.")) {
                flag = true;
            }
            if (rootView.getChildAt(m) instanceof ViewGroup) {
                for (int n = 0; n < ((ViewGroup) rootView.getChildAt(m)).getChildCount(); n++) {
                    if (((ViewGroup) rootView.getChildAt(m)).getChildAt(n).getClass().getName()
                            .startsWith("com.facebook" +
                                    ".react.")) {
                        flag = true;
                    }
                }
            }
        }
        return flag;
    }

    private void startWebSocket() {
        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);
        if (plugin != null) {
            WsHandler test = new WsHandler(plugin.getApplication(), mConfig, upload);
            test.openWS();
        }
    }


    private long lastClickTime = 0L;
    private static final int FAST_CLICK_DELAY_TIME = 200; // 快速点击间隔

    private void onTouchDown(InitialPlugin plugin, Activity activity, MotionEvent event) {
        if (System.currentTimeMillis() - lastClickTime < FAST_CLICK_DELAY_TIME) {
            return;
        }
        lastClickTime = System.currentTimeMillis();
        heatMapClickReport(plugin, activity, event);
    }


    private void heatMapClickReport(InitialPlugin plugin, Activity activity, MotionEvent event) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ReportField.pageId.name(), activity.getClass().getCanonicalName());
        map.put(ReportField.xaxis.name(), event.getX());
        map.put(ReportField.yaxis.name(), event.getY());
        View decorview = activity.getWindow().peekDecorView();
        map.put(ReportField.resolution.name(), decorview
                .getWidth() + "#" + decorview.getHeight());
        map.put(ReportField.href.name(), activity.getClass().getCanonicalName());
        Issue issue = new Issue(TYPE_TOUCH, HeatMap, HeatMap, map, plugin);
        plugin.onDetectIssue(issue);
    }


}
