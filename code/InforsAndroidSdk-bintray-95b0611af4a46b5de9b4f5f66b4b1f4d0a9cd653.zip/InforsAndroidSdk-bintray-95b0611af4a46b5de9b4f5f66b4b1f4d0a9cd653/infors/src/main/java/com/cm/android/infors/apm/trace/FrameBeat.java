package com.cm.android.infors.apm.trace;

import android.app.Activity;
import android.view.Choreographer;
import com.cm.android.infors.apm.trace.listeners.IFrameBeat;
import com.cm.android.infors.apm.trace.listeners.IFrameBeatListener;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.core.events.ProcessMonitor;
import com.cm.android.infors.utils.InforsUtil;

import java.util.LinkedList;


/**
 * @author wusm
 * <p>
 * The FrameBeat receives the frame event from Choreographer{@link Choreographer},
 * and it notifies tracer to deal with their own work.
 * It can help us to calculate FPS and know if mainThread does too much work.
 * </p>
 * <p>
 * The FrameBeat only cares about the main thread.
 * when the app is staying at background,it's unavailable.
 * </p>
 */
public final class FrameBeat implements IFrameBeat, Choreographer.FrameCallback, ProcessMonitor.Listener {
    private static final String TAG = "Infors.FrameBeat";
    private static FrameBeat mInstance;
    private final LinkedList<IFrameBeatListener> mFrameListeners;
    private Choreographer mChoreographer;
    private boolean isCreated;
    private volatile boolean isPause = true;
    private long mLastFrameNanos;

    private FrameBeat() {
        mFrameListeners = new LinkedList<>();
    }

    public static FrameBeat getInstance() {
        if (null == mInstance) {
            mInstance = new FrameBeat();
        }
        return mInstance;
    }

    @Override
    public void onCreate() {
        if (!InforsUtil.isInMainThread(Thread.currentThread().getId())) {
            Logger.e(TAG, "[onCreate] FrameBeat must create on main thread");
            return;
        }
        Logger.i(TAG, "[onCreate] FrameBeat real onCreate!");
        if (!isCreated) {
            isCreated = true;
            ProcessMonitor.get().registerListener(this);
            mChoreographer = Choreographer.getInstance();
            resume();
        } else {
            Logger.w(TAG, "[onCreate] FrameBeat is created!");
        }
    }

    public void resume() {
        if (!isCreated) {
            return;
        }
        isPause = false;
        if (null != mChoreographer) {
            mChoreographer.removeFrameCallback(this);
            mChoreographer.postFrameCallback(this);
            mLastFrameNanos = 0;
        }
    }

    public void pause() {
        if (!isCreated) {
            return;
        }
        isPause = true;
        if (null != mChoreographer) {
            mChoreographer.removeFrameCallback(this);
            mLastFrameNanos = 0;
            for (IFrameBeatListener listener : mFrameListeners) {
                listener.cancelFrame();
            }
        }
    }


    public boolean isPause() {
        return isPause;
    }


    /**
     * when the device's Vsync is coming,it will be called.
     *
     * @param frameTimeNanos The time in nanoseconds when the frame started being rendered.
     */
    @Override
    public void doFrame(long frameTimeNanos) {
        if (isPause()) {
            return;
        }
        if (frameTimeNanos < mLastFrameNanos || mLastFrameNanos <= 0) {
            mLastFrameNanos = frameTimeNanos;
            if (null != mChoreographer) {
                //注册下一帧回调
                mChoreographer.postFrameCallback(this);
            }
            return;
        }

        if (null != mFrameListeners) {
            for (IFrameBeatListener listener : mFrameListeners) {
                listener.doFrame(mLastFrameNanos, frameTimeNanos);
            }
            if (null != mChoreographer) {
                mChoreographer.postFrameCallback(this);
            }
            mLastFrameNanos = frameTimeNanos;
        }
    }

    @Override
    public void onDestroy() {
        if (isCreated) {
            isCreated = false;
            if (null != mChoreographer) {
                mChoreographer.removeFrameCallback(this);
                for (IFrameBeatListener listener : mFrameListeners) {
                    listener.cancelFrame();
                }
            }
            mChoreographer = null;
            if (null != mFrameListeners) {
                mFrameListeners.clear();
            }
        } else {
            Logger.w(TAG, "[onDestroy] FrameBeat is not created!");
        }

    }

    @Override
    public void addListener(IFrameBeatListener listener) {
        if (null != mFrameListeners && !mFrameListeners.contains(listener)) {
            mFrameListeners.add(listener);
            if (isPause()) {
                resume();
            }
        }
    }

    @Override
    public void removeListener(IFrameBeatListener listener) {
        if (null != mFrameListeners) {
            mFrameListeners.remove(listener);
            if (mFrameListeners.isEmpty()) {
                pause();
            }
        }
    }


    @Override
    public void onActivityForegroundToBackground(Activity activity) {
        Logger.i(TAG, "[onBackground] isCreated:%s removeFrameCallback", isCreated);
        pause();
    }

    @Override
    public void onActivityBackgroundToForeground(Activity activity) {
        Logger.i(TAG, "[onFront] isCreated:%s postFrameCallback", isCreated);
        resume();
    }
}
