package com.cm.android.infors.utils;

/**
 * @author wusm
 */

import android.content.Context;
import android.graphics.Point;
import android.os.Build.VERSION;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;

public class ResUtils {

    public static <T> T throwIfNull(T item) {
        if (item == null) {
            throw new NullPointerException();
        }
        return item;
    }

    public static void throwIfNot(boolean condition) {
        if (!condition) {
            throw new IllegalStateException();
        }
    }

    public static int[] getScreenSize(Context context) {
        WindowManager windowManager;
        try {
            windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        } catch (Throwable var6) {
            //  MobLogger.getInstance(context).W(var6);
            windowManager = null;
        }

        if (windowManager == null) {
            return new int[]{0, 0};
        } else {
            Display display = windowManager.getDefaultDisplay();
            if (VERSION.SDK_INT < 13) {
                DisplayMetrics t1 = new DisplayMetrics();
                display.getMetrics(t1);
                return new int[]{t1.widthPixels, t1.heightPixels};
            } else {
                try {
                    Point t = new Point();
                    Method method = display.getClass().getMethod("getRealSize", new Class[]{Point.class});
                    method.setAccessible(true);
                    method.invoke(display, new Object[]{t});
                    return new int[]{t.x, t.y};
                } catch (Throwable var5) {
                    //      MobLogger.getInstance(context).W(var5);
                    return new int[]{0, 0};
                }
            }
        }
    }


    public static String getCacheRoot(Context context) {
        String appDir = context.getFilesDir().getAbsolutePath() + "/Mob/";
        DeviceUtils helper = DeviceUtils.getInstance(context);
        if (helper.getSdcardState()) {
            appDir = helper.getSdcardPath() + "/Mob/";
        }

        File file = new File(appDir);
        if (!file.exists()) {
            file.mkdirs();
        }

        return appDir;
    }

    public static String getCachePath(Context context, String category) {
        String appDir = context.getFilesDir().getAbsolutePath() + "/Mob/cache/";
        DeviceUtils helper = DeviceUtils.getInstance(context);

        try {
            if (helper.getSdcardState()) {
                appDir = helper.getSdcardPath() + "/Mob/" + helper.getPackageName() + "/cache/";
            }
        } catch (Throwable var5) {
            //  MobLogger.getInstance(context).D(var5);
        }

        if (!TextUtils.isEmpty(category)) {
            appDir = appDir + category + "/";
        }

        File file = new File(appDir);
        if (!file.exists()) {
            file.mkdirs();
        }

        return appDir;
    }


    public static void clearCache(Context context) throws Throwable {
        String path = getCachePath(context, (String) null);
        File cacheFolder = new File(path);
        deleteFileAndFolder(cacheFolder);
    }


    public static void deleteFileAndFolder(File folder) throws Throwable {
        if (folder != null && folder.exists()) {
            if (folder.isFile()) {
                folder.delete();
            } else {
                String[] names = folder.list();
                if (names != null && names.length > 0) {
                    String[] var2 = names;
                    int var3 = names.length;

                    for (int var4 = 0; var4 < var3; ++var4) {
                        String name = var2[var4];
                        File f = new File(folder, name);
                        if (f.isDirectory()) {
                            deleteFileAndFolder(f);
                        } else {
                            f.delete();
                        }
                    }

                    folder.delete();
                } else {
                    folder.delete();
                }
            }
        }
    }


    public static int parseInt(String string) throws Throwable {
        return parseInt(string, 10);
    }

    public static int parseInt(String string, int radix) throws Throwable {
        return Integer.parseInt(string, radix);
    }

    public static long parseLong(String string) throws Throwable {
        return parseLong(string, 10);
    }

    public static long parseLong(String string, int radix) throws Throwable {
        return Long.parseLong(string, radix);
    }

    public static String toString(Object obj) {
        return obj == null ? "" : obj.toString();
    }


    public static <T> T forceCast(Object obj, T defValue) {
        if (obj == null) {
            return defValue;
        } else {
            if (obj instanceof Byte) {
                byte value = ((Byte) obj).byteValue();
                if (defValue instanceof Boolean) {
                    return (T) Boolean.valueOf(value != 0);
                }

                if (defValue instanceof Short) {
                    return (T) Short.valueOf((short) value);
                }

                if (defValue instanceof Character) {
                    return (T) Character.valueOf((char) value);
                }

                if (defValue instanceof Integer) {
                    return (T) Integer.valueOf(value);
                }

                if (defValue instanceof Float) {
                    return (T) Float.valueOf((float) value);
                }

                if (defValue instanceof Long) {
                    return (T) Long.valueOf((long) value);
                }

                if (defValue instanceof Double) {
                    return (T) Double.valueOf((double) value);
                }
            } else if (obj instanceof Character) {
                char value1 = ((Character) obj).charValue();
                if (defValue instanceof Byte) {
                    return (T) Byte.valueOf((byte) value1);
                }

                if (defValue instanceof Boolean) {
                    return (T) Boolean.valueOf(value1 != 0);
                }

                if (defValue instanceof Short) {
                    return (T) Short.valueOf((short) value1);
                }

                if (defValue instanceof Integer) {
                    return (T) Integer.valueOf(value1);
                }

                if (defValue instanceof Float) {
                    return (T) Float.valueOf((float) value1);
                }

                if (defValue instanceof Long) {
                    return (T) Long.valueOf((long) value1);
                }

                if (defValue instanceof Double) {
                    return (T) Double.valueOf((double) value1);
                }
            } else if (obj instanceof Short) {
                short value2 = ((Short) obj).shortValue();
                if (defValue instanceof Byte) {
                    return (T) Byte.valueOf((byte) value2);
                }

                if (defValue instanceof Boolean) {
                    return (T) Boolean.valueOf(value2 != 0);
                }

                if (defValue instanceof Character) {
                    return (T) Character.valueOf((char) value2);
                }

                if (defValue instanceof Integer) {
                    return (T) Integer.valueOf(value2);
                }

                if (defValue instanceof Float) {
                    return (T) Float.valueOf((float) value2);
                }

                if (defValue instanceof Long) {
                    return (T) Long.valueOf((long) value2);
                }

                if (defValue instanceof Double) {
                    return (T) Double.valueOf((double) value2);
                }
            } else if (obj instanceof Integer) {
                int value3 = ((Integer) obj).intValue();
                if (defValue instanceof Byte) {
                    return (T) Byte.valueOf((byte) value3);
                }

                if (defValue instanceof Boolean) {
                    return (T) Boolean.valueOf(value3 != 0);
                }

                if (defValue instanceof Character) {
                    return (T) Character.valueOf((char) value3);
                }

                if (defValue instanceof Short) {
                    return (T) Short.valueOf((short) value3);
                }

                if (defValue instanceof Float) {
                    return (T) Float.valueOf((float) value3);
                }

                if (defValue instanceof Long) {
                    return (T) Long.valueOf((long) value3);
                }

                if (defValue instanceof Double) {
                    return (T) Double.valueOf((double) value3);
                }
            } else if (obj instanceof Float) {
                float value4 = ((Float) obj).floatValue();
                if (defValue instanceof Byte) {
                    return (T) Byte.valueOf((byte) ((int) value4));
                }

                if (defValue instanceof Boolean) {
                    return (T) Boolean.valueOf(value4 != 0.0F);
                }

                if (defValue instanceof Character) {
                    return (T) Character.valueOf((char) ((int) value4));
                }

                if (defValue instanceof Short) {
                    return (T) Short.valueOf((short) ((int) value4));
                }

                if (defValue instanceof Integer) {
                    return (T) Integer.valueOf((int) value4);
                }

                if (defValue instanceof Long) {
                    return (T) Long.valueOf((long) value4);
                }

                if (defValue instanceof Double) {
                    return (T) Double.valueOf((double) value4);
                }
            } else if (obj instanceof Long) {
                long value5 = ((Long) obj).longValue();
                if (defValue instanceof Byte) {
                    return (T) Byte.valueOf((byte) ((int) value5));
                }

                if (defValue instanceof Boolean) {
                    return (T) Boolean.valueOf(value5 != 0L);
                }

                if (defValue instanceof Character) {
                    return (T) Character.valueOf((char) ((int) value5));
                }

                if (defValue instanceof Short) {
                    return (T) Short.valueOf((short) ((int) value5));
                }

                if (defValue instanceof Integer) {
                    return (T) Integer.valueOf((int) value5);
                }

                if (defValue instanceof Float) {
                    return (T) Float.valueOf((float) value5);
                }

                if (defValue instanceof Double) {
                    return (T) Double.valueOf((double) value5);
                }
            } else if (obj instanceof Double) {
                double value6 = ((Double) obj).doubleValue();
                if (defValue instanceof Byte) {
                    return (T) Byte.valueOf((byte) ((int) value6));
                }

                if (defValue instanceof Boolean) {
                    return (T) Boolean.valueOf(value6 != 0.0D);
                }

                if (defValue instanceof Character) {
                    return (T) Character.valueOf((char) ((int) value6));
                }

                if (defValue instanceof Short) {
                    return (T) Short.valueOf((short) ((int) value6));
                }

                if (defValue instanceof Integer) {
                    return (T) Integer.valueOf((int) value6);
                }

                if (defValue instanceof Float) {
                    return (T) Float.valueOf((float) value6);
                }

                if (defValue instanceof Long) {
                    return (T) Long.valueOf((long) value6);
                }
            }

            try {
                return (T) obj;
            } catch (Throwable var4) {
                return defValue;
            }
        }
    }


    public static void copyFile(FileInputStream src, FileOutputStream dst) throws Throwable {
        byte[] buf = new byte[65536];

        for (int len = src.read(buf); len > 0; len = src.read(buf)) {
            dst.write(buf, 0, len);
        }

        src.close();
        dst.close();
    }


    public static long getFileSize(File file) throws Throwable {
        if (!file.exists()) {
            return 0L;
        } else if (!file.isDirectory()) {
            return file.length();
        } else {
            String[] names = file.list();
            int size = 0;

            for (int i = 0; i < names.length; ++i) {
                File f = new File(file, names[i]);
                size = (int) ((long) size + getFileSize(f));
            }

            return (long) size;
        }
    }


}
