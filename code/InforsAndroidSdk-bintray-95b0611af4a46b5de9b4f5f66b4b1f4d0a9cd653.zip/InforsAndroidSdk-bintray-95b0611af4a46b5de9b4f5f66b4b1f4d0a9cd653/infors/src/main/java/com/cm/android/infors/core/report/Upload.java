package com.cm.android.infors.core.report;

import android.content.Context;
import android.support.annotation.Keep;
import android.text.TextUtils;

import com.cm.android.infors.apm.trace.hacker.Hacker;
import com.cm.android.infors.core.*;
import com.cm.android.infors.core.thread.InforsHandlerThread;
import com.cm.android.infors.db.APMEventEntity;
import com.cm.android.infors.request.modal.*;

import com.cm.android.infors.db.EventEntity;
import com.cm.android.infors.db.InforsDatabase;
import com.cm.android.infors.utils.DeviceId;
import com.cm.android.infors.utils.DeviceUtils;
import com.cm.android.infors.utils.InforsUtil;
import com.cm.android.infors.vieweditor.IViewEditor;
import com.google.gson.Gson;


import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import okhttp3.*;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.*;
import retrofit2.http.Headers;

import static com.cm.android.infors.core.Consts.*;
import static com.cm.android.infors.utils.EncryptData.Base64Decode;

/**
 * retrofit 上报
 *
 * @author wusm
 */
public class Upload {
    private final ThreadPoolExecutor executor;
    private InforsConfig config;
    private AtomicBoolean isEventUploading = new AtomicBoolean(false);
    private AtomicBoolean isLogUploading = new AtomicBoolean(false);
    private String baseUrl;
    private APIService service;
    private Retrofit retrofit;
//    private Handler mHandler;

    HttpLoggingInterceptor logInterceptor = new HttpLoggingInterceptor(
            new HttpLoggingInterceptor.Logger() {
                @Override
                public void log(String message) {
                    Logger.w(TAG, "okhttp -> " + message);
                }
            });


    public Upload(InforsConfig config, Boolean openLog, ThreadPoolExecutor executor) {

//        mHandler = new Handler(InforsHandlerThread.getDefaultHandlerThread().getLooper());
        this.executor = executor;
        this.config = config;
        initNet(config.getBaseUrl(), openLog);
    }

    @Keep
    private void initNet(String baseUrl, Boolean openLog) {
//            baseUrl = "http://10.200.80.77:10801";
        if (TextUtils.isEmpty(baseUrl)) {
            this.baseUrl = "https://touch.cmft.com/";
        } else {
            this.baseUrl = baseUrl;
        }

        if (openLog) {
            logInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        } else {
            logInterceptor.setLevel(HttpLoggingInterceptor.Level.NONE);
        }

        OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient.Builder()
                .addInterceptor(logInterceptor);

        okHttpClientBuilder.sslSocketFactory(SSLSocketFactoryUtils.createSSLSocketFactory(),
                SSLSocketFactoryUtils.createTrustAllManager())
                .hostnameVerifier(new SSLSocketFactoryUtils.TrustAllHostnameVerifier())
                .retryOnConnectionFailure(true)
                .connectTimeout(18, TimeUnit.MINUTES)
                .readTimeout(18, TimeUnit.MINUTES)
                .writeTimeout(18, TimeUnit.MINUTES);

        OkHttpClient okhttpclient = okHttpClientBuilder.build();


        retrofit = new Retrofit.Builder()
                .baseUrl(this.baseUrl)
                .client(okhttpclient)
                .addConverterFactory(GsonConverterFactory.create())
                .build();


        service = retrofit.create(APIService.class);
    }

    /**
     * 获取app可视化配置信息
     *
     * @param config
     * @param callback
     */
    public void getConfigInfo(final Context context, InforsConfig config, final IViewEditor
            .OnSuccess
            callback) {
        Call<ResponseBody> call = service.getConfigInfo(config.getAppKey());
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        callback.onSuccess(response.body().string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                uploadEvents(context);
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                uploadEvents(context);
            }
        });
    }


    /**
     * 获取sdk 配置开关
     *
     * @param callback
     */
    public void getSwith(Context context, InforsConfig config, final SDKSwitchHandler.NetResponse
            callback) {
        Call<SdkSwitchRes> call = service.getSwith(config.getAppKey(), DeviceId.getDeviceId
                (context, config), Consts.PLATFORM, InforsUtil
                .getUserId
                        (context));
        call.enqueue(new Callback<SdkSwitchRes>() {
            @Override
            public void onResponse(Call<SdkSwitchRes> call, Response<SdkSwitchRes> response) {
                if (response.isSuccessful()
                        && response.body() != null
                        && TextUtils.equals(response.body().getCode(), SUCCESSCODE)) {
                    callback.onSuccess(response.body().getBody());
                } else {
                    callback.onFailure();
                }
            }

            @Override
            public void onFailure(Call<SdkSwitchRes> call, Throwable t) {
                callback.onFailure();
            }

        });
    }


    /**
     * 可视化的时候上传屏幕截图
     *
     * @param imagePath
     * @param callback
     */
    public void uploadPic(final String imagePath, final IViewEditor.OnSuccess callback) {
        File file = new File(imagePath);
        RequestBody requestFile =
                RequestBody.create(MediaType.parse("multipart/form-data"), file);
        MultipartBody.Part body =
                MultipartBody.Part.createFormData("file", file.getName(), requestFile);
        Call<ResponseBody> call = service.screenCast(body);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        String result = response.body().string();
                        Gson gson = new Gson();
                        BaseRes base = gson.fromJson(result, BaseRes.class);
                        if (TextUtils.equals(base.getCode(), Consts.SUCCESSCODE)) {
                            callback.onSuccess(base.getBody());
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });
    }


    private JsonArray formatEvents(List<EventEntity> list) {
//        BaseReq infors = new BaseReq();
        Gson gson = new Gson();

        List<JsonObject> inforslist = new ArrayList<>();
        for (EventEntity entity : list) {
//            BaseReq.EventsBean eventsBean = new BaseReq.EventsBean();

            if (!TextUtils.isEmpty(entity.getContent())) {
                String content = Base64Decode(entity.getContent());
                JsonObject jsonObject = gson.fromJson(content, JsonObject.class);
//            eventsBean.setEvent(jsonObject);
                if (content.contains(ReportField.config.name())) {
                    inforslist.add(jsonObject);
                }
            }

        }
//        infors.setEvents(inforslist);
        String jsonStr = gson.toJson(inforslist);
        JsonArray jsonObject = gson.fromJson(jsonStr, JsonArray.class);

        return jsonObject;
    }

    private JsonObject formatAPMEvents(Context context, List<APMEventEntity> list) {
        JsonObject eventObj = new JsonObject();
        Gson gson = new Gson();
        JsonArray jsonArray = new JsonArray();
        for (APMEventEntity entity : list) {

            if (!TextUtils.isEmpty(entity.getContent())) {
                String entityContent = Base64Decode(entity.getContent());
                JsonObject jsonObject = gson.fromJson(entityContent, JsonObject.class);
                jsonArray.add(jsonObject);
            }

        }
        eventObj.add("events", jsonArray);
        eventObj.addProperty(ReportField.deviceId.name(), DeviceId.getDeviceId(context, config));
        eventObj.addProperty(ReportField.sdkVersion.name(), SDK_VERSION);
        eventObj.addProperty(ReportField.appVersion.name(), config.getAppVersionName(context));
//        eventObj.addProperty(ReportField.appKey.name(), config.getAppKey());
        String appKeysStr = gson.toJson(config.getAppKeys());
        JsonParser jsonParser = new JsonParser();
        JsonElement jsonElement = jsonParser.parse(appKeysStr);
        eventObj.add(ReportField.appKeys.name(), jsonElement);
        eventObj.addProperty(ReportField.telephonyInfo.name(), DeviceUtils.getInstance(context)
                .operatorToCarrier());
        eventObj.addProperty(ReportField.deviceName.name(), config.getDeviceType(context));
        eventObj.addProperty(ReportField.osVersion.name(), InforsUtil.getOSVersion(context));
        eventObj.addProperty(ReportField.localIP.name(), DeviceUtils.getInstance
                (context).getIPAddress());
        eventObj.addProperty(ReportField.userId.name(), InforsUtil.getUserId(context));
        eventObj.addProperty(ReportField.appStartTime.name(), Hacker.sApplicationCreateBeginTime);
        return eventObj;
    }


    private List<EventEntity> getTopEventList(Context context) {
        List<EventEntity> list = null;
        try {
            list = InforsDatabase.getInstance(context).eventDao().getTopListEvents(THRESHOLD);
        } catch (Exception e) {
            Logger.d(Consts.TAG, e.getMessage());
        }
        return list;
    }

    private List<APMEventEntity> getTopAPMEventList(Context context) {
        List<APMEventEntity> list = null;
        try {
            list = InforsDatabase.getInstance(context).apmEventDao().getTopListEvents(THRESHOLD);
        } catch (Exception e) {
            Logger.d(Consts.TAG, e.getMessage());
        }
        return list;
    }

    /**
     * 上报日志
     *
     * @param context
     */
    public void uploadEvents(final Context context) {
        if (!isEventUploading.get()) {
            executor.execute(new Runnable() {
                @Override
                public void run() {
                    List<EventEntity> entityList = getTopEventList(context);
                    if (0 != entityList.size()) {
                        JsonArray jsonArray = formatEvents(entityList);
                        uploadEventList(context, jsonArray, entityList);
                    }
                }
            });
        }
    }

    /**
     * 上报APM日志
     * 默认跟在uploadEvents事件上传成功之后
     *
     * @param context
     */
    public void uploadAPMEvents(final Context context) {
        if (!isEventUploading.get()) {
            executor.execute(new Runnable() {
                @Override
                public void run() {
                    List<APMEventEntity> entityList = getTopAPMEventList(context);
                    if (0 != entityList.size()) {
                        JsonObject jsonArray = formatAPMEvents(context, entityList);
                        uploadAPMEventList(context, jsonArray, entityList);
                    }
                }
            });
        }
    }


    private void uploadEventList(final Context context, final JsonArray baseReq, final
    List<EventEntity> entityList) {
        isEventUploading.set(true);

        Call<BaseRes> call = service.issueReport(baseReq);
        call.enqueue(new Callback<BaseRes>() {
            @Override
            public void onResponse(Call<BaseRes> call, final Response<BaseRes> response) {
                isEventUploading.set(false);
                executor.execute(new Runnable() {
                    @Override
                    public void run() {
                        if (response.isSuccessful()) {
                            if (TextUtils.equals(response.body().getCode(),
                                    SUCCESSCODE) || TextUtils.equals(response.body().getMessage()
                                    , Consts.JSONERROR)) {
                                for (final EventEntity eventEntity : entityList) {
                                    try {
                                        InforsDatabase.getInstance(context).eventDao().delete
                                                (eventEntity);
                                    } catch (Exception e) {
                                        Logger.d(Consts.TAG, e.getMessage());
                                    }
                                }

                                executor.execute(new Runnable() {
                                    @Override
                                    public void run() {
                                        List<EventEntity> entityList = getTopEventList(context);
                                        if (0 != entityList.size()) {
                                            JsonArray jsonArray = formatEvents(entityList);
                                            uploadEventList(context, jsonArray, entityList);
                                        } else {
                                            uploadAPMEvents(context);
                                        }
                                    }
                                });
                            }

                        }
                    }
                });


            }

            @Override
            public void onFailure(Call<BaseRes> call, Throwable t) {
                isEventUploading.set(false);
//                mHandler.post(new Runnable() {
//                    @Override
//                    public void run() {
//                        List<EventEntity> entityList = getTopEventList(context);
//                        if (0 != entityList.size()) {
//                            JsonArray jsonArray = formatEvents(entityList);
//                            uploadEventList(context, jsonArray, entityList);
//                        } else {
//                            uploadAPMEvents(context);
//                        }
//                    }
//                });
            }
        });
    }


    public void webAPMReport(final JSAPMEvent jsapmEvent) {
        Gson gson = new Gson();
        String content = gson.toJson(jsapmEvent);
        Logger.i(TAG, "edited js 日志 ->" + content);
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"),
                content);
        Call<BaseRes> call = service.webApmReport(requestBody);
        call.enqueue(new Callback<BaseRes>() {
            @Override
            public void onResponse(Call<BaseRes> call, Response<BaseRes> response) {
            }

            @Override
            public void onFailure(Call<BaseRes> call, Throwable t) {
            }
        });
    }


    public void web4APMReport(final JsonObject jsonObject) {
        Logger.i(TAG, "edited js 日志4 ->" + jsonObject);

        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"),
                jsonObject.toString());
        Call<BaseRes> call = service.web4ApmReport(requestBody);
        call.enqueue(new Callback<BaseRes>() {
            @Override
            public void onResponse(Call<BaseRes> call, Response<BaseRes> response) {
            }

            @Override
            public void onFailure(Call<BaseRes> call, Throwable t) {
            }
        });
    }


    private void uploadAPMEventList(final Context context, final JsonObject jsonObject, final
    List<APMEventEntity> entityList) {
        isEventUploading.set(true);
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"),
                jsonObject.toString());
        Call<BaseRes> call = service.apmReport(requestBody);
        call.enqueue(new Callback<BaseRes>() {
            @Override
            public void onResponse(Call<BaseRes> call, final Response<BaseRes> response) {
                isEventUploading.set(false);

                executor.execute(new Runnable() {
                    @Override
                    public void run() {
                        if (response.isSuccessful()) {
                            if (TextUtils.equals(response.body().getCode(),
                                    SUCCESSCODE) || TextUtils.equals(response.body().getMessage()
                                    , Consts.JSONERROR)) {
                                for (final APMEventEntity eventEntity : entityList) {
                                    try {
                                        InforsDatabase.getInstance(context).apmEventDao().delete
                                                (eventEntity);
                                    } catch (Exception e) {
                                        Logger.d(Consts.TAG, e.getMessage());
                                    }

                                }


                                executor.execute(new Runnable() {
                                    @Override
                                    public void run() {
                                        List<APMEventEntity> entityList = getTopAPMEventList
                                                (context);
                                        if (0 != entityList.size()) {
                                            JsonObject jsonObject = formatAPMEvents(context,
                                                    entityList);
                                            uploadAPMEventList(context, jsonObject, entityList);
                                        }
                                    }
                                });
                            }

                        }
                    }
                });

            }

            @Override
            public void onFailure(Call<BaseRes> call, Throwable t) {
                isEventUploading.set(false);
//                mHandler.post(new Runnable() {
//                    @Override
//                    public void run() {
//                        List<APMEventEntity> entityList = getTopAPMEventList(context);
//                        if (0 != entityList.size()) {
//                            JsonObject jsonObject = formatAPMEvents(context, entityList);
//                            uploadAPMEventList(context, jsonObject, entityList);
//                        }
//                    }
//                });
            }
        });
    }

    public void uploadLogFiles(Context context, List<File> logFile, final LoganHelper.NetCallBack
            callback) {
        if (!isLogUploading.get()) {
            isLogUploading.set(true);
            Map<String, RequestBody> params = new HashMap<>();
            params.put("appKey", convertToRequestBody(config.getAppKey()));
            params.put("userId", convertToRequestBody(InforsUtil.getUserId(context)));
            params.put("deviceId", convertToRequestBody(DeviceId.getDeviceId(context, config)));

            List<MultipartBody.Part> parts = filesToMultipartBodyParts(logFile, callback);

            service.uploadLogFiles(params, parts)
                    .enqueue(new Callback<BaseRes>() {
                        @Override
                        public void onResponse(Call<BaseRes> call, Response<BaseRes> response) {
                            isLogUploading.set(false);
                            if (response.isSuccessful()) {
                                callback.onSuccess();
                            } else {
                                callback.onFailure("response.isSuccessful()-false");
                            }
                        }

                        @Override
                        public void onFailure(Call<BaseRes> call, Throwable t) {
                            isLogUploading.set(false);
                            callback.onFailure(t.getMessage().toString());
                        }
                    });
        }
    }

    static int fileLength;

    private static List<MultipartBody.Part> filesToMultipartBodyParts(List<File> filelist, final
    LoganHelper.NetCallBack callback) {
        List<MultipartBody.Part> parts = new ArrayList<>();

        for (File file : filelist) {
            fileLength += file.length();
//        }

//        for (String filePath : filelist) {
//            File file = new File(filePath);
            RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"),
                    file);

            ProgressRequestBody progressRequestBody = new ProgressRequestBody(requestBody, new
                    ProgressRequestBody.UploadProgressListener() {
                        @Override
                        public void onProgress(long currentBytesCount) {
                            setProgresshandler(fileLength, currentBytesCount, callback);
                        }
//                @Override
//                public void onProgress(long currentBytesCount, long totalBytesCount) {
//                    callback.onProgress(currentBytesCount, totalBytesCount, true);
//                }
                    });
            MultipartBody.Part part = MultipartBody.Part.createFormData("filelist", file.getName
                    ().replace(".copy", ".log"), progressRequestBody);
            parts.add(part);
        }

//        MultipartBody.Part part = MultipartBody.Part.createFormData("filelist", file.getName()
// .replace(".copy", ".log"), new ProgressRequestBody(requestBody, new ProgressRequestBody
// .UploadProgressListener() {
//            @Override
//            public void onProgress(long currentBytesCount, long totalBytesCount) {
//                callback.onProgress(currentBytesCount, totalBytesCount);
//            }
//        }));

        return parts;
    }

    static long preByte = 0;

    private static void setProgresshandler(long totalBytesCount, long currentByte, final
    LoganHelper.NetCallBack callback) {
        if (preByte > currentByte) {
            preByte += currentByte;
        }
        callback.onProgress(preByte, totalBytesCount);
        preByte = currentByte;
    }

    private RequestBody convertToRequestBody(String param) {
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain"), param);
        return requestBody;
    }

    interface APIService {
        @Headers({"Content-Type: application/json", "Accept: application/json"})
        @POST("log/v2/event")
        Call<BaseRes> issueReport(@Body JsonArray baseReq);

        @Headers({"Content-Type: application/json", "Accept: application/json"})
        @POST("/log/v2/apm/android")
        Call<BaseRes> apmReport(@Body RequestBody requestBody);


        @Headers({"Content-Type: application/json", "Accept: application/json"})
        @POST("/log/v1/apm/web")
        Call<BaseRes> webApmReport(@Body RequestBody requestBody);


        @Headers({"Content-Type: application/json", "Accept: application/json"})
        @POST("/log/v2/apm/web")
        Call<BaseRes> web4ApmReport(@Body RequestBody requestBody);


        @Multipart
        @POST("/api/v1/uploadSDK")
        Call<ResponseBody> screenCast(@Part MultipartBody.Part file);

        @Headers({"Content-Type: application/json", "Accept: application/json"})
        @GET("/api/v1/visual/sdk/cfg")
        Call<ResponseBody> getConfigInfo(@Query("appKey") String appKey);

        @Headers({"Content-Type: application/json", "Accept: application/json"})
        @GET("api/v2/switch")
        Call<SdkSwitchRes> getSwith(@Query("appKey") String appKey, @Query("deviceId") String
                deviceId, @Query("platform") String platform, @Query("userId") String userId);

        @Multipart
        @POST("/log/v1/phone/upload/userlog")
        Call<BaseRes> uploadLogFiles(@PartMap Map<String, RequestBody> partMap, @Part()
                List<MultipartBody.Part> parts);
    }


}
