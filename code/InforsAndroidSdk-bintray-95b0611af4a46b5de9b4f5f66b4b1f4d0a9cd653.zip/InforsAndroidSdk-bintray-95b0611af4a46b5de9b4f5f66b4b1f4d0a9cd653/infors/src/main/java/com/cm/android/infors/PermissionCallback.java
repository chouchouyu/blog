package com.cm.android.infors;

import android.support.annotation.Keep;

@Keep
public interface PermissionCallback {
    void onPermissionGranted();

    void onIndividualPermissionGranted(String grantedPermission[]);

    void onPermissionDenied();

    void onPermissionDeniedBySystem();
}