package com.cm.android.infors.core;


import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.cm.android.infors.request.modal.SignleApp;
import com.cm.android.infors.utils.DeviceUtils;
import com.cm.android.infors.utils.EncryptData;
import com.cm.android.infors.utils.SharedPreferencesFactory;


import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.cm.android.infors.core.Consts.SP_APP_LAUNCH;
import static com.cm.android.infors.core.Consts.SP_TO_BACKGROUND;
import static com.cm.android.infors.core.Consts.TAG;
import static com.cm.android.infors.utils.PrefUtils.*;

/**
 * Infors config
 *
 * @author wusm
 */

public class InforsConfig {

    private int requestIdMode;

    public void addSignleApp(String appkey, SignleApp signleApp) {
        appMap.put(appkey, signleApp);
    }

    public void setGlobalParams(String currentAppKey, Map<String, String> globalParams) {
        if (appMap.containsKey(currentAppKey)) {
            SignleApp app = appMap.get(currentAppKey);
            app.setGlobalMap(globalParams);
            appMap.remove(currentAppKey);
            appMap.put(currentAppKey, app);
        } else {
            Set<String> list = appMap.keySet();
            String keys = "";
            for (String appKey :
                    list) {
                keys += appKey + ", ";
            }
            Logger.e(TAG, "setGlobalParams -> appKey:" + currentAppKey + " is not contains in the" +
                    " map" + keys);
        }
    }

    public void setRequestIdMode(int requestIdMode) {
        this.requestIdMode = requestIdMode;
    }

    public int getRequestIdMode() {
        return requestIdMode;
    }

    private static class SingleTonHoler {
        private static InforsConfig INSTANCE = new InforsConfig();
    }

    public static InforsConfig getInstance() {
        return SingleTonHoler.INSTANCE;
    }


    public synchronized InforsConfig setAppKey(String appKey) {
        this.appKey = appKey;
        return this;
    }

    private Map<String, SignleApp> appMap;

    private String baseUrl;

    private InforsConfig() {
        if (null == this.appMap) {
            this.appMap = new HashMap<>();
        }
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    private final int sharedPreferencesMode = Context.MODE_PRIVATE;

    private final String sharedPreferencesName = Consts.SDK_NAME;


    private String appKey;


    @NonNull
    public String sharedPreferencesName() {
        return sharedPreferencesName;
    }

    public int sharedPreferencesMode() {
        return sharedPreferencesMode;
    }

    public String getAppKey() {
        return appKey;
    }

    public HashSet<String> getAppKeys() {
        HashSet set = new HashSet<String>();
        for (Map.Entry<String, SignleApp> entry : appMap.entrySet()) {
            set.add(entry.getKey());
            if (entry.getValue().getShareKeys() != null) {
                List<String> list = entry.getValue().getShareKeys();
                for (String shareKeys : list) {
                    set.add(shareKeys);
                }
            }
        }
        return set;

    }

    public long getAppLaunchTime(Context context) {
        return getLongFromSP(context, this, SP_APP_LAUNCH);
    }

    public void setAppLaunchTime(Context context, long appLaunchTime) {

        saveLongSP(context, this, SP_APP_LAUNCH, appLaunchTime);
    }

    public Map<String, SignleApp> getGlobalAppConfig(String appKey) {
        if (TextUtils.isEmpty(appKey)) {
            return appMap;
        } else {
            Map<String, SignleApp> signleAppMap = new HashMap<>();
            if (appMap.get(appKey) != null) {
                signleAppMap.put(appKey, appMap.get(appKey));
            }
            return signleAppMap;
        }
    }


    public void setGlobalParams(Map<String, String> globalParams) {
        this.setGlobalParams(appKey, globalParams);
    }

//    public String getDeviceId(Context context) {
//        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
//                this);
//        SharedPreferences prefs = sharedPreferencesFactory.create();
//        String deviceId = prefs.getString(Consts.SP_DEVICE_ID, "");
//        if (TextUtils.isEmpty(deviceId)) {
//            deviceId = EncryptData.getMD5(DeviceUtils.getInstance(context)
//                    .getDeviceData());
//
//            saveStringSP(context,
//                    this, Consts.SP_DEVICE_ID,
//                    deviceId);
//
//        }
//        return deviceId;
//    }

    public String getAppVersionName(Context context) {
        return DeviceUtils.getInstance(context).getAppVersionName();
    }

    public String getAppName(Context context) {
        return DeviceUtils.getInstance(context).getAppName();
    }

    private String getManufacturer(Context context) {
        return DeviceUtils.getInstance(context).getManufacturer();
    }

    private String getModel(Context context) {
        return DeviceUtils.getInstance(context).getModel();
    }

    public String getDeviceType(Context context) {
        return getManufacturer(context) + " " + getModel(context);
    }


    /**
     * requestId
     *
     * @param context
     * @return
     */
    public static String getRequestid(Context context) {
        String deviceId = EncryptData.getMD5(DeviceUtils.getInstance(context)
                .getDeviceData());
        return deviceId + System.currentTimeMillis();
    }
}
