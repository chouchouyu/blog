package com.cm.android.infors.apm.network;

import android.net.Uri;
import android.text.TextUtils;

import java.io.EOFException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.*;
import java.util.concurrent.TimeUnit;

import com.cm.android.infors.Infors;
import com.cm.android.infors.core.Consts;
import com.cm.android.infors.core.InforsConfig;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.core.ReportField;
import com.cm.android.infors.core.events.ActivityTracker;
import com.cm.android.infors.core.plugin.Plugin;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.utils.DeviceUtils;
import com.cm.android.infors.utils.InforsUtil;

import okhttp3.*;
import okhttp3.internal.http.HttpHeaders;
import okio.Buffer;
import okio.BufferedSource;
import okio.GzipSource;

import static com.cm.android.infors.core.Consts.MAX_BODY_LENGTH;
import static com.cm.android.infors.core.Consts.TYPE_HTTP;

/**
 * https://www.jianshu.com/p/44122b58a8fe
 *
 * @author wusm
 */
public final class InforsInterceptor implements Interceptor {

    private static final Charset UTF8 = Charset.forName("UTF-8");

    private void printEvent(String msg) {
        Logger.d(TAG, msg);

    }

    private static final String TAG = "Infors.Network";


    public InforsInterceptor() {

    }

    private static class SingletonHandler {
        private static InforsInterceptor singleton = new InforsInterceptor();

    }

    public static InforsInterceptor getInstance() {
        return SingletonHandler.singleton;
    }


    private static boolean isShouldCollect() {
        if (null == Infors.getInstance().getPluginByClass(HttpPlugin.class)) {
            return false;
        } else {
            return Infors.getInstance().getPluginByClass(HttpPlugin.class).isSupported();
        }

    }


    @Override
    public Response intercept(Chain chain) throws IOException {
        boolean isJsonRequest = false;
        Request request = chain.request();
        if (!isShouldCollect()) {
            return chain.proceed(request);
        }
        //不是json格式的不采集
        if (request.body() != null && request.body().contentType() != null && !request.body()
                .contentType().subtype().contains("json")) {
            return chain.proceed(request);
        }
        HttpPlugin plugin = Infors.getInstance().getPluginByClass(HttpPlugin.class);
        if (plugin == null) {
            return chain.proceed(request);
        }

        String requestId = InforsConfig.getRequestid(plugin.getApplication());
        InforsConfig config = InforsConfig.getInstance();
        OkHttpData mOkHttpData = new OkHttpData();
        mOkHttpData.setNet_operator(DeviceUtils.getInstance(ActivityTracker.get()
                .tryGetTopActivity()).getDetailNetworkTypeForStatic());
        mOkHttpData.setResponseFail(false);
        RequestBody requestBody = request.body();
        boolean hasRequestBody = requestBody != null;

        Connection connection = chain.connection();

        mOkHttpData.setUrl(request.url().toString());

        String requestStartMessage = "--> "
                + request.method()
                + ' ' + request.url()
                + (connection != null ? " " + connection.protocol() : "");
        if (hasRequestBody) {
            mOkHttpData.setRequest_bytes(requestBody.contentLength());
            requestStartMessage += " (" + requestBody.contentLength() + "-byte body)";
        }
        printEvent(requestStartMessage);

        if (hasRequestBody) {
            // Request body headers are only present when installed as a network interceptor. Force
            // them to be included (when available) so there values are known.
            if (requestBody.contentType() != null) {
                //form-data //json
                if (request.body()
                        .contentType().subtype().contains("json")) {
                    isJsonRequest = true;
                }
                Logger.d(TAG, "equest.body().contentType().subtype :" + request.body()
                        .contentType().subtype());
                printEvent("Content-Type: " + requestBody.contentType());
            }
            if (requestBody.contentLength() != -1) {
                mOkHttpData.setRequest_bytes(requestBody.contentLength());
                printEvent("Content-Length: " + requestBody.contentLength());
            }
        }


        //todo requestId
//        String requestId = String.valueOf(System.nanoTime()) + Math.floor(Math.random() * 999999);
//
//        mOkHttpData.setRequest_id(requestId);
//
        Request.Builder builder = request.newBuilder();

        Logger.d("RequestId:========" + config.getRequestIdMode());
        switch (config.getRequestIdMode()) {
            case 2:
                break;
            case 1:
                String oldUrl = mOkHttpData.getUrl();
                Uri uri = Uri.parse(oldUrl);
                if (TextUtils.isEmpty(uri.getQuery())) {
                    oldUrl = oldUrl.concat("?");
                } else {
                    oldUrl = oldUrl.concat("&");
                }

                oldUrl = oldUrl.concat(ReportField.tRequestId.name() + "=" + requestId);
                mOkHttpData.setUrl(oldUrl);
                request = builder.url(new URL(oldUrl)).build();
                break;
            case 0:
            default:
                request = builder
                        .addHeader(ReportField.tRequestId.name(), requestId)
                        .build();
                break;
        }


        Headers headers = request.headers();
        Map<String, Object> headerMap = new HashMap<>();
        for (int i = 0, count = headers.size(); i < count; i++) {
            String name = headers.name(i);
            // Skip headers from the request body as they are explicitly logged above.
            if (!"Content-Type".equalsIgnoreCase(name) && !"Content-Length".equalsIgnoreCase
                    (name)) {
                printEvent(name + ": " + headers.value(i));
                headerMap.put(name, headers.value(i));
            }
        }
        mOkHttpData.setHeaders(headerMap);

        if (!hasRequestBody) {
            printEvent("--> END " + request.method());
        } else if (bodyHasUnknownEncoding(request.headers())) {
            printEvent("--> END " + request.method() + " (encoded body omitted)");
        } else {
            Buffer buffer = new Buffer();
            requestBody.writeTo(buffer);

            Charset charset = UTF8;
            MediaType contentType = requestBody.contentType();
            if (contentType != null) {
                charset = contentType.charset(UTF8);
            }

            printEvent("");
            if (isPlaintext(buffer)) {
                printEvent(buffer.readString(charset));
                printEvent("--> END " + request.method()
                        + " (" + requestBody.contentLength() + "-byte body)");
                mOkHttpData.setRequest_bytes(requestBody.contentLength());
                if (mOkHttpData.getRequest_bytes() < 1000 && isJsonRequest) {
                    mOkHttpData.setRequestBody(buffer.readString(charset));
                }
            } else {
                printEvent("--> END " + request.method() + " (binary "
                        + requestBody.contentLength() + "-byte body omitted)");
                mOkHttpData.setRequest_bytes(requestBody.contentLength());
            }
        }

        mOkHttpData.setRequestTime(System.currentTimeMillis());
        long startNs = System.nanoTime();

        InetAddress server;
        if (connection != null) {
            server = connection.route().socketAddress().getAddress();
            mOkHttpData.setRemote_ip(server.toString());
        }

        Response response;
        try {
            response = chain.proceed(request);
        } catch (Exception e) {
            mOkHttpData.setFail_msg(e.toString());
            mOkHttpData.setResponseFail(true);
            printEvent("<-- HTTP FAILED: " + e);
            doReportHttpResult(mOkHttpData, plugin, requestId);
            throw e;
        }
        long tookTime = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startNs);
        mOkHttpData.setTakeTime(tookTime);
        mOkHttpData.setCostTime(tookTime);


        ResponseBody responseBody = response.body();
        long contentLength = responseBody.contentLength();

        mOkHttpData.setResponse_bytes(contentLength);

        String bodySize = contentLength != -1 ? contentLength + "-byte" : "unknown-length";

        mOkHttpData.setResponse_code(response.code());

        printEvent("<-- "
                + response.code()
                + (response.message().isEmpty() ? "" : ' ' + response.message())
                + ' ' + response.request().url()
                + " (" + tookTime + "ms" + (", " + bodySize + " body") + ')');

        Headers respHeaders = response.headers();
        for (int i = 0, count = respHeaders.size(); i < count; i++) {
            printEvent(respHeaders.name(i) + ": " + respHeaders.value(i));
        }

        if (!HttpHeaders.hasBody(response)) {
            printEvent("<-- END HTTP");
        } else if (bodyHasUnknownEncoding(response.headers())) {
            printEvent("<-- END HTTP (encoded body omitted)");
        } else {
            BufferedSource source = responseBody.source();
            source.request(Long.MAX_VALUE); // Buffer the entire body.
            Buffer buffer = source.buffer();

            Long gzippedLength = null;
            if ("gzip".equalsIgnoreCase(respHeaders.get("Content-Encoding"))) {
                gzippedLength = buffer.size();
                GzipSource gzippedResponseBody = null;
                try {
                    gzippedResponseBody = new GzipSource(buffer.clone());
                    buffer = new Buffer();
                    buffer.writeAll(gzippedResponseBody);
                } finally {
                    if (gzippedResponseBody != null) {
                        gzippedResponseBody.close();
                    }
                }
            }

            Charset charset = UTF8;
            MediaType contentType = responseBody.contentType();
            if (contentType != null) {
                charset = contentType.charset(UTF8);
            }

            if (!isPlaintext(buffer)) {
                printEvent("");
                mOkHttpData.setResponse_bytes(buffer.size());
                printEvent("<-- END HTTP (binary " + buffer.size() + "-byte body omitted)");
                return response;
            }

            if (contentLength != 0) {
                printEvent("");
                printEvent(buffer.clone().readString(charset));
                if (contentLength < 1000) {
                    mOkHttpData.setResponseBody(buffer.clone().readString(charset));
                }
            }

            if (gzippedLength != null) {
                mOkHttpData.setResponse_bytes(buffer.size());
                printEvent("<-- END HTTP (" + buffer.size() + "-byte, "
                        + gzippedLength + "-gzipped-byte body)");
            } else {
                mOkHttpData.setResponse_bytes(buffer.size());
                printEvent("<-- END HTTP (" + buffer.size() + "-byte body)");
            }
        }
        doReportHttpResult(mOkHttpData, plugin, requestId);
        return response;
    }


    /**
     * deviceId + (new Date()).getTime() + Math.floor(Math.random() * 999999)
     *
     * @param mOkHttpData
     */
    private void doReportHttpResult(OkHttpData mOkHttpData, Plugin plugin, String requestId) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ReportField.netOperator.name(), mOkHttpData.getNet_operator());
        map.put(ReportField.url.name(), mOkHttpData.getUrl());
        map.put(ReportField.occurTime.name(), mOkHttpData.getRequestTime());
        map.put(ReportField.costTime.name(), mOkHttpData.getTakeTime());
        map.put(ReportField.responseCode.name(), mOkHttpData.getResponse_code());
        map.put(ReportField.requestBytes.name(), mOkHttpData.getRequest_bytes());
        map.put(ReportField.responseBytes.name(), mOkHttpData.getResponse_bytes());
        map.put(ReportField.isSlowRequest.name(), mOkHttpData.isSlowRequest());
        map.put(ReportField.remoteIp.name(), mOkHttpData.getRemote_ip());
        map.put(ReportField.failMsg.name(), mOkHttpData.getFail_msg());
        map.put(ReportField.isResponseFail.name(), mOkHttpData.isResponseFail());
        if (!TextUtils.isEmpty(mOkHttpData.getRequestBody()) && shouldADDbody(mOkHttpData)) {
            if (mOkHttpData.getRequestBody().length() > Consts.MAX_BODY_LENGTH) {
                map.put(ReportField.requestBody.name(), mOkHttpData.getRequestBody().substring(0,
                        Consts.MAX_BODY_LENGTH));
            } else {
                map.put(ReportField.requestBody.name(), mOkHttpData.getRequestBody());
            }
        } else {
            map.put(ReportField.requestBody.name(), "");
        }

        if (!TextUtils.isEmpty(mOkHttpData.getResponseBody()) && shouldADDbody(mOkHttpData)) {
            if (mOkHttpData.getResponseBody().length() > Consts.MAX_BODY_LENGTH) {
                map.put(ReportField.responseBody.name(), mOkHttpData.getResponseBody().substring
                        (0, MAX_BODY_LENGTH));
            } else {
                map.put(ReportField.responseBody.name(), mOkHttpData.getResponseBody());
            }
        } else {
            map.put(ReportField.responseBody.name(), "");
        }

        if (mOkHttpData.getHeaders() != null && shouldADDbody(mOkHttpData)) {
            map.put(ReportField.headField.name(), InforsUtil.mapToJson(mOkHttpData.getHeaders())
                    .toString()
            );
        } else {
            map.put(ReportField.headField.name(), "");
        }
        map.put(ReportField.requestId.name(), requestId);
        Issue issue = new Issue(TYPE_HTTP, map, plugin);
        plugin.onDetectIssue(issue);
    }

    private boolean shouldADDbody(OkHttpData mOkHttpData) {
        if (!mOkHttpData.isSlowRequest()
                && mOkHttpData.getResponse_code() == 200
                && !mOkHttpData.isResponseFail()) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Returns true if the body in question probably contains human readable text. Uses a small
     * sample
     * of code points to detect unicode control characters commonly used in binary file signatures.
     */
    static boolean isPlaintext(Buffer buffer) {
        try {
            Buffer prefix = new Buffer();
            long byteCount = buffer.size() < 64 ? buffer.size() : 64;
            buffer.copyTo(prefix, 0, byteCount);
            for (int i = 0; i < 16; i++) {
                if (prefix.exhausted()) {
                    break;
                }
                int codePoint = prefix.readUtf8CodePoint();
                if (Character.isISOControl(codePoint) && !Character.isWhitespace(codePoint)) {
                    return false;
                }
            }
            return true;
        } catch (EOFException e) {
            return false; // Truncated UTF-8 sequence.
        }
    }

    private boolean bodyHasUnknownEncoding(Headers headers) {
        String contentEncoding = headers.get("Content-Encoding");
        return contentEncoding != null
                && !contentEncoding.equalsIgnoreCase("identity")
                && !contentEncoding.equalsIgnoreCase("gzip");
    }


}
