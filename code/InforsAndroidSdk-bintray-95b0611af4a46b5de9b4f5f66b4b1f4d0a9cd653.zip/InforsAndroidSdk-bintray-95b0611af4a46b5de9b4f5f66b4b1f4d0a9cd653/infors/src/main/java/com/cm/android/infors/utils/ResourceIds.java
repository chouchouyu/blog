package com.cm.android.infors.utils;

/**
 * @author wusm
 */

public interface ResourceIds {
    boolean knownIdName(String name);

    int idFromName(String name);

    String nameForId(int id);
}
