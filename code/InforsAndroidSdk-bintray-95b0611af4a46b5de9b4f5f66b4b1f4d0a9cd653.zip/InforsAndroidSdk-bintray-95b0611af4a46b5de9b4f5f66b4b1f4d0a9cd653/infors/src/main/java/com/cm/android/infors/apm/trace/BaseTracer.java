package com.cm.android.infors.apm.trace;

import android.os.Process;
import com.cm.android.infors.apm.trace.listeners.IFrameBeatListener;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.core.events.ActivityTracker;
import com.cm.android.infors.core.report.IssuePublisher;

import java.util.HashMap;

public abstract class BaseTracer extends IssuePublisher implements IFrameBeatListener {
    private static final String TAG = "Infors.BaseTracer";

    public TracePlugin getPlugin() {
        return mPlugin;
    }

    private final TracePlugin mPlugin;
    private static final HashMap<Class<BaseTracer>, BaseTracer> sTracerMap = new HashMap<>();
    private boolean isCreated = false;
    private String mScene;

    BaseTracer(TracePlugin plugin) {
        super(plugin);
        this.mPlugin = plugin;
        sTracerMap.put((Class<BaseTracer>) this.getClass(), this);
    }

    public <T extends BaseTracer> T getTracer(Class<T> clazz) {
        return (T) sTracerMap.get(clazz);
    }

    protected boolean isEnableMethodBeat() {
        return false;
    }

    public void onCreate() {
        Logger.i(TAG, "[onCreate] name:%s process:%s", this.getClass().getCanonicalName(), Process.myPid());
        FrameBeat.getInstance().addListener(this);
        isCreated = true;
    }

    public void onDestroy() {
        Logger.i(TAG, "[onDestroy] name:%s  process:%s", this.getClass().getCanonicalName(), Process.myPid());
        FrameBeat.getInstance().removeListener(this);
        isCreated = false;
    }

    protected String getScene() {
        return ActivityTracker.get().tryGetTopActivity().getClass().getCanonicalName();
    }

    @Override
    public void doFrame(long lastFrameNanos, long frameNanos) {
    }

    @Override
    public void cancelFrame() {
        //FrameTracer
    }

}
