package com.cm.android.infors.apm.trace;

import android.os.Looper;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Error thrown by {@link com.cm.android.infors.apm.trace.BlockError} when an ANR is detected.
 * Contains the stack trace of the frozen UI thread.
 * <p>
 * It is important to notice that, in an ANRError, all the "Caused by" are not really the cause
 * of the exception. Each "Caused by" is the stack trace of a running thread. Note that the main
 * thread always comes first.
 */
public class BlockError extends Error {

    private static class $ implements Serializable {
        private final String _name;
        private final StackTraceElement[] _stackTrace;

        private class _Thread extends Throwable {
            private _Thread(_Thread other) {
                super(_name, other);
            }

            @Override
            public Throwable fillInStackTrace() {
                setStackTrace(_stackTrace);
                return this;
            }
        }

        private $(String name, StackTraceElement[] stackTrace) {
            _name = name;
            _stackTrace = stackTrace;
        }


    }

    private static final long serialVersionUID = 1L;

    /**
     * The minimum duration, in ms, for which the main thread has been blocked. May be more.
     */
    @SuppressWarnings("WeakerAccess")
    public final long droppedFrames;
    private final boolean isANR;
    private final String screen;
    private final String thread;

    private BlockError($._Thread st, long droppedFrames, String screen, boolean isANR, String thread, String cause) {
        super(cause, st);
        this.droppedFrames = droppedFrames;
        this.screen = screen;
        this.isANR = isANR;
        this.thread = thread;
    }

//    private BlockError($._Thread st, long droppedFrames, String screen, boolean isANR, String thread) {
//        super("Skipped " + droppedFrames + " frames!  "
//                + "The application may be doing too much work on its main thread.", st);
//        this.droppedFrames = droppedFrames;
//        this.screen = screen;
//        this.isANR = isANR;
//        this.thread = thread;
//    }
//
//    public BlockError(long droppedFrames, String screen, boolean isANR, String thread) {
//        super("your app has occur a block exception in page" + screen + ",skipped frame: " + droppedFrames);
//        this.droppedFrames = droppedFrames;
//        this.screen = screen;
//        this.isANR = isANR;
//        this.thread = thread;
//    }

    public String getScreen() {
        return screen;
    }

    public String getThread() {
        return thread;
    }

    @Override
    public Throwable fillInStackTrace() {
        setStackTrace(new StackTraceElement[]{});
        return this;
    }

//    static BlockError NewMainOnly(long droppedFrames, String screen, boolean isANR) {
//        final Thread mainThread = Looper.getMainLooper().getThread();
//        String thread = getThreadTitle(mainThread);
//        BlockError error;
//        if (isANR) {
//            final StackTraceElement[] mainStackTrace = mainThread.getStackTrace();
//            error = new BlockError(new $(thread, mainStackTrace).new _Thread(null), droppedFrames, screen, isANR, thread);
//        } else {
//            error = new BlockError(droppedFrames, screen, isANR, thread);
//        }
//
//        return error;
//    }


    static BlockError New(long droppedFrames, String screen, boolean isANR) {
        final Thread mainThread = Looper.getMainLooper().getThread();
        String thread = getThreadTitle(mainThread);
        final Map<Thread, StackTraceElement[]> stackTraces = new TreeMap<Thread, StackTraceElement[]>(new Comparator<Thread>() {
            @Override
            public int compare(Thread lhs, Thread rhs) {
                if (lhs == rhs)
                    return 0;
                if (lhs == mainThread)
                    return 1;
                if (rhs == mainThread)
                    return -1;
                return rhs.getName().compareTo(lhs.getName());
            }
        });


        $._Thread tst = null;
        for (Map.Entry<Thread, StackTraceElement[]> entry : stackTraces.entrySet())
            tst = new $(getThreadTitle(entry.getKey()), entry.getValue()).new _Thread(tst);

        String msg;
        if (isANR) {
            msg = "Skipped " + droppedFrames + " frames!  "
                    + "The application may be doing too much work on its main thread.";
        } else {
            msg = "your app has occur a block exception in page" + screen + ",skipped frame: " + droppedFrames;
        }

        return new BlockError(tst, droppedFrames, screen, isANR, thread, msg);
    }




    private static String getThreadTitle(Thread thread) {
        return " thread = " + thread.getName() + " (threadId = " + thread.getId() + " , state = " + thread.getState() + ")";
    }
}