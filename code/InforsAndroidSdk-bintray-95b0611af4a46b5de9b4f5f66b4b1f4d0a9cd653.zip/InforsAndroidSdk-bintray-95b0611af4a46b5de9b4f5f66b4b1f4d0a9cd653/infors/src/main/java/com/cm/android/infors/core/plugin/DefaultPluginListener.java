package com.cm.android.infors.core.plugin;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;

import com.cm.android.infors.Infors;
import com.cm.android.infors.apm.crash.CrashPlugin;
import com.cm.android.infors.apm.network.HttpPlugin;
import com.cm.android.infors.apm.trace.TracePlugin;
import com.cm.android.infors.core.*;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.core.thread.InforsHandlerThread;
import com.cm.android.infors.db.APMEventEntity;
import com.cm.android.infors.db.EventEntity;
import com.cm.android.infors.db.InforsDatabase;
import com.cm.android.infors.utils.DeviceId;
import com.cm.android.infors.utils.EncryptData;
import com.cm.android.infors.utils.InforsUtil;
import com.cm.android.infors.utils.SharedPreferencesFactory;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

import static com.cm.android.infors.core.Consts.*;
import static com.cm.android.infors.utils.EncryptData.Base64Encode;
import static com.cm.android.infors.utils.PrefUtils.*;

/**
 * @author wusm
 */

public class DefaultPluginListener implements PluginListener {
    private static final String TAG = "Infors.DefaultPluginListener";
    private final ThreadPoolExecutor executor;

    private final Context context;

    private InforsConfig config;

    public DefaultPluginListener(Context context, InforsConfig confige, ThreadPoolExecutor
            executor) {
        this.context = context;
        this.config = confige;
        this.executor = executor;
    }

    @Override
    public void onInit(Plugin plugin) {
        Logger.i(TAG, "%s plugin is inited", plugin.getTag());
    }

    @Override
    public void onStart(Plugin plugin) {
        Logger.i(TAG, "%s plugin is started", plugin.getTag());
    }

    @Override
    public void onStop(Plugin plugin) {
        Logger.i(TAG, "%s plugin is stopped", plugin.getTag());
    }

    @Override
    public void onDestroy(Plugin plugin) {
        Logger.i(TAG, "%s plugin is destroyed", plugin.getTag());
    }

    @Override
    public void onReportIssue(Issue issue) {
        String eventType = null;
        JsonObject jsonObject = null;

        if (issue.getPlugin() instanceof InitialPlugin) {
            eventType = issue.getType();
            if (null != issue.getJsonObject() && TextUtils.equals(issue.getType(), TYPE_JS)) {
                jsonObject = issue.getJsonObject();
            } else {
                jsonObject = new JsonObject();
                if (null != issue.getJsonObject() && TextUtils.equals(issue.getType(), TYPE_USER)) {
                    JsonObject userJson = issue.getJsonObject();

//                    if (config.getGlobalParams() != null
//                            && config.getGlobalParams().size() > 0) {
//                        Map<String, String> globalParams = config.getGlobalParams();
//                        for (String key : globalParams.keySet()) {
//                            userJson.addProperty(key, globalParams.get(key));
//                        }
//                    }

                    jsonObject.add("data", userJson);
                    jsonObject.add("config", InforsUtil.getConfigJson(config, issue.getAppkey()));


                } else {
                    Map<String, Object> map = issue.getContentMap();

//                    if (config.getGlobalParams() != null
//                            && config.getGlobalParams().size() > 0) {
//                        Map<String, String> globalParams = config.getGlobalParams();
//                        for (String key : globalParams.keySet()) {
//                            map.put(key, globalParams.get(key));
//                        }
//                    }

                    jsonObject.add("data", InforsUtil.mapToJson(map));
                    jsonObject.add("config", InforsUtil.getConfigJson(config, issue.getAppkey()));

                }
                String eventId = getMD5EventId(issue);
                jsonObject.addProperty(ReportField.eventId.name(), eventId);
                jsonObject.addProperty(ReportField.eventType.name(), issue.getType());
                jsonObject.addProperty(ReportField.timestamp.name(), issue.getTimestamp());
                jsonObject.addProperty(ReportField.appKey.name(), getAppKey(issue));
                jsonObject.addProperty(ReportField.sessionId.name(), InforsUtil.getSessionId
                        (context, config, getAppKey(issue)));
                jsonObject.addProperty(ReportField.deviceId.name(), DeviceId.getDeviceId(context,
                        config));
                jsonObject.addProperty(ReportField.sdkVersion.name(), SDK_VERSION);
                jsonObject.addProperty(ReportField.appVersion.name(), config.getAppVersionName
                        (context));
                if (!TextUtils.isEmpty(InforsUtil.getUserId(context))) {
                    jsonObject.addProperty(ReportField.userId.name(), InforsUtil.getUserId
                            (context));
                }
                jsonObject.addProperty(ReportField.platform.name(), PLATFORM);
                eventIdHandler(eventId);
                jsonObject.addProperty(ReportField.preEventId.name(), previousEventId);

            }
            //todo
        }

        if (isAPMPlugin(issue.getPlugin())) {
            JsonObject eventObj = new JsonObject();
            Map<String, Object> map = issue.getContentMap();
            eventObj.add(issue.getType(), InforsUtil.mapToJson(map));
            eventType = issue.getType();
            jsonObject = eventObj;
        }

        if (!TextUtils.isEmpty(eventType) && null != jsonObject) {
            saveToDB(eventType, jsonObject, issue.getPlugin());
        }

    }

    private boolean isAPMPlugin(Plugin plugin) {
        if (plugin instanceof CrashPlugin || plugin instanceof HttpPlugin || plugin instanceof
                TracePlugin) {
            return true;
        } else {
            return false;
        }
    }


    private void saveToDB(final String type, JsonObject eventObj, final Plugin plugin) {
        Logger.i(TAG, "日志 ->" + eventObj.toString());
        final String json = new Gson().toJson(eventObj);

//        executor.execute(new Runnable() {
//            @Override
//            public void run() {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if (isAPMPlugin(plugin)) {
                        APMEventEntity eventEntity = new APMEventEntity();
                        eventEntity.setTime(new Date(System.currentTimeMillis()));
                        eventEntity.setContent(Base64Encode(json));
                        eventEntity.setEventType(type);
                        InforsDatabase.getInstance(context).apmEventDao().insert(eventEntity);
                    } else {
                        EventEntity eventEntity = new EventEntity();
                        eventEntity.setTime(new Date(System.currentTimeMillis()));
                        eventEntity.setContent(Base64Encode(json));
                        eventEntity.setEventType(type);
                        InforsDatabase.getInstance(context).eventDao().insert(eventEntity);

                    }
                } catch (Exception e) {
                    Logger.d(Consts.TAG, e.getMessage());
                }

            }

        });
    }


    /**
     * eventId 规则 （deviceId + 13位时间戳 + 3位随机数）32bit_md5
     */
    private String getMD5EventId(Issue issue) {
        int randomNum = 100 + (int) (Math.random() * 900);
        StringBuffer sb = new StringBuffer();
        sb.append(DeviceId.getDeviceId(context, config)).append(issue.getTimestamp()).append
                (randomNum);
        return EncryptData.getMD5(sb.toString());
    }

    private String getAppKey(Issue issue) {
        if (issue.getAppkey() == null) {
            return config.getAppKey();
        } else {
            return issue.getAppkey();
        }
    }

    String previousEventId;
    String eventId;

    private void eventIdHandler(String eventId) {
        this.previousEventId = this.eventId;
        this.eventId = eventId;
    }


}
