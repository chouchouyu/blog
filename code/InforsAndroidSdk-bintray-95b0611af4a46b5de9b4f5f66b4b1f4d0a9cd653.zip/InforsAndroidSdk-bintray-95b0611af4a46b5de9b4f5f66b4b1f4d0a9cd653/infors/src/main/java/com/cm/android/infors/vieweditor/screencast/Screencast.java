package com.cm.android.infors.vieweditor.screencast;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.view.View;


import com.cm.android.infors.core.InforsConfig;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.core.events.ActivityTracker;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.cm.android.infors.core.Consts.TAG;

/**
 * 可视化 截屏功能
 * Created by wusm on 2018/8/6.
 */

public final class Screencast {
    private static final long FRAME_DELAY = 200L;

    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private final BitmapFetchRunnable mBitmapFetchRunnable = new BitmapFetchRunnable();
    private final ActivityTracker mActivityTracker = ActivityTracker.get();
    private final RectF mTempSrc = new RectF();
    private final RectF mTempDst = new RectF();
    private final InforsConfig config;
    private String activityName;
    private boolean mIsRunning;
    private HandlerThread mHandlerThread;
    private Bitmap mBitmap;
    private Canvas mCanvas;


    int destWidth;
    int destHeight;
    private Activity activity;

    public Screencast(InforsConfig config, ScreenCastSavedListener screenCastSaved) {
        this.config = config;
        this.screenCastSaved = screenCastSaved;
    }

    public void startScreencast(Activity activity) {
        this.activity = activity;
        Logger.w(TAG, "===== Starting screencast =====");

        mHandlerThread = new HandlerThread("Screencast Thread");
        mHandlerThread.start();
        mIsRunning = true;
        mMainHandler.postDelayed(mBitmapFetchRunnable, FRAME_DELAY);
    }

    private class BitmapFetchRunnable implements Runnable {
        @Override
        public void run() {
            updateScreenBitmap();
        }

        private void updateScreenBitmap() {
            if (!mIsRunning) {
                return;
            }

            if (activity == null) {
                return;
            }

            // This stuff needs to happen in the UI thread
            View rootView = activity.getWindow().peekDecorView();
            try {
                if (mBitmap == null) {
                    int viewWidth = rootView.getWidth();
                    int viewHeight = rootView.getHeight();
                    float scale = 1;
                    destWidth = (int) (viewWidth * scale);
                    destHeight = (int) (viewHeight * scale);
                    if (destHeight <= 0 && destWidth <= 0) {
                        return;
                    }
                    mBitmap = Bitmap.createBitmap(destWidth, destHeight, Bitmap.Config.RGB_565);
                    mCanvas = new Canvas(mBitmap);
                    Matrix matrix = new Matrix();
                    mTempSrc.set(0, 0, viewWidth, viewHeight);
                    mTempDst.set(0, 0, destWidth, destHeight);
                    matrix.setRectToRect(mTempSrc, mTempDst, Matrix.ScaleToFit.CENTER);
                    mCanvas.setMatrix(matrix);
                }
                rootView.draw(mCanvas);
                save(mBitmap, activity);
            } catch (OutOfMemoryError e) {
                Logger.e(TAG, "Out of memory trying to allocate screencast Bitmap.");
            }
        }
    }


    private void save(final Bitmap mBitmap, Activity context) {
        activityName = context.getClass().getCanonicalName();
        File rootfile = new File(context.getFilesDir() + File.separator + this.getClass()
                .getSimpleName());
        if (!rootfile.exists()) {
            rootfile.mkdirs();
        }
        final File file = new File(rootfile + File.separator + activityName
                + getDate() + ".png");


        new Thread(new Runnable() {
            @Override
            public void run() {
                FileOutputStream out;
                try {
                    out = new FileOutputStream(file);
                    if (mBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                        out.flush();
                        out.close();
                    }

                    Message message = new Message();
                    message.what = SAVEPIC;
                    message.obj = file.getAbsolutePath();
                    myHandler.sendMessage(message);

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();


    }

    private String getDate() {
        Date date = new Date();
        DateFormat format5 = new SimpleDateFormat("yyyyMMddhhmmss");
        return format5.format(date);
    }

    public static final int SAVEPIC = 0x09;
//    String prePath;

    Handler myHandler = new Handler() {


        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SAVEPIC:
                    String picPath = (String) msg.obj;
                    Logger.i(TAG, "Screen Capture ->:saved path ->" + picPath);
                    callback(picPath);
                    break;
            }
            super.handleMessage(msg);
        }

        private void callback(String picPath) {
            if (screenCastSaved != null) {
                screenCastSaved.onScreenCastSaved(activityName, picPath);
            }
        }
    };


    private ScreenCastSavedListener screenCastSaved;

    public interface ScreenCastSavedListener {
        void onScreenCastSaved(String activityName, String picPath);

    }


}
