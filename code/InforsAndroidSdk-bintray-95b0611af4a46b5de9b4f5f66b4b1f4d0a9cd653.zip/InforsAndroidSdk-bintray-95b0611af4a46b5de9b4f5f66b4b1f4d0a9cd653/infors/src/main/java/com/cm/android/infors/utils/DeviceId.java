package com.cm.android.infors.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.cm.android.infors.core.Consts;
import com.cm.android.infors.core.InforsConfig;
import com.cm.android.infors.core.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.UUID;

import static com.cm.android.infors.utils.PrefUtils.saveStringSP;

/**
 * 用于生成设备ID
 * https://www.jianshu.com/p/471df87af749
 * https://blog.csdn.net/jiangtea/article/details/72889018
 *
 * @author lijian on 2018/1/21.
 */

public class DeviceId {

    private static final String TAG = Consts.TAG;

    //保存文件的路径
    private static final String CM_CACHE = "Infors";
    //保存的文件 采用隐藏文件的形式进行保存
    private static final String DEVICES_FILE_NAME = ".DEVICES";

    /**
     * 获取AndroidId
     * 这个每一次设备恢复出厂设置的时候会改变
     *
     * @param context
     * @return
     */
    private static String getAndroidId(Context context) {
        String androidId = Settings.System.getString(context.getContentResolver(), Settings
                .Secure.ANDROID_ID);
        Logger.d(TAG, "DeviceId:getAndroidId()=" + androidId);
        return androidId;
    }

    /**
     * 获取序列号
     * 注意必须获取权限Manifest.permission.READ_PHONE_STATE
     * 这个权限6.0以上需要动态获取
     *
     * @param context
     * @return
     */
    private static String getSerialNumber(Context context) throws SecurityException {
        String serialNumber = "";
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            serialNumber = Build.getSerial();
        } else {
            serialNumber = android.os.Build.SERIAL;
        }
        Logger.d(TAG, "DeviceId:getSerialNumber=" + serialNumber);
        return serialNumber;
    }

    /**
     * 获取设备的DeviceId(IMES) 这里需要相应的权限<br/>
     * 需要 READ_PHONE_STATE 权限
     * 这个权限6.0以上需要动态获取
     *
     * @param context
     * @return
     */
    private static String getIMIE(Context context) throws SecurityException {
        TelephonyManager tm = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
        String deviceId = tm.getDeviceId();
        Logger.d(TAG, "DeviceId:getIMIE=" + deviceId);
        return deviceId;
    }


    /**
     * 获取设备MAC 地址 由于 6.0 以后 WifiManager 得到的 MacAddress得到都是 相同的没有意义的内容
     * 所以采用以下方法获取Mac地址
     * 这个需要
     *
     * @param context
     * @return
     */
    private static String getLocalMac(Context context) {
        String macAddress = null;
        StringBuffer buf = new StringBuffer();
        NetworkInterface networkInterface = null;
        try {
            networkInterface = NetworkInterface.getByName("eth1");
            if (networkInterface == null) {
                networkInterface = NetworkInterface.getByName("wlan0");
            }
            if (networkInterface == null) {
                return "";
            }
            byte[] addr = networkInterface.getHardwareAddress();


            for (byte b : addr) {
                buf.append(String.format("%02X:", b));
            }
            if (buf.length() > 0) {
                buf.deleteCharAt(buf.length() - 1);
            }
            macAddress = buf.toString();
        } catch (SocketException e) {
            e.printStackTrace();
            return "";
        }
        Logger.d(TAG, "DeviceId:getLocalMac()=" + macAddress);
        return macAddress;
    }


    /**
     * 生成一个随机ID
     *
     * @return
     */
    private static String getGUID() {
        String uid = UUID.randomUUID().toString();
        Logger.d(TAG, "DeviceId:getGUID()=" + uid);
        return uid;
    }


    /**
     * 获取设备唯一标识符,如果需要持久化到磁盘，需要
     * Manifest.permission.WRITE_EXTERNAL_STORAGE权限
     * 如果需要使用IMEI，序列号，Mac地址作为参数，需要
     * Manifest.permission.ACCESS_NETWORK_STATE
     * Manifest.permission.READ_PHONE_STATE
     * 6.0以下声明在Manifest里面，6.0以上动态申请
     * 如果不申请任何权限，默认使用AndroidID，如果AndroidID是空的，
     * 使用一个随机生成的ID
     *
     * @param context
     * @return
     */
    public static String getDeviceId(Context context, InforsConfig config) {
        if (context == null) {
            throw new NullPointerException("getDeviceId() but context null!!");
        }
        //优先使用sp里面的值
        String deviceId = getDeviceIdFromSp(context, config);
        try {
            //再考虑从磁盘里面的值
            if (TextUtils.isEmpty(deviceId)) {
                deviceId = getDeviceIdFromStore();
                //恢复sp里面的值
                saveDeviceIdInSp(context, deviceId, config);
            }
            if (!TextUtils.isEmpty(deviceId)) {
                return deviceId;
            }

            //持久化存储获取不到，重新生成
            StringBuilder builder = new StringBuilder();

            try {
                builder.append(getAndroidId(context));
                builder.append(getIMIE(context));
                builder.append(getSerialNumber(context));
                builder.append(getLocalMac(context));

            } catch (SecurityException e) {
                Logger.e(TAG, e.toString());
            }
            String raw = builder.toString();
            if (TextUtils.isEmpty(raw)) {
                raw = getGUID();
            }
            //MD5
            deviceId = EncryptData.MD5_32(raw);

            saveDeviceIdInSp(context, deviceId, config);
            saveDeviceIdInStore(context, deviceId);
        } catch (Exception e) {
            Logger.e(TAG, e.toString());
        }

        return deviceId;

    }

    private static void saveDeviceIdInSp(Context context, String deviceId, InforsConfig config) {
        saveStringSP(context,
                config, Consts.SP_DEVICE_ID,
                deviceId);
        Logger.d(TAG, "DeviceId:saveDeviceIdInSp()" + deviceId);
    }

    private static String getDeviceIdFromSp(Context context, InforsConfig config) {
        String deviceId = "";
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                config);
        SharedPreferences prefs = sharedPreferencesFactory.create();
        deviceId = prefs.getString(Consts.SP_DEVICE_ID, "");
        Logger.d(TAG, "DeviceId:getDeviceIdFromSp()" + deviceId);
        return deviceId;
    }

    private static void saveDeviceIdInStore(Context context, String deviceId) throws IOException {
        if (context == null || TextUtils.isEmpty(deviceId)) {
            return;
        }
        File path = null;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            path = new File(Environment.getExternalStorageDirectory(), CM_CACHE);
            if (!path.exists()) {
                path.mkdirs();
            }
            File file = new File(path, DEVICES_FILE_NAME);
            if (file.exists()) {
                file.deleteOnExit();
            }
            file.createNewFile();
            FileOutputStream outputStream = new FileOutputStream(file);
            outputStream.write(deviceId.getBytes());
            outputStream.flush();
            outputStream.close();
            Logger.d(TAG, "DeviceId:saveDeviceIdInStore()" + deviceId);
        }
    }

    private static String getDeviceIdFromStore() {
        File path = null;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            try {
                path = new File(Environment.getExternalStorageDirectory(), CM_CACHE);
                if (path.exists()) {
                    File file = new File(path, DEVICES_FILE_NAME);
                    if (file.exists()) {
                        FileInputStream fileInputStream = null;

                        fileInputStream = new FileInputStream(file);
                        byte bytes[] = new byte[32];
                        fileInputStream.read(bytes);
                        fileInputStream.close();
                        String deviceId = new String(bytes);
                        Logger.d("DeviceId:getDeviceIdFromStore()" + deviceId);
                        return deviceId;
                    }
                }
            } catch (IOException e) {
                Logger.d(TAG, "DeviceId:getDeviceIdFromStore()" + e.toString());
            }
        }
        return "";
    }


}

