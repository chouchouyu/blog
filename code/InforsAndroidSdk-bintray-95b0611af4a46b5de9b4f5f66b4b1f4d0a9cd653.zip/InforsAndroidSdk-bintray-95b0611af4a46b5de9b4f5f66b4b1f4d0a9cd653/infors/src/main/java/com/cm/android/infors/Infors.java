package com.cm.android.infors;

import android.app.Application;
import android.support.annotation.IntDef;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

import com.cm.android.infors.apm.crash.CrashPlugin;
import com.cm.android.infors.apm.network.HttpPlugin;
import com.cm.android.infors.apm.trace.TracePlugin;
import com.cm.android.infors.apm.trace.hacker.Hacker;
import com.cm.android.infors.core.*;
import com.cm.android.infors.core.events.ActivityTracker;
import com.cm.android.infors.core.events.ProcessMonitor;
import com.cm.android.infors.core.plugin.DefaultPluginListener;
import com.cm.android.infors.core.plugin.Plugin;
import com.cm.android.infors.core.plugin.PluginListener;
import com.cm.android.infors.core.report.Upload;
import com.cm.android.infors.core.thread.DefaultPoolExecutor;
import com.cm.android.infors.request.modal.SignleApp;
import com.cm.android.infors.request.modal.UserInfo;
import com.cm.android.infors.vieweditor.listener.WindowCallbackListener;

import static com.cm.android.infors.core.Consts.*;
import static com.cm.android.infors.utils.PrefUtils.saveLongSP;

/**
 * Created by wusm on 2018/4/2.
 */
public final class Infors implements SDKSwitchHandler.SDKSwitchListener {

    static {
        Hacker.hackSysHandlerCallback();
    }
    public volatile static ThreadPoolExecutor executor = DefaultPoolExecutor.getInstance();

    private volatile static InforsConfig config = InforsConfig.getInstance();
    private Boolean openLog = false;
    private LoganHelper loganHelper;

    @Override
    public void onSwitchChange(SDKSwitchHandler sdkSwitchHandler) {
        Logger.i(TAG, "sdk 开关->: "
                + "SDK总开关 :" + sdkSwitchHandler.isInforsEnable()
                + "；自动埋点开关 :" + sdkSwitchHandler.isAutoTraceEnable()
                + "；热力图开关 :" + sdkSwitchHandler.isHeatMapEnable()
                + "；可视化开关 :" + sdkSwitchHandler.isViewEditorEnable()
                + "；http开关 :" + sdkSwitchHandler.isHttpEnable()
                + "；卡顿开关 :" + sdkSwitchHandler.isBlockEnable()
                + "；奔溃开关 :" + sdkSwitchHandler.isCrashEnable()
                + "；日志打印开关 :" + sdkSwitchHandler.isLogPrintEnable()
                + "；日志上传开关 :" + sdkSwitchHandler.isLogUploadEnable()
        );


        if (sdkSwitchHandler.isInforsEnable()) {
            plugins = new HashSet<>();
            addPlugin(new HttpPlugin());
            addPlugin(new CrashPlugin());
            addPlugin(new TracePlugin());
            addPlugin(new InitialPlugin(config, upload, processMonitor));
            for (Plugin plugin : plugins) {
                plugin.init(app, pluginListener, sdkSwitchHandler);
                pluginListener.onInit(plugin);
            }
            startAllPlugins();
        }
        if (sdkSwitchHandler.isLogUploadEnable()) {
            Map<String, Long> logFileMap = loganHelper.getAllLogFilesInfo();
            if (logFileMap != null) {
                List<String> mapKeyList = new ArrayList<>(logFileMap.keySet());
//            SimpleDateFormat dataFormat = new SimpleDateFormat("yyyy-MM-dd");
//            String d = dataFormat.format(new Date(System.currentTimeMillis()));
//            String[] temp = new String[1];
//            temp[0] = d; //2019-05-22
                if (mapKeyList.size() != 0) {
                    reportLog(new String[]{mapKeyList.get(mapKeyList.size() - 1)}, new
                            LoganCallBack() {
                                @Override
                                public void onRequestSuccess() {
                                    Logger.i(TAG, "LogUploadEnable ->: onRequestSuccess :");
                                }

                                @Override
                                public void onRequestProgress(long currentBytesCount, long
                                        totalBytesCount) {
                                    Logger.i(TAG, "LogUploadEnable ->: onRequestProgress " +
                                            ":currentBytesCount " +
                                            "-" + currentBytesCount + ",totalBytesCount-" +
                                            totalBytesCount);
                                }

                                @Override
                                public void onRequestFailure(String msg) {
                                    Logger.i(TAG, "LogUploadEnable ->: onRequestFailure :" + msg);
                                }

                                @Override
                                public void onFileDeleted() {
                                    Logger.i(TAG, "LogUploadEnable ->: onFileDeleted :");
                                }

                                @Override
                                public void noLogExist(String msg) {
                                    Logger.i(TAG, "LogUploadEnable ->: noLogExist :" + msg);
                                }
                            });
                }
            }


        }

    }


    public static class Builder {
        private final Application application;
        private String appkey;
        private Boolean openLog;
        //        private HashSet<Plugin> plugins;
        private PluginListener pluginListener;
        private String baseUrl;
        private int maxLogFile;
        private List<String> shareKeyList = new ArrayList<>();
        private int requestId;

        public Builder(@NonNull Application app) {
            if (app == null) {
                throw new RuntimeException("Infors init, application is null");
            }
            this.application = app;
        }
//
//        private Builder plugin(Plugin plugin) {
//            if (plugins == null) {
//                plugins = new HashSet<>();
//            }
//            String tag = plugin.getTag();
//            for (Plugin exist : plugins) {
//                if (tag.equals(exist.getTag())) {
//                    throw new RuntimeException(String.format("plugin with tag %s is already
// exist", tag));
//                }
//            }
//            plugins.add(plugin);
//            return this;
//        }


        public Builder setBaseUrl(@NonNull String baseUrl) {
            this.baseUrl = baseUrl;
            return this;
        }

        public Builder patchListener(@NonNull PluginListener pluginListener) {
            this.pluginListener = pluginListener;
            return this;
        }


        public Builder setAppkey(@NonNull String appkey) {
            this.appkey = appkey;
            return this;
        }

        public Builder Loggable(@NonNull Boolean openLog) {
            this.openLog = openLog;
            return this;
        }

        public Builder setShareKeyList(String... shareKey) {
            this.shareKeyList.addAll(Arrays.asList(shareKey));
            return this;
        }


        public Builder setRequestIdMode(@RequestIdMode int requestIdMode) {
            this.requestId = requestIdMode;
            return this;
        }


        public Infors build() {
            if (PermissionHelper.checkBasicConfiguration(application)) {
                Logger.i(TAG, TAG + " ====== 权限申请不全 =====");
            }
            if (pluginListener == null) {
                pluginListener = new DefaultPluginListener(application, config,executor);
            }


            if (this.openLog == null) {
                Loggable(false);
            }

            if (TextUtils.isEmpty(appkey)) {
                Logger.i(TAG, TAG + " ====== Infors.build没有设置appKey =====");

            }

            //生成app的对象
            SignleApp signleApp = new SignleApp();
            signleApp.setAppKey(appkey);
            signleApp.setShareKeys(shareKeyList);
            signleApp.setGlobalMap(new HashMap<String, String>());


            return new Infors(application, appkey, this.openLog, pluginListener, baseUrl,
                    maxLogFile,
                    signleApp, requestId);
        }

    }


    public static Infors init(@NonNull Infors infors) {
        if (infors == null) {
            throw new RuntimeException("Infors init,infors should not be null.");
        }
        synchronized (Infors.class) {
            if (null == instance) {
                instance = infors;
            } else {
                Logger.e(TAG, "Infors init instance is already set. this invoking will be ignored");
            }
        }
        return instance;
    }

    public static Infors getInstance() {
        if (instance == null) {
            throw new RuntimeException("you must init Infors sdk first");
        }
        return instance;
    }

    private Upload upload;
    private PluginListener pluginListener = null;
    private HashSet<Plugin> plugins;

    public void startAllPlugins() {
        if (plugins == null) {
            return;
        }
        for (Plugin plugin : plugins) {
            plugin.start();
        }
    }

    public void stopAllPlugins() {
        if (plugins == null) {
            return;
        }
        for (Plugin plugin : plugins) {
            plugin.stop();
        }
    }

    public void destroyAllPlugins() {
        if (plugins == null) {
            return;
        }
        for (Plugin plugin : plugins) {
            plugin.destroy();
        }
    }

    public HashSet<Plugin> getPlugins() {
        return plugins;
    }

    public Plugin getPluginByTag(String tag) {
        if (plugins == null) {
            return null;
        }
        for (Plugin plugin : plugins) {
            if (plugin.getTag().equals(tag)) {
                return plugin;
            }
        }
        return null;
    }

    public <T extends Plugin> T getPluginByClass(Class<T> pluginClass) {
        if (plugins == null) {
            return null;
        }
        String className = pluginClass.getName();
        for (Plugin plugin : plugins) {
            if (plugin.getClass().getName().equals(className)) {
                return (T) plugin;
            }
        }
        return null;
    }


    ProcessMonitor processMonitor = ProcessMonitor.get();


    private HashSet<Plugin> addPlugin(Plugin plugin) {
        if (plugins == null) {
            plugins = new HashSet<>();
        }
        String tag = plugin.getTag();
        for (Plugin exist : plugins) {
            if (tag.equals(exist.getTag())) {
                throw new RuntimeException(String.format("plugin with tag %s is already exist",
                        tag));
            }
        }
        plugins.add(plugin);
        return plugins;
    }

    private volatile static boolean hasInit;

    private Infors(final Application application, String appkey, Boolean openLog,
                   PluginListener pluginListener, String baseUrl, int maxLogFile, SignleApp
                           signleApp, int requestIdMode) {

        this.app = application;
        if (!TextUtils.isEmpty(appkey) && TextUtils.isEmpty(config.getAppKey())) {
            config.setAppKey(appkey);
            config.setRequestIdMode(requestIdMode);
            this.openLog = openLog;
            this.pluginListener = pluginListener;
            initLogger(this.openLog);
            hasInit = false;
        } else {
            hasInit = true;
        }

        if (!TextUtils.isEmpty(baseUrl) && TextUtils.isEmpty(config.getBaseUrl())) {
            config.setBaseUrl(baseUrl);
        }
        config.addSignleApp(appkey, signleApp);


        if (null == upload) {
            upload = new Upload(config, this.openLog,executor);
            this.loganHelper = new LoganHelper(application, this.openLog, config, upload,
                    maxLogFile);
        }

        if (app == null) {
            Logger.i(TAG, "Infors ===== Application 不能为null =====");
            return;
        }


        if (hasInit) {
            Logger.i(TAG, "Infors ===== 数据采集已开启 =====");
        } else {
            Logger.i(TAG, "Infors ===== 数据采集开启 ===== " + SDK_VERSION);

            boolean isTrackingActivities = ActivityTracker.get().beginTrackingIfPossible(
                    app);
            if (!isTrackingActivities) {
                Logger.i(TAG, "Automatic activity tracking not available on this API level, " +
                        "caller " +
                        "must " +
                        "invoke " +
                        "ActivityTracker methods manually!");
            }

            processMonitor.start();

            SDKSwitchHandler switchHandler = new SDKSwitchHandler(app, config, this);
            switchHandler.getSwitchConfigFormNet(app, upload);

            new WindowCallbackListener(config, upload);
            hasInit = true;
        }
    }


    private final Application app;

    public Application getAppContext() {
        return app;
    }

    private static volatile Infors instance;

    private void initLogger(final boolean flag) {
        Logger.enableLogger(flag);
    }

    /**
     * app 启动时间计时
     */
//    private void setAppLaunchTime() {
//        config.setAppLaunchTime(Hacker.sApplicationCreateBeginTime);
//    }


    /**
     * 用户登录时 设置用户信息
     *
     * @param userInfo
     */
    public void setUserDetail(@NonNull UserInfo userInfo) {
        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);

        if (plugin != null) {
            plugin.reportUserInfo(userInfo);
        }

    }

    /**
     * 用户登出时 设置登出信息
     */
    public void logout() {
        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);

        if (plugin != null) {
            plugin.reportUserInfo(null);
        }
    }

    /**
     * 用户自添加数据，在每次上报都会带上的。
     * V3.0.0 兼容多次调用
     *
     * @param globalParams
     */
    public void setGlobalInfo(@NonNull Map<String, String> globalParams) {
        config.setGlobalParams(globalParams);
    }

    /**
     * 设置全局上报信息,针对平台
     *
     * @param globalParams 全局信息
     */
    public void setGlobalInfo(@NonNull String appkey, @NonNull Map<String, String> globalParams) {
        config.setGlobalParams(appkey, globalParams);
    }


    /**
     * 设置自定义Event
     * Map中的key,String中不要带"-",后台不支持，会被过滤掉
     *
     * @param vid
     * @param describe
     * @param map
     */
    public void track(@NonNull String vid, @NonNull String describe, @NonNull Map<String, String>
            map) {
        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);
        if (plugin != null) {
            plugin.reportTraceEvent(vid, describe, map, null);
        }
    }

    /**
     * 区分track，通过该接口上传的事件会单立传至appkey的项目，而非默认项目
     *
     * @param vid      事件的vid,不同的事件保持不一样就行
     * @param describe 作为埋点名称，会在网页中被展示
     * @param map      事件的详细信息，会被插入上报事件的data节点
     * @param appkey   上报至指定的appkey项目下。
     */
    public void trackDistinct(@NonNull String vid, @NonNull String describe, @NonNull Map<String,
            String>
            map, @NonNull String appkey) {
        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);
        if (plugin != null) {
            plugin.reportTraceEvent(vid, describe, map, appkey);
        }
    }


    /**
     * 调用该接口，日志可存入文件
     *
     * @param msg
     */
    public void saveLog(String msg, int type) {
        loganHelper.saveLog(msg, type);
    }


    /**
     * 如果你想立即写入日志文件，需要调用flush方法
     */
    public void flushLog() {
        loganHelper.flushLog();
    }

    /**
     * 获取Infors保存的的所有文件
     *
     * @return key: Log file date; //2019-05-21
     * value: Log file size(Bytes). //9787856kb
     */
    public Map<String, Long> getAllLogFilesInfo() {
        return loganHelper.getAllLogFilesInfo();
    }


    /**
     * 上报日志
     * 05-22 16:29:05.000
     * 05-22 16:41:44.671
     *
     * @param date     SimpleDateFormat("yyyy-MM-dd")的String数组
     * @param callback
     */
    public void reportLog(String[] date, LoganCallBack callback) {
        loganHelper.reportLog(date, callback);
    }


    public static final int HEAD_REQUESTID = 0;
    public static final int URL_REQUESTID = 1;
    public static final int NONE_REQUESTID = 2;

    @IntDef({HEAD_REQUESTID, URL_REQUESTID, NONE_REQUESTID})
    @Retention(RetentionPolicy.SOURCE)
    public @interface RequestIdMode {
    }

}

