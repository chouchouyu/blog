package com.cm.android.infors.request.modal;

import android.support.annotation.StringDef;

import com.google.gson.annotations.SerializedName;

import java.lang.annotation.*;


/**
 * 用户信息
 *
 * @author wusm
 */

public class UserInfo {

    private String userid;
    private String username;
    private String gender;
    private int age;
    private String avatar;

    //应服务端要求修改职位的键值
    @SerializedName("position")
    private String job;
    private String company;
    private String department;
    private String birthdate;
    private String telephone;


    @Documented // 表示开启Doc文档
    @StringDef({
            "男",
            "女"
    }) //限定为MAN,WOMEN
    @Target({
            ElementType.PARAMETER,
            ElementType.FIELD,
            ElementType.METHOD,
    }) //表示注解作用范围，参数注解，成员注解，方法注解
    @Retention(RetentionPolicy.SOURCE) //表示注解所存活的时间,在运行时,而不会存在 .class 文件中
    public @interface Sex {
    }


    private String province;
    private String city;

    private String channel;


    public UserInfo(String userid, String username) {
        this.userid = userid;
        this.username = username;
    }


    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
//  todo map      Map<String, SignleApp> map = InforsConfig.getInstance().getGlobalParams(null);
//        if (null == map) {
//            map = new HashMap<>();
//        }
//        map.put(ReportField.channel.name(), channel);
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUserName() {
        return username;
    }

    public void setUserName(String username) {
        this.username = username;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(@Sex String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "userid='" + userid + '\'' +
                ", username='" + username + '\'' +
                ", gender='" + gender + '\'' +
                ", age=" + age +
                ", avatar='" + avatar + '\'' +
                ", job='" + job + '\'' +
                ", company='" + company + '\'' +
                ", department='" + department + '\'' +
                ", birthdate='" + birthdate + '\'' +
                ", telephone='" + telephone + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", channel='" + channel + '\'' +
                '}';
    }
}