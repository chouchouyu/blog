package com.cm.android.infors.webview;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.JavascriptInterface;

import com.cm.android.infors.Infors;
import com.cm.android.infors.core.*;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.request.modal.Event;
import com.cm.android.infors.request.modal.JSAPMEvent;
import com.cm.android.infors.request.modal.SignleApp;
import com.cm.android.infors.utils.DeviceId;
import com.cm.android.infors.utils.InforsUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.cm.android.infors.core.Consts.*;
import static com.cm.android.infors.utils.PrefUtils.saveStringSP;

/**
 * js调用原生
 * 网络请求
 *
 * @author susan
 */
public class JsCallInfors {

    //    private Context context;

    public JsCallInfors(@NonNull Context context) {
        //        this.context = context;
    }


    @JavascriptInterface
    public void saveToInfors(@NonNull String msg) {
        if (TextUtils.isEmpty(msg)) {
            return;
        }
        Logger.i(TAG, "raw js 日志 ->" + msg);

        Gson gson = new Gson();
        JsonParser jsonParser = new JsonParser();

        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);
        InforsConfig config = InforsConfig.getInstance();

        if (plugin != null && plugin.getDynamicConfig().isInforsEnable()) {
            Context context = plugin.getApplication();

            //                     deviceId,sessionId,userId
            if (msg.contains(ReportField.batchLog.name())) {
                if (msg.contains(ReportField.touchH5Type.name())) {
                    JsonObject jsonObject = gson.fromJson(msg, JsonObject.class);
                    jsonObject.remove(ReportField.touchH5Type.name());


//                    if (jsonObject.has(ReportField.batchLog.name())) {
                    JsonArray jsonArray = jsonObject.get(ReportField.batchLog.name())
                            .getAsJsonArray();
                    JsonArray saveArray = new JsonArray();
                    for (int i = 0; i < jsonArray.size(); i++) {
                        JsonObject item = jsonArray.get(i).getAsJsonObject();
                        if (item.has(ReportField.deviceId.name())) {
                            item.remove(ReportField.deviceId.name());
                        }
                        item.addProperty(ReportField.deviceId.name(), DeviceId.getDeviceId
                                (context, config));

                        if (item.has(ReportField.sessionId.name())) {
                            item.remove(ReportField.sessionId.name());
                        }
                        item.addProperty(ReportField.sessionId.name(), InforsUtil
                                .getSessionId(context, config, config.getAppKey()));

                        Logger.i(TAG, "js -> user ->" + InforsUtil
                                .getUserId
                                        (context));

                        if (!TextUtils.isEmpty(InforsUtil.getUserId(context))) {
                            if (item.has(ReportField.userMsg.name())) {
                                item.remove(ReportField.userMsg.name());
                            }
                            item.addProperty(ReportField.userMsg.name(), InforsUtil
                                    .getUserId
                                            (context));
                        }
                        String itemStr = item.toString();
                        saveArray.add(jsonParser.parse(itemStr));
                    }
//                    }

                    plugin.web4APMReport(jsonObject);

                } else {
                    //APM 只需要改deviceId和userId
                    JSAPMEvent event = gson.fromJson(msg, JSAPMEvent.class);
                    if (null != event) {
                        List<JSAPMEvent.BatchLogBean> batchLogBeanList = event.getBatchLog();
                        List<JSAPMEvent.BatchLogBean> reportBatchLogList = new ArrayList<>();
                        for (JSAPMEvent.BatchLogBean bean : batchLogBeanList) {
                            bean.setDeviceId(DeviceId.getDeviceId(context, config));

                            if (!TextUtils.isEmpty(bean.getUserMsg())) {
                                saveStringSP(context, InforsConfig.getInstance(), Consts
                                                .SP_USERINFO,
                                        bean.getUserMsg());
                            }

                            if (!TextUtils.isEmpty(InforsUtil.getUserId(context))) {
                                bean.setUserMsg(InforsUtil.getUserId(context));
                            }
                            reportBatchLogList.add(bean);
                        }
                        event.setBatchLog(reportBatchLogList);

                        plugin.webAPMReport(event);

                    }
                }
            } else {
                JsonObject jsonObject = gson.fromJson(msg, JsonObject.class);


                if (jsonObject.has(ReportField.touchH5Type.name())) {

                    /**
                     需替换的字段：
                     H5定义H5事件类型，

                     类型1.属于原生的H5
                     appkey,deviceId,sessionId,appVersion,platform,userId (注意：保留eventsource)
                     类型2.外部的H5
                     deviceId,sessionId,userId
                     类型3：nuc登录页这种（既上报给原生，也上报给H5，不是替换关系）
                     替换字段痛，同类型2，但是把原生的默认appkey，添加到web事件的shareAppkeys中（相当于，H5事件自己要一份，也给原生一份）

                     字段touchH5Type ，分别传1,2,3
                     */

                    switch (jsonObject.get(ReportField.touchH5Type.name()).getAsInt()) {
                        case 1:
//                            String h5AppKey = null;
                            if (jsonObject.has(ReportField.appKey.name())) {
//                                h5AppKey = jsonObject.get(ReportField.appKey.name())
// .getAsString();
                                jsonObject.remove(ReportField.appKey.name());
                                jsonObject.addProperty(ReportField.appKey.name(), config
                                        .getAppKey());
                            }

                            if (jsonObject.has(ReportField.config.name())) {
                                jsonObject.remove(ReportField.config.name());
                            }
                            JsonArray appArray = InforsUtil.getConfigJson(config, null);
                            JsonElement appElement = jsonParser.parse(appArray.toString());
                            jsonObject.add(ReportField.config.name(), appElement);
//                                JsonArray jsonArray = jsonObject.getAsJsonArray(ReportField
//                                        .config.name());
//
//                                for (int i = 0; i < jsonArray.size(); i++) {
//                                    JsonObject item = jsonArray.get(i).getAsJsonObject();
//                                    if (item.has(ReportField.appKey.name()) && !TextUtils.isEmpty
//                                            (h5AppKey)) {
//                                        if (item.get(ReportField.appKey.name()).getAsString()
//                                                .contains(h5AppKey)) {
//                                            item.remove(ReportField.appKey.name());
//                                            item.addProperty(ReportField.appKey.name(), config
//                                                    .getAppKey());
//                                            String itemStr = gson.toJson(item);
//                                            JsonElement itemElement = jsonParser.parse(itemStr);
//                                            jsonArray.remove(i);
//                                            jsonArray.add(itemElement);
//                                        }
//                                    }
//                                }
//                                jsonObject.remove(ReportField.config.name());
//                                jsonObject.add(ReportField.config.name(), jsonArray);


                            if (jsonObject.has(ReportField.deviceId.name())) {
                                jsonObject.remove(ReportField.deviceId.name());
                                jsonObject.addProperty(ReportField.deviceId.name(), DeviceId
                                        .getDeviceId(context, config));
                            }

                            if (jsonObject.has(ReportField.appVersion.name())) {
                                jsonObject.remove(ReportField.appVersion.name());
                                jsonObject.addProperty(ReportField.appVersion.name(), config
                                        .getAppVersionName(context));
                            }

                            if (jsonObject.has(ReportField.platform.name())) {
                                jsonObject.remove(ReportField.platform.name());
                                jsonObject.addProperty(ReportField.platform.name(), Consts
                                        .PLATFORM);
                            }

                            if (jsonObject.has(ReportField.sessionId.name())) {
                                jsonObject.remove(ReportField.sessionId.name());
                                jsonObject.addProperty(ReportField.sessionId.name(), InforsUtil
                                        .getSessionId(context, config, config.getAppKey()));
                            }

                            if (jsonObject.has(ReportField.data.name())) {
                                JsonObject data = jsonObject.get(ReportField.data.name())
                                        .getAsJsonObject();
//                                data.add(ReportField.webVersion.name(), jsonObject.get
//                                        (ReportField.sdkVersion
//                                                .name()));

                                if (!TextUtils.isEmpty(InforsUtil.getUserId(context))) {
                                    if (data.has(ReportField.userId.name())) {
                                        data.remove(ReportField.userId.name());
                                    }
                                    data.addProperty(ReportField.userId.name(), InforsUtil
                                            .getUserId
                                                    (context));
                                }

                                jsonObject.remove(ReportField.data.name());
                                jsonObject.add(ReportField.data.name(), data);
                            }

//                            if (jsonObject.has(ReportField.sdkVersion.name())) {
//                                jsonObject.remove(ReportField.sdkVersion.name());
//                                jsonObject.addProperty(ReportField.sdkVersion.name(),
// SDK_VERSION);
//                            }

                            break;
                        case 2:
                            if (jsonObject.has(ReportField.deviceId.name())) {
                                jsonObject.remove(ReportField.deviceId.name());
                                jsonObject.addProperty(ReportField.deviceId.name(), DeviceId
                                        .getDeviceId(context, config));
                            }
                            if (jsonObject.has(ReportField.sessionId.name())) {
                                jsonObject.remove(ReportField.sessionId.name());
                                jsonObject.addProperty(ReportField.sessionId.name(), InforsUtil
                                        .getSessionId(context, config, config.getAppKey()));
                            }

                            if (jsonObject.has(ReportField.data.name())) {
                                JsonObject data = jsonObject.get(ReportField.data.name())
                                        .getAsJsonObject();

                                if (!TextUtils.isEmpty(InforsUtil.getUserId(context))) {
                                    if (data.has(ReportField.userId.name())) {
                                        data.remove(ReportField.userId.name());
                                    }
                                    data.addProperty(ReportField.userId.name(), InforsUtil
                                            .getUserId
                                                    (context));
                                }

                                jsonObject.remove(ReportField.data.name());
                                jsonObject.add(ReportField.data.name(), data);
                            }
                            break;
                        case 3:

                            if (jsonObject.has(ReportField.deviceId.name())) {
                                jsonObject.remove(ReportField.deviceId.name());
                            }
                            jsonObject.addProperty(ReportField.deviceId.name(), DeviceId
                                    .getDeviceId(context, config));

                            if (jsonObject.has(ReportField.sessionId.name())) {
                                jsonObject.remove(ReportField.sessionId.name());
                            }
                            jsonObject.addProperty(ReportField.sessionId.name(), InforsUtil
                                    .getSessionId(context, config, config.getAppKey()));

                            if (jsonObject.has(ReportField.data.name())) {
                                JsonObject data = jsonObject.get(ReportField.data.name())
                                        .getAsJsonObject();

                                if (!TextUtils.isEmpty(InforsUtil.getUserId(context))) {
                                    if (data.has(ReportField.userId.name())) {
                                        data.remove(ReportField.userId.name());
                                    }
                                    data.addProperty(ReportField.userId.name(), InforsUtil
                                            .getUserId
                                                    (context));
                                }

                                jsonObject.remove(ReportField.data.name());
                                jsonObject.add(ReportField.data.name(), data);
                            }

                            if (jsonObject.has(ReportField.config.name())) {
                                JsonArray jsonArray = jsonObject.getAsJsonArray(ReportField
                                        .config.name());
                                JsonArray addedJsonArray = new JsonArray();
                                for (int i = 0; i < jsonArray.size(); i++) {
                                    JsonObject item = jsonArray.get(i).getAsJsonObject();
                                    JsonArray shareKeysArray;
                                    if (item.has(ReportField.shareKeys.name())) {
                                        shareKeysArray = item.get(ReportField.shareKeys
                                                .name()).getAsJsonArray();
                                    } else {
                                        shareKeysArray = new JsonArray();
                                    }
                                    for (int j = 0; j < shareKeysArray.size(); j++) {
                                        if (shareKeysArray.get(j).getAsString().contains(config
                                                .getAppKey())) {
                                            shareKeysArray.remove(j);
                                        }
                                    }
                                    shareKeysArray.add(config.getAppKey());
                                    String shareKeysStr = gson.toJson(shareKeysArray);
                                    JsonElement jsonElement = jsonParser.parse(shareKeysStr);
                                    item.remove(ReportField.shareKeys.name());
                                    item.add(ReportField.shareKeys.name(), jsonElement);


                                    String itemStr = gson.toJson(item);
                                    JsonElement itemElement = jsonParser.parse(itemStr);
                                    addedJsonArray.add(itemElement);

                                }
//                                Map<String, SignleApp> map = config.getGlobalAppConfig(config
//                                        .getAppKey());
//                                if (map != null && map.size() > 0) {
//                                    JsonArray jsonArray = jsonObject.getAsJsonArray(ReportField
//                                            .config.name());
//                                    String appConfigStr = gson.toJson(map.get(0));
//                                    JsonElement jsonElement = jsonParser.parse(appConfigStr);
//                                    jsonArray.add(jsonElement);
//                                    jsonObject.remove(ReportField.config.name());
//                                    jsonObject.add(ReportField.config.name(), jsonArray);
//                                }
                            }
                            break;
                    }
                    jsonObject.remove(ReportField.touchH5Type.name());
                } else {
                    Event event = gson.fromJson(msg, Event.class);
                    if (null != event.getEventType()) {
                        jsonObject.addProperty(ReportField.eventType.name(), event.getEventType());

                    }

                    if (null != event.getEventId()) {
                        jsonObject.addProperty(ReportField.eventId.name(), event.getEventId());
                    }

                    if (null != event.getTimestamp()) {
                        jsonObject.addProperty(ReportField.timestamp.name(), event.getTimestamp());
                    }
                    if (null != event.getAppKey()) {
                        jsonObject.addProperty(ReportField.appKey.name(), event.getAppKey());
                    }
                    if (null != event.getSessionId()) {
                        jsonObject.addProperty(ReportField.sessionId.name(), event.getSessionId());
                    }
                    if (null != event.getPreEventId()) {
                        jsonObject.addProperty(ReportField.preEventId.name(), event.getPreEventId
                                ());
                    }


                    jsonObject.addProperty(ReportField.platform.name(), Consts.PLATFORM);
                    jsonObject.addProperty(ReportField.deviceId.name(), DeviceId
                            .getDeviceId(context, config));

                    jsonObject.addProperty(ReportField.sdkVersion.name(), SDK_VERSION);
                    jsonObject.addProperty(ReportField.appVersion.name(), InforsConfig.getInstance()
                            .getAppVersionName(context));

                    if (event.getData() != null) {
                        Map<String, Object> datamap = event.getData();
                        if (event.getEventType().contains(TYPE_USER)) {
                            if (datamap.containsKey("userId")) {
                                saveStringSP(context, InforsConfig.getInstance(), Consts
                                                .SP_USERINFO,
                                        (String) datamap.get("userId"));
                            }
                        }
                        Map<String, SignleApp> map = config.getGlobalAppConfig(config
                                .getAppKey());
                        if (map != null && map.size() > 0 && map.keySet().size() > 0) {
                            for (String key : map.get(0).getGlobalMap().keySet()) {
                                datamap.put(key, map.get(0).getGlobalMap().get(key));
                            }
                        }

                        if (!TextUtils.isEmpty(event.getSdkVersion())) {
                            datamap.put(ReportField.webVersion.name(), event.getSdkVersion());
                        }

                        jsonObject.add("data", InforsUtil.mapToJson(datamap));
                    }

                    if (!TextUtils.isEmpty(InforsUtil.getUserId(context))) {
                        jsonObject.addProperty(ReportField.userId.name(), InforsUtil.getUserId
                                (context));
                    }

                }
                Issue issue = new Issue(TYPE_JS, jsonObject, plugin);
                plugin.onDetectIssue(issue);

            }
        }
    }

//    private boolean isBefore4_V(String sdkVersion) {
//        String[] versionArray = sdkVersion.split(".");
//        if (versionArray != null && Integer.parseInt(versionArray[0]) < 4) {
//            return true;
//        } else {
//            return false;
//        }
//    }


}
