package com.cm.android.infors.demo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class CouponActivity extends AppCompatActivity {

    Button btnGetCoupon;

    boolean isLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coupon);
        Intent intent = getIntent();
        if (intent == null) {
            isLogin = intent.getBooleanExtra("isLogin", false);
        }
        btnGetCoupon = findViewById(R.id.btn_get_coupon);
        btnGetCoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMessage("feat");
                if (isLogin) {
                } else {
                    startActivity(new Intent(CouponActivity.this, LoginActivity.class));
                }
            }
        });
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();
        switch (action) {
//            case MotionEvent.ACTION_POINTER_1_DOWN:
//                showMessage("第一个手指按下");
//                break;
//            case MotionEvent.ACTION_POINTER_1_UP:
//                showMessage("第一个手指抬起");
//                break;
            case MotionEvent.ACTION_POINTER_2_DOWN:
                showMessage("第二个手指按下");
                break;
//            case MotionEvent.ACTION_POINTER_2_UP:
//                showMessage("第二个手指抬起");
//                break;
//            case MotionEvent.ACTION_POINTER_3_DOWN:
//                showMessage("第三个手指按下");
//                break;
//            case MotionEvent.ACTION_POINTER_3_UP:
//                showMessage("第三个手指抬起");
//                break;
        }
        return true;
    }

    private void showMessage(String s) {
        Toast toast = Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT);
        toast.show();
    }

}
