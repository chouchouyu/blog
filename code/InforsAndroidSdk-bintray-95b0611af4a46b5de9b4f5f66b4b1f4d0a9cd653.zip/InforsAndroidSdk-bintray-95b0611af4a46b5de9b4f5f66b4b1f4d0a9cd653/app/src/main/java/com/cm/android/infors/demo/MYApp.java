package com.cm.android.infors.demo;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;
import com.cm.android.infors.Infors;

/**
 * Created by wusm on 2018/4/10.
 */

public class MYApp extends Application {


    @Override
    public void onCreate() {
        super.onCreate();
        Infors.Builder builder = new Infors.Builder(this);
        builder.setAppkey("4733342ab52f4129b16f59cc99dc46c8");
        builder.Loggable(true);
        builder.setBaseUrl("https://touch-di1.sit.cmrh.com/");
        Infors.init(builder.build());//第三参数为是否显示Log日志

//        ProcessMonitor.attach(this);


//        Stetho.initializeWithDefaults(this);

//        if (LeakCanary.isInAnalyzerProcess(this)) {
//            // This process is dedicated to LeakCanary for heap analysis.
//            // You should not init your app in this process.
//            return;
//        }
//        LeakCanary.install(this);


    }


    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }


    @Override
    public void onLowMemory() {
        super.onLowMemory();
//        ProcessMonitor.detach(this);
    }
}