package com.cm.android.infors.demo;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.cm.android.infors.Infors;
import com.cm.android.infors.PermissionCallback;
import com.cm.android.infors.PermissionHelper;
import com.cm.android.infors.demo.webviewdemo.WebViewActivity;

import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import com.cm.android.infors.request.modal.UserInfo;

public class MainActivity extends AppCompatActivity {

    public Button mButton;
    public TextView mTextView;
    @BindView(R.id.tv)
    TextView tv;
    @BindView(R.id.btn)
    Button btn;
    @BindView(R.id.btn2)
    ImageButton btn2;

    PermissionHelper permissionHelper;
    private String tag = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);


        mButton = (Button) findViewById(R.id.btn);
        mTextView = (TextView) findViewById(R.id.tv);

        findViewById(R.id.btn_webview).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, WebViewActivity.class));
            }
        });

        mTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserInfo userInfo = new UserInfo("小猪", "佩奇");
                userInfo.setAge(3);
                userInfo.setGender("男");
                userInfo.setUserName("佩奇");
                Infors.getInstance().setUserDetail(userInfo);


                Map<String, String> map = new HashMap<>();
                map.put("key1", "Value1");
                map.put("key2", "Value2");
                Infors.getInstance().track(view.getId() + "", "describe", map);
            }
        });


        permissionHelper = new PermissionHelper(this, new String[]{Manifest.permission
                .READ_PHONE_STATE,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_COARSE_LOCATION}, 100);
        permissionHelper.request(new  PermissionCallback() {
            @Override
            public void onPermissionGranted() {
                //全都授权
                Log.e(tag, "onPermissionGranted...");
            }

            @Override
            public void onIndividualPermissionGranted(String[] grantedPermission) {
                //某个授权
                Log.e(tag, "onIndividualPermissionGranted() called with: grantedPermission = [" +
                        TextUtils.join(",", grantedPermission) + "]");
            }

            @Override
            public void onPermissionDenied() {
                //某个拒绝
                Log.e(tag, "onPermissionDenied...");
            }

            @Override
            public void onPermissionDeniedBySystem() {
                //用户选择了"不再询问"后，点击"拒绝按钮"，执行此方法
                Log.e(tag, "onPermissionDeniedBySystem...");
            }
        });


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                Infors.getInstance().logout();

                startActivity(new Intent(MainActivity.this, com.cm.android.infors.demo.liba_datapick
                        .activity.MainActivity.class));

            }
        });
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainActivity.this, CouponActivity.class));

//                Map<String, String> map2 = new HashMap<>();
//                map2.put("Globalkey1", "GlobalValue1");
//                map2.put("Globalkey2", "GlobalValue2");
//                Infors.getInstance().setGlobalInfo(map2);

            }
        });

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (permissionHelper != null) {
            permissionHelper.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

}
