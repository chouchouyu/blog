#include <jni.h>
#include <string>
#include <sys/socket.h>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_cm_android_infors_demo_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}
