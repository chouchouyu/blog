/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, {Component} from 'react';
// import {Platform, StyleSheet, Text, View,Button, NativeModules} from 'react-native';
import {Platform, StyleSheet, Text, View,Button} from 'react-native';
import Infors from './Infors';
 

const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});


type Props = {};
export default class App extends Component<Props> {
  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.welcome}>请在合适的时机为sdk申请权限</Text>

        <Button
        title="第一步：上报用户信息"
        onPress={this.login}
        color="#841584">
      </Button> 

      <Button
        title="自定义埋点"
        onPress={this.track}
        color="#841584">
      </Button> 

      <Button
        title="设置每次上报带上的数据"
        onPress={this.setGlobalInfo}
        color="#841584">
      </Button> 

      

      <Button
        title="最后:用户登出"
        onPress={this.logout}
        color="#841584">
      </Button> 

      </View>
    );
  }

  login(){
   Infors.setUserDetail({
        age: 222,
        city: "shenzhen",
        gender: "女",
        province: "guandong",
        userId: "小猪",
        userName: "佩奇"
    });
  }

  logout(){
    Infors.logout();
    
    }

  setGlobalInfo(){
    let map =[{
      key:"channel-1",
      value:"微信公众号"
    },{
      key:"channel-2",
      value:"微博"
    },{
      key:"channel-3",
      value:"仁和app"
    },{
      key:"channel-4",
      value:"iOS"
    }
  ];
//   let map =[{
//     "channel-1":"微信公众号"
//   },{
//     "channel-2":"微博"
//   },{
//     "channel-3":"仁和app"
//   },{
//     "channel-4":"iOS"
//   }
// ];
   Infors.setGlobalInfo(map);
  }


    track(){
      let arr =[{
        key:1,
        value:2
      },{
        key:3,
        value:4
      }];
      // let arr =[{
      //   1:2
      // },{
      //   3:4
      // }];

      Infors.track("vid","describe",  arr );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});
