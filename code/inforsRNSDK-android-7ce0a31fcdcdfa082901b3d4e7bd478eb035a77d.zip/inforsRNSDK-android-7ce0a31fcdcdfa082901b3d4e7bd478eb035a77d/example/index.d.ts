
export type MapItem = {
    key:string;
    value:string
  }
  

export namespace FaceAttributes {
    export type GenderEnum = '男' | '女' ;
      
     export const GenderEnum = {
        Male: '男' as GenderEnum,
        Female: '女' as GenderEnum,
    };
  }

export declare function setUserDetail(user: {
  userId:string;
  userName:string;
  gender?:FaceAttributes.GenderEnum;
  age?:number;
  province?:string;
  city?:string;
}): void;


export declare function logout(): void;


export declare function setGlobalInfo(...args: MapItem[]): void;


export declare function track(key: string, value: string,...args: MapItem[]): void;
 
 
 
 

 
 
