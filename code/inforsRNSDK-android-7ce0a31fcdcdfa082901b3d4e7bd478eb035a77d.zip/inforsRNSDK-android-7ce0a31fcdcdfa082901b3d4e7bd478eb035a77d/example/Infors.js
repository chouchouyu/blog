import { NativeModules } from 'react-native';

const RNInfors = NativeModules.Infors;

export const GenderEnum = {
    Male: "男",
    Female: "女"
  };

export const Infors = {
    logout() {
        RNInfors.logout();
    },
    setUserDetail(user) {
        person=new Object();
        person.userId=user.userId;
        person.userName=user.userName;
        console.log(user.gender);
        // if(user.gender.Female){
        //     person.gender="女";
        // }
        // if(user.gender.Male){
        //     person.gender="男";
        // }
        person.gender=user.gender;
        person.age=user.age;
        person.province=user.province;
        person.city=user.city;
        RNInfors.setUserDetail(user);
    },
    setGlobalInfo(map) {
        RNInfors.setGlobalInfo(map)
    },
    track(vid,describe,arr) {
        RNInfors.track(vid,describe,  arr );
    }

};

export default Infors;

 