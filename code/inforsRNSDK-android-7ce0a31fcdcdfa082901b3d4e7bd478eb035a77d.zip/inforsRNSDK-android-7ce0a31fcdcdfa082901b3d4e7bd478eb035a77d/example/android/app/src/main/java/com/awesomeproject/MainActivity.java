package com.awesomeproject;

import com.cm.android.infors.Infors;
import com.cm.android.infors.request.modal.UserInfo;
import com.facebook.react.ReactActivity;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends ReactActivity {

    /**
     * Returns the name of the main component registered from JavaScript.
     * This is used to schedule rendering of the component.
     */
    @Override
    protected String getMainComponentName() {
        return "AwesomeProject";
    }

    @Override
    protected void onResume() {
        super.onResume();

        UserInfo userInfo = new UserInfo("小猪", "佩奇");
        userInfo.setAge(3);
        userInfo.setGender("femela");
        userInfo.setUserName("佩奇");
        Infors.getInstance().setUserDetail(userInfo);

        Map<String, String> map2 = new HashMap<>();
        map2.put("Globalkey-1", "GlobalValue1");
        map2.put("Globalkey-2", "GlobalValue2");

        Infors.getInstance().setGlobalInfo(map2);

        Map<String, String> map = new HashMap<>();
        map.put("key-1", "Value-1");
        map.put("key-2", "Value-2");
        Infors.getInstance().track("vid" + "", "describe", map);
    }
}
