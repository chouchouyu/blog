package com.awesomeproject;

import android.app.Application;

import android.util.Log;
import com.cm.android.infors.Infors;
import com.cm.android.infors.rn.InforsReactPackage;
import com.facebook.react.ReactApplication;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.shell.MainReactPackage;
import com.facebook.soloader.SoLoader;

import java.util.Arrays;
import java.util.List;

public class MainApplication extends Application implements ReactApplication {

    private final ReactNativeHost mReactNativeHost = new ReactNativeHost(this) {
        @Override
        public boolean getUseDeveloperSupport() {
            return BuildConfig.DEBUG;
        }

        @Override
        protected List<ReactPackage> getPackages() {
            return Arrays.<ReactPackage>asList(
                    new MainReactPackage(),
                    new InforsReactPackage()
            );
        }

        @Override
        protected String getJSMainModuleName() {
            return "index";
        }
    };

    @Override
    public ReactNativeHost getReactNativeHost() {
        return mReactNativeHost;
    }

    @Override
    public void onCreate() {
        super.onCreate();


        SoLoader.init(this, /* native exopackage */ false);

        Infors.Builder builder = new Infors.Builder(this);
        builder.setAppkey("4733342ab52f4129b16f59cc99dc46c8");
        builder.Loggable(true);//是否显示Log日志
        builder.setBaseUrl("https://touch-di1.sit.cmrh.com/");
        Infors.init(builder.build());


    }
}
