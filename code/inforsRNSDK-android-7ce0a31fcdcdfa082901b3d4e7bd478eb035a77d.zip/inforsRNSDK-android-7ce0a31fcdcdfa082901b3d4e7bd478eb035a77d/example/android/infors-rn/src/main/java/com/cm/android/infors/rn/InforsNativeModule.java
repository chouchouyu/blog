package com.cm.android.infors.rn;

import com.cm.android.infors.Infors;
import com.cm.android.infors.request.modal.UserInfo;
import com.facebook.react.bridge.*;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;

public class InforsNativeModule extends ReactContextBaseJavaModule {


    public InforsNativeModule(@Nonnull ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Nonnull
    @Override
    public String getName() {
        return "Infors";
    }

    @ReactMethod
    public void setUserDetail(ReadableMap params) {
        if (params.hasKey("userId") && params.hasKey("userName")) {
            UserInfo userInfo = new UserInfo(params.getString("userId"), params.getString("userName"));
            if (params.hasKey("gender")) {
                userInfo.setGender(params.getString("gender"));
            }
            if (params.hasKey("age")) {
                userInfo.setAge((new Double(params.getDouble("age")).intValue()));
            }
            if (params.hasKey("province")) {
                userInfo.setProvince(params.getString("province"));
            }
            if (params.hasKey("city")) {
                userInfo.setCity(params.getString("city"));
            }
            Infors.getInstance().setUserDetail(userInfo);
        }
    }


    @ReactMethod
    public void logout() {
        Infors.getInstance().logout();
    }


    @ReactMethod
    public void setGlobalInfo(ReadableArray readableArray) {
        HashMap<String, String> hashMap = new HashMap();
        for (int i = 0; i < readableArray.size(); i++) {
            ReadableMap readableMap = readableArray.getMap(i);
            if (readableMap.hasKey("key") && readableMap.hasKey("value")) {
                hashMap.put(valueToString(readableMap, "key"), valueToString(readableMap, "value"));
            }
        }
        Infors.getInstance().setGlobalInfo(hashMap);
    }


    @ReactMethod
    public void track(String vid, String describe, ReadableArray readableArray) {
        HashMap<String, String> hashMap = new HashMap();
        for (int i = 0; i < readableArray.size(); i++) {
            ReadableMap readableMap = readableArray.getMap(i);
            if (readableMap.hasKey("key") && readableMap.hasKey("value")) {
                hashMap.put(valueToString(readableMap, "key"), valueToString(readableMap, "value"));
            }
        }
        Infors.getInstance().track(vid, describe, hashMap);
    }

    /**
     * Boolean -> Bool
     * Integer -> Number
     * Double -> Number
     * Float -> Number
     * String -> String
     * Callback -> function
     * ReadableMap -> Object
     * ReadableArray -> Array
     * ---------------------
     * 作者：xiangzhihong8
     * 来源：CSDN
     * 原文：https://blog.csdn.net/xiangzhihong8/article/details/81383092
     * 版权声明：本文为博主原创文章，转载请附上博文链接！
     *
     * @param readableMap
     * @param key
     * @return
     */
    private String valueToString(@Nullable ReadableMap readableMap, String key) {
        if (readableMap == null) {
            return null;
        }

        String result;


        final ReadableType readableType = readableMap.getType(key);
        switch (readableType) {
            case Null:
                result = key;
                break;
            case Boolean:
                result = String.valueOf(readableMap.getBoolean(key));
                break;
            case Number:
                // Can be int or double.
                double tmp = readableMap.getDouble(key);
                if (tmp == (int) tmp) {
                    result = String.valueOf((int) tmp);
                } else {
                    result = String.valueOf(tmp);
                }
                break;
            case String:
                result = readableMap.getString(key);
                break;
            case Map:
//                result = readableMapToMap(readableMap.getMap(key));
//                break;
                throw new IllegalArgumentException("Infors don't supported Type with key: " + key + ".");
            case Array:
//                result = readableArrayToList(readableMap.getArray(key));
//                break;
                throw new IllegalArgumentException("Infors don't supported Type  with key: " + key + ".");
            default:
                throw new IllegalArgumentException("Infors don't supported Type  with key: " + key + ".");
        }

        return result;
    }


}
