
export type MapItem = {
    key:string;
    value:string
  }

  export enum GenderEnum {
    Male = "男",
    Female = "女"
  }
  

export declare function setUserDetail(user: {
  userId:string;
  userName:string;
  gender?:GenderEnum;
  age?:number;
  province?:string;
  city?:string;
}): void;


export declare function logout(): void;


export declare function setGlobalInfo(...args: MapItem[]): void;


export declare function track(key: string, value: string,...args: MapItem[]): void;
 
 
 
 

 
 
