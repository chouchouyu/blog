/*
 * Copyright (c) 2018-present, 美团点评
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package test.logan.dianping.com.logan;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.dianping.logan.Logan;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public class MainActivity extends Activity {

    private static final String TAG = MainActivity.class.getName();

    private TextView mTvInfo;
    private EditText mEditIp;
    private RealSendLogRunnable mSendLogRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        mSendLogRunnable = new RealSendLogRunnable();
    }

    private void initView() {
        Button button = (Button) findViewById(R.id.write_btn);
        Button batchBtn = (Button) findViewById(R.id.write_batch_btn);
        Button sendBtn = (Button) findViewById(R.id.send_btn);
        Button logFileBtn = (Button) findViewById(R.id.show_log_file_btn);
        mTvInfo = (TextView) findViewById(R.id.info);
        mEditIp = (EditText) findViewById(R.id.send_ip);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Logan.w("啊哈哈哈哈66666", 2);
//                String fileName = getApplicationContext().getExternalFilesDir(null).getAbsolutePath()
//                        + File.separator + "吴思敏.txt";
//                File file = new File(fileName);
//                if (!file.exists()) {
//                    try {
//                        file.createNewFile();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//
//                for (int i = 0; i < Integer.MAX_VALUE; i++) {
//                    writeFile(i + ":还要注意练手感，让大脑能指挥手，感觉到笔变成了手的一部分，变成了手的延伸，手能轻松的指挥笔，想快则快，想慢则慢，想轻则轻，想重则重，想写出什么样的效果就能写出什么样的效果。 第四要练结构，因为练字的关键是掌握字的结构。字的结构是指字的笔画的长短比例及笔画间的穿插避让关系。谢晓东在歌曲《中国人》中唱道：“最爱写的字啊是先生教的方块字，方方正正做人要象他……”“方方正正”概括了汉字的结构特点。掌握了汉字的结构，写出了方方正正，结构美观的黑体字，将其笔画稍加变化就能写出宋体、魏体、楷体、仿宋体、庞体、司马体、隶书等各种字体的汉字。如果掌握不住汉字的结构，无论如何对字的笔画进行修饰，进行美化，都是难看的赘物，越变越难看。所以掌握字的结构，写好黑体字是练好一切字体的关键和基础。 第五要练笔画。", fileName, true);
//                }


            }
        });
        batchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loganTest();
            }
        });
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loganSend();
            }
        });
        logFileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loganFilesInfo();
            }
        });
    }

    /**
     * 将字符串写入文件
     *
     * @param text     写入的字符串
     * @param fileStr  文件的绝对路径
     * @param isAppend true从尾部写入，false从头覆盖写入
     */
    public static void writeFile(String text, String fileStr, boolean isAppend) {
        try {
            File file = new File(fileStr);
            File parentFile = file.getParentFile();
            if (!parentFile.exists()) {
                parentFile.mkdirs();
            }
            if (!file.exists()) {
                file.createNewFile();
            } else {
                if (file.length() > (2 * 1024 * 1024)) {
                    file.renameTo(new File(fileStr+".copy"));
                }
            }

            FileOutputStream f = new FileOutputStream(fileStr, isAppend);
            f.write(text.getBytes());
            f.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    private void loganTest() {
        new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    for (int i = 0; i < Integer.MAX_VALUE; i++) {
                        Log.d(TAG, "times : " + i);
                        Logan.w(String.valueOf(i) + "  BufferedSink中定义了一系列写入缓存区的方法，当然其一定定义了与Buffer相关的方法，具体方法相见官方API。  BufferedSink中901,\"botany\", n 植物学\n" +
                                "【根】botane草料，植物一植物学\n" +
                                "【记】bo读：抱，tany＝any，见到什么植物都抱－肯定是学植物学的\n" +
                                "【参】botanical （adj  植物学的）\"\n" +
                                " \n" +
                                "902,\"botch\", v （笨手笨脚地）弄坏某事物，搞的一团糟＝mismanage＝blow\n" +
                                "【例】She botches all She touches   她一动手就把东西弄坏了。\n" +
                                "【记】读：抱吃。抱着一大堆东西吃，肯定一团糟。\"\n" +
                                " \n" +
                                "903,\"bother\", vt （通过令人烦躁的小事或没有被邀请而闯入）打搅，打扰\n" +
                                "【例】Don't bother me   不要打扰我。   I'm sorry to bother you…  劳驾…Don't bother yourself about me   别为我操心。   Bother it!  讨厌!\n" +
                                "【记】bo读：抱，ther＝her。抱她－她在好好背单词呢，你抱她不是打搅，打扰她吗？\"\n" +
                                " \n" +
                                "904,\"bottleneck\", n 瓶颈；adj 有阻碍的\n" +
                                "【记】bottle瓶子，neck脖子－瓶颈\n" +
                                "【反】indefinite（adj 无限定的）\"\n" +
                                " \n" +
                                "905,\"boudoir\", n 闺房（包括：女人的私人起居室、化妆室或卧室）\n" +
                                "【源】源自古法语bouder[生气，不高兴]，因为擅闯闺房，女方会不高兴的。\n" +
                                "【记】读：不得挖。闺房当然不能让你挖坑了，闯进去她都会生气，你要是想在闺房里挖坑，她还不得宰了你。\"\n" +
                                " \n" +
                                "906,\"boulder\", n 巨砾（大而圆的岩石块）；大的鹅卵石\n" +
                                "【记】读：搏斗。用又大又圆得石头互相砍。巨人的shoulder上有boulder\n" +
                                "【类】colossus:figurine＝boulder:pebble巨型雕像:小雕像＝大石头:小卵石frond:leaf＝boulder:rock蕨类叶是一种叶子＝大石头是一种岩石\"\n" +
                                " \n" +
                                "907,\"boundary\", n 边界，分界线＝border＝limit\n" +
                                "【例】A stone wall marked the boundary between the two farms 石墙是两个农场的分界线。\n" +
                                "【反】unrestraint（n 无拘束；放纵）\"\n" +
                                " \n" +
                                "908,\"boundless\", adj 无限制的（没有限制或界线的）\n" +
                                "【例】boundless imagination  无限的想象力\n" +
                                "【记】bound界限，less少－无限制的\n" +
                                "【类】boundless:limit＝impeccable:flaw无限的无限制＝无瑕疵的无瑕疵\n" +
                                "【反】limited（adj 有限的）\"\n" +
                                " \n" +
                                "909,\"bounteous\", adj 慷慨的（大方而大量给予的）；丰富的＝plentiful＝bountiful\n" +
                                "【例】bounteous nature  大方的性格   a bounteous repast  丰盛的一餐\n" +
                                "【记】1）bount＝bound界限，ous多－说明邻国多，朋友多，是你慷慨的结果。2）bount读：帮他，ous多－帮他多的－慷慨的\"\n" +
                                " \n" +
                                "910,\"bouquet\", n 花束（一束花）；酒香＝fragrance；恭维话\n" +
                                "【例】a bouquet of roses  一束玫瑰花   a rich bouquet  浓郁的香味\n" +
                                "【记】banquet（n 宴会），宴会上缺que的三样东西：花束，酒香，恭维话。\n" +
                                "【类】bouquet:flowers＝woodpile:logs＝constellation:star花束由花组成＝木料堆由木头组成＝星群由星星组成singer:choir＝flower:bouquet   歌手组成唱师班＝花组成花束\"\n" +
                                " \n" +
                                "911,\"bourgeois\", n （渴求名利、社会地位和物质财富的，平庸的）中产阶级\n" +
                                "【记】源于：bourg（n 中世纪靠近城堡的村庄）那里盛产hamburg（n 汉堡包），被认为是中产阶级的食品。\"\n" +
                                " \n" +
                                "912,\"bout\", n 一回合，一阵（对手间的一次较量，一次比赛，特指拳击的一回合）\n" +
                                "【例】a wrestling bout   一回摔跤比赛\n" +
                                "【记】1）原指农夫来回犁地，现在指带有反复性的活动。参：boutique（n 专卖流行衣服的小商店）－妇女反复走的地方2）读：抱他。在拳击比赛中，当一回合快结束得时候，如果有其中的一方体力不支，就会采取抱住对方得手段，可以拖延时间，等到一回合结束后，他就可以休息了。\"\n" +
                                " \n" +
                                "913,\"bovine\", adj （似）牛的；牛一般迟钝的（行动迟缓的，呆头呆脑的）＝stolid\n" +
                                "【例】His bovine face gave no response   他无感情的脸上没有丝毫反应。\n" +
                                "【记】1）bov＝cow（母牛）2）bo读：抱，vine葡萄酒。整天抱着葡萄酒－牛饮，喝多了就会迟钝。\"\n" +
                                " \n" +
                                "914,\"bowdlerize\", v 删去（书中猥亵不当的部分）＝expurgate\n" +
                                "【例】This book has been bowdlerized   这本书中不当的部分已被删去。\n" +
                                "【源】源自托马斯·鲍勒Bowdler，他于1818年出版了莎士比亚修订本，后来就用了他的名字来表示删去的含义。\n" +
                                "【记】读：不得了了。不得了了，这本书有色情内容－赶快删去\"\n" +
                                " \n" +
                                "915,\"bower\", n 凉亭；有树荫的休息处＝arbor\n" +
                                "【记】bow弓－凉亭的顶常是”弓”形的读：保尔－炼钢的哥们儿，有点儿热，在凉亭里吧！\"\n" +
                                " \n" +
                                "916,\"box\",\"v 拳击＝buffet＝smack＝spank\n" +
                                "【类】box:fight＝debate:argue拳击是一种对抗＝争论是一种辩论\"\n" +
                                " \n" +
                                "917,\"boycott\",  v 联合抵制（联合起来拒绝使用、购买、经销，以示抗议、不满）；联合排斥某国货物或与某国绝交\n" +
                                "【例】They're boycotting the shop   他们联合抵制那家商店。\n" +
                                "【源】源于查理斯·C·博伊考特。他是爱尔兰的房地产经纪人，占有爱尔兰大部分土地。1880年，博伊考特被选为一项政策的试点，此项政策是由一个爱尔兰政治家─查理斯·帕内尔提出的。那些不愿降低地租的地主或佃农都被帕内尔的支持者疏远。作为原英军士兵的博伊考特，拒绝收取低地租并且驱逐佃户。此时帕内尔爱尔兰土地联盟成员插手了，博伊考特及其家人发现他们被孤立了─没有仆人，工人，得不到商店服务，甚至没人送信。博伊考特的名字很快就被用作这种对待方法的专有名词。\n" +
                                "【记】来自人名\"\"Boycott\"\"，1897英国驻爱尔兰官员，因拒绝降低房租（地租）而被爱尔兰人抵制及驱逐（ostracize）\n" +
                                "【反】patronize（v 资助）\"\n" +
                                " \n" +
                                "918,\"brace\", v 使稳固，使振奋＝strengthen；n 支撑物＝fastener；括号\n" +
                                "【例】I braced my foot against the wall   我把脚顶着墙站稳。Brace yourself for a new challenge!   振作起来迎接新的挑战!\n" +
                                "【记】brace原指双臂，用双臂支撑－使稳固用两个brace embrace（v 拥抱）\n" +
                                "【反】denounce（vt 公开指责）\"\n" +
                                " \n" +
                                "919,\"bracelet\", n 手镯，手拷，表带（戴在手腕或手臂上的装饰品）\n" +
                                "【记】brace双臂，1et小东西－戴在双臂上的小东西－手镯，表带\"\n" +
                                " \n" +
                                "920,\"bracing\", adj 令人振奋的（振奋精神，令人奋发的）＝exhilarating＝exhilarative＝quickening＝tonic\n" +
                                "【例】a bracing lecture  振奋人心的报告\n" +
                                "【记】brace双臂（挥舞）：令人振奋的\n" +
                                "【反】vapid（adj 索然无味的）\"\n" +
                                " \n" +
                                "921,\"bracket\", n 托架；小括号 \n" +
                                "【例】bracket a word  把一个字置于括弧内\n" +
                                "【记】brack＝brace双臂，et小。见上图的托架就是有双臂支撑。\n" +
                                "【区】racket（n 球拍）\n" +
                                "【类】buttress:wall＝bracket:shelf扶壁用来支撑墙壁＝支架用来支撑书架\"\n" +
                                " \n" +
                                "922,\"brackish\", adj 含盐的，微有咸味的（尤指来自含有海水和淡水混合物的）；味道不好的，令人恶心的\n" +
                                "【例】a thin, brackish gruel   稀而难以下咽的粥\n" +
                                "【记】读：不爱口试。有个好办法，喝咸水，这样嗓子就哑了，就可以不参加口试了。\n" +
                                "【类】brackish:repulse   可厌的:厌恶\"\n" +
                                " \n" +
                                "923,\"brag\", v 吹嘘＝boast；吹牛\n" +
                                "【例】You are the baggiest of all persons   你是所有人中最会吹牛的。\n" +
                                "【记】b不，rag破布。如有一人大喊：“我不是破布，我是好布！”那他一定是在吹牛。\"\n" +
                                " \n" +
                                "924,\"braggadocio\",  n 大吹大擂＝boasting；吹牛大王\"\n" +
                                " \n" +
                                "925,\"braggart\", n 吹嘘；adj 吹牛的，自夸的\n" +
                                "【记】b不，rag破布，art艺术。这不是破布，而是艺术－吹牛\"\n" +
                                " \n" +
                                "926,\"braid\", v 编织（用斜纹重叠方式交错编织三股或三股以上）；n 辫子，穗带 \n" +
                                "【例】wear one's hair in braids  把头发梳成辫子\n" +
                                "【记】br不，aid帮助。女孩编辫子不需要帮助，可以自己搞定。头里长的是brain，头上长的是braid\n" +
                                "【类】grooved:striated＝braided:stranded开槽的:有条纹的＝编织成的:梳成辫子的（同义）\"\n" +
                                " \n" +
                                "927,\"brake\", n 刹车；v （尤指通过接触摩擦）减速，阻止＝impede＝obstruct\n" +
                                "【例】The government put the brakes on all these projects 政府使所有这些工程都停顿下来了。\n" +
                                "【源】brake首次出现于16世纪，意指“马缰或勒马带”。远早于汽车的出现。\n" +
                                "【类】divert:shunt＝retard:brake 转向和使车转向＝阻止前进和刹车brake:decelerate＝clamp:compression刹车的作用是减速＝夹子的作用是压缩\"\n" +
                                " \n" +
                                "928,\"brand\", n 商标；烙印（标明身份或所有权的一种标记，用热铁在动物皮上烧成）；v 在某事物或动物上打烙印\n" +
                                "【例】We've branded our cattle   我们已经给牛打上了标记了。What brand of computer do you like?  你喜欢什么牌子的计算机？\n" +
                                "【类】underscore:emphasis＝brand:ownership下划线表明强调＝商标表明所有权\"\n" +
                                " \n" +
                                "929,\"brandish\", v （威胁性或蔑视性的）挥动或挥舞（如武器、刀、剑）\n" +
                                "【例】words brandished and banners waved   刀剑挥舞, 旌旗飘扬。\n" +
                                "【记】1）brand商标，挥舞刀剑就是军队的商标。2）读：不愿dish（盘子）。工人罢工得时候会挥舞着刀剑大喊：“我们不愿洗盘子。”\"\n" +
                                " \n" +
                                "930,\"brash\", adj 轻率鲁莽的（急躁、仓促、冲动、不加思索的）＝madcap＝reckless\n" +
                                "【参】rash（adj 轻率的，匆忙的，卤莽的）\n" +
                                "【类】frivolous:gravity＝brash:discretion   轻浮的不庄重＝轻率的不慎重candor:subterfuge＝brash:deliberate   直率没有托词＝仓促没有深思熟虑\"\n" +
                                " \n" +
                                "931,\"brassy\", adj 黄铜的；厚颜无耻的\n" +
                                "【记】脸象brass（n 黄铜）一样厚－厚颜无耻的\n" +
                                "【反】diffident（adj 胆怯的，缺乏自信的）；humble（adj 谦虚的）；furtive（adj 偷偷摸摸的）；unassertive（adj 无自信的）\"\n" +
                                " \n" +
                                "932,\"brat\", n （被宠坏乳臭未干调皮捣蛋举止粗鲁的）小鬼，顽童\n" +
                                "【记】1）读：不爱他。顽童没人爱。2）读：捕rat（n 耗子），顽童喜欢捕老鼠。\"\n" +
                                " \n" +
                                "933,\"brattish\", adj （特指小孩）讨厌的、被惯坏的、幼稚无礼的\n" +
                                "【类】tightfisted:parsimonious＝brattish:mischievous吝啬的对十分吝啬的＝淘气的对十分淘气的\"\n" +
                                " \n" +
                                "934,\"bravado\", v 虚张声势（故作勇敢）\n" +
                                "【例】The mob bravadoed a while but never got really violent 暴民们虚张声势了一番，但始终没有真正地闹起来。\n" +
                                "【记】bravo[勇敢，优秀的]，do作－作出勇敢状－虚张声势\n" +
                                "【参】bravura（n 演出等精彩，热烈）\n" +
                                "【类】courageous:bravado＝complimentary:fulsomeness假勇敢的是虚张声势＝假称赞的是过分恭维swagger:bravado＝caress:affection大摇大摆表示虚张声势＝爱抚表示爱\"\n" +
                                " \n" +
                                "935,\"bravery\", n 勇敢；（衣服）鲜艳华丽\n" +
                                "【例】He is unrivaled in bravery   他英勇无比。The girls are wearing their bravery   姑娘们都穿上她们的华丽衣服。\"\n" +
                                " \n" +
                                "936,\"bravura\", adj 华美的，炫耀技巧的；n 气势磅礴的演奏；勇敢的尝试\n" +
                                "【例】This picture has a bravura of execution   这幅画作风大胆。\n" +
                                "【记】bravo[勇敢，优秀的]，a和o结尾的单词多数是意大利语，表示音乐。\n" +
                                "【类】bravura:performance＝resplendent:appearance华美的表演＝灿烂的外表\"\n" +
                                " \n" +
                                "937,\"brawl\", v/n 争吵（喧闹的争吵或争斗）＝quarrel or fight\n" +
                                "【例】The river brawled over the rapids   河水哗哗地流过湍滩。a family brawl  家庭争吵\n" +
                                "【记】1）brawny（adj 强壮的），两个强壮的人在一起－争吵2）读：不弱。两个不弱的人在一起－争吵3）awl（n 锥子，尖钻），用来争斗\n" +
                                "【参】crawl（v 爬行）；awl（n 尖钻）\"\n" +
                                " \n" +
                                "938,\"brawny\", adj （人因为肌肉结实）强壮的＝strong＝muscular\n" +
                                "【记】brawn＝brown（adj 棕色的），肌肉结实就是棕色的。\n" +
                                "【参】brawn（n 强壮的肌肉，腕力，野猪肉）\"\n" +
                                " \n" +
                                "939,\"brazen\", adj 黄铜的；厚颜无耻的＝impudent\n" +
                                "【例】They prefer to brazen a thing out rather than admit defeat 他们不愿承认失败，宁肯厚着脸皮干下去。\n" +
                                "【记】braz＝brass（n 黄铜）－脸像黄铜－厚颜无耻的\n" +
                                "【参】brazier（n 火盆，黄铜匠）\n" +
                                "【类】impudence:brazen＝deadpan:impassive厚颜无耻的特点是厚脸皮的＝无表情的特点是冷漠的\n" +
                                "【反】modest（adj 谦虚的）；self-effacing（adj 不出风头的；谦卑的）\"\n" +
                                " \n" +
                                "940,\"breach\", v 违背；打破，突破；n （与of连用）违背，不履行；缺口＝fissure＝rent＝rift＝schism＝hiatus\n" +
                                "【例】You are in breach of the contract   你违反了合同。\n" +
                                "【记】breach＝break（n 破裂；v 打破，违犯）\n" +
                                "【反】solder（v 焊接）\"\n" +
                                " \n" +
                                "941,\"breadth\", n 宽度，广度；（性格，胸襟等的）宽宏大度；（知识的）广博\n" +
                                "【例】What's the breadth of this river?  这条河的宽度是多少？breadth of mind  胸襟远大a man of intellectual breadth  知识渊博的人\"\n" +
                                " \n" +
                                "942,\"breakthrough\",  n 突破（克服或穿越障碍或限制的行为，突破敌人防线的军事攻击）；重大成就（如在技术上的突破）\n" +
                                "【例】Surgeons have made a great breakthrough   外科医生们取得了重大突破。\"\n" +
                                " \n" +
                                "943,\"breeder\", n 饲养动物者，培育植物者（尤指为了繁殖下一代而育种的人）\n" +
                                "【记】breed（v （使）繁殖，抚养；n 品种，种类）\"\n" +
                                " \n" +
                                "944,\"breezeway\",  n 有顶棚的通路（联接两个建筑的带屋顶的侧边敞开的过道）\n" +
                                "【记】breeze（n 微风），way路。有微风吹过的路－侧边敞开的过道\n" +
                                "【类】breezeway:building＝stairway:floor有顶棚的通道是建筑物间的通道＝楼梯是楼层间的通道\"\n" +
                                " \n" +
                                "945,\"brevity\", n 简洁（讲话、文章、表达简明扼要）＝conciseness；（时间）短暂\n" +
                                "【例】the brevity of his life  他短暂的生命\n" +
                                "【记】brev短，缩短，ity表状态－短的状态－`短暂，简短\n" +
                                "【类】epitomize:brevity＝embellish:ornamentation概括的特点是简洁＝修饰的特点是装饰exaggeration:caricature＝brevity:epigram夸张是讽刺画的特点＝简洁是警句的特点brevity:aphorism＝distortion:caricature简洁是格言的特点＝扭曲是讽刺画发特点\n" +
                                "【反】prolixity（n 罗嗦）；lengthiness（n 冗长）\"\n" +
                                " \n" +
                                "946,\"bribe\", n /v 贿赂\n" +
                                "【类】bribe:incorruptible＝affect:insensible『hear:uncommunicative』贿赂不是不腐败的＝感动不是无知觉的\"\n" +
                                " \n" +
                                "947,\"bricklayer\",  n 砖匠（在建造中有砌砖技能的人） \n" +
                                "【记】brick（n 砖），layer（n 层）－把砖用一层水泥垒上－砖匠\"\n" +
                                " \n" +
                                "948,\"bridle\", n/v （对欲望的）抑制，控制＝curb＝control；n 马笼头（安放在马头周围，用来限制或引导的一种马具，包括笼头、马勒和缰绳）\n" +
                                "【例】Bridle your tongue   说话要谨慎。\n" +
                                "【记】1）bride（n 新娘），婚后新娘会控制新郎，成为半边天。2）读：不愿动。因为被抑制，控制了。3）来自ride骑，前边有个b不：不骑。用马笼头来实现。\n" +
                                "【反】without restraint（没有控制）\"\n" +
                                " \n" +
                                "949,\"brigand\", n （流窜或在山林中的）土匪强盗\n" +
                                "【记】变成bring gun d：带着枪的－土匪强盗\"\n" +
                                " \n" +
                                "950,\"brilliant\", adj 才气焕发的（极其聪明的，表现出不寻常的、令人难望的敏锐的智力的；辉煌的＝sparkling\n" +
                                "【例】a brilliant scientist  一位才华横溢的科学家\n" +
                                "【记】brilli闪耀，发光，ant蚂蚁－发光的蚂蚁－才华横溢的\n" +
                                "【参】brilliance（n 光辉灿烂＝brightness；才华横溢＝intelligence）\n" +
                                "【类】firm:ironclad＝smart:brilliant坚固的和十分坚固的＝聪明的和才华横溢的\"\n" +
                                " \n" +
                                "951,\"brim\", n （杯、碗、帽子的）边缘；v 盈满，溢满\n" +
                                "【例】Her eyes brimmed over with tears   她的眼睛里充满了泪水。He brimmed a glass of beer   他斟满了一杯啤酒。\n" +
                                "【记】rim（n 边，框），你到了悬崖边上，我会说‘b’不grim（adj 严厉的，坚定的），g鬼在边上rim－严厉的\n" +
                                "【参】brimful（adj 充满的，盈满的）\"\n" +
                                " \n" +
                                "952,\"brindled\", adj 有斑纹的，有斑点的（黄褐色或灰色的底上有暗色条纹或斑点的）\n" +
                                "【记】中间有rind（n 西瓜皮），西瓜皮是有斑纹的。\n" +
                                "【参】brindle（n 斑点，有斑纹的动物，如：斑马）\"\n" +
                                " \n" +
                                "953,\"brink\", n （河、海、峭壁等的）边缘；（危险或刺激性事物的）边缘＝verge＝border\n" +
                                "【例】on the brink of the grave  濒于死亡\n" +
                                "【记】blink（v 眨眼）－在峭壁的边缘吓得直闭眼\n" +
                                "【根】bri＝brim边－悬崖\"\n" +
                                " \n" +
                                "954,\"brisk\", adj （人）轻快活泼的（表现为充满生机的和有活力的）；（天气）清爽的＝nimble＝spry＝yare＝zippy\n" +
                                "【记】读：不risk。不冒险就难受－充满生机的和有活力的\n" +
                                "【反】ponderous（adj 沉重的）\"\n" +
                                " \n" +
                                "955,\"bristle\", vi （毛发等）竖起，发怒；n 短而硬的毛（比如：猪的鬃毛；植物的刺毛；刷子的毛；人的胡须茬）\n" +
                                "【例】His hair bristled with anger   他怒发冲冠了。\n" +
                                "【记】b不，ris＝rise升起，tle读：头。不抬头，豪猪的毛竖起来的时候是不抬头的。\n" +
                                "【区】gristle（n 软骨），gristle鬼抬头，没有肉，露出软骨。\n" +
                                "【类】bristle:anger＝vacillate:irresolution『condone:mercy』『condemn:warning』发怒＝愤怒＝忧郁不定＝不坚决『 赦免:仁慈』『谴责:警告』\n" +
                                "【反】cower（v 畏缩）\"\n" +
                                " \n" +
                                "956,\"brittle\", adj 东西易碎的；关系脆弱的；声音尖利的＝crisp＝crumbly＝crunchy\n" +
                                "【例】glass is brittle  玻璃容易碎She has a brittle temper   她动不动就发脾气。\n" +
                                "【记】bottle容易brittle。\n" +
                                "【参】brittleness（n 脆弱fragility）\n" +
                                "【类】manifest:perceive＝brittle:break明显的容易被察觉＝易碎的容易被打碎\"\n" +
                                " \n" +
                                "957,\"broach\", v 提出（一个主题供讨论或辩论）（to start a discussion＝bring up＝moot）；开瓶；钻洞\n" +
                                "【例】broach beer from a keg  开桶啤酒It's a good chance to broach the subject   这是提出那个问题的好机会。\n" +
                                "【记】读：不如吃。不如咱们把这瓶酒吃了吧？这是提出一个主题供讨论，大家同意后就可以开瓶了。\n" +
                                "【参】breach（n 缺口），cockroach（n 蟑螂）\n" +
                                "【反】close off（关闭）\"\n" +
                                " \n" +
                                "958,\"broaden\", vt ＝vi （使马路、知识面、心胸等）变宽，（使）扩大\n" +
                                "【例】To do a part-time job will broaden your outlook 打工可使你开阔眼界。The road broadens out at this point   这条马路在这里开始变宽。\n" +
                                "【类】broad:width＝heavy:weight宽广的宽度＝沉重的重量\"\n" +
                                " \n" +
                                "959,\"brocade\", n 织锦（有金银丝浮花或富丽的凸花纹）\n" +
                                "【例】gold [silver] brocade  织金[银]锦缎\n" +
                                "【记】读：不如K他，就是不如打他的意思，因为他穿了一身的织锦，这种公子哥最讨厌了，总是欺负良家妇女，K他！！！\n" +
                                "【参】cascade（n 小瀑布）；facade（n 表面，正面）\"\n" +
                                " \n" +
                                "960,\"brochure\", n 小册子（比如：推销材料和产品信息）＝booklet＝pamphlet\n" +
                                "【例】a holiday brochure  假日指南\n" +
                                "【记】读：不如撤。国民党溃败的时候就每人发了一本小册子，上书：不如撤。\"\n" +
                                " \n" +
                                "961,\"broil\", vt/vi 烧烤；酷暑\n" +
                                "【例】to broil a chicken  烧烤一只鸡   It's broiling today!  今天太热了！\n" +
                                "【记】烧烤要用oil；还要烧开水boil；两个r可以支起一个烧烤架。\"\n" +
                                " \n" +
                                "962,\"broker\", n 经纪人（他人的代理，如在谈判、签约、购买时的代理人）\n" +
                                "【源】“一笔交易做成时作为礼节性的礼品”\n" +
                                "【记】pawnbroker（n 典当商）\n" +
                                "【类】impresario:entertainment＝broker:trade剧团经理经营娱乐表演＝贸易经纪人经营贸易\"\n" +
                                " \n" +
                                "963,\"bromide\", n 陈词滥调＝platitude；溴化物（可作镇静剂,或止痛药）\n" +
                                "【记】读：不如买的。买的都是好东西，新潮的东西。不如买的就是过时的东西－陈词滥调\n" +
                                "【类】equivocation:misleading＝bromide:hackneyed模棱两可的话是误导的＝陈词滥调是陈腐的\n" +
                                "【反】unhackneyed（adj 新奇的）\"\n" +
                                " \n" +
                                "964,\"brooch\", n 用作装饰的胸针、领针等＝pin\n" +
                                "【记】读：布肉吃。胸针不是扎在布上就是扎在肉上。\"\n" +
                                " \n" +
                                "965,\"brood\", n （由同一母亲照料的）一窝幼鸟；v 孵（蛋）；（郁闷的）苦想\n" +
                                "【例】Don't brood about it   不要闷闷不乐地想了。\n" +
                                "【记】鸡在孵蛋的时候，苦想有几只男鸡，几只女鸡。\"\n" +
                                " \n" +
                                "966,\"brook\", v 容忍，忍受（常与否定词no连用）＝put up with；n 小河＝stream\n" +
                                "【例】A great man cannot brook a rival   一山难容二虎。\n" +
                                "【记】小河要容忍泛滥，或者断流的痛苦。\n" +
                                "【类】twig:limb＝brook:river  小树枝和树枝＝小河和河\n" +
                                "【反】refuse to tolerate（拒绝容忍）\"\n" +
                                " \n" +
                                "967,\"browbeat\", v 欺侮；吓唬（对…声色俱厉地进行威逼）＝bully＝bludgeon＝bluster＝bulldoze＝cow＝dragoon＝hector\n" +
                                "【记】brow眉毛，beat打架。>:-<（吓唬）\n" +
                                "【类】instigator:incite＝bully:browbeat煽动者擅长煽动＝欺凌弱小者擅长威逼\"\n" +
                                " \n" +
                                "968,\"browse\", v/n （与on连用）吃嫩草＝nibble；浏览（特点：快速，随意）\n" +
                                "【例】browse on grass  吃草browse through the book  浏览一下这本书\n" +
                                "【记】1）brow＝broust[嫩枝]－吃嫩叶；2）browser（n 计算机浏览器，吃嫩叶的动物）\"\n" +
                                " \n" +
                                "969,\"bruise\", n/v 瘀伤（皮下组织或骨头受伤，皮肤没破损，但是血管破裂，有淤血），擦伤（可指人，蔬菜，水果等）；（感情）受伤\n" +
                                "【例】My feeling was bruised   我的感情受到了伤害。I bruised my knee   我的膝盖擦伤了。\n" +
                                "【记】读：不如死。擦伤是小，感情受伤是大，还不如去死呢。\"\n" +
                                " \n" +
                                "970,\"bruit\", v （about，abroad）散布（谣言等）＝blazon\n" +
                                "【例】It is bruited that      据谣传…\n" +
                                "【记】读：不如他。我不如他？？？这是谣言！！！\n" +
                                "【反】keep secret（保守秘密）\"\n" +
                                " \n" +
                                "971,\"brunt\", n （进攻时的）主要冲击力＝impact＝shock\n" +
                                "【例】I had to bear the brunt of the criticisms   我不得不承受批评的压力。\n" +
                                "【记】中间有run跑，冲锋时的主要冲击力。\"\n" +
                                " \n" +
                                "972,\"brushwork\", n 绘画；画家的笔触、笔法、风格\n" +
                                "【例】rugged brushwork  粗犷笔法\"\n" +
                                " \n" +
                                "973,\"brusque\", adj （态度，语言）粗鲁无礼的、唐突鲁莽的＝rough＝abrupt＝blunt\n" +
                                "【例】brusque behavior  无礼的行为\n" +
                                "【记】1）源于意大利语brusco[粗野的，粗鲁的]－唐突鲁莽的2）读：不如死磕。动不动就要与人死磕－唐突鲁莽的3）brus＝brut野兽－粗鲁无礼的\"\n" +
                                " \n" +
                                "974,\"brutal\", adj （态度或语言）野蛮残忍的，粗暴无礼的＝savage＝violent；（天气）严酷的＝harsh＝rigorous\n" +
                                "【例】the brutal truth  残酷的事实   a brutal winter  严冬\n" +
                                "【记】brut野兽－野蛮残忍的。参：brutality（n 残酷，兽行）\"\n" +
                                " \n" +
                                "975,\"brute\", n （粗暴的，麻木不仁的）残忍的人；畜生\n" +
                                "【例】brute strength  蛮力   brute courage  匹夫之勇She is a brute to me   她虐待我。\n" +
                                "【记】brut野兽－残忍的人\"\n" +
                                " \n" +
                                "976,\"bubble\", v 起泡＝foam＝effervesce；n 气泡，水泡；象气泡般不切实际的想法\n" +
                                "【例】The kettle is at the bubble  壶里的水在沸腾。\n" +
                                "【区】bubble有u像个锅可以烧开水－气泡babble（v 说傻话），《bad boy》puddle（n 小水坑），u象小水坑pebble（n 小卵石），\"\n" +
                                " \n" +
                                "977,\"buck\", v  竭力反对＝oppose＝resist＝traverse；（马等）突然一跃（将骑手摔下）；n 雄鹿，雄兔，[口]美圆\n" +
                                "【例】I bucked at your suggestion   我坚决反对你的建议。\n" +
                                "【记】读：罢课。一种竭力反对上课的行为。\n" +
                                "【反】assent to（同意）\"\n" +
                                " \n" +
                                "978,\"bucket\", n 圆桶＝container，一桶之量；[俚]屁股；篮下禁区；v 雨倾盆而下\n" +
                                "【例】One bucket of paint will be enough for the wall 一桶油漆足够刷墙用了。The rain was coming down in buckets   天下着倾盆大雨。\"\n" +
                                " \n" +
                                "979,\"buckle\", n （安全带、皮带）扣环；v 扣紧＝fasten \n" +
                                "【记】读：叭扣，叭的一声扣上。buckle up扣紧安全带\"\n" +
                                " \n" +
                                "980,\"bucolic\", adj 乡村的＝rustic＝rural；牧羊的＝pastoral；田园生活的\n" +
                                "【记】bu＝bull（n 公牛），co＝cow（n 母牛）－养牛的－乡村的\n" +
                                "【类】palatial:hovel＝city[metropolis]:bucolic＝hovel:palatial富丽堂皇的对简陋的＝城市对乡村的＝简陋小屋对宏伟的\n" +
                                "【反】urban（adj 城市的）；sophisticated（adj 久经世故的）\"\n" +
                                " \n" +
                                "981,\"bud\", n 芽；花蕾；还未完全发育成熟的人或物（如：新思想的萌芽）\n" +
                                "【例】Trees begin to bud in the spring  树在春天开始发芽。\"\n" +
                                " \n" +
                                "982,\"budge\", v 微微移动一点＝move a little；妥协（改变立场或态度）＝yield\n" +
                                "【例】He can't budge this rock   他搬不动这块岩石。Money can't budge her   金钱不能使她改变立场。\n" +
                                "【记】budget（n 预算），去掉t（微微移动一点）就变成了‘budge’\n" +
                                "【类】obdurate[diehard]:budge＝lachrymose:cheer＝hidebound:innovation顽固的[人]不会让步＝悲哀的不会高兴＝死板的不会创新palter:candor＝vagary:predict   含糊其词不会直率＝奇特行为不会预知\"\n" +
                                " \n" +
                                "983,\"budget\", n 预算（给定时间内的系统消费计划）\n" +
                                "【例】A new car will not be part of my budget   买一辆新车不在我的预算之内\n" +
                                "【类】regimen:health＝budget:solvency 养生法可增加健康＝预算可增加偿债能力\"\n" +
                                " \n" +
                                "984,\"buffet\", v 把…连续的打来打去＝strike＝slap；自助餐\n" +
                                "【例】The travelers were buffeted about during the rough boat ride 船在风浪中航行，旅客们被颠得东倒西歪\n" +
                                "【记】读：8feet。比如：章鱼。可以把…连续的打来打去\"\n" +
                                " \n" +
                                "985,\"buffoon\", n 小丑，粗俗而愚蠢的人＝clown＝harlequin＝zany\n" +
                                "【记】读：把风。粗俗而愚蠢的人想当坏蛋都困难，只能干这种把风的工作。读：布冯－曾经是意大利国家队最年轻的守门员，虽然不像小丑，但是为了我们的前途，从现在开始，布冯就是小丑了。\n" +
                                "【类】ludicrous:buffoon＝dissolute:libertine＝humorous:wag＝inexperience:neophyte丑角特点是可笑的＝放纵者特点是放纵的＝小丑特点是幽默的＝新手的特点是没有经验\"\n" +
                                " \n" +
                                "986,\"bugaboo\", n 吓人的东西（经常夸大了令人害怕的程度）；妖怪＝bugbear \n" +
                                "【记】bug臭虫，a一块，boo布。如上图：臭虫盖上一块布。\"\n" +
                                " \n" +
                                "987,\"buggy\", n 轻型马车＝carriage；婴儿车＝baby carriage；adj 臭虫成灾的\n" +
                                "【记】bug臭虫。象臭虫一样大的车：婴儿车\"\n" +
                                " \n" +
                                "988,\"bulb\", n 植物的球茎；球状物；灯泡；扁桃腺；快门\n" +
                                "【参】bulbous（adj 球根的，球根长成的）；bulb作词根：圆\"\n" +
                                " \n" +
                                "989,\"bulge\", v/n 膨胀，鼓起，突起的状态＝protrude＝jut＝outthrust＝protuberance\n" +
                                "【例】My pocket bulges with money   我的衣袋因装着钱鼓了起来。\n" +
                                "【记】读：爆炸－膨胀，鼓起，突起的状态\n" +
                                "【区】budge（v 让步）budget让一个t出来。bilge（n 船底），bill钞票，ge搁，把钞票搁在船底来走私。\n" +
                                "【反】depressed region（凹陷的地方）\"\n" +
                                " \n" +
                                "990,\"bulk\", n 体积，数量＝size＝quantity；大多数；大块头（尤指人的身体）\n" +
                                "【例】The bulk of the students voted   大多数同学投了票。\n" +
                                "【记】读：宝库。既有体积，又有数量。\"\n" +
                                " \n" +
                                "991,\"bulletin\", n 布告，公告（一种简短的报告，关于政府就公众感兴趣的事件，并使其立即公开） \n" +
                                "【例】bulletin board  布告牌\n" +
                                "【记】bullet子弹，in进。布告可以用子弹打进去。\"\n" +
                                " \n" +
                                "992,\"bullion\", n 金、银条块（只考虑数量而不重价值的金或银）；金银丝花边\n" +
                                "【记】bull公牛，lion狮子，卖公牛得银，卖狮子得金；或者：想看公牛斗狮子，拿金条来；或者：用公牛和狮子守住金库的门。\"\n" +
                                " \n" +
                                "993,\"bully\", v （用威胁，恐吓的方式）以强欺弱＝hurt＝tyrannize ；n 欺负弱小者\n" +
                                "【例】He's always bullying smaller children   他总是欺侮比他小的孩子。\n" +
                                "【记】1）bul＝boele[情人]，在争夺情人的斗争中总是强的打败弱的，所以有”欺负”之意2）BULL芝加哥公牛队：以强欺弱的典型，不过已经成为历史了。\n" +
                                "【类】instigator:incite＝bully:browbeat[intimidate]＝stupid:gullibility煽  欺负:恐吓\n" +
                                "【反】underdog（n 受压迫者）动者煽动＝欺凌弱小者恐吓＝笨人轻信sabotage:subvertness＝bull:intimidation『dupe:duplicity』阴谋破坏是一种颠覆＝暴力强迫是一种胁迫bully:scare\"\n" +
                                " \n" +
                                "994,\"bulwark\", n 堡垒（用作防御工事的墙或土堤）＝rampart；保障\n" +
                                "【例】Law is the bulwark of society   法律是社会的防御工具。\n" +
                                "【记】1）bul＝bole[板条，厚板]，wark工作－用厚板工作－堡垒2）bul＝bull公牛，wark工作。防止公牛的工作－作堡垒\"\n" +
                                " \n" +
                                "995,\"bumble\", v 结结巴巴地说＝stumble；踉跄笨拙地走；弄糟笨拙地做\n" +
                                "【例】The old lady kept bumbling on about something 老太太结结巴巴地说个不停\n" +
                                "【记】读：8ball。踩在8个球上走－踉跄笨拙地走＝stumble（v 跌倒，结巴）\n" +
                                "【区】humble（adj 谦虚的）；bumblebee（n 大黄蜂）\"\n" +
                                " \n" +
                                "996,\"bump\", v 碰撞＝hit＝knock；n 碰撞声\n" +
                                "【例】he couldn't see clearly and ran bump into a tree 昏暗中他看不清一头撞在一棵树上。\n" +
                                "【记】象声词\"\n" +
                                " \n" +
                                "997,\"bumper\", n （汽车前后的）保险杠；（铁路机车的）减震器（用来减少碰撞中的冲击的金属杆） \n" +
                                "【记】bump（v 碰撞）－防止碰撞的东西－保险杠\n" +
                                "【参】bumpy（adj 崎岖的），地上都是碰撞的坑。\n" +
                                "【类】protocol:blunder＝bumper:damage学习礼节防止犯错＝安装保险杠防止毁坏\"\n" +
                                " \n" +
                                "998,\"bumptious\", adj 傲慢的，自夸的\n" +
                                "【例】be bumptious over one's inferiors  对下级态度傲慢\n" +
                                "【记】混合了bump（v 碰撞），presumptuous（adj 专横的）：喜欢顶撞的专横的人－傲慢的\n" +
                                "【类】dour:geniality＝impetuous:vacillation[hesitation]＝bumptious:humbleness严厉的不亲切＝冲动的不犹豫＝傲慢的不谦逊bumptious:bombast＝exaggerative:hyperbole盲目自大的用夸大的言辞＝夸张的用夸张法\n" +
                                "【反】humble（adj 谦逊的）\"\n" +
                                " \n" +
                                "999,\"bungle\", v 粗制滥造，拙劣的工作（do sth badly）；n 拙劣的工作（做事拙劣或低效率）＝blooper＝blunder＝boner＝fluff＝lapse\n" +
                                "【例】I bungled the job   我把事情搞糟了。\n" +
                                "【记】读：般沟。帮人搬家把东西般到沟里－拙劣的工作\n" +
                                "【参】bungler（n 笨手笨脚的人）；jungle（n 丛林）读：长高tangle（v 纠缠）读：探戈－两个人纠缠在一起。\n" +
                                "【反】bring off（顺利完成）\"\n" +
                                " \n" +
                                "1000,\"buoy\", n 浮标（带有铃或灯的漂浮物，用来作危险警告或航道指示）；救生圈； v 支持，鼓励＝encourage\n" +
                                "【例】They were buoyed up by good news   他们为好消息所鼓舞。\n" +
                                "【记】boy＋u（象大水坑）：男孩掉进大水坑－需要救生圈。\n" +
                                "【参】buoyancy（n 浮动，快乐）\n" +
                                "【反】unsupported（adj 无支持的）－buoyed（adj 支持的）；sink（v 沉下）\"\n" +
                                " 定义了一系列写入缓存区的方法，当然其一定定义了与Buffer相关的方法，具体方法相见官方API。  BufferedSink中定义了一系列写入缓存区的方法，当然其一定定义了与Buffer相关的方法，具体方法相见官方API。  BufferedSink中定义了一系列写入缓存区的方法，当然其一定定义了与Buffer相关的方法，具体方法相见官方API。  BufferedSink中定义了一系列写入缓存区的方法，当然其一定定义了与Buffer相关的方法，具体方法相见官方API。  BufferedSink中定义了一系列写入缓存区的方法，当然其一定定义了与Buffer相关的方法，具体方法相见官方API。  BufferedSink中定义了一系列写入缓存区的方法，当然其一定定义了与Buffer相关的方法，具体方法相见官方API。  BufferedSink中定义了一系列写入缓存区的方法，当然其一定定义了与Buffer相关的方法，具体方法相见官方API。  BufferedSink中定义了一系列写入缓存区的方法，当然其一定定义了与Buffer相关的方法，具体方法相见官方API。", 1);
                        Thread.sleep(5);
                    }
                    Log.d(TAG, "write log end");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void loganSend() {
        SimpleDateFormat dataFormat = new SimpleDateFormat("yyyy-MM-dd");
        String d = dataFormat.format(new Date(System.currentTimeMillis()));
        String[] temp = new String[1];
        temp[0] = d;
        String ip = mEditIp.getText().toString().trim();
        if (!TextUtils.isEmpty(ip)) {
            mSendLogRunnable.setIp(ip);
        }
        Logan.s(temp, mSendLogRunnable);
    }

    private void loganFilesInfo() {
        Map<String, Long> map = Logan.getAllFilesInfo();
        if (map != null) {
            StringBuilder info = new StringBuilder();
            for (Map.Entry<String, Long> entry : map.entrySet()) {
                info.append("文件日期：").append(entry.getKey()).append("  文件大小（bytes）：").append(
                        entry.getValue()).append("\n");
            }
            mTvInfo.setText(info.toString());
        }
    }
}
