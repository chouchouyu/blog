package com.cm.android.infors.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;

import com.cm.android.infors.core.InforsConfig;


/**
 * 创建SP
 *
 * @author wusm
 */
public class SharedPreferencesFactory {
    private final Context context;
    private final InforsConfig config;

    public SharedPreferencesFactory(@NonNull Context context, @NonNull InforsConfig config) {
        this.context = context;
        this.config = config;
    }

    /**
     * @return The Shared Preferences where ACRA will retrieve its user adjustable setting.
     */
    @NonNull
    public SharedPreferences create() {
        //noinspection ConstantConditions
        if (context == null) {
            throw new IllegalStateException("在创建SharePerfect之前需要先 infors.init(app).");
        } else if (!"".equals(config.sharedPreferencesName())) {
            return context.getSharedPreferences(config.sharedPreferencesName(), config.sharedPreferencesMode());
        } else {
            return PreferenceManager.getDefaultSharedPreferences(context);
        }
    }




}
