package com.cm.android.infors.core;

import android.content.Context;
import android.util.Log;

import com.cm.android.infors.LoganCallBack;
import com.cm.android.infors.core.report.Upload;
import com.cm.android.infors.utils.InforsUtil;
import com.dianping.logan.Logan;
import com.dianping.logan.LoganConfig;
import com.dianping.logan.OnLoganProtocolStatus;
import com.dianping.logan.SendLogRunnable;

import java.io.*;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;


/**
 * Logan的封装
 */
public class LoganHelper {

//    private static final String FILE_NAME = "Infors_Logan";

    private final SDKSwitchHandler sdkSwitchHandler;
    private final Upload upload;
    private final Context context;
    private final int maxLogFile;
    private RealSendLogRunnable mSendLogRunnable;

    public interface NetCallBack {
        void onSuccess();

        void onProgress(long bytesRead, long contentLength);

        void onFailure(String msg);
    }


    ///storage/emulated/0/Android/data/com.cm.android.infors.demo/files/Infors_Logan
    private String getLogFilePath(Context context) {
        return context.getExternalFilesDir(null).getAbsolutePath()
                + File.separator + Consts.SDK_NAME;
    }


//    private static final long MAX_FILE_SIZE = 3;
//    private static final long M_SIZE = 1024 * 1024 * 1024;

    public LoganHelper(Context context, boolean loggable, InforsConfig inforsConfig, Upload
            upload, int maxLogFile) {

        this.sdkSwitchHandler = new SDKSwitchHandler(context, inforsConfig);
        this.upload = upload;
        this.context = context;
        if (maxLogFile > 0) {
            this.maxLogFile = maxLogFile;
        } else {
            this.maxLogFile = 10;
        }
        LoganConfig config = new LoganConfig.Builder()
                .setCachePath(context.getFilesDir().getAbsolutePath())
                .setPath(getLogFilePath(context))
                .setMaxFile(maxLogFile)
                .setEncryptKey16(InforsUtil.SubStringAppkey(inforsConfig.getAppKey()).getBytes())
                .setEncryptIV16(InforsUtil.SubStringAppkey(inforsConfig.getAppKey()).getBytes())
                .build();
        Logan.init(config);
        if (loggable) {
            Logan.setDebug(true);
        } else {
            Logan.setDebug(false);
        }

        Logan.setOnLoganProtocolStatus(new OnLoganProtocolStatus() {
            @Override
            public void loganProtocolStatus(String cmd, int code) {
                Logger.i(TAG, "clogan --> cmd : " + cmd + " | " + "code : " + code);
            }
        });
        mSendLogRunnable = new RealSendLogRunnable();
    }

    public void saveLog(String msg, int type) {
        if (sdkSwitchHandler.isLogPrintEnable()) {
            Logan.w(msg, type);
        }
    }


    public void flushLog() {
        if (sdkSwitchHandler.isLogPrintEnable()) {
            Logan.f();
        }
    }

    public Map<String, Long> getAllLogFilesInfo() {
        return Logan.getAllFilesInfo();
    }


    /**
     * @param date          2019-05-22
     * @param loganCallBack
     */
    public void reportLog(String[] date, LoganCallBack loganCallBack) {
        if (sdkSwitchHandler.isInforsEnable()) {
            return;
        }
        for (String item : date) {
            if (null != Logan.getAllFilesInfo() && Logan.getAllFilesInfo().containsKey(item)) {
                mSendLogRunnable.setUserCallback(loganCallBack);
                Logan.s(date, mSendLogRunnable);
            } else {
                loganCallBack.noLogExist("date " + item + " doesn't have any log!");
            }
        }

    }

    class RealSendLogRunnable extends SendLogRunnable {

        private LoganCallBack loganCallBack;

        @Override
        public void sendLog(final List<File> logFile) {
            if (logFile.size() != 0) {

                upload.uploadLogFiles(context, logFile, new NetCallBack() {
                    @Override
                    public void onSuccess() {
//                    Logger.d("userLog" + "->  onSuccess");
                        // Must Call finish after send log
                        finish();
                        if (null != loganCallBack) {
                            loganCallBack.onRequestSuccess();
                        }
//                                    变量文件夹下所有日志
                        for (File file : logFile) {
                            if (file.getName().contains(".copy")) {
                                Logger.i(TAG, "logan --> 删除文件 : " + file.getAbsolutePath());
                                file.delete();
                            }
                        }
                        if (null != loganCallBack) {
                            loganCallBack.onFileDeleted();
                        }
                    }


                    @Override
                    public void onProgress(long bytesRead, long contentLength) {
                        if (null != loganCallBack) {
                            loganCallBack.onRequestProgress(bytesRead, contentLength);
                        }
//                    Logger.d("userLog" + "->  提示:上传中", "总共" + totalBytesCount + "已传" +
// currentBytesCount);
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != loganCallBack) {
                            loganCallBack.onRequestFailure(msg);
                        }

                        // D/Infors::: userLog->  onFailureWrite error: ssl=0xab47b400: I/O error
                        // during system call, Broken pipe
//                    Logger.d("userLog" + "->  onFailure " + msg);
                    }
                });
            } else {
                finish();
                for (File file : logFile) {
                    if (file.getName().contains(".copy")) {
                        Logger.i(TAG, "logan --> 删除文件 : " + file.getAbsolutePath());
                        file.delete();
                    }
                }
                if (null != loganCallBack) {
                    loganCallBack.onFileDeleted();
                }
            }

        }


        public void setUserCallback(LoganCallBack loganCallBack) {
            this.loganCallBack = loganCallBack;
        }
    }

}
