package com.cm.android.infors.core;


/**
 * 常量
 * Created by wusm on 2018/4/2.
 */
public final class Consts {
    public static final String SDK_NAME = "Infors";
    public static final String TAG = SDK_NAME + "::";
    public static final String SDK_VERSION = "4.0.9";
    public static final String TABLE_NAME = SDK_NAME;
    public static final String TABLE_APM = SDK_NAME + "_APM";
    public static final int THRESHOLD = 20;
    public static final int M = 1024 * 1024; //M
    public static final String SUCCESSCODE = "Y";
    public static final String defaultValue = "default";
    public static final String HeatMap = "HeatMap";
    public static final String PLATFORM = "android";
    public static final float DEFAULT_DEVICE_REFRESH_RATE = 16.666667f;
    public static final int TIME_MILLIS_TO_NANO = 1000000;
    public static long THRESHOLD_TIME = 2000;
    public static int MAX_BODY_LENGTH = 500;
    public static String JSONERROR = "log format error";
    //    public static final String WS_URL = "wss://touch-di1.sit.cmrh.com/api/sdk-ws";
    //    public static final String WS_URL = "ws://10.200.80.77:10801/api/sdk-ws";

    public static final String SP_DEVICE_ID = "Infors.deviceId2";
    public static final String SP_PC_CFG = "Infors.CFG";
    public static final String SP_APP_LAUNCH = "Infors.launch";
    public static final String SP_IS_WEBSOCKT = "Infors.websocket";
    //sdk总开关
    public static final String SP_SWITCH_INFORS = "Infors.isInforsEnable";
    //奔溃的开关
    public static final String SP_SWITCH_CRASH = "Infors.isCrashEnable";
    //卡顿APM
    public static final String SP_SWITCH_BLOCK = "Infors.isBlockEnable";
    //网络APM
    public static final String SP_SWITCH_HTTP = "Infors.isHttpEnable";
    // 关闭时，只上报用户手动上报的事件 EventType包括 track userInfo deviceInfo. pageview
    public static final String SP_SWITCH_AUTOTRACE = "Infors.isAutoTraceEnable";
    //可视化的开关 相关的EventType click
    public static final String SP_SWITCH_VIEWEDITOR = "Infors.isViewEditorEnable";
    //热力图的开关 相关EventType touch
    public static final String SP_SWITCH_HEATMAP = "Infors.isHeatMapEnable";
    //打印日志至文件的开关
    public static final String SP_SWITCH_LOG_PRINT = "Infors.isPrintLogEnable";
    //上传日志至文件的开关
    public static final String SP_SWITCH_LOG_UPLOAD = "Infors.isUploadLogEnable";

    public static final String SP_USERINFO = "Infors.USER_ID";

    public static final String SP_TO_BACKGROUND = "Infors.ToBackground";

//    public static final String SP_SESSIONID = "Infors.SessionId";

//    public static final String WS_URL = "wss://touch-di1.sit.cmrh.com/api/sdk-ws";
    //    public static final String WS_URL = "ws://10.200.80.77:10801/api/sdk-ws";


    public static final String TYPE_JS = "JS";
    public static final String TYPE_BLOCK = "block";
    public static final String TYPE_HTTP = "http";
    public static final String TYPE_CRASH = "crash";
    public static final String TYPE_PAGE_PAUSE = "page_pause";
    public static final String TYPE_PAGE_RESUME = "page_resume";
    public static final String TYPE_USER = "userInfo";
    //app启动事件
    public static final String TYPE_LAUNCH = "launch";
    public static final String TYPE_DEVICE = "deviceType";
    //热力图 heatmap
    public static final String TYPE_TOUCH = "touch";
    //用户自埋点
    public static final String TYPE_TRACK = "track";
    //页面跳转
    public static final String TYPE_PAGEVIEW = "pageview";
    //可视化
    public static final String TYPE_VISUAL_TRACK = "visualtrack";


}
