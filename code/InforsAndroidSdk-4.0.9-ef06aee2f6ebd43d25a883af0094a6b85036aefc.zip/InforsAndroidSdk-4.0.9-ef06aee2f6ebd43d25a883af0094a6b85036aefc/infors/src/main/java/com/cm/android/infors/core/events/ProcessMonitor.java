package com.cm.android.infors.core.events;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import com.cm.android.infors.core.Logger;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


/**
 * 前后台切换监听
 * <p/>
 *
 * @author wusm
 */
public class ProcessMonitor implements ActivityTracker.Listener {
    private static final ProcessMonitor _sInstance = new ProcessMonitor();

    private static final String TAG = "ProcessMonitor";

    private static int compatStartCount = 0;

    private static boolean isCompatForeground = true;
    private static boolean isCompatLockStop = false;

    private static boolean isStandard() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB;
    }

    private static boolean isInteractive(Context context) {
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            return pm.isInteractive();
        } else {
            return pm.isScreenOn();
        }
    }

    public static ProcessMonitor get() {
        return _sInstance;
    }

 
    public void start() {
        ActivityTracker activityTracker = ActivityTracker.get();
        activityTracker.registerListener(this);
    }

    private static void onStart(Activity activity) {
        compatStartCount++;
        if (!isCompatForeground) {
            isCompatForeground = true;
            onBackgroundToForeground(activity);
        }
    }

    private static void onResume(Activity activity) {
        if (isStandard()) {
            //np
        } else {
            if (isCompatLockStop) {
                isCompatLockStop = false;
                onStart(activity);
            }
        }
    }

    private static void onPause(Activity activity) {
        if (isStandard()) {
            //np
        } else {
            if (!isInteractive(activity)) { //锁屏触发
                isCompatLockStop = true;
                onStop(activity);
            }
        }
    }

    private static void onStop(Activity activity) {
        compatStartCount--;
        if (compatStartCount == 0) {
            isCompatForeground = false;
            onForegroundToBackground(activity);
        }
    }

    private static void onForegroundToBackground(Activity activity) {
        for (ProcessMonitor.Listener listener : mListeners) {
            listener.onActivityForegroundToBackground(activity);
        }
        Logger.i(TAG, "前台->后台" + activity.getClass().getCanonicalName());

    }

    private static final List<Listener> mListeners = new CopyOnWriteArrayList<>();

    public void unregisterListener(ProcessMonitor.Listener listener) {
        mListeners.remove(listener);
    }

    public void registerListener(ProcessMonitor.Listener listener) {
        mListeners.add(listener);
    }

    @Override
    public void onActivityCreate(Activity activity) {
    }

    @Override
    public void onActivityStart(Activity activity) {
        onStart(activity);
    }

    @Override
    public void onActivityResume(Activity activity) {
        onResume(activity);
    }

    @Override
    public void onActivityPause(Activity activity) {
        onPause(activity);
    }

    @Override
    public void onActivityStop(Activity activity) {
        onStop(activity);
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
    }

    public interface Listener {
        void onActivityForegroundToBackground(Activity activity);

        void onActivityBackgroundToForeground(Activity activity);
    }

    private static void onBackgroundToForeground(Activity activity) {
        for (ProcessMonitor.Listener listener : mListeners) {
            listener.onActivityBackgroundToForeground(activity);
        }
        Logger.i(TAG, "后台->前台 " + activity.getClass().getCanonicalName());
    }


}