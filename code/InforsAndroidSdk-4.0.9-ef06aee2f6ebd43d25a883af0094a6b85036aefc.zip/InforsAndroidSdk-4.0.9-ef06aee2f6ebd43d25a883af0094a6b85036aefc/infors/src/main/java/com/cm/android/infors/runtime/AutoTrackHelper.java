package com.cm.android.infors.runtime;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.cm.android.infors.Infors;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.R;
import com.cm.android.infors.core.InitialPlugin;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.core.ReportField;
import com.cm.android.infors.request.modal.ViewConfigRes;

import com.cm.android.infors.utils.ViewPathUtil;
import com.google.gson.Gson;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

import static com.cm.android.infors.core.Consts.*;

/**
 * 字节码插桩调用的类
 *
 * @author wusm
 */
public class AutoTrackHelper {
    private static HashMap<Integer, Long> eventTimestamp = new HashMap<>();

    private static boolean isDeBounceTrack(Object object) {
        boolean isDeBounceTrack = false;
        long currentOnClickTimestamp = System.currentTimeMillis();
        Object targetObject = eventTimestamp.get(object.hashCode());
        if (targetObject != null) {
            long lastOnClickTimestamp = (long) targetObject;
            if ((currentOnClickTimestamp - lastOnClickTimestamp) < 500) {
                isDeBounceTrack = true;
            }
        }

        eventTimestamp.put(object.hashCode(), currentOnClickTimestamp);
        return isDeBounceTrack;
    }

    private static void traverseView(String fragmentName, ViewGroup root) {
        try {
            if (TextUtils.isEmpty(fragmentName)) {
                return;
            }

            if (root == null) {
                return;
            }

            final int childCount = root.getChildCount();
            for (int i = 0; i < childCount; ++i) {
                final View child = root.getChildAt(i);
                if (child instanceof ListView ||
                        child instanceof GridView ||
                        child instanceof Spinner ||
                        child instanceof RadioGroup) {
                    child.setTag(R.id.auto_track_tag_view_fragment_name, fragmentName);
                } else if (child instanceof ViewGroup) {
                    traverseView(fragmentName, (ViewGroup) child);
                } else {
                    child.setTag(R.id.auto_track_tag_view_fragment_name, fragmentName);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static boolean isFragment(Object object) {
        try {
            Class<?> supportFragmentClass = null;
            Class<?> androidXFragmentClass = null;
            try {
                supportFragmentClass = Class.forName("android.support.v4.app.Fragment");
            } catch (Exception e) {
                //ignored
            }

            try {
                androidXFragmentClass = Class.forName("androidx.fragment.app.Fragment");
            } catch (Exception e) {
                //ignored
            }

            if (supportFragmentClass == null && androidXFragmentClass == null) {
                return false;
            }

            if ((supportFragmentClass != null
                    && supportFragmentClass.isInstance(object)) ||
                    (androidXFragmentClass != null
                            && androidXFragmentClass.isInstance(object))) {
                return true;
            }
        } catch (Exception e) {
            //ignored
        }
        return false;
    }

    public static void onFragmentViewCreated(Object object, View rootView, Bundle bundle) {
        try {
            if (!isFragment(object)) {
                return;
            }

            //Fragment名称
            String fragmentName = object.getClass().getName();

            if (rootView instanceof ViewGroup) {
                traverseView(fragmentName, (ViewGroup) rootView);
            } else {
                rootView.setTag(R.id.auto_track_tag_view_fragment_name, fragmentName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static void trackFragmentAppViewScreen(Object fragment) {
        try {

            if ("com.bumptech.glide.manager.SupportRequestManagerFragment".equals(fragment.getClass().getCanonicalName())) {
                return;
            }


//            JSONObject properties = new JSONObject();
            Map<String, Object> map = new HashMap<String, Object>();

            String fragmentName = fragment.getClass().getCanonicalName();
            Activity activity = null;
            try {
                Method getActivityMethod = fragment.getClass().getMethod("getActivity");
                if (getActivityMethod != null) {
                    activity = (Activity) getActivityMethod.invoke(fragment);
                }
            } catch (Exception e) {
                //ignored
            }

            if (activity != null) {
//                String activityTitle = AutoTrackUtils.getActivityTitle(activity);
//                if (!TextUtils.isEmpty(activityTitle)) {
//                    properties.put(AopConstants.TITLE, activityTitle);
//                }
                map.put(ReportField.pageId.name(), String.format(Locale.CHINA, "%s|%s", activity.getClass().getCanonicalName(), fragmentName));
//                properties.put(AopConstants.SCREEN_NAME, String.format(Locale.CHINA, "%s|%s", activity.getClass().getCanonicalName(), fragmentName));
            } else {
                map.put(ReportField.pageId.name(), fragmentName);
//                properties.put(AopConstants.SCREEN_NAME, fragmentName);
            }

//            SensorsDataFragmentTitle sensorsDataFragmentTitle = fragment.getClass().getAnnotation(SensorsDataFragmentTitle.class);
//            if (sensorsDataFragmentTitle != null) {
//                properties.put(AopConstants.TITLE, sensorsDataFragmentTitle.title());
//            }

//            if (fragment instanceof ScreenAutoTracker) {
//                ScreenAutoTracker screenAutoTracker = (ScreenAutoTracker) fragment;
//
//                String screenUrl = screenAutoTracker.getScreenUrl();
//                JSONObject otherProperties = screenAutoTracker.getTrackProperties();
//                if (otherProperties != null) {
//                    SensorsDataUtils.mergeJSONObject(otherProperties, properties);
//                }
//
//                SensorsDataAPI.sharedInstance().trackViewScreen(screenUrl, properties);
//            } else {
//                SensorsDataAutoTrackAppViewScreenUrl autoTrackAppViewScreenUrl = fragment.getClass().getAnnotation(SensorsDataAutoTrackAppViewScreenUrl.class);
//                if (autoTrackAppViewScreenUrl != null) {
//                    String screenUrl = autoTrackAppViewScreenUrl.url();
//                    if (TextUtils.isEmpty(screenUrl)) {
//                        screenUrl = fragmentName;
//                    }
//                    SensorsDataAPI.sharedInstance().trackViewScreen(screenUrl, properties);
//                } else {
//                    SensorsDataAPI.sharedInstance().track("$AppViewScreen", properties);
//                }
//            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void trackFragmentResume(Object object) {

        if (!isFragment(object)) {
            return;
        }

        try {
            Method getParentFragmentMethod = object.getClass().getMethod("getParentFragment");
            if (getParentFragmentMethod != null) {
                Object parentFragment = getParentFragmentMethod.invoke(object);
                if (parentFragment == null) {
                    if (!fragmentIsHidden(object) && fragmentGetUserVisibleHint(object)) {
                        trackFragmentAppViewScreen(object);
                    }
                } else {
                    if (!fragmentIsHidden(object) && fragmentGetUserVisibleHint(object) && !fragmentIsHidden(parentFragment) && fragmentGetUserVisibleHint(parentFragment)) {
                        trackFragmentAppViewScreen(object);
                    }
                }
            }
        } catch (Exception e) {
            //ignored
        }
    }

    private static boolean fragmentGetUserVisibleHint(Object fragment) {
        try {
            Method getUserVisibleHintMethod = fragment.getClass().getMethod("getUserVisibleHint");
            if (getUserVisibleHintMethod != null) {
                return (boolean) getUserVisibleHintMethod.invoke(fragment);
            }
        } catch (Exception e) {
            //ignored
        }
        return false;
    }

    private static boolean fragmentIsHidden(Object fragment) {
        try {
            Method isHiddenMethod = fragment.getClass().getMethod("isHidden");
            if (isHiddenMethod != null) {
                return (boolean) isHiddenMethod.invoke(fragment);
            }
        } catch (Exception e) {
            //ignored
        }
        return false;
    }

    public static void trackFragmentSetUserVisibleHint(Object object, boolean isVisibleToUser) {

        if (!isFragment(object)) {
            return;
        }

        Object parentFragment = null;
        try {
            Method getParentFragmentMethod = object.getClass().getMethod("getParentFragment");
            if (getParentFragmentMethod != null) {
                parentFragment = getParentFragmentMethod.invoke(object);
            }
        } catch (Exception e) {
            //ignored
        }

        if (parentFragment == null) {
            if (isVisibleToUser) {
                if (fragmentIsResumed(object)) {
                    if (!fragmentIsHidden(object)) {
                        trackFragmentAppViewScreen(object);
                    }
                }
            }
        } else {
            if (isVisibleToUser && fragmentGetUserVisibleHint(parentFragment)) {
                if (fragmentIsResumed(object) && fragmentIsResumed(parentFragment)) {
                    if (!fragmentIsHidden(object) && !fragmentIsHidden(parentFragment)) {
                        trackFragmentAppViewScreen(object);
                    }
                }
            }
        }
    }

    private static boolean fragmentIsResumed(Object fragment) {
        try {
            Method isResumedMethod = fragment.getClass().getMethod("isResumed");
            if (isResumedMethod != null) {
                return (boolean) isResumedMethod.invoke(fragment);
            }
        } catch (Exception e) {
            //ignored
        }
        return false;
    }

    public static void trackOnHiddenChanged(Object object, boolean hidden) {

        if (!isFragment(object)) {
            return;
        }

        Object parentFragment = null;
        try {
            Method getParentFragmentMethod = object.getClass().getMethod("getParentFragment");
            if (getParentFragmentMethod != null) {
                parentFragment = getParentFragmentMethod.invoke(object);
            }
        } catch (Exception e) {
            //ignored
        }

        if (parentFragment == null) {
            if (!hidden) {
                if (fragmentIsResumed(object)) {
                    if (fragmentGetUserVisibleHint(object)) {
                        trackFragmentAppViewScreen(object);
                    }
                }
            }
        } else {
            if (!hidden && !fragmentIsHidden(parentFragment)) {
                if (fragmentIsResumed(object) && fragmentIsResumed(parentFragment)) {
                    if (fragmentGetUserVisibleHint(object) && fragmentGetUserVisibleHint(parentFragment)) {
                        trackFragmentAppViewScreen(object);
                    }
                }
            }
        }
    }

    public static void trackExpandableListViewOnGroupClick(ExpandableListView expandableListView, View view,
                                                           int groupPosition) {
        try {

            //获取所在的 Context
            Context context = expandableListView.getContext();
            if (context == null) {
                return;
            }

            //将 Context 转成 Activity
            Activity activity = null;
            if (context instanceof Activity) {
                activity = (Activity) context;
            }

            Map<String, Object> map = new HashMap<String, Object>();
//            JSONObject properties = new JSONObject();
//            String xpath = ViewPathUtil.getViewPath(view);
//            collectionData.put(ReportField.xpath, new StringElement(xpath));
//            AutoTrackUtils.addViewPathProperties(activity, view, properties);
//            String pageName = null;

            // $screen_name & $title
//            if (activity != null) {
//                pageName = activity.getClass().getCanonicalName();
//                collectionData.put(ReportField.pageId, new StringElement(pageName));
//                properties.put(AopConstants.SCREEN_NAME, activity.getClass().getCanonicalName());
//                String activityTitle = AutoTrackUtils.getActivityTitle(activity);
//                if (!TextUtils.isEmpty(activityTitle)) {
//                    collectionData.put(ReportField.pageId, new StringElement(activityTitle));
//                    properties.put(AopConstants.TITLE, activityTitle);
//                }
//            }

            // ViewId

//            int viewId = AutoTrackUtils.getId(activity, view);
//            collectionData.put(ReportField.vid, new IntegerElement(viewId));
//            String idString = AutoTrackUtils.getViewId(expandableListView);
//            if (!TextUtils.isEmpty(idString)) {
//                properties.put(AopConstants.ELEMENT_ID, idString);
//            }
            map.put(ReportField.position.name(), String.format(Locale.CHINA, "%d", groupPosition));
//            properties.put(AopConstants.ELEMENT_POSITION, String.format(Locale.CHINA, "%d", groupPosition));
            map.put(ReportField.type.name(), view.getClass().getCanonicalName());


            String viewText = null;
            if (view instanceof ViewGroup) {
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    viewText = AutoTrackUtils.traverseView(stringBuilder, (ViewGroup) view);
                    if (!TextUtils.isEmpty(viewText)) {
                        viewText = viewText.substring(0, viewText.length() - 1);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            //$element_content
            if (!TextUtils.isEmpty(viewText)) {
                map.put(ReportField.text.name(), viewText);
//                properties.put(AopConstants.ELEMENT_CONTENT, viewText);
            }

            //fragmentName
            AutoTrackUtils.getFragmentNameFromView(expandableListView, map);

            // 获取 View 自定义属性
//            JSONObject p = (JSONObject) view.getTag(R.id.auto_track_tag_view_properties);
//            if (p != null) {
//                AutoTrackUtils.mergeJSONObject(p, properties);
//            }

            // 扩展属性
            ExpandableListAdapter listAdapter = expandableListView.getExpandableListAdapter();
            if (listAdapter != null) {
//                if (listAdapter instanceof SensorsExpandableListViewItemTrackProperties) {
//                    try {
//                        SensorsExpandableListViewItemTrackProperties trackProperties = (SensorsExpandableListViewItemTrackProperties) listAdapter;
//                        JSONObject jsonObject = trackProperties.getSensorsGroupItemTrackProperties(groupPosition);
//                        if (jsonObject != null) {
//                            AutoTrackUtils.mergeJSONObject(jsonObject, properties);
//                        }
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
//                }
            }

            Logger.i(TAG, "cfg -> AutoTrack trackExpandableListViewOnGroupClick  : " + map.toString());
            reportEvent(map, activity, view);

//            collectorFactory.save(new ClickCollector(vid, viewText
//                    , "[Auto]" + "click:" + view.getClass().getSimpleName() + "-" + viewText
//                    , System.currentTimeMillis(), collectionData));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void trackExpandableListViewOnChildClick(ExpandableListView expandableListView, View view,
                                                           int groupPosition, int childPosition) {
        try {
            //关闭 AutoTrack
//            if (!SensorsDataAPI.sharedInstance().isAutoTrackEnabled()) {
//                return;
//            }

            //$AppClick 被过滤
//            if (SensorsDataAPI.sharedInstance().isAutoTrackEventTypeIgnored(SensorsDataAPI.AutoTrackEventType.APP_CLICK)) {
//                return;
//            }

            //获取所在的 Context
            Context context = expandableListView.getContext();
            if (context == null) {
                return;
            }

            //将 Context 转成 Activity
            Activity activity = AutoTrackUtils.getActivityFromContext(context, expandableListView);

            //Activity 被忽略
//            if (activity != null) {
//                if (SensorsDataAPI.sharedInstance().isActivityAutoTrackAppClickIgnored(activity.getClass())) {
//                    return;
//                }
//            }

            //ExpandableListView 被忽略
//            if (AutoTrackUtils.isViewIgnored(ExpandableListView.class)) {
//                return;
//            }

            //View 被忽略
//            if (AutoTrackUtils.isViewIgnored(expandableListView)) {
//                return;
//            }

            //View 被忽略
//            if (AutoTrackUtils.isViewIgnored(view)) {
//                return;
//            }

            //获取 View 自定义属性
//            JSONObject properties = (JSONObject) view.getTag(R.id.auto_track_tag_view_properties);
//
//            if (properties == null) {
//                properties = new JSONObject();
//            }

            Map<String, Object> map = new HashMap<String, Object>();
            map.put(ReportField.position.name(), String.format(Locale.CHINA, "%d:%d", groupPosition, childPosition));
//            properties.put(AopConstants.ELEMENT_POSITION, String.format(Locale.CHINA, "%d:%d", groupPosition, childPosition));

            //扩展属性
            ExpandableListAdapter listAdapter = expandableListView.getExpandableListAdapter();
            if (listAdapter != null) {
//                if (listAdapter instanceof SensorsExpandableListViewItemTrackProperties) {
//                    SensorsExpandableListViewItemTrackProperties trackProperties = (SensorsExpandableListViewItemTrackProperties) listAdapter;
//                    JSONObject jsonObject = trackProperties.getSensorsChildItemTrackProperties(groupPosition, childPosition);
//                    if (jsonObject != null) {
//                        AutoTrackUtils.mergeJSONObject(jsonObject, properties);
//                    }
//                }
            }
//            String xpath = ViewPathUtil.getViewPath(view);
//            collectionData.put(ReportField.xpath, new StringElement(xpath));
//            AutoTrackUtils.addViewPathProperties(activity, view, properties);
//            String pageName = null;
            //$screen_name & $title
//            if (activity != null) {
//
//                pageName = activity.getClass().getCanonicalName();
//                collectionData.put(ReportField.pageId, new StringElement(pageName));
//                properties.put(AopConstants.SCREEN_NAME, activity.getClass().getCanonicalName());
//                String activityTitle = AutoTrackUtils.getActivityTitle(activity);
//                if (!TextUtils.isEmpty(activityTitle)) {
//                    properties.put(AopConstants.TITLE, activityTitle);
//                }
//            }

            //ViewId
//            int viewId = AutoTrackUtils.getId(activity, view);
//            collectionData.put(ReportField.vid, new IntegerElement(viewId));
//            String idString = AutoTrackUtils.getViewId(expandableListView);
//            if (!TextUtils.isEmpty(idString)) {
//                properties.put(AopConstants.ELEMENT_ID, idString);
//            }

//            properties.put(AopConstants.ELEMENT_TYPE, "ExpandableListView");

            map.put(ReportField.type.name(), view.getClass().getCanonicalName());


            String viewText = null;
            if (view instanceof ViewGroup) {
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    viewText = AutoTrackUtils.traverseView(stringBuilder, (ViewGroup) view);
                    if (!TextUtils.isEmpty(viewText)) {
                        viewText = viewText.substring(0, viewText.length() - 1);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            //$element_content
            if (!TextUtils.isEmpty(viewText)) {
                map.put(ReportField.text.name(), viewText);
//                properties.put(AopConstants.ELEMENT_CONTENT, viewText);
            }

            //fragmentName
//            AutoTrackUtils.getFragmentNameFromView(expandableListView, properties);

            //获取 View 自定义属性
//            JSONObject p = (JSONObject) view.getTag(R.id.auto_track_tag_view_properties);
//            if (p != null) {
//                AutoTrackUtils.mergeJSONObject(p, properties);
//            }
            Logger.i(TAG, "cfg -> AutoTrack trackExpandableListViewOnChildClick  : " + map.toString());
//            Log.e("why", collectionData.toJSON().toString());
            reportEvent(map, activity, view);

//            SensorsDataAPI.sharedInstance().track(AopConstants.APP_CLICK_EVENT_NAME, properties);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void trackTabHost(String tabName) {
        try {
            //关闭 AutoTrack
//            if (!SensorsDataAPI.sharedInstance().isAutoTrackEnabled()) {
//                return;
//            }

            //$AppClick 被过滤
//            if (SensorsDataAPI.sharedInstance().isAutoTrackEventTypeIgnored(SensorsDataAPI.AutoTrackEventType.APP_CLICK)) {
//                return;
//            }

            //TabHost 被忽略
//            if (AutoTrackUtils.isViewIgnored(TabHost.class)) {
//                return;
//            }

//            JSONObject properties = new JSONObject();

//            properties.put(AopConstants.ELEMENT_CONTENT, tabName);

//            properties.put(AopConstants.ELEMENT_TYPE, "TabHost");
//            SensorsDataAPI.sharedInstance().track(AopConstants.APP_CLICK_EVENT_NAME, properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void trackTabLayoutSelected(Object object, Object tab) {
        try {
            //关闭 AutoTrack
//            if (!SensorsDataAPI.sharedInstance().isAutoTrackEnabled()) {
//                return;
//            }

            //$AppClick 被过滤
//            if (SensorsDataAPI.sharedInstance().isAutoTrackEventTypeIgnored(SensorsDataAPI.AutoTrackEventType.APP_CLICK)) {
//                return;
//            }

            Class<?> supportTabLayoutCLass = null;
            Class<?> androidXTabLayoutCLass = null;
            try {
                supportTabLayoutCLass = Class.forName("android.support.design.widget.TabLayout");
            } catch (Exception e) {
                //ignored
            }

            try {
                androidXTabLayoutCLass = Class.forName("com.google.android.material.tabs.TabLayout");
            } catch (Exception e) {
                //ignored
            }

            if (supportTabLayoutCLass == null && androidXTabLayoutCLass == null) {
                return;
            }

            //TabLayout 被忽略
//            if (supportTabLayoutCLass != null) {
//                if (AutoTrackUtils.isViewIgnored(supportTabLayoutCLass)) {
//                    return;
//                }
//            }
//            if (androidXTabLayoutCLass != null) {
//                if (AutoTrackUtils.isViewIgnored(androidXTabLayoutCLass)) {
//                    return;
//                }
//            }

            if (isDeBounceTrack(tab)) {
                return;
            }

            //将 Context 转成 Activity
            Activity activity = null;
            if (object instanceof Context) {
                activity = AutoTrackUtils.getActivityFromContext((Context) object, null);
            } else {
                try {
                    Field[] fields = object.getClass().getDeclaredFields();
                    for (Field field : fields) {
                        field.setAccessible(true);
                        Object bridgeObject = field.get(object);
                        if (bridgeObject instanceof Activity) {
                            activity = (Activity) bridgeObject;
                            break;
                        }
                    }
                } catch (Exception e) {

                    e.printStackTrace();
                }
            }
            //Activity 被忽略
//            if (activity != null) {
//                if (SensorsDataAPI.sharedInstance().isActivityAutoTrackAppClickIgnored(activity.getClass())) {
//                    return;
//                }
//            }

//            JSONObject properties = new JSONObject();
            Map<String, Object> map = new HashMap<String, Object>();
//            String pageName = null;
            //$screen_name & $title
//            if (activity != null) {

//                pageName = activity.getClass().getCanonicalName();
//                collectionData.put(ReportField.pageId, new StringElement(pageName));
//                properties.put(AopConstants.SCREEN_NAME, activity.getClass().getCanonicalName());
//                String activityTitle = AutoTrackUtils.getActivityTitle(activity);
//                if (!TextUtils.isEmpty(activityTitle)) {
//                    properties.put(AopConstants.TITLE, activityTitle);
//                }
//            }

            Class<?> supportTabClass = null;
            Class<?> androidXTabClass = null;
            Class<?> currentTabClass;
            try {
                supportTabClass = Class.forName("android.support.design.widget.TabLayout$Tab");
            } catch (Exception e) {
                //ignored
            }

            try {
                androidXTabClass = Class.forName("com.google.android.material.tabs.TabLayout$Tab");
            } catch (Exception e) {
                //ignored
            }

            if (supportTabClass != null) {
                currentTabClass = supportTabClass;
            } else {
                currentTabClass = androidXTabClass;
            }

            if (currentTabClass != null) {
                Method method = null;
                try {
                    method = currentTabClass.getMethod("getText");
                } catch (NoSuchMethodException e) {
                    //ignored
                }

                if (method != null) {
                    Object text = method.invoke(tab);

                    //Content
                    if (text != null) {
                        map.put(ReportField.text.name(), (String) text);
//                        properties.put(AopConstants.ELEMENT_CONTENT, text);
                    }
                }

                if (activity != null) {
                    try {
                        Field field;
                        try {
                            field = currentTabClass.getDeclaredField("mCustomView");
                        } catch (NoSuchFieldException ex) {
                            try {
                                field = currentTabClass.getDeclaredField("customView");
                            } catch (NoSuchFieldException e) {
                                field = null;
                            }
                        }

                        View view = null;
                        if (field != null) {
                            field.setAccessible(true);
                            view = (View) field.get(tab);
                        }

                        if (view == null || view.getId() == -1) {
                            try {
                                field = currentTabClass.getDeclaredField("mParent");
                            } catch (NoSuchFieldException ex) {
                                field = currentTabClass.getDeclaredField("parent");
                            }
                            field.setAccessible(true);
                            view = (View) field.get(tab);
                        }

//                        int viewId = AutoTrackUtils.getId(activity, view);
//                        collectionData.put(ReportField.vid, new IntegerElement(viewId));

//                        String resourceId = activity.getResources().getResourceEntryName(view.getId());
//                        if (!TextUtils.isEmpty(resourceId)) {
//                            properties.put(AopConstants.ELEMENT_ID, resourceId);
//                        }
//                        String xpath = ViewPathUtil.getViewPath(view);
//                        collectionData.put(ReportField.xpath, new StringElement(xpath));
                        map.put(ReportField.type.name(), view.getClass().getCanonicalName
                                ());
                        Logger.i(TAG, "cfg -> AutoTrack trackTabLayoutSelected  : " + map.toString());
                        reportEvent(map, activity, view);


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            //Type

//            properties.put(AopConstants.ELEMENT_TYPE, "TabLayout");
//

//            SensorsDataAPI.sharedInstance().track(AopConstants.APP_CLICK_EVENT_NAME, properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void trackMenuItem(MenuItem menuItem) {
        trackMenuItem(null, menuItem);
    }

    public static void trackMenuItem(Object object, MenuItem menuItem) {
        try {
            //关闭 AutoTrack
//            if (!SensorsDataAPI.sharedInstance().isAutoTrackEnabled()) {
//                return;
//            }

            //$AppClick 被过滤
//            if (SensorsDataAPI.sharedInstance().isAutoTrackEventTypeIgnored(SensorsDataAPI.AutoTrackEventType.APP_CLICK)) {
//                return;
//            }

            //MenuItem 被忽略
//            if (AutoTrackUtils.isViewIgnored(MenuItem.class)) {
//                return;
//            }

            if (isDeBounceTrack(menuItem)) {
                return;
            }

            Context context = null;
            if (object != null) {
                if (object instanceof Context) {
                    context = (Context) object;
                }
            }

            //将 Context 转成 Activity
            Activity activity = null;
            if (context != null) {
                activity = AutoTrackUtils.getActivityFromContext(context, null);
            }

            //Activity 被忽略
//            if (activity != null) {
//                if (SensorsDataAPI.sharedInstance().isActivityAutoTrackAppClickIgnored(activity.getClass())) {
//                    return;
//                }
//            }

            //获取View ID
            String idString = null;
            try {
                if (context != null) {
                    idString = context.getResources().getResourceEntryName(menuItem.getItemId());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

//            JSONObject properties = new JSONObject();
            Map<String, Object> map = new HashMap<String, Object>();

            //$screen_name & $title
            if (activity != null) {
                map.put(ReportField.pageId.name(), activity.getClass().getCanonicalName());
//                properties.put(AopConstants.SCREEN_NAME, activity.getClass().getCanonicalName());
//                String activityTitle = AutoTrackUtils.getActivityTitle(activity);
//                if (!TextUtils.isEmpty(activityTitle)) {
//                    properties.put(AopConstants.TITLE, activityTitle);
//                }
            }

            //ViewID
            if (!TextUtils.isEmpty(idString)) {
//                properties.put(AopConstants.ELEMENT_ID, idString);
                map.put(ReportField.vid.name(), idString);
            }


            //Content
            if (!TextUtils.isEmpty(menuItem.getTitle())) {
                map.put(ReportField.text.name(), menuItem.getTitle().toString());
//                properties.put(AopConstants.ELEMENT_CONTENT, menuItem.getTitle());
            }

            //Type
            map.put(ReportField.type.name(), "MenuItem");
//            properties.put(AopConstants.ELEMENT_TYPE, "MenuItem");
//            Log.e("why", collectionData.toJSON().toString());
//            SensorsDataAPI.sharedInstance().track(AopConstants.APP_CLICK_EVENT_NAME, properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void trackRadioGroup(RadioGroup view, int checkedId) {
        try {
            //关闭 AutoTrack
//            if (!SensorsDataAPI.sharedInstance().isAutoTrackEnabled()) {
//                return;
//            }

            //$AppClick 被过滤
//            if (SensorsDataAPI.sharedInstance().isAutoTrackEventTypeIgnored(SensorsDataAPI.AutoTrackEventType.APP_CLICK)) {
//                return;
//            }

            //获取所在的 Context
            Context context = view.getContext();
            if (context == null) {
                return;
            }

            //将 Context 转成 Activity
            Activity activity = AutoTrackUtils.getActivityFromContext(context, view);

            //Activity 被忽略
//            if (activity != null) {
//                if (SensorsDataAPI.sharedInstance().isActivityAutoTrackAppClickIgnored(activity.getClass())) {
//                    return;
//                }
//            }

            //View 被忽略
//            if (AutoTrackUtils.isViewIgnored(view)) {
//                return;
//            }

            Map<String, Object> map = new HashMap<String, Object>();
            //ViewId
//            int viewId = AutoTrackUtils.getId(activity, view);
//            collectionData.put(ReportField.vid, new IntegerElement(viewId));

//            String idString = AutoTrackUtils.getViewId(view);
//            if (!TextUtils.isEmpty(idString)) {
//                properties.put(AopConstants.ELEMENT_ID, idString);
//            }
//            String pageName = null;
//            String xpath = null;
            //$screen_name & $title
//            if (activity != null) {

//                pageName = activity.getClass().getCanonicalName();
//                collectionData.put(ReportField.pageId, new StringElement(pageName));
//                properties.put(AopConstants.SCREEN_NAME, activity.getClass().getCanonicalName());
//                String activityTitle = AutoTrackUtils.getActivityTitle(activity);
//                if (!TextUtils.isEmpty(activityTitle)) {
//                    properties.put(AopConstants.TITLE, activityTitle);
//                }
//            }

            map.put(ReportField.type.name(), view.getClass().getCanonicalName
                    ());
//            properties.put(AopConstants.ELEMENT_TYPE, "RadioButton");

            //获取变更后的选中项的ID
            int checkedRadioButtonId = view.getCheckedRadioButtonId();
            if (activity != null) {
                try {
                    RadioButton radioButton = (RadioButton) activity.findViewById(checkedRadioButtonId);
                    if (radioButton != null) {
                        if (!TextUtils.isEmpty(radioButton.getText())) {
                            String viewText = radioButton.getText().toString();
                            if (!TextUtils.isEmpty(viewText)) {
                                map.put(ReportField.text.name(), viewText);
//                                properties.put(AopConstants.ELEMENT_CONTENT, viewText);
                            }
                        }

//                        xpath = ViewPathUtil.getViewPath(view);
//                        collectionData.put(ReportField.xpath, new StringElement(xpath));
//                        AutoTrackUtils.addViewPathProperties(activity, radioButton, properties);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            //fragmentName
//            AutoTrackUtils.getFragmentNameFromView(view, properties);

            //获取 View 自定义属性
//            JSONObject p = (JSONObject) view.getTag(R.id.auto_track_tag_view_properties);
//            if (p != null) {
//                AutoTrackUtils.mergeJSONObject(p, properties);
//            }
            Logger.i(TAG, "cfg -> AutoTrack trackRadioGroup  : " + map.toString());

            reportEvent(map, activity, view);
//            SensorsDataAPI.sharedInstance().track(AopConstants.APP_CLICK_EVENT_NAME, properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void trackDialog(DialogInterface dialogInterface, int whichButton) {
        try {
            //关闭 AutoTrack
//            if (!SensorsDataAPI.sharedInstance().isAutoTrackEnabled()) {
//                return;
//            }

            //$AppClick 被过滤
//            if (SensorsDataAPI.sharedInstance().isAutoTrackEventTypeIgnored(SensorsDataAPI.AutoTrackEventType.APP_CLICK)) {
//                return;
//            }

            //获取所在的Context
            Dialog dialog = null;
            if (dialogInterface instanceof Dialog) {
                dialog = (Dialog) dialogInterface;
            }

            if (dialog == null) {
                return;
            }

            if (isDeBounceTrack(dialog)) {
                return;
            }

            Context context = dialog.getContext();

            //将Context转成Activity
            Activity activity = AutoTrackUtils.getActivityFromContext(context, null);

            if (activity == null) {
                activity = dialog.getOwnerActivity();
            }

            //Activity 被忽略
//            if (activity != null) {
//                if (SensorsDataAPI.sharedInstance().isActivityAutoTrackAppClickIgnored(activity.getClass())) {
//                    return;
//                }
//            }

            //Dialog 被忽略
//            if (AutoTrackUtils.isViewIgnored(Dialog.class)) {
//                return;
//            }

//            JSONObject properties = new JSONObject();
//            CollectionData collectionData = new CollectionData();

            try {
                if (dialog.getWindow() != null) {
                    String idString = (String) dialog.getWindow().getDecorView().getTag(R.id.auto_track_tag_view_id);
                    if (!TextUtils.isEmpty(idString)) {
//                        collectionData.put(ReportField.vid, new StringElement(idString));
//                        properties.put(AopConstants.ELEMENT_ID, idString);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            //$screen_name & $title
            if (activity != null) {
//                collectionData.put(ReportField.pageId, new StringElement(activity.getClass().getCanonicalName()));
//                properties.put(AopConstants.SCREEN_NAME, activity.getClass().getCanonicalName());
//                String activityTitle = AutoTrackUtils.getActivityTitle(activity);
//                if (!TextUtils.isEmpty(activityTitle)) {
//                    properties.put(AopConstants.TITLE, activityTitle);
//                }
            }
//            collectionData.put(ReportField.type, new StringElement(dialog.getClass().getCanonicalName
//                    ()));
//            properties.put(AopConstants.ELEMENT_TYPE, "Dialog");

            Class<?> supportAlertDialogClass = null;
            Class<?> androidXAlertDialogClass = null;
            Class<?> currentAlertDialogClass = null;
            try {
                supportAlertDialogClass = Class.forName("android.support.v7.app.AlertDialog");
            } catch (Exception e) {
                //ignored
            }

            try {
                androidXAlertDialogClass = Class.forName("androidx.appcompat.app.AlertDialog");
            } catch (Exception e) {
                //ignored
            }

            if (supportAlertDialogClass == null && androidXAlertDialogClass == null) {
                return;
            }

            if (supportAlertDialogClass != null) {
                currentAlertDialogClass = supportAlertDialogClass;
            } else {
                currentAlertDialogClass = androidXAlertDialogClass;
            }

            if (dialog instanceof android.app.AlertDialog) {
                android.app.AlertDialog alertDialog = (android.app.AlertDialog) dialog;
                Button button = alertDialog.getButton(whichButton);
                if (button != null) {
                    if (!TextUtils.isEmpty(button.getText())) {
//                        collectionData.put(ReportField.text, new StringElement(button.getText().toString()));
//                        properties.put(AopConstants.ELEMENT_CONTENT, button.getText());
                    }
                } else {
                    ListView listView = alertDialog.getListView();
                    if (listView != null) {
                        ListAdapter listAdapter = listView.getAdapter();
                        Object object = listAdapter.getItem(whichButton);
                        if (object != null) {
                            if (object instanceof String) {
//                                collectionData.put(ReportField.text, new StringElement((String) object));
//                                properties.put(AopConstants.ELEMENT_CONTENT, object);
                            }
                        }
                    }
                }

            } else if (currentAlertDialogClass.isInstance(dialog)) {
                Button button = null;
                try {
                    Method getButtonMethod = dialog.getClass().getMethod("getButton", new Class[]{int.class});
                    if (getButtonMethod != null) {
                        button = (Button) getButtonMethod.invoke(dialog, whichButton);
                    }
                } catch (Exception e) {
                    //ignored
                }

                if (button != null) {
                    if (!TextUtils.isEmpty(button.getText())) {
//                        collectionData.put(ReportField.text, new StringElement(button.getText().toString()));
//                        properties.put(AopConstants.ELEMENT_CONTENT, button.getText());
                    }
                } else {
                    try {
                        Method getListViewMethod = dialog.getClass().getMethod("getListView");
                        if (getListViewMethod != null) {
                            ListView listView = (ListView) getListViewMethod.invoke(dialog);
                            if (listView != null) {
                                ListAdapter listAdapter = listView.getAdapter();
                                Object object = listAdapter.getItem(whichButton);
                                if (object != null) {
                                    if (object instanceof String) {
//                                        collectionData.put(ReportField.text, new StringElement((String) object));
//                                        properties.put(AopConstants.ELEMENT_CONTENT, object);
                                    }
                                }
                            }
                        }
                    } catch (Exception e) {
                        //ignored
                    }
                }
            }

//            Log.e("why", collectionData.toJSON().toString());
//            SensorsDataAPI.sharedInstance().track(AopConstants.APP_CLICK_EVENT_NAME, properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void trackListView(AdapterView<?> adapterView, View view, int position) {
        try {
            //闭 AutoTrack
//            if (!SensorsDataAPI.sharedInstance().isAutoTrackEnabled()) {
//                return;
//            }

            //$AppClick 被过滤
//            if (SensorsDataAPI.sharedInstance().isAutoTrackEventTypeIgnored(SensorsDataAPI.AutoTrackEventType.APP_CLICK)) {
//                return;
//            }

            //获取所在的 Context
            Context context = view.getContext();
            if (context == null) {
                return;
            }

            //将 Context 转成 Activity
            Activity activity = AutoTrackUtils.getActivityFromContext(context, view);

            //Activity 被忽略
//            if (activity != null) {
//                if (SensorsDataAPI.sharedInstance().isActivityAutoTrackAppClickIgnored(activity.getClass())) {
//                    return;
//                }
//            }

            //View Type 被忽略
//            if (AutoTrackUtils.isViewIgnored(adapterView.getClass())) {
//                return;
//            }

//            JSONObject properties = new JSONObject();
            Map<String, Object> map = new HashMap<String, Object>();

//            List<Class> mIgnoredViewTypeList = SensorsDataAPI.sharedInstance().getIgnoredViewTypeList();
//            if (mIgnoredViewTypeList != null) {
//                if (adapterView instanceof ListView) {
//                    properties.put(AopConstants.ELEMENT_TYPE, "ListView");
//                    if (AutoTrackUtils.isViewIgnored(ListView.class)) {
//                        return;
//                    }
//                } else if (adapterView instanceof GridView) {
//                    properties.put(AopConstants.ELEMENT_TYPE, "GridView");
//                    if (AutoTrackUtils.isViewIgnored(GridView.class)) {
//                        return;
//                    }
//                }
//            }
            map.put(ReportField.type.name(), view.getClass().getCanonicalName
                    ());
            //ViewId
//            String idString = AutoTrackUtils.getViewId(adapterView);
//            if (!TextUtils.isEmpty(idString)) {
//                properties.put(AopConstants.ELEMENT_ID, idString);
//            }
//            int viewId = AutoTrackUtils.getId(activity, view);
//            collectionData.put(ReportField.vid, new IntegerElement(viewId));

            //扩展属性
            Adapter adapter = adapterView.getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                adapter = ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            }

//            if (adapter instanceof SensorsAdapterViewItemTrackProperties) {
//                try {
//                    SensorsAdapterViewItemTrackProperties objectProperties = (SensorsAdapterViewItemTrackProperties) adapter;
//                    JSONObject jsonObject = objectProperties.getSensorsItemTrackProperties(position);
//                    if (jsonObject != null) {
//                        AutoTrackUtils.mergeJSONObject(jsonObject, properties);
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//            }
//            String xpath = ViewPathUtil.getViewPath(view);
//            collectionData.put(ReportField.xpath, new StringElement(xpath));
//            AutoTrackUtils.addViewPathProperties(activity, view, properties);
//            String pageName = null;
            //Activity 名称和页面标题
//            if (activity != null) {
//                pageName = activity.getClass().getCanonicalName();
//                collectionData.put(ReportField.pageId, new StringElement(pageName));
//                properties.put(AopConstants.SCREEN_NAME, activity.getClass().getCanonicalName());
//                String activityTitle = AutoTrackUtils.getActivityTitle(activity);
//                if (!TextUtils.isEmpty(activityTitle)) {
//                    properties.put(AopConstants.TITLE, activityTitle);
//                }
//            }

            //点击的 position
            map.put(ReportField.position.name(), String.valueOf(position));
//            properties.put(AopConstants.ELEMENT_POSITION, String.valueOf(position));

            String viewText = null;
            if (view instanceof ViewGroup) {
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    viewText = AutoTrackUtils.traverseView(stringBuilder, (ViewGroup) view);
                    if (!TextUtils.isEmpty(viewText)) {
                        viewText = viewText.substring(0, viewText.length() - 1);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (view instanceof TextView) {
                viewText = ((TextView) view).getText().toString();
            }
            //$element_content
            if (!TextUtils.isEmpty(viewText)) {
                map.put(ReportField.text.name(), viewText);
//                properties.put(AopConstants.ELEMENT_CONTENT, viewText);
            }

            //fragmentName
//            AutoTrackUtils.getFragmentNameFromView(adapterView, properties);

            //获取 View 自定义属性
//            JSONObject p = (JSONObject) view.getTag(R.id.auto_track_tag_view_properties);
//            if (p != null) {
//                AutoTrackUtils.mergeJSONObject(p, properties);
//            }
            Logger.i(TAG, "cfg -> AutoTrack trackListView  : " + map.toString());
            reportEvent(map, activity, view);

//            SensorsDataAPI.sharedInstance().track(AopConstants.APP_CLICK_EVENT_NAME, properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void trackDrawerOpened(View view) {
//        try {
//            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("$element_content", "Open");
//
//            SensorsDataAPI.sharedInstance().setViewProperties(view, jsonObject);
//
//            trackViewOnClick(view);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

    public static void trackDrawerClosed(View view) {
//        try {
//            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("$element_content", "Close");
//
//            SensorsDataAPI.sharedInstance().setViewProperties(view, jsonObject);
//
//            trackViewOnClick(view);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

    public static void trackViewOnClick(View view) {
        try {

            //获取所在的 Context
            Context context = view.getContext();

            //将 Context 转成 Activity
            Activity activity = AutoTrackUtils.getActivityFromContext(context, view);

            //Activity 被忽略
//            if (activity != null) {
//                if (SensorsDataAPI.sharedInstance().isActivityAutoTrackAppClickIgnored(activity.getClass())) {
//                    return;
//                }
//            }

            //View 被忽略
//            if (AutoTrackUtils.isViewIgnored(view)) {
//                return;
//            }

            long currentOnClickTimestamp = System.currentTimeMillis();
            String tag = (String) view.getTag(R.id.auto_track_tag_view_onclick_timestamp);
            if (!TextUtils.isEmpty(tag)) {
                try {
                    long lastOnClickTimestamp = Long.parseLong(tag);
                    if ((currentOnClickTimestamp - lastOnClickTimestamp) < 500) {
                        return;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            view.setTag(R.id.auto_track_tag_view_onclick_timestamp, String.valueOf(currentOnClickTimestamp));

//            JSONObject properties = new JSONObject();
            Map<String, Object> map = new HashMap<String, Object>();
//            String xpath = ViewPathUtil.getViewPath(view);
//            collectionData.put(ReportField.xpath, new StringElement(xpath));
//            AutoTrackUtils.addViewPathProperties(activity, view, properties);

            //ViewId
//            String idString = AutoTrackUtils.getViewId(view);
//            if (!TextUtils.isEmpty(idString)) {
//                properties.put(AopConstants.ELEMENT_ID, idString);
//            }
//            int viewId = AutoTrackUtils.getId(activity, view);
//            collectionData.put(ReportField.vid, new IntegerElement(viewId));
//            String pageName = null;
            //$screen_name & $title
//            if (activity != null) {
//                pageName = activity.getClass().getCanonicalName();
//                collectionData.put(ReportField.pageId, new StringElement(pageName));

//                properties.put(AopConstants.SCREEN_NAME, activity.getClass().getCanonicalName());
//                String activityTitle = AutoTrackUtils.getActivityTitle(activity);
//                if (!TextUtils.isEmpty(activityTitle)) {
//                    properties.put(AopConstants.TITLE, activityTitle);
//                }
//            }

            String viewType = view.getClass().getCanonicalName();

            Class<?> supportSwitchCompatClass = null;
            Class<?> androidXSwitchCompatClass = null;
            Class<?> currentSwitchCompatClass = null;
            try {
                supportSwitchCompatClass = Class.forName("android.support.v7.widget.SwitchCompat");
            } catch (Exception e) {
                //ignored
            }

            try {
                androidXSwitchCompatClass = Class.forName("androidx.appcompat.widget.SwitchCompat");
            } catch (Exception e) {
                //ignored
            }

            if (supportSwitchCompatClass != null) {
                currentSwitchCompatClass = supportSwitchCompatClass;
            } else {
                currentSwitchCompatClass = androidXSwitchCompatClass;
            }

            Class<?> supportViewPagerClass = null;
            Class<?> androidXViewPagerClass = null;
            Class<?> currentViewPagerClass = null;
            try {
                supportViewPagerClass = Class.forName("android.support.v4.view.ViewPager");
            } catch (Exception e) {
                //ignored
            }

            try {
                androidXViewPagerClass = Class.forName("androidx.viewpager.widget.ViewPager");
            } catch (Exception e) {
                //ignored
            }

            if (supportViewPagerClass != null) {
                currentViewPagerClass = supportViewPagerClass;
            } else {
                currentViewPagerClass = androidXViewPagerClass;
            }

            CharSequence viewText = null;
            if (view instanceof CheckBox) { // CheckBox
                viewType = "CheckBox";
                CheckBox checkBox = (CheckBox) view;
                viewText = checkBox.getText();
            } else if (currentViewPagerClass != null && currentViewPagerClass.isInstance(view)) {
                viewType = "ViewPager";
                try {
                    Method getAdapterMethod = view.getClass().getMethod("getAdapter");
                    if (getAdapterMethod != null) {
                        Object viewPagerAdapter = getAdapterMethod.invoke(view);
                        Method getCurrentItemMethod = view.getClass().getMethod("getCurrentItem");
                        if (getCurrentItemMethod != null) {
                            int currentItem = (int) getCurrentItemMethod.invoke(view);
                            map.put(ReportField.position.name(), String.format(Locale.CHINA, "%d", currentItem));

//                            properties.put(AopConstants.ELEMENT_POSITION, String.format(Locale.CHINA, "%d", currentItem));
                            Method getPageTitleMethod = viewPagerAdapter.getClass().getMethod("getPageTitle", new Class[]{int.class});
                            if (getPageTitleMethod != null) {
                                viewText = (String) getPageTitleMethod.invoke(viewPagerAdapter, new Object[]{currentItem});
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (currentSwitchCompatClass != null && currentSwitchCompatClass.isInstance(view)) {
                viewType = "SwitchCompat";
                CompoundButton switchCompat = (CompoundButton) view;
                Method method;
                if (switchCompat.isChecked()) {
                    method = view.getClass().getMethod("getTextOn");
                } else {
                    method = view.getClass().getMethod("getTextOff");
                }
                viewText = (String) method.invoke(view);
            } else if (view instanceof RadioButton) { // RadioButton
                viewType = "RadioButton";
                RadioButton radioButton = (RadioButton) view;
                viewText = radioButton.getText();
            } else if (view instanceof ToggleButton) { // ToggleButton
                viewType = "ToggleButton";
                ToggleButton toggleButton = (ToggleButton) view;
                boolean isChecked = toggleButton.isChecked();
                if (isChecked) {
                    viewText = toggleButton.getTextOn();
                } else {
                    viewText = toggleButton.getTextOff();
                }
            } else if (view instanceof Button) { // Button
                viewType = "Button";
                Button button = (Button) view;
                viewText = button.getText();
            } else if (view instanceof CheckedTextView) { // CheckedTextView
                viewType = "CheckedTextView";
                CheckedTextView textView = (CheckedTextView) view;
                viewText = textView.getText();
            } else if (view instanceof TextView) { // TextView
                viewType = "TextView";
                TextView textView = (TextView) view;
                viewText = textView.getText();
            } else if (view instanceof ImageView) { // ImageView
                viewType = "ImageView";
                ImageView imageView = (ImageView) view;
                if (!TextUtils.isEmpty(imageView.getContentDescription())) {
                    viewText = imageView.getContentDescription().toString();
                }
            } else if (view instanceof RatingBar) {
                viewType = "RatingBar";
                RatingBar ratingBar = (RatingBar) view;
                viewText = String.valueOf(ratingBar.getRating());
            } else if (view instanceof SeekBar) {
                viewType = "SeekBar";
                SeekBar seekBar = (SeekBar) view;
                viewText = String.valueOf(seekBar.getProgress());
            } else if (view instanceof Spinner) {
                viewType = "Spinner";
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    viewText = AutoTrackUtils.traverseView(stringBuilder, (ViewGroup) view);
                    if (!TextUtils.isEmpty(viewText)) {
                        viewText = viewText.toString().substring(0, viewText.length() - 1);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (view instanceof ViewGroup) {
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    viewText = AutoTrackUtils.traverseView(stringBuilder, (ViewGroup) view);
                    if (!TextUtils.isEmpty(viewText)) {
                        viewText = viewText.toString().substring(0, viewText.length() - 1);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            //$element_content
            if (!TextUtils.isEmpty(viewText)) {
                map.put(ReportField.text.name(), viewText.toString());
//                properties.put(AopConstants.ELEMENT_CONTENT, viewText.toString());
            }

            //$element_type
            map.put(ReportField.type.name(), view.getClass().getCanonicalName
                    ());
//            properties.put(AopConstants.ELEMENT_TYPE, viewType);

            //fragmentName
//            AutoTrackUtils.getFragmentNameFromView(view, properties);

            //获取 View 自定义属性
//            JSONObject p = (JSONObject) view.getTag(R.id.auto_track_tag_view_properties);
//            if (p != null) {
//                AutoTrackUtils.mergeJSONObject(p, properties);
//            }
            Logger.i(TAG, "cfg -> AutoTrack trackViewOnClick  : " + map.toString());
            reportEvent(map, activity, view);
//            SensorsDataAPI.sharedInstance().track(AopConstants.APP_CLICK_EVENT_NAME, properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void reportEvent(Map<String, Object> map, Activity activity, View view) {
        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);
        if (plugin != null && plugin.getDynamicConfig().isAutoTraceEnable()) {
            ViewConfigRes.BodyBean.CfgBean viewInfo = isCfgContainsView(activity.getClass().getCanonicalName(), ViewPathUtil.getViewPath(view));
            if (null != viewInfo) {
                map.put(ReportField.xpath.name(), viewInfo.getXpath());
                map.put(ReportField.pageId.name(), viewInfo.getPageName());
                Issue issue = new Issue(TYPE_VISUAL_TRACK, viewInfo.getOption().getVid(), viewInfo.getOption().getDescribe(), map, plugin);
                plugin.onDetectIssue(issue);
            }
        }
    }


    private static List<ViewConfigRes.BodyBean.CfgBean> getCfgList() {
        Gson gson = new Gson();
        String cfgJsonStr = AutoTrackUtils.getCfgJsonStr();
        ViewConfigRes viewConfigRes = gson.fromJson(cfgJsonStr, ViewConfigRes.class);
        if (viewConfigRes != null) {
            return viewConfigRes.getBody().getCfg();
        }
        return null;

    }

    private static ViewConfigRes.BodyBean.CfgBean isCfgContainsView(String pageName, String xpath) {
        if (null != getCfgList()) {
            List<ViewConfigRes.BodyBean.CfgBean> cfgBeans = getCfgList();
            for (ViewConfigRes.BodyBean.CfgBean bean : cfgBeans) {
                if (TextUtils.equals(bean.getPageName(), pageName)
                        && TextUtils.equals(bean.getXpath(), xpath)) {
                    Logger.i(TAG, "cfg -> contains  View: pageName - " + pageName + ",xpath- " + xpath + ", vid -" + bean.getOption().getVid());
                    return bean;
                }
            }
        }
        return null;
    }


}
