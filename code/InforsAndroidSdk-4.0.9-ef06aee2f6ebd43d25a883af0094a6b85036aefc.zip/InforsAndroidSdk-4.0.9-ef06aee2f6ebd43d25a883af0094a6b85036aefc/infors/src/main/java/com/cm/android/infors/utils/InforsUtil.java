/*
 * Tencent is pleased to support the open source community by making wechat-matrix available.
 * Copyright (C) 2018 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the BSD 3-Clause License (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://opensource.org/licenses/BSD-3-Clause
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.cm.android.infors.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import com.cm.android.infors.core.Consts;
import com.cm.android.infors.core.InforsConfig;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.request.modal.SignleApp;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Closeable;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.cm.android.infors.core.Consts.SP_TO_BACKGROUND;
import static com.cm.android.infors.utils.PrefUtils.*;
import static com.cm.android.infors.utils.PrefUtils.getStringFromSP;

/**
 * @author wusm
 */

public final class InforsUtil {
    private static final String TAG = "Infors.InforsUtil";
    private static String processName = null;

    private InforsUtil() {
    }

    public static String SubStringAppkey(String appkey) {
        return appkey.substring(0, 16);
    }

    public static String formatTime(String format, final long timeMilliSecond) {
        return new java.text.SimpleDateFormat(format).format(new java.util.Date(timeMilliSecond));
    }

    public static boolean isInMainThread(final long threadId) {
        return Looper.getMainLooper().getThread().getId() == threadId;
    }

    public static boolean isInMainProcess(Context context) {
        String pkgName = context.getPackageName();
        String processName = getProcessName(context);
        if (processName == null || processName.length() == 0) {
            processName = "";
        }

        return pkgName.equals(processName);
    }

    /**
     * add process name cache
     *
     * @param context
     * @return
     */
    public static String getProcessName(final Context context) {
        if (processName != null) {
            return processName;
        }
        //will not null
        processName = getProcessNameInternal(context);
        return processName;
    }

    private static String getProcessNameInternal(final Context context) {
        int myPid = android.os.Process.myPid();

        if (context == null || myPid <= 0) {
            return "";
        }

        ActivityManager.RunningAppProcessInfo myProcess = null;
        ActivityManager activityManager =
                (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);

        if (activityManager != null) {
            List<ActivityManager.RunningAppProcessInfo> appProcessList = activityManager
                    .getRunningAppProcesses();

            if (appProcessList != null) {
                try {
                    for (ActivityManager.RunningAppProcessInfo process : appProcessList) {
                        if (process.pid == myPid) {
                            myProcess = process;
                            break;
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "getProcessNameInternal exception:" + e.getMessage());
                }

                if (myProcess != null) {
//                    return "Process: " + myProcess.processName + ", PID: " + myPid;
                    return myProcess.processName;
                }
            }
        }

        byte[] b = new byte[128];
        FileInputStream in = null;
        try {
            in = new FileInputStream("/proc/" + myPid + "/cmdline");
            int len = in.read(b);
            if (len > 0) {
                for (int i = 0; i < len; i++) { // lots of '0' in tail , remove them
                    if (b[i] <= 0) {
                        len = i;
                        break;
                    }
                }
                return new String(b, 0, len, Charset.forName("UTF-8"));
            }

        } catch (Exception e) {
            Log.e(TAG, "getProcessNameInternal exception:" + e.getMessage());
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e) {
                Log.e(TAG, e.getMessage());
            }
        }
        return "";
    }


    public static String getLatestStack(String stack, int count) {
        if (stack == null || stack.isEmpty()) {
            return "";
        }
        String[] strings = stack.split("\n");
        if (strings.length <= count) {
            return stack;
        }
        StringBuffer sb = new StringBuffer(count);
        for (int i = 0; i < count; i++) {
            sb.append(strings[i]).append('\n');
        }
        return sb.toString();
    }

    /**
     * Closes the given {@code Closeable}. Suppresses any IO exceptions.
     */
    public static void closeQuietly(Closeable closeable) {
        try {
            if (closeable != null) {
                closeable.close();
            }
        } catch (IOException e) {
            Log.w(TAG, "Failed to close resource", e);
        }
    }

    private static char[] hexDigits = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a',
            'b', 'c', 'd', 'e', 'f'};
    private final static ThreadLocal<MessageDigest> MD5_DIGEST = new ThreadLocal<MessageDigest>() {
        @Override
        protected MessageDigest initialValue() {
            try {
                return MessageDigest.getInstance("MD5");
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException("Initialize MD5 failed.", e);
            }
        }
    };

    public static String getMD5String(String s) {
        return getMD5String(s.getBytes());
    }

    public static String getMD5String(byte[] bytes) {
        MessageDigest digest = MD5_DIGEST.get();
        return bufferToHex(digest.digest(bytes));
    }

    private static String bufferToHex(byte[] bytes) {
        return bufferToHex(bytes, 0, bytes.length);
    }

    private static String bufferToHex(byte[] bytes, int m, int n) {
        StringBuffer stringbuffer = new StringBuffer(2 * n);
        int k = m + n;
        for (int l = m; l < k; l++) {
            appendHexPair(bytes[l], stringbuffer);
        }
        return stringbuffer.toString();
    }

    private static void appendHexPair(byte bt, StringBuffer stringbuffer) {
        char c0 = hexDigits[(bt & 0xf0) >> 4];
        char c1 = hexDigits[bt & 0xf];
        stringbuffer.append(c0);
        stringbuffer.append(c1);
    }


    /**
     * Print thread stack
     */
    public static String formatStackTrace(StackTraceElement[] stackTrace) {
        StringBuilder sb = new StringBuilder();
        for (StackTraceElement element : stackTrace) {
            sb.append("    at ").append(element.toString());
            sb.append("\n");
        }
        return sb.toString();
    }


    public static JsonObject mapToJson(Map<String, Object> map) {
        Gson gson = new Gson();
        String str = gson.toJson(map);
        JsonObject jsonObject = gson.fromJson(str, JsonObject.class);
        return jsonObject;
    }

    public static String getUserId(Context context) {
        return getStringFromSP(context, InforsConfig.getInstance(), Consts.SP_USERINFO);
    }


    public static boolean isConnected(Context context) {
        return getBooleanFromSP(context, InforsConfig.getInstance(), Consts.SP_IS_WEBSOCKT);
    }

    public static void setConnection(Context context, boolean connection) {
        saveBooleanSP(context, InforsConfig.getInstance(), Consts.SP_IS_WEBSOCKT, connection);
    }

    public static String getOSVersion(Context context) {
        return DeviceUtils.getInstance(context).getOSVersionName();
    }

    public static JsonArray getConfigJson(InforsConfig mConfig, String appkey) {
        Map<String, SignleApp> globalParams;
        if (TextUtils.isEmpty(appkey)) {
            globalParams = mConfig.getGlobalAppConfig(null);
        } else {
            Map<String, SignleApp> savedMap = mConfig.getGlobalAppConfig(appkey);
            if (savedMap.size() == 0) {
                SignleApp signleApp = new SignleApp();
                signleApp.setAppKey(appkey);
                signleApp.setShareKeys(new ArrayList<String>());
                signleApp.setGlobalMap(new HashMap<String, String>());
                globalParams = new HashMap<>();
                globalParams.put(appkey, signleApp);
            } else {
                globalParams = savedMap;
            }

        }
//        try {
//            for (SignleApp app : globalParams.values()) {
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("appKey", app.getAppKey());
//                JSONArray shareKeysJA = new JSONArray();
//                List<String> shareKeyList = app.getShareKeys();
//                for (String shareKey : shareKeyList) {
//                    jsonObject.put(shareKey);
//                }
//
//
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
        List<SignleApp> configList = new ArrayList();
        for (SignleApp app : globalParams.values()) {
            app.getShareKeys();
            configList.add(app);
        }


        Gson gson = new Gson();
        String str = gson.toJson(configList);
        return gson.fromJson(str, JsonArray.class);
    }


//    private static Boolean shouldGenerateNewSessionId(Context context, InforsConfig config) {
//        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
//                config);
//        SharedPreferences sharedPreferences = sharedPreferencesFactory.create();
//        if (sharedPreferences.contains(SP_TO_BACKGROUND)) {
//            Long oldTimeStampe = getLongFromSP(context, config, SP_TO_BACKGROUND);
//            if (System.currentTimeMillis() - oldTimeStampe > 3000 * 60) { //3分钟
//                return true;
//            } else {
//                return false;
//            }
//        } else {
//            return true;
//        }
//
//    }

    /**
     * 启动时的13位时间戳字符串+productId + deviceId + userId(如果存在)）32bit_MD5
     *
     * @return
     */
    public static String getSessionId(Context context, InforsConfig config, String appKey) {
//        if (shouldGenerateNewSessionId(context, config)) {

        Logger.d("===修改时间戳====getSessionId" + getLongFromSP(context, config, SP_TO_BACKGROUND));
        StringBuffer rawSessionIdSB = new StringBuffer();
        String sessionId = EncryptData.getMD5(rawSessionIdSB.append
                (appKey).append(DeviceId.getDeviceId(context, config)).append(InforsUtil
                .getUserId(context)).append(getLongFromSP(context, config, SP_TO_BACKGROUND))
                .toString());
        Logger.d("===修改时间戳====sessionId--" + sessionId);
//        saveStringSP(context, config, Consts.SP_SESSIONID, sessionId);
        return sessionId;
//        } else {
//            return getStringFromSP(context, config, SP_SESSIONID);
//        }
    }
}
