package com.cm.android.infors;

public interface LoganCallBack {
    void onRequestSuccess();

    void onRequestProgress(long currentBytesCount, long totalBytesCount);

    void onRequestFailure(String msg);

    void onFileDeleted();

    void noLogExist(String msg);
}