package com.cm.android.infors.request.modal;

import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;


public class SignleApp {

    private String appKey;

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    private List<String> shareKeys;
    private Map<String, String> globalInfo;


    public List<String> getShareKeys() {
        return shareKeys;
    }

    public void setShareKeys(List<String> shareKeys) {
        this.shareKeys = shareKeys;
    }

    public Map<String, String> getGlobalMap() {
        return globalInfo;
    }

    public void setGlobalMap(Map<String, String> globalMap) {
        this.globalInfo = globalMap;
    }


    @Override
    public String toString() {
        return "SignleApp{" +
                "appKey='" + appKey + '\'' +
                ", shareKeys=" + shareKeys +
                ", globalMap=" + globalInfo +
                '}';
    }
}