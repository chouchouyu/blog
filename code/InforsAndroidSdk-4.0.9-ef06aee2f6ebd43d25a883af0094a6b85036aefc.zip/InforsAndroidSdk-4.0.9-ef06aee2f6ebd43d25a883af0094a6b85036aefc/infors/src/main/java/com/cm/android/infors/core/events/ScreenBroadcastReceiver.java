package com.cm.android.infors.core.events;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Looper;
import android.support.annotation.GuardedBy;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.utils.ResUtils;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import static com.cm.android.infors.core.Consts.TAG;


/**
 * 监听手机事件，触发sdk事件上报
 *
 * @author wusm
 */
public class ScreenBroadcastReceiver extends BroadcastReceiver {

    @GuardedBy("Looper.getMainLooper()")
    private final ArrayList<WeakReference<Activity>> mActivities = new ArrayList<>();


    @Override
    public void onReceive(Context context, Intent intent) {
        final String action = intent.getAction();
    }


    public void register(Activity context) {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            filter.addAction(Intent.ACTION_USER_BACKGROUND);
            filter.addAction(Intent.ACTION_USER_FOREGROUND);
            filter.addAction(Intent.ACTION_USER_INITIALIZE);
        }
        Logger.i(TAG, "ScreenBroadcastReceiver.register" + context.getClass().getSimpleName());
        context.registerReceiver(this, filter);
        mActivities.add(new WeakReference<>(context));
    }

    public void unRegister(Activity context) {
        if (this != null) {
            checkNotnull(context);
            if (removeFromWeakList(mActivities, context)) {
                Logger.i(TAG, "ScreenBroadcastReceiver.unRegister" + context.getClass().getSimpleName());
                context.unregisterReceiver(this);
            }

        }
    }

    private static <T> boolean removeFromWeakList(ArrayList<WeakReference<T>> haystack, T needle) {
        for (int i = 0, N = haystack.size(); i < N; i++) {
            T hay = haystack.get(i).get();
            if (hay == needle) {
                haystack.remove(i);
                return true;
            }
        }
        return false;
    }

    private void checkNotnull(Activity activity) {
        ResUtils.throwIfNull(activity);
        ResUtils.throwIfNot(Looper.myLooper() == Looper.getMainLooper());
    }
}