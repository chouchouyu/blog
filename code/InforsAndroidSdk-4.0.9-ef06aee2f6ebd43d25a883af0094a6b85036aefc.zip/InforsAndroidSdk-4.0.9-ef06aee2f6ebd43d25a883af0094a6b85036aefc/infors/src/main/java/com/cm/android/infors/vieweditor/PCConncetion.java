package com.cm.android.infors.vieweditor;


import android.text.TextUtils;
import com.cm.android.infors.core.Logger;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

import java.net.SocketException;

import static com.cm.android.infors.core.Consts.TAG;


public class PCConncetion implements IViewEditor {

    WsConncetion wsConncetion;
    //
    private WebSocketListener wsListener;
    private String url;
    private IViewEditor.WsHandle handle;


    public static PCConncetion getInstance(String url, IViewEditor.WsHandle handle) {
        return new PCConncetion(url, handle);
    }

    public PCConncetion(String url, IViewEditor.WsHandle handle) {
        wsConncetion = new WsConncetion();
        wsListener = new WsListener();
        this.url = url;
        this.handle = handle;
    }

    public void startConnect() {
        wsConncetion.connect(url, wsListener);
    }

    @Override
    public void send(String msg) {
        wsConncetion.send(msg);
    }

    @Override
    public void close() {
        wsConncetion.close();
    }

    public class WsListener extends WebSocketListener {
        @Override
        public void onClosed(WebSocket webSocket, int code, String reason) {
//            showToast("websocket ->:Listener: onClosed ->", reason);
            Logger.i(TAG, "websocket ->:Listener: onClosed ->" + reason);
            handle.onDisconnect(new SocketException(code + reason));
        }


        @Override
        public void onClosing(WebSocket webSocket, int code, String reason) {
//            showToast("websocket ->:Listener: onClosing ->", reason);
            Logger.i(TAG, "websocket ->:Listener: onClosing ->" + reason);
            handle.onDisconnect(new SocketException(code + reason));
        }

        /**
         * onFailure ->java.io.EOFException 为后台提前关闭所报错误。属于正常逻辑
         *
         * @param webSocket
         * @param t
         * @param response
         */
        @Override
        public void onFailure(WebSocket webSocket, Throwable t, Response response) {
//            showToast("websocket ->:Listener: onFailure ->", t.toString());

            Logger.i(TAG, "websocket ->:Listener: onFailure ->" + t.toString());
            handle.onDisconnect(t);
        }

        @Override
        public void onMessage(WebSocket webSocket, String text) {
            if (TextUtils.isEmpty(text)) {
                return;
            }
            if (text.contains("start to upload pageInfo")) {
                handle.onSendMessageSuccess();
            }

//            showToast("websocket ->:Listener: onMessage ->", text);

            Logger.i(TAG, "websocket ->:Listener: onMessage ->" + text);
        }

        @Override
        public void onOpen(WebSocket webSocket, Response response) {
//            Toast.makeText(Infors.getInstance().getAppContext(), "websocket ->:Listener: onOpen ->" + response, Toast.LENGTH_SHORT).show();

            Logger.i(TAG, "websocket ->:Listener: onOpen ->" + response);
            handle.onOpen();
        }
    }

//    private void showToast(final String s, final String s2) {
//        Looper.prepare();
//        ActivityTracker.get().tryGetTopActivity().runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//
//                Toast.makeText(Infors.getInstance().getAppContext(), s + s2, Toast.LENGTH_SHORT).show();
//
//            }
//        });
//        Looper.loop();
//
//    }


}
