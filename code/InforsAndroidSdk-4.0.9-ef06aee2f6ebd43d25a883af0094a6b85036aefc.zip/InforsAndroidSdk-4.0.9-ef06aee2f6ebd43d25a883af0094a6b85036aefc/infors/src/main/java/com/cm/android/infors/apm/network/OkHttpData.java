package com.cm.android.infors.apm.network;

import java.text.SimpleDateFormat;
import java.util.Map;

/**
 * OKHTTP 数据采集字段
 *
 * @author wusm
 */
public class OkHttpData {
    private String net_operator;
    private String fail_msg;
    private String url;
    private long request_bytes;
    private long response_bytes;
    public long requestTime;
    public long costTime;
    public long takeTime;
    private boolean isResponseFail;

    private int response_code;

    private String remote_ip;
    private boolean is_slow_request;
    private String request_id;

    private String requestBody;
    private String responseBody;
    private String headField;
    private Map<String, Object> headers;

    public void setHeaders(Map<String, Object> headers) {
        this.headers = headers;
    }

    public String getRequestBody() {
        return requestBody;
    }

    public void setRequestBody(String requestBody) {
        this.requestBody = requestBody;
    }

    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    public String getHeadField() {
        return headField;
    }

    public void setHeadField(String headField) {
        this.headField = headField;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public long getRequest_bytes() {
        return request_bytes;
    }

    public void setRequest_bytes(long request_bytes) {
        this.request_bytes = request_bytes;
    }

    public long getResponse_bytes() {
        return response_bytes;
    }

    public void setResponse_bytes(long response_bytes) {
        this.response_bytes = response_bytes;
    }


    public int getResponse_code() {
        return response_code;
    }

    public void setResponse_code(int response_code) {
        this.response_code = response_code;
    }

    public String getRemote_ip() {
        return remote_ip;
    }

    public void setRemote_ip(String remote_ip) {
        this.remote_ip = remote_ip;
    }

    /**
     * if (timeInv > 2 && (model.request_bytes+model.response_bytes)/1000 < 50.0) {
     *
     * @return
     */
    public boolean isSlowRequest() {
        if (costTime > 2000 && (request_bytes + response_bytes) / 1000 < 50.0) {
            this.is_slow_request = true;
        } else {
            this.is_slow_request = false;
        }
//        if (costTime > 3000) {
//            this.is_slow_request = true;
//        }
        return is_slow_request;
    }

    public boolean isResponseFail() {
        return isResponseFail;
    }

    public void setResponseFail(boolean responseFail) {
        isResponseFail = responseFail;
    }

    public String getRequest_id() {
        return request_id;
    }

    public void setRequest_id(String request_id) {
        this.request_id = request_id;
    }


    public long getCostTime() {
        return costTime;
    }

    public void setCostTime(long costTime) {
        this.costTime = costTime;
    }

    public String getNet_operator() {
        return net_operator;
    }

    public void setNet_operator(String net_operator) {
        this.net_operator = net_operator;
    }


    public long getTakeTime() {
        return takeTime;
    }

    public void setTakeTime(long takeTime) {
        this.takeTime = takeTime;
    }

    public String getFail_msg() {
        return fail_msg;
    }

    public void setFail_msg(String fail_msg) {
        this.fail_msg = fail_msg;
    }

    public long getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(long requestTime) {
        this.requestTime = requestTime;
    }


    @Override
    public String toString() {
        return "OkHttpData{" +
                "net_operator='" + net_operator + '\'' +
                ", fail_msg='" + fail_msg + '\'' +
                ", url='" + url + '\'' +
                ", takeTime=" + takeTime +
                ", request_bytes=" + request_bytes +
                ", response_bytes=" + response_bytes +
                ", requestTime=" + requestTime +
                ", costTime=" + costTime +
                ", isResponseFail=" + isResponseFail +
                ", response_code=" + response_code +
                ", remote_ip='" + remote_ip + '\'' +
                ", is_slow_request=" + is_slow_request +
                ", request_id='" + request_id + '\'' +
                ", requestBody='" + requestBody + '\'' +
                ", responseBody='" + responseBody + '\'' +
                ", headField='" + headField + '\'' +
                ", headers=" + headers +
                '}';
    }

    public static String dataFormat(long currentTime) {
        SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return dateformat.format(currentTime);
    }

    public Map<String, Object> getHeaders() {
        return headers;
    }
}
