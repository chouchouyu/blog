package com.cm.android.infors.db;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.migration.Migration;
import android.support.annotation.NonNull;
import com.cm.android.infors.core.Consts;

import static com.cm.android.infors.core.Consts.TABLE_APM;

/**
 * 数据库升级Migration
 *
 * @author wusm
 */
public class Migrations {


    public static final Migration MIGRATION_2_3 = new Migration(2, 3) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            //此处对于数据库中的所有更新都需要写下面的代码
//            database.execSQL("ALTER TABLE "+ Consts.SDK_NAME
//                    + " ADD COLUMN last_update INTEGER");

            // Create the new table
            database.execSQL(
//                    "CREATE TABLE " + TABLE_APM + " (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,CONTENT TEXT, EVENT_TYPE TEXT, DATE INTEGER,"
//                            + " PRIMARY KEY(id))");
                    "CREATE TABLE  IF NOT EXISTS " + TABLE_APM + " (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,CONTENT TEXT, EVENT_TYPE TEXT, DATE INTEGER)");

            database.execSQL("CREATE  INDEX IF NOT EXISTS `index_Infors_APM_DATE` ON `"+TABLE_APM+"` (`DATE`)");
        }
    };
}