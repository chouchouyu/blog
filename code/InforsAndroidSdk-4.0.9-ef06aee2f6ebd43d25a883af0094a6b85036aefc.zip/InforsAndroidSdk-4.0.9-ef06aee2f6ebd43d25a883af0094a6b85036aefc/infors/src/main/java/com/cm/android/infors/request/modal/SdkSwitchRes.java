package com.cm.android.infors.request.modal;

public class SdkSwitchRes {

    /**
     * code : Y
     * body : {"isInforsEnable":true,"isCrashEnable":true,"isAutoTraceEnable":true,"isBlockEnable":true,"isViewEditorEnable":true,"isHttpEnable":true,"isHeatMapEnable":true}
     * message : null
     */

    private String code;
    private BodyBean body;
    private Object message;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public BodyBean getBody() {
        return body;
    }

    public void setBody(BodyBean body) {
        this.body = body;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public static class BodyBean {
        /**
         * isInforsEnable : true
         * isCrashEnable : true
         * isAutoTraceEnable : true
         * isBlockEnable : true
         * isViewEditorEnable : true
         * isHttpEnable : true
         * isHeatMapEnable : true
         */

        private boolean isInforsEnable;
        private boolean isCrashEnable;
        private boolean isAutoTraceEnable;
        private boolean isBlockEnable;
        private boolean isViewEditorEnable;
        private boolean isHttpEnable;
        private boolean isHeatMapEnable;
        private boolean isPrintLogEnable;
        private boolean isUploadLogEnable;

        public boolean isPrintLogEnable() {
            return isPrintLogEnable;
        }

        public void setPrintLogEnable(boolean printLogEnable) {
            isPrintLogEnable = printLogEnable;
        }

        public boolean isUploadLogEnable() {
            return isUploadLogEnable;
        }

        public void setUploadLogEnable(boolean uploadLogEnable) {
            isUploadLogEnable = uploadLogEnable;
        }

        public boolean isIsInforsEnable() {
            return isInforsEnable;
        }

        public void setIsInforsEnable(boolean isInforsEnable) {
            this.isInforsEnable = isInforsEnable;
        }

        public boolean isIsCrashEnable() {
            return isCrashEnable;
        }

        public void setIsCrashEnable(boolean isCrashEnable) {
            this.isCrashEnable = isCrashEnable;
        }

        public boolean isIsAutoTraceEnable() {
            return isAutoTraceEnable;
        }

        public void setIsAutoTraceEnable(boolean isAutoTraceEnable) {
            this.isAutoTraceEnable = isAutoTraceEnable;
        }

        public boolean isIsBlockEnable() {
            return isBlockEnable;
        }

        public void setIsBlockEnable(boolean isBlockEnable) {
            this.isBlockEnable = isBlockEnable;
        }

        public boolean isIsViewEditorEnable() {
            return isViewEditorEnable;
        }

        public void setIsViewEditorEnable(boolean isViewEditorEnable) {
            this.isViewEditorEnable = isViewEditorEnable;
        }

        public boolean isIsHttpEnable() {
            return isHttpEnable;
        }

        public void setIsHttpEnable(boolean isHttpEnable) {
            this.isHttpEnable = isHttpEnable;
        }

        public boolean isIsHeatMapEnable() {
            return isHeatMapEnable;
        }

        public void setIsHeatMapEnable(boolean isHeatMapEnable) {
            this.isHeatMapEnable = isHeatMapEnable;
        }
    }
}
