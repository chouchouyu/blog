package com.cm.android.infors.demo.liba_datapick.bean;

public class SecondGroupBean {

    private String name;

    public SecondGroupBean(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
