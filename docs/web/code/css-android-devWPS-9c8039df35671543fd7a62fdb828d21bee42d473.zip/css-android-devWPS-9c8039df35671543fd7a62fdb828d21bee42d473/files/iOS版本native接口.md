/*
SDK启动配置
 */
//启动加密沙箱服务，配置为config
+ (void)setupSever:(CrypterConfig *)config;
//加密沙箱进入后台,在AppDelegate下面方法内调用
+ (void)enterBackground:(UIApplication *)application;
//加密沙箱进入前台
+ (void)becomeActive;
//加密沙箱打开URL,在AppDelegate下面方法内调用
+ (void)handleURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options;

/*
 SDK工具接口
 */
//判断WPS是否安装
+ (BOOL)checkWPS;
//获取token
+ (NSString *)getHttpToken;
//获取BaseURL如http://127.0.0.1:8080
+ (NSString *)getBaseUrl;
//使用file和Cmd获取URL
+ (NSString *)getUrlWithFileCmd:(NSString *)cmd AndParam:(NSDictionary *)param;

/*
 SDK文件管理操作接口
 */
//获取路径path下的文件列表
+(NSArray *)getFileListWithPath:(NSString *)path;
//在path路径下创建文件夹，名字为name，成功返回true，否则false
+(BOOL)mkdirWithPath:(NSString *)path andName:(NSString *)name;
//删除path路径的文件或者文件夹，成功返回true，否则false
+(BOOL)rmWithPath:(NSString *)path;
//往path路径下写文件，文件流为data，文件名为name,是否可以覆盖为flag,写成功返回true，否则false
+(BOOL)writeFileWithPath:(NSString *)path name:(NSString *)name data:(NSData *)data canOverWriter:(BOOL)canOverWriter;
//获取path路径下，名字为name的文件,存在该文件返回文件流，否则返回空
+(NSData *)getFileWithPath:(NSString *)path name:(NSString *)name;
//重命名path路径下名字为name的文件,把名称改成newName，写成功返回true，否则false
+(BOOL)renameFileWithPath:(NSString *)path name:(NSString *)name newName:(NSString *)newName;
//打开path路径的文件,editEnable为true则可以编辑，否则不能编辑,编辑保存的数据可以通过代理回调回来
+(BOOL)openWpsWithPath:(NSString *)path editEnable:(BOOL)editEnable savePath:(NSString *)savePath;


/*
  SDK 文件转移接口
 */
//拷贝外部文件到沙箱
+(BOOL)copyLocalFilePath:(NSString *)localPath toSanBoxPath:(NSString *)sanBoxPath;
//拷贝沙箱文件到沙箱其他路径
+(BOOL)copySanBoxPath:(NSString *)srcPath toSanBoxPath:(NSString *)destPath;
//移动沙箱文件到沙箱其他路径
+(BOOL)moveSanBoxPath:(NSString *)srcPath toSanBoxPath:(NSString *)destPath;

/*
 SDK OSS文件操作接口
 */
//文件从加密沙箱上传到cos
//OssCompletionType:id为服务端返回数据,BOOL为网络请求成功或失败
+(void)uploadSanboxFilePath:(NSString *)filePath ossUrl:(NSString *)url token:(NSString *)token userId:(NSString *)userId uploadProgress:(nullable void (^)(NSProgress *uploadProgress)) uploadProgressBlock completion:(OssCompletionType)completion;

//文件从普通沙箱上传到cos
//OssCompletionType:id为服务端返回数据,BOOL为网络请求成功或失败
+(void)uploadLocalFilePath:(NSString *)filePath ossUrl:(NSString *)url token:(NSString *)token userId:(NSString *)userId uploadProgress:(nullable void (^)(NSProgress *uploadProgress)) uploadProgressBlock completion:(OssCompletionType)completion;

//文件从cos下载到沙箱
//OssCompletionType:id为服务端返回数据,BOOL为网络请求成功或失败
+(void)downloadOssFileWithOssUrl:(NSString *)url toSanboxPath:(NSString *)filePath downloadProgress:(nullable void (^)(NSProgress *uploadProgress)) downloadProgressBlock completion:(OssCompletionType)completion;