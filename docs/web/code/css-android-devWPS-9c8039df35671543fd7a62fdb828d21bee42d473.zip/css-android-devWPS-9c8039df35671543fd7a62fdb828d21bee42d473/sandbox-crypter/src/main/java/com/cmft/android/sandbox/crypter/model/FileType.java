package com.cmft.android.sandbox.crypter.model;

public enum FileType {
    UNKNOW("UNKNOW", 0x00), DOC("DOC", 0x01), DOCX("DOCX", 0x02), WPS("WPS", 0x03),
    TXT("TXT", 0x04), XLS("XLS", 0x05), XLSX("XLSX", 0x06), PPT("PPT", 0x07),
    PPTX("PPTX", 0x08), PDF("PDF", 0x09);


    private String name;
    private int index;

    FileType(String name, int index) {
        this.name = name;
        this.index = index;
    }

    public static String getName(int index) {
        for (FileType c : FileType.values()) {
            if (c.getIndex() == index) {
                return c.name;
            }
        }
        return null;
    }

    public int getIndex() {
        return index;
    }

    public String getName() {
        return name;
    }


    @Override
    public String toString() {
        return this.index + "_" + this.name;
    }

}
