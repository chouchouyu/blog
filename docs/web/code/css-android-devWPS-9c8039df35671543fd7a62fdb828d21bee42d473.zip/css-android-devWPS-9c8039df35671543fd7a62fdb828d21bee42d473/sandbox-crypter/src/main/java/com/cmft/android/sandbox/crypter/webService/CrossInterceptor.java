/*
 * Copyright 2018 Zhenjie Yan.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.cmft.android.sandbox.crypter.webService;

import android.support.annotation.NonNull;

import com.cmft.android.sandbox.crypter.core.Constant;
import com.cmft.android.sandbox.crypter.core.SandBoxCenter;
import com.yanzhenjie.andserver.annotation.Interceptor;
import com.yanzhenjie.andserver.framework.HandlerInterceptor;
import com.yanzhenjie.andserver.framework.handler.RequestHandler;
import com.yanzhenjie.andserver.http.HttpMethod;
import com.yanzhenjie.andserver.http.HttpRequest;
import com.yanzhenjie.andserver.http.HttpResponse;
import com.yanzhenjie.andserver.util.MultiValueMap;

import java.util.Map;


/**
 * Created by Zhenjie Yan on 2018/9/11.
 */
@Interceptor
public class CrossInterceptor implements HandlerInterceptor {

    @Override
    public boolean onIntercept(@NonNull HttpRequest request, @NonNull HttpResponse response,
                               @NonNull RequestHandler handler) {
//        if (request.getMethod().compareTo(HttpMethod.OPTIONS) == 0) {
        response = crossDomain(response);
//        }
        String path = request.getPath();
        HttpMethod method = request.getMethod();
        MultiValueMap<String, String> valueMap = request.getParameter();
        SandBoxCenter.logger.debug(Constant.TAG, "CrossInterceptor:Path: " + path);
        SandBoxCenter.logger.debug(Constant.TAG, "CrossInterceptor:Method: " + method.value());
        for (String key : valueMap.keySet()) {
            SandBoxCenter.logger.debug(Constant.TAG, "CrossInterceptor:CrossInterceptorParam:key " +
                    " " + key);
            SandBoxCenter.logger.debug(Constant.TAG, "CrossInterceptor:Param:value  " + valueMap
                    .get(key));
        }
        return false;
    }

    private HttpResponse crossDomain(HttpResponse response) {
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access_Control_Allow_Credentials", "true");
        response.addHeader("Access-Control-Allow-Headers", "X-Requested-With, Content-Type, " +
                "Accept, Authorization");
        response.addHeader("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
        return response;
    }
}