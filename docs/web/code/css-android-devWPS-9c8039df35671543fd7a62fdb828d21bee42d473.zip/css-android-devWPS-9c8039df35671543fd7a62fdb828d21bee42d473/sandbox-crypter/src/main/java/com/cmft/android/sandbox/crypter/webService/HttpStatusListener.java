package com.cmft.android.sandbox.crypter.webService;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;

public interface HttpStatusListener {
    void unregisterHttpReceiver(BroadcastReceiver receiver);

    void registerHttpReceiver(BroadcastReceiver receiver, IntentFilter filter);

    void startHttpService(Intent intent);

    void stopHttpService(Intent intent);

    void onServerStart(String ip);

    void onServerError(String error);

    void onServerStop();
}
