package com.cmft.android.sandbox.crypter.utils;

/**
 * @author wusm
 */
public class CachePool<K, V> {
    private int capacity;
    private int size;
    private Node<K, V> head;
    private Node<K, V> tail;

    public CachePool(int capacity) {
        this.capacity = capacity;
    }

    public synchronized boolean put(K key, V value) {
        if(key != null && this.capacity > 0) {
            Node n = null;

            while(true) {
                while(true) {
                    while(this.size >= this.capacity) {
                        n = this.tail;
                        if(n == null) {
                            Node n1 = this.head;
                            if(n1 == null) {
                                this.size = 0;
                                this.tail = null;
                            } else {
                                for(this.size = 1; n1.next != null; n1 = n1.next) {
                                    ++this.size;
                                }

                                this.tail = n1;
                            }
                        } else {
                            this.tail = this.tail.previous;
                            this.tail.next = null;
                            --this.size;
                        }
                    }

                    if(n == null) {
                        n = new Node();
                    }

                    n.cacheTime = System.currentTimeMillis();
                    n.key = key;
                    n.value = value;
                    n.previous = null;
                    n.next = this.head;
                    if(this.size == 0) {
                        this.tail = n;
                    } else if(this.head != null) {
                        this.head.previous = n;
                    } else {
                        this.tail = n;
                        this.size = 0;
                    }

                    this.head = n;
                    ++this.size;
                    return true;
                }
            }
        } else {
            return false;
        }
    }

    public synchronized V get(K key) {
        if(this.head == null) {
            this.size = 0;
            this.tail = null;
            return null;
        } else if(this.head.key.equals(key)) {
            return this.head.value;
        } else {
            Node n = this.head;

            do {
                if(n.next == null) {
                    return null;
                }

                n = n.next;
            } while(!n.key.equals(key));

            if(n.next == null) {
                n.previous.next = null;
                this.tail = n.previous;
            } else {
                n.previous.next = n.next;
                n.next.previous = n.previous;
            }

            n.previous = null;
            n.next = this.head;
            this.head.previous = n;
            this.head = n;
            return (V) n.value;
        }
    }

    public synchronized void clear() {
        this.head = this.tail = null;
        this.size = 0;
    }

    public synchronized void trimBeforeTime(long time) {
        if(this.capacity > 0) {
            for(Node n = this.head; n != null; n = n.next) {
                if(n.cacheTime < time) {
                    if(n.previous != null) {
                        n.previous.next = n.next;
                    }

                    if(n.next != null) {
                        n.next.previous = n.previous;
                    }

                    if(n.equals(this.head)) {
                        this.head = this.head.next;
                    }

                    --this.size;
                }
            }

        }
    }

    public int size() {
        return this.size;
    }

    private static class Node<K, V> {
        public K key;
        public V value;
        public Node<K, V> previous;
        public Node<K, V> next;
        private long cacheTime;

        private Node() {
        }
    }
}
