/*
 * Copyright © 2018 Zhenjie Yan.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.cmft.android.sandbox.crypter.webService;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.text.TextUtils;

import com.cmft.android.sandbox.crypter.core.Constant;
import com.cmft.android.sandbox.crypter.core.SandBoxCenter;
import com.yanzhenjie.andserver.AndServer;
import com.yanzhenjie.andserver.Server;

import java.util.concurrent.TimeUnit;

import static com.cmft.android.sandbox.crypter.core.Constant.PORT;


/**
 * @author Zhenjie Yan
 * @date 2018/6/9
 */
public class AndService extends Service {

    private Server mServer;

    @Override
    public void onCreate() {
        mServer = AndServer.serverBuilder()
                .inetAddress(NetUtils.getLocalIPAddress())
                .port(PORT)
                .timeout(10, TimeUnit.SECONDS)
                .listener(new Server.ServerListener() {
                    @Override
                    public void onStarted() {
                        try {
                            if (mServer.isRunning()) {
                                String hostAddress = mServer.getInetAddress().getHostAddress() +
                                        PORT;
                                if (TextUtils.isEmpty(hostAddress)) {
                                    SandBoxCenter.logger.debug(Constant.TAG, "AndService " +
                                            "onStarted " +
                                            "无网络");
                                } else {
                                    SandBoxCenter.logger.debug(Constant.TAG, "AndService " +
                                            "onStarted ip" +
                                            " ->" +
                                            hostAddress);
                                }
                            } else {
                                SandBoxCenter.logger.debug(Constant.TAG, "AndService 网络服务器关闭状态 ");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onStopped() {
                        try {
                            if (mServer.isRunning()) {
                                String hostAddress = mServer.getInetAddress().getHostAddress() +
                                        PORT;

                                SandBoxCenter.logger.debug(Constant.TAG, "AndService onStopped" +
                                        hostAddress);
                            } else {
                                SandBoxCenter.logger.debug(Constant.TAG, "AndService 网络服务器关闭状态 ");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onException(Exception e) {
                        try {
                            if (mServer.isRunning()) {
                                SandBoxCenter.logger.debug(Constant.TAG, "AndService onException :"
                                        + e.toString());
                            } else {
                                SandBoxCenter.logger.debug(Constant.TAG, "AndService 网络服务器未启动 ");
                            }
                        } catch (Exception e1) {
                            e1.printStackTrace();
                        }

                    }
                })
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startServer();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopServer();
        super.onDestroy();
    }

    /**
     * Start server.
     */
    private void startServer() {
        try {
            SandBoxCenter.logger.debug(Constant.TAG, "AndService startServer");
            if (mServer.isRunning()) {
                String hostAddress = mServer.getInetAddress().getHostAddress();
            } else {
                mServer.startup();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * Stop server.
     */
    private void stopServer() {
        try {
            SandBoxCenter.logger.debug(Constant.TAG, "AndService stopServer");
            if (mServer.isRunning()) {
                mServer.shutdown();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}