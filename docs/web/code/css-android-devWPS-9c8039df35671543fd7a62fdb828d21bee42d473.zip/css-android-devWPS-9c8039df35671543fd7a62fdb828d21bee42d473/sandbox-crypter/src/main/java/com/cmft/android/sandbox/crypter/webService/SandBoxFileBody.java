/*
 * Copyright 2018 Yan Zhenjie.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.cmft.android.sandbox.crypter.webService;


import com.cmft.android.sandbox.crypter.CallBack;
import com.cmft.android.sandbox.crypter.core.SandBoxCenter;
import com.yanzhenjie.andserver.http.ResponseBody;
import com.yanzhenjie.andserver.util.IOUtils;
import com.yanzhenjie.andserver.util.MediaType;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

public class SandBoxFileBody implements ResponseBody {

    private File mBody;

    public SandBoxFileBody(File body) {
        if (body == null) {
            throw new IllegalArgumentException("The file cannot be null.");
        }
        this.mBody = body;
    }

    @Override
    public long contentLength() {
        if (SandBoxCenter.getInstance().isEncrypted(mBody)) {
            return SandBoxCenter.getInstance().decryptFileSize(mBody);
        } else {
            return mBody.length();
        }

    }

    @Override
    public MediaType contentType() {
        return MediaType.getFileMediaType(mBody.getName());
    }

    @Override
    public void writeTo(OutputStream output) {
        if (SandBoxCenter.getInstance().isEncrypted(mBody)) {
            SandBoxCenter.getInstance().decrypt(mBody, output, new CallBack<Boolean>() {
                @Override
                public void onSuccess(Boolean response) {

                }

                @Override
                public void onFail(String string) {

                }
            });
        } else {
            try {
                IOUtils.write(new FileInputStream(mBody), output);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}