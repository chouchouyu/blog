package com.cmft.android.sandbox.crypter;


import com.cmft.android.sandbox.crypter.model.FileInfor;
import com.cmft.android.sandbox.crypter.core.SandBoxCenter;
import com.cmft.android.sandbox.crypter.core.SandBoxConfig;
import com.cmft.android.sandbox.crypter.utils.LogListener;
import com.cmft.android.sandbox.crypter.wps.util.Util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;


public final class SandBox {

    private volatile static boolean hasInit = false;
    private volatile static SandBox instance = null;

    private SandBox() {
    }

    /**
     * SandBox初始化
     */
    public static void init(SandBoxConfig SandBoxConfig) {
        if (!hasInit) {
            hasInit = SandBoxCenter.init(SandBoxConfig);
        }
    }


    public static SandBox getInstance() {
        if (!hasInit) {
            throw new RuntimeException("Please initialize SandBox first");
        } else {
            if (instance == null) {
                synchronized (SandBox.class) {
                    if (instance == null) {
                        instance = new SandBox();
                    }
                }
            }
            return instance;
        }
    }

    /**
     * 获取沙箱打印日志
     *
     * @param logListener
     */
    public static void setLogListener(LogListener logListener) {
        SandBoxCenter.getInstance().setLogListener(logListener);
    }


    /**
     * 获得沙箱本地服务请求的token
     *
     * @return
     */
    public String getToken() {
        return SandBoxCenter.getInstance().getToken();
    }


    /**
     * 初始化后，设置setUserName后，所有的文件操作都会存在userName目录下
     *
     * @param userName
     */
    public void setUserName(String userName) {
        SandBoxCenter.getInstance().setUserName(userName);
    }

//-----------------以上初始化方法————————————————————————————————

    /**
     * 通过WPS编辑文档
     *
     * @param fileid     相对sandbox打开路径
     * @param saveFileId 相对sandbox保存路径
     */
    public void editWithWPS(String fileid, String saveFileId) {
        SandBoxCenter.getInstance().editWithWPS(fileid, saveFileId);
    }


    /**
     * 通过WPS打开文档
     *
     * @param fileid 相对sandbox打开路径
     */
    public void openWithWPS(String fileid) {
        SandBoxCenter.getInstance().openWithWPS(fileid);
    }

    /**
     * wps版本升级检测
     */
    public void checkWPSVersion() {
        SandBoxCenter.getInstance().checkVersion();
    }

    /**
     * wps文件类型
     *
     * @param file
     * @return
     */
    public boolean isWPSFile(File file) {
        return Util.IsWPSFile(file);
    }


    /**
     * 是否图片文件类型
     *
     * @param path
     * @return
     */
    public boolean isImagelFile(String path) {
        return Util.isImagelFile(path);
    }


    //-----------------以上WPS方法————————————————————————————————

    /**
     * 沙箱加密文件流，存储
     *
     * @param fileId      沙箱相对路径
     * @param inputStream 待加密文件流
     * @param callBack    成功时返回 filedid ,失败返回error string
     */
    public void encrypt(String fileId, InputStream inputStream, CallBack<String>
            callBack) {

        SandBoxCenter.getInstance().encrypt(fileId, inputStream, callBack);
    }

    /**
     * 直接用cos加密， 加密结果会存在沙箱
     *
     * @param fileid      沙箱相对路径
     * @param inputStream 待加密文件流
     * @param callBack    成功时返回 filedid ,失败返回error string
     */
    public void cosEncrypt(String fileid, InputStream inputStream, CallBack<String>
            callBack) {

        SandBoxCenter.getInstance().encryptCosKey(fileid, inputStream, callBack);
    }


    /**
     * 沙箱内，文件是否是加密过的文件
     *
     * @param fileId
     * @return
     */
    public boolean isEncrypted(File fileId) {
        return SandBoxCenter.getInstance().isEncrypted(fileId);
    }

    /**
     * 传入完整路径判断文件是否加密
     *
     * @param fileAbsoultpath
     * @return
     */
    public boolean isEncrypted(String fileAbsoultpath) {
        return SandBoxCenter.getInstance().isEncrypted(fileAbsoultpath);
    }


    /**
     * 文件是否存在在沙箱判断
     *
     * @param path
     * @return
     */
    public boolean isFileExists(String path) {
        return SandBoxCenter.getInstance().isFileExists(path);
    }


    /**
     * 沙箱解密文件流，支持cos加密文件和 file加密文件
     *
     * @param sourcePath   待加密文件
     * @param outputStream 加密后文件流
     * @param callBack     true成功 false 失败
     */
    public void decrypt(String sourcePath, OutputStream outputStream, CallBack<Boolean>
            callBack) {
        SandBoxCenter.getInstance().decrypt(sourcePath, outputStream, callBack);
    }

    /**
     * 获取沙盒内部文件流，由于沙箱地址不对外暴露
     *
     * @param fileid 沙箱相对地址
     * @return
     */
    public FileOutputStream getInnerOutStream(String fileid) {
        return SandBoxCenter.getInstance().getInnerOutStream(fileid);
    }

//-----------------以上沙箱基础加解密的方法———————————————————————————————


    /**
     * cos下载 下载解密cos文件/非加密文件，存储不加密数据
     *
     * @param fileid     沙箱相对路径
     * @param sourcePath 待加密文件路径
     * @param callBack   成功时返回 filedid ,失败返回error string
     */
    public void cosSaveToSandbox(String fileid, String sourcePath, CallBack<String>
            callBack) {

        SandBoxCenter.getInstance().cosSaveToSandbox(fileid, sourcePath, callBack);
    }


    /**
     * cos 上传 必须cos加密
     *
     * @param fileid       沙箱相对路径
     * @param outputStream cos加密了的文件流
     * @param callBack     true成功 false 失败
     */
    public void cosUpload(String fileid, OutputStream outputStream, CallBack<Boolean>
            callBack) {
        SandBoxCenter.getInstance().cosUpload(fileid, outputStream, callBack);
    }


//-----------------以上cos上传方法———————————————————————————————


    /**
     * 沙箱内，文件大小
     *
     * @param fileId
     * @return
     */
    public long getFileSize(File fileId) {
        return SandBoxCenter.getInstance().getFileSize(fileId);
    }


    /**
     * 沙箱内，文件删除
     *
     * @param fileid
     * @return
     */
    public boolean delete(String fileid) {
        return SandBoxCenter.getInstance().delete(fileid);
    }


    /**
     * 获取路径path下的文件列表
     *
     * @param path
     * @return
     */
    public List<FileInfor> getFileListWithPath(String path) {
        return SandBoxCenter.getInstance().getFileListWithPath(path);
    }

    /**
     * 在path路径下创建文件夹，名字为name，成功返回true，否则false
     *
     * @param path
     * @param name
     * @return
     */
    public boolean MKdirWithPath(String path, String name) {
        return SandBoxCenter.getInstance().MKdirWithPath(path, name);
    }

    /**
     * 删除path路径的文件或者文件夹，成功返回true，否则false
     *
     * @param path
     * @return
     */
    public boolean RMWithPath(String path) {
        return SandBoxCenter.getInstance().RMWithPath(path);
    }


    public FileOutputStream getFileWithPath(String path, String name) {
        return SandBoxCenter.getInstance().getFileWithPath(path, name);
    }

    //-----------------------消息加解密---------------

    /**
     * 字节解密
     * @param content 内容
     * @return
     */
    public byte[] decryptSession( byte[] content) {
        return SandBoxCenter.getInstance().decryptSession( content);

    }

    /**
     * 字节加密
     * @param content 内容
     * @return
     */
    public byte[] encryptSession( byte[] content) {
        return SandBoxCenter.getInstance().encryptSession( content);

    }

}

