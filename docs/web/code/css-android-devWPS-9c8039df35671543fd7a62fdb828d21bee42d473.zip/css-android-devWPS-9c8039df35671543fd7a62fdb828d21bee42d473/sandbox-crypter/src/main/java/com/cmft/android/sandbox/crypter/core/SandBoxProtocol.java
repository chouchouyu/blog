package com.cmft.android.sandbox.crypter.core;

import android.content.Context;
import android.os.RemoteException;


import com.cmft.android.sandbox.crypter.CallBack;
import com.cmft.android.sandbox.crypter.model.FileContent;
import com.cmft.android.sandbox.crypter.model.FileEntity;
import com.cmft.android.sandbox.crypter.model.FileType;
import com.cmft.android.sandbox.crypter.utils.SandboxUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

import cn.wps.moffice.client.OfficeInputStream;
import cn.wps.moffice.client.OfficeOutputStream;

import static com.cmft.android.sandbox.crypter.wps.util.EncryptClass.BUFFER_SIZE;

public class SandBoxProtocol {

    static {
        System.loadLibrary("native-lib");
    }

    private Context context;
    private String mKey;

    /**
     * @param key     加密的key 必须是128位 16个字节
     * @param context
     */
    public SandBoxProtocol(String key, Context context) {
        mKey = key;
        this.context = context;
    }

    public boolean isSecurityFileData(byte[] fileHead) {
        return csandbox_isSecurityFileData(fileHead);
    }


//+++++++++++++++++++++++encrypt++++++++++++++++++++++++++

    /**
     * wps 加密保存文件时调用
     *
     * @param input
     * @param savePath
     * @param type
     */
    public void encryptSaveFile(final OfficeInputStream input, String fileId, String key,
                                final String savePath, FileType fileType, int type,
                                CallBack<Boolean> callBack) {
        try {
            SandBoxCenter.logger.debug(Constant.TAG, "加密: WPS identification: " + fileId);
            SandBoxCenter.logger.debug(Constant.TAG, "加密: WPS key: " + key);

            long encrypter = csandbox_encryptCreate(savePath, fileId, key, fileType.getIndex(),
                    type, true);

            if (encrypter == 0) {
                SandBoxCenter.logger.error(Constant.TAG, "加密: 创建加密器失败: " + savePath);
                return;
            }

            final byte[] buffer = new byte[BUFFER_SIZE];
            int[] read = new int[1];
            while (input.read(buffer, read) >= 0) {
                if (read[0] <= 0) {
                    break;
                }
                csandbox_encrypt(encrypter, fileId, savePath, key, buffer, fileType.getIndex(),
                        true,
                        read[0], type);
            }
            encryptClose(encrypter);
            input.close();
            callBack.onSuccess(true);
        } catch (Exception e) {
            e.printStackTrace();
            callBack.onFail(e.toString());
        }

    }


    public void encryptSaveFile(String fileId, String key, FileEntity fileEntity,
                                InputStream fis, int keyType, CallBack<Boolean> callBack) {

        SandBoxCenter.logger.debug(Constant.TAG, " 加密: identification: " + fileId);
        SandBoxCenter.logger.debug(Constant.TAG, "加密: key: " + key);

        try {

            long encrypter = csandbox_encryptCreate(fileEntity.getFilePath(), fileId, key,
                    fileEntity
                            .getFileType().getIndex(), keyType, true);

            if (encrypter == 0) {
                SandBoxCenter.logger.error(Constant.TAG, "加密: 创建加密器失败: " + fileEntity.getFilePath
                        ());
                return;
            }

            byte[] buffer = new byte[BUFFER_SIZE];

            int i;

            while ((i = fis.read(buffer)) != -1) {
                csandbox_encrypt(encrypter, fileId, fileEntity.getFilePath(), key, buffer,
                        fileEntity
                                .getFileType().getIndex(), true, i, keyType);
            }

            encryptClose(encrypter);
            fis.close();
            callBack.onSuccess(true);

        } catch (IOException e) {
            e.printStackTrace();
            callBack.onFail(e.toString());
        }
    }

    private void encryptClose(long closer) {
        csandbox_encryptClose(closer);
        SandBoxCenter.logger.debug(Constant.TAG, "加密: encryptClose");
    }

    //+++++++++++++++++++++++decrypt++++++++++++++++++++++++++

    /**
     * 核心解密方法 支持coskey和filekey的加密
     * @param encryptedFile 加密文件绝对路径File
     * @param outputStream 解密后内容放在outputStream里
     * @param callBack 解密完成后时机的回调，回调完成后就可以从outputStream里取
     */
    public void decrypt(File encryptedFile, OutputStream outputStream,
                        CallBack<Boolean> callBack) {
        try {
            String key = null;
            String encryptedFilePath = encryptedFile.getAbsolutePath();
            SandBoxCenter.logger.debug(Constant.TAG, " ------------------------解密:开始解密" +
                    encryptedFilePath);
            if (outputStream == null) {
                SandBoxCenter.logger.debug(Constant.TAG, " 解密:outputStream is null");
            } else {
                SandBoxCenter.logger.debug(Constant.TAG, " 解密:outputStream " + outputStream
                        .toString());
            }

            FileContent fileContent = new FileContent();
            long decrypter = csandbox_decryptCreate(encryptedFilePath, fileContent);

            SandBoxCenter.logger.debug(Constant.TAG, " 解密:文件原始大小 " + fileContent.getFileSize());

            //解密r: 9655文件原始大小
            if (fileContent.getFileSize() > 0 && decrypter != 0) {
                SandBoxCenter.logger.debug(Constant.TAG, " 解密:identification: " + fileContent
                        .getKey());

                if (fileContent.getFileype() == 0x0101) {
                    key = SandboxUtils.fileKey(context, mKey, fileContent.getKey());
                    SandBoxCenter.logger.debug(Constant.TAG, " 解密:fileKey: " + key);

                } else if (fileContent.getFileype() == 0x1010) {
                    key = SandboxUtils.cosKey(fileContent.getKey());
                    SandBoxCenter.logger.debug(Constant.TAG, " 解密:cosKey: " + key);
                }

                for (; ; ) {

                    byte[] bytes = csandbox_decrypt(decrypter, encryptedFilePath, key);


                    if (bytes != null && bytes.length > 0) {
                        outputStream.write(bytes);
                        outputStream.flush();
                        SandBoxCenter.logger.debug(Constant.TAG, " 解密:for[" + bytes.length + "]大小");
                    } else {
                        SandBoxCenter.logger.debug(Constant.TAG, " 解密:结束");
                        break;
                    }
                }

                decryptClose(decrypter);

                outputStream.close();

                SandBoxCenter.logger.debug(Constant.TAG, " 解密:解密完成------------------------");
                callBack.onSuccess(true);

            } else {
                callBack.onFail("file size is 0");
            }


        } catch (IOException e) {
            e.printStackTrace();
            SandBoxCenter.logger.debug(Constant.TAG, " 解密:解密完成onFail------------------------");
            callBack.onFail(e.toString());
        }
    }


    /**
     * 对接wps的解密方法
     * @param encryptedFilePath
     * @param fileOutputStream 这是wps封装的流，和普通的outputStream方法不一样，所以单独封装
     */
    public void decrypt(String encryptedFilePath, OfficeOutputStream fileOutputStream) {

        try {
            FileContent fileContent = new FileContent();
            long decrypter = csandbox_decryptCreate(encryptedFilePath, fileContent);

            String key;
            SandBoxCenter.logger.debug(Constant.TAG, " 解密:wps identification: " + fileContent
                    .getKey());

            if (fileContent.getFileype() == 0x0101) {
                key = SandboxUtils.fileKey(context, mKey, fileContent.getKey());
                SandBoxCenter.logger.debug(Constant.TAG, " 解密:wps fileKey: " + key);
            } else {
                key = SandboxUtils.cosKey(fileContent.getKey());
                SandBoxCenter.logger.debug(Constant.TAG, " 解密:wps cosKey: " + key);
            }
            SandBoxCenter.logger.debug(Constant.TAG, " 解密: wps" + fileContent.getFileSize() +
                    "btyes");//9655文件原始大小

            if (decrypter != 0) {

                for (; ; ) {
                    byte[] bytes = csandbox_decrypt(decrypter, encryptedFilePath, key);

                    if (bytes.length > 0) {
                        fileOutputStream.write(bytes, 0, bytes.length);
                        SandBoxCenter.logger.debug(Constant.TAG, " 解密: wps btye[" + bytes.length
                                + "]");
                    } else {
                        SandBoxCenter.logger.debug(Constant.TAG, " 解密: wps 结束");
                        break;
                    }
                }

            } else {
                SandBoxCenter.logger.debug(Constant.TAG, "创建解密器失败.");
            }

            decryptClose(decrypter);

            fileOutputStream.close();

            SandBoxCenter.logger.debug(Constant.TAG, " 解密wps:解密完成------------------------");

        } catch (RemoteException e) {
            e.printStackTrace();
            SandBoxCenter.logger.debug(Constant.TAG, " " +
                    "解密wps:解密异常-RemoteException-----------------------");
        }
    }

    public void decryptFileSize(String encryptedFilePath, FileContent fileContent) {
        long decrypter = csandbox_decryptCreate(encryptedFilePath, fileContent);
        decryptClose(decrypter);
    }


    public void decryptClose(long closer) {
        SandBoxCenter.logger.debug(Constant.TAG, " 解密:Close");
        csandbox_decryptClose(closer);
    }

    public byte[] decryptSession(String key, byte[] input){
        return csandbox_decryptSession(key, input);
    }

    public byte[] encryptSession(String key, byte[] input){
        return csandbox_encryptSession(key, input);
    }


    private native long csandbox_decryptCreate(String filePath, FileContent fileContent);

    private native byte[] csandbox_decrypt(long object, String filePath, String mKey);

    private native void csandbox_decryptClose(long object);

    private native long csandbox_encryptCreate(String filePath, String fileId, String key, int
            fileType, int keyType, boolean isSecurity);

    private native boolean csandbox_encrypt(long object, String fileId, String path, String key,
                                            byte[]
                                                    content, int fileType, boolean security, long
                                                    bufferSize, int type);

    private native void csandbox_encryptClose(long object);

    public native boolean csandbox_isSecurityFile(String filePath);

    public native boolean csandbox_isSecurityFileData(byte[] fileHead);

    private native byte[] csandbox_decryptSession(String key, byte[] input);

    private native byte[] csandbox_encryptSession(String key, byte[] input);


}
