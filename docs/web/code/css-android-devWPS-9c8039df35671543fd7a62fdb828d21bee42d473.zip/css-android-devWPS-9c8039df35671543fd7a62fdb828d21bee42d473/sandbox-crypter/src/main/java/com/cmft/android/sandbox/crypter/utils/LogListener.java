package com.cmft.android.sandbox.crypter.utils;

public interface LogListener {
    void onLog(String tag, String msg);
}
