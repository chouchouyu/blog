package com.cmft.android.sandbox.crypter.wps.client;


import android.app.AlertDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import android.view.WindowManager;
import android.widget.TextView;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.android.sandbox.crypter.core.Constant;
import com.cmft.android.sandbox.crypter.core.SandBoxCenter;
import com.cmft.android.sandbox.crypter.wps.WPSService;
import com.cmft.android.sandbox.crypter.wps.util.Define;
import com.cmft.android.sandbox.crypter.wps.util.EncryptClass;
import com.cmft.android.sandbox.crypter.wps.util.SettingPreference;

import java.io.File;

import cn.wps.moffice.client.ActionType;
import cn.wps.moffice.client.AllowChangeCallBack;
import cn.wps.moffice.client.OfficeEventListener;
import cn.wps.moffice.client.OfficeInputStream;
import cn.wps.moffice.client.OfficeOutputStream;
import cn.wps.moffice.client.ViewType;
import cn.wps.moffice.service.OfficeService;
import cn.wps.moffice.service.doc.Document;


/**
 * @author wps
 */
public class OfficeEventListenerImpl extends OfficeEventListener.Stub {
    protected MOfficeClientService service = null;

    private boolean mIsValidPackage = true;

    public OfficeEventListenerImpl(MOfficeClientService service) {
        this.service = service;
    }

    @Override
    public int onOpenFile(String path, OfficeOutputStream output)
            throws RemoteException {


        if (!mIsValidPackage) {
            return -1;
        }
        SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener -onOpenFile");
        boolean isEncrypt = SandBox.getInstance().isEncrypted(new File(path));
        if (isEncrypt) {
            return EncryptClass.encryptOpenFile(path, output);
        } else {
            return EncryptClass.normalOpenFile(path, output);
        }

    }

    @Override
    public int onSaveFile(OfficeInputStream input, String path) throws RemoteException {
        SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener -onSaveFile");
        File file = new File(path);
        if (SandBoxCenter.getInstance().isEncrypted(file) || !TextUtils.isEmpty(SandBoxCenter
                .getInstance().getWPSSavePath())) {
            //本身是加密文件 或者需要另存为的文件
            return EncryptClass.encryptSaveFile(input, file);
        } else {
            return EncryptClass.normalSaveFile(input, path);
        }
    }

    @Override
    public int onCloseFile() throws RemoteException {
        SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener -onCloseFile");
        return 0;
    }

    @Override
    public boolean isActionAllowed(String path, ActionType type) throws RemoteException {
        SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener-isActionAllowed" + type
                .toString());

        SettingPreference settingPreference;
        settingPreference = new SettingPreference(this.service.getApplicationContext());

        //光标输入模式，进行特殊处理
//		if (type.equals(ActionType.AT_CURSOR_MODEL)
//		    && settingPreference.getSettingParam(type.toString(), true))
//		{
//			return isCursorMode(path, type);
//		}
//
//		if (type.equals(ActionType.AT_EDIT_REVISION)) 	//如果是接受或拒绝某条修订的事件,做特殊处理
//		{
//			return isRevisionMode(path, type, settingPreference);
//		}
//		if (type.equals(ActionType.AT_SAVE))
//		{
//			return false;
//		}
//		if (type.equals(ActionType.AT_SAVEAS))
//		{
//			return false;
//		}
        if (type.equals(ActionType.AT_COPY)) {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止复制");
            return false;
        }
        if (type.equals(ActionType.AT_CUT)) {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止剪切");
            return false;
        }
//		if (type.equals(ActionType.AT_PASTE))
//		{
//			return false;
//		}
        if (type.equals(ActionType.AT_SHARE)) { //禁止分享；
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止分享");
            return false;
        }
        if (type.equals(ActionType.AT_PRINT)) //禁止打印
        {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止打印");
            return false;
        }
//		if (type.equals(ActionType.AT_SPELLCHECK))
//		{
//			return false;
//		}
//		if (type.equals(ActionType.AT_MULTIDOCCHANGE))
//		{
//			return false;
//		}
//		if (type.equals(ActionType.AT_QUICK_CLOSE_REVISEMODE))
//		{
//			return false;
//		}
//		if (type.equals(ActionType.AT_EDIT_REVISION))
//		{
//			return false;
//		}
//		if (type.equals(ActionType.AT_CHANGE_COMMENT_USER))
//		{
//			return false;
//		}
//		if (type.equals(ActionType.AT_SHARE_PLAY))
//		{
//			return false;
//		}
//		if (type.equals(ActionType.AT_GRID_BACKBOARD))
//		{
//			return false;
//		}
        if (type.equals(ActionType.AT_EXPORT_AS_PDF)) //禁止输出为PDF
        {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止输出为PDF");
            return false;
        }
//
//		if (type.equals(ActionType.AT_MENU_FIND))
//		{
//			return false;
//		}


        boolean result = true;
        boolean typeAT = settingPreference.getSettingParam(type.toString(), true);
        String pathAT = settingPreference.getSettingParam(Define.AT_PATH, "/");
        boolean isExist = path.startsWith(pathAT) || "".equals(path);  //有部分事件传过来路径为"",
        if (!typeAT && isExist) {
            result = false;
        }

        return result;
    }

    @Override
    public boolean isViewForbidden(String arg0, ViewType arg1) throws RemoteException {
        if (arg1 == ViewType.VT_FILE_PRINT) {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止打印");
            return true;
        } else if (arg1 == ViewType.VT_FILE_SAVEAS) {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止另存为");
            return true;
        } else if (arg1 == ViewType.VT_FILE_SHARE) {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止分享");
            return true;
        } else if (arg1 == ViewType.VT_FILE_PRINT) {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止打印");
            return true;
        } else if (arg1 == ViewType.VT_EDIT_CUT) {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止编辑剪切");
            return true;
        } else if (arg1 == ViewType.VT_EDIT_COPY) {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeEventListener禁止编辑复制");
            return true;
        }
        return false;
    }

    @Override
    public boolean isViewInVisible(String arg0, ViewType arg1) throws RemoteException {
//		if (arg1 == ViewType.VT_MENU_REVIEW || arg1 == ViewType.VT_MENU_PEN)
//		{
//			return true;
//		}
        return false;
    }

    @Override
    public void onMenuAtion(String path, String id) throws RemoteException {
        //TODO　自定义菜单，path为文档路径，id为传入的菜单按钮id
        Document mDoc = service.mService.getActiveDocument();
        if (mDoc == null) {
            SandBoxCenter.logger.error(Constant.TAG, "WPS:OfficeEventListener服务已经断开，请重启程序");
        } else {
            if ("menu_id_comment_pad".equals(id)) {
                mDoc.enterReviseMode();
            } else if ("menu_id_exit_comment".equals(id)) {
                mDoc.exitReviseMode();
            }
        }
    }

    @Override
    public String getMenuText(String path, String id) throws RemoteException {
        //TODO　自定义菜单，可更新菜单文字，path为文档路径，id为传入的菜单按钮id
        if ("menu_id_comment".equals(id)) {
            return "退出修订";
        }
        return null;
    }

    @Override
    public void setText(CharSequence charSequence) throws RemoteException {

    }

    @Override
    public CharSequence getText() throws RemoteException {
        return null;
    }

    @Override
    public boolean hasText() throws RemoteException {
        return false;
    }

    @Override
    public int printFileSave(String s, String s1) throws RemoteException {
        return 0;
    }

    //是否可以操作他人修订（作者名不同的修订）
    private boolean isRevisionMode(String path, ActionType type, SettingPreference
            settingPreference) {
        String docUserName = settingPreference.getSettingParam(Define.USER_NAME, "");
        boolean typeAT = settingPreference.getSettingParam(type.toString(), true);
        boolean isSameOne = docUserName.equals(path);    //在此事件中，path中存放是是作者批注名
        if (!typeAT && !isSameOne) {
            return false;
        }

        return true;
    }

    //中广核特殊需求
    private boolean isCursorMode(String path, ActionType type) throws RemoteException {

        boolean flag = null != WPSService.getDocument() && WPSService.getDocument().getSelection
                ().getStart() == WPSService.getDocument().getSelection().getEnd();

        if (!flag) {
            return false;
        }

        if (WPSService.getDocument().isProtectOn()) {
            return false;
        }

        WPSService.getDocument().getSelection().getFont().setBold(true);
        WPSService.getDocument().getSelection().getFont().setItalic(true);
        WPSService.getDocument().getSelection().getFont().setName("宋体");
        WPSService.getDocument().getSelection().getFont().setStrikeThrough();
        WPSService.getDocument().getSelection().getFont().setSize((float) 15.0);
        WPSService.getDocument().getSelection().getFont().setTextColor(0x00ff00);

        return true;
    }

    /**
     * 实现多个可变包名的验证
     * originalPackage是最原始的第三方包名，华为渠道为“com.huawei.svn.hiwork”
     * thirdPackage为可变动的应用包名，具体有企业资金定制
     */
    @Override
    public boolean isValidPackage(String originalPackage, String thirdPackage)
            throws RemoteException {
//此处是某些企业的特殊需求，可以忽略
//		mIsValidPackage = false;
//		if (originalPackage.equals(service.getPackageName()) && thirdPackage.equals("cn.wps
// .moffice"))
//		{
//			mIsValidPackage = true;
//			return true;
//		}
        return false;
    }

    @Override
    public void setAllowChangeCallBack(AllowChangeCallBack allowChangeCallBack) throws
            RemoteException {
        WPSService.setAllowCallBack(allowChangeCallBack);
    }

    @Override
    public int invoke(String actionID, String args) throws RemoteException {
        // TODO Auto-generated method stub
        if ("addPicture".equals(actionID)) {
            OfficeService officeService = service.getOfficeService();
//			officeService.getActiveDocument().getShapes().addPicture(args, false, false, 100, 100,
// 100, 100, 0, WrapType.None);
        } else if ("showDialog".equals(actionID)) {
            Message msg = Message.obtain();
            showDialogHandler.sendMessage(msg);
        }
        return 0;
    }

    private Handler showDialogHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            showSystemDialog(OfficeEventListenerImpl.this.service.getApplicationContext());
        }
    };

    private void showSystemDialog(Context context) {
        TextView t = new TextView(context);
        t.setText("showSystemDialog");
        AlertDialog d = new AlertDialog.Builder(context).create();
        d.setView(t, 0, 0, 0, 0);
        d.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
        d.show();
    }
}
