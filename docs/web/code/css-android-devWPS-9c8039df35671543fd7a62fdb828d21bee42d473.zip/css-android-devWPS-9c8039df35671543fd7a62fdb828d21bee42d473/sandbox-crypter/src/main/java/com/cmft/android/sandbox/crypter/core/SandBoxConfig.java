package com.cmft.android.sandbox.crypter.core;

import android.app.Application;
import android.content.Context;
import android.text.TextUtils;

import java.io.File;


import static com.cmft.android.sandbox.crypter.core.Constant.SANDBOX_ROOT;

public class SandBoxConfig {

    String sandboxPath;
    Application application;
    String mEncryptKey; //uuID
    String waterMark;
    boolean buggable;


    boolean isValid() {
        boolean valid = false;
        if (TextUtils.isEmpty(mEncryptKey) || mEncryptKey.length() != 16
//                && !TextUtils.isEmpty(userName)
//                && !TextUtils.isEmpty
//                (mFileProvider)
                ) {
            throw new RuntimeException("SandBoxConfig.Builder().setEncryptKey 必须为16位");
        } else {
            valid = true;
        }

        return valid;
    }

    public Application getApplication() {
        return application;
    }

    public Context getContext() {
        return application.getApplicationContext();
    }

    public String getWaterMark() {
        return waterMark;
    }

    private SandBoxConfig(Application application) {
        this.application = application;
//        this.sandboxPath= "/sdcard/Download";
        this.sandboxPath = getContext().getExternalFilesDir(null)
                .getAbsolutePath()
                + File.separator + SANDBOX_ROOT;
    }

    private void setEncryptKey(String encryptKey) {
        mEncryptKey = encryptKey;
    }

    public void setWaterMark(String waterMark) {
        this.waterMark = waterMark;
    }


    public void setBuggable(boolean buggable) {
        this.buggable = buggable;
    }

    public boolean isBuggable() {
        return buggable;
    }


    public static final class Builder {
        String mEncryptKey; //16位
        String mWaterMark;
        //        String mUerName;
        //        String mFileProvider;
        boolean debuggable;

        public Builder setWaterMark(String waterMark) {
            this.mWaterMark = waterMark;
            return this;
        }

        public Builder isBuggable(boolean buggable) {
            this.debuggable = buggable;
            return this;
        }

        public Builder setEncryptKey(String encryptKey) {
//            if (encryptKey16.length() < 16) {
//                new RuntimeException("密钥请设置为16位");
//            }
            mEncryptKey = encryptKey;
            return this;
        }


        public SandBoxConfig build(Application application) {
            SandBoxConfig config = new SandBoxConfig(application);
            config.setEncryptKey(mEncryptKey);
            config.setWaterMark(mWaterMark);
            config.setBuggable(debuggable);
            return config;
        }


    }

}
