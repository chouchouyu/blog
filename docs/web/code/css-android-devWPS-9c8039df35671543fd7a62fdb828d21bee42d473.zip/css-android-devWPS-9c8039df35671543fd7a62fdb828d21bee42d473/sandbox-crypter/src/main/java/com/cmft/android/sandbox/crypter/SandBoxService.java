package com.cmft.android.sandbox.crypter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;

import com.cmft.android.sandbox.crypter.webService.HttpCoreSer;
import com.cmft.android.sandbox.crypter.webService.HttpStatusListener;
import com.cmft.android.sandbox.crypter.webService.ServerManager;
import com.cmft.android.sandbox.crypter.core.Constant;

public class SandBoxService implements HttpStatusListener {

    private ServerManager mServerManager;
    private Context context;
    private SandBoxServiceListener listener;

    public void register(Context context, SandBoxServiceListener listener) {
        this.context = context;
        this.listener = listener;
        Intent intent = new Intent(context, HttpCoreSer.class);
        mServerManager = new ServerManager(this, intent);
        mServerManager.register();
    }

    public void unRegister() {
        mServerManager.unRegister();
    }

    public void startServer() {
        mServerManager.startServer();
    }

    public void stopServer() {
        mServerManager.stopServer();
    }

    @Override
    public void unregisterHttpReceiver(BroadcastReceiver receiver) {
        context.unregisterReceiver(receiver);
    }

    @Override
    public void registerHttpReceiver(BroadcastReceiver receiver, IntentFilter filter) {
        context.registerReceiver(receiver, filter);
    }

    @Override
    public void startHttpService(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //android8.0以上通过startForegroundService启动service
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    @Override
    public void stopHttpService(Intent intent) {
        context.stopService(intent);
    }

    @Override
    public void onServerStart(String ip) {
        if (null != listener) {
            listener.onServerStart("http://" + ip + ":" + Constant.PORT);
        }
    }

    @Override
    public void onServerError(String error) {
        if (null != listener) {
            listener.onServerError(error);
        }

    }

    @Override
    public void onServerStop() {
        if (null != listener) {
            listener.onServerStop();
        }

    }
}
