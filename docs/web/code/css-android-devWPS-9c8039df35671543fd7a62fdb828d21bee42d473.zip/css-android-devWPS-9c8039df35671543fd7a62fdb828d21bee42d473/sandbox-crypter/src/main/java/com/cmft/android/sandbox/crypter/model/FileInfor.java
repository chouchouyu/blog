package com.cmft.android.sandbox.crypter.model;

public class FileInfor {
    String type;
    String name;
    long size;
    String path;

    public FileInfor(String type, String name, long size, String path) {
        this.type = type;
        this.name = name;
        this.size = size;
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }
}

