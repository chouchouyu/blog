package com.cmft.android.sandbox.crypter.model;

public class FileContent {
    private int buffrLength;
    private int fileype;
    private String key;

    public int getFileSize() {
        return buffrLength;
    }

    public void setBuffrLength(int buffrLength) {
        this.buffrLength = buffrLength;
    }

    public int getFileype() {
        return fileype;
    }

    public void setFileype(int fileype) {
        this.fileype = fileype;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
