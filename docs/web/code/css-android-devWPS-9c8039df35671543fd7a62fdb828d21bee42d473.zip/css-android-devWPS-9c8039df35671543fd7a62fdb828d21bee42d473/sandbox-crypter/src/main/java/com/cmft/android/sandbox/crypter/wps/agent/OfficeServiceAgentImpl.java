package com.cmft.android.sandbox.crypter.wps.agent;

import android.os.RemoteException;

import com.cmft.android.sandbox.crypter.core.Constant;
import com.cmft.android.sandbox.crypter.core.SandBoxCenter;
import com.cmft.android.sandbox.crypter.core.SandBoxConfig;
import com.cmft.android.sandbox.crypter.utils.SandboxUtils;
import com.cmft.android.sandbox.crypter.wps.test.AutoTestParam;
import com.cmft.android.sandbox.crypter.wps.util.Util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.wps.moffice.agent.OfficeServiceAgent;

public class OfficeServiceAgentImpl extends OfficeServiceAgent.Stub {
    private static final String JSON_DATA =
            "[" +
                    "{ \"name\" : \"cn.wps.moffice.client.OfficeServiceClient1875\"," +
                    " \"type\" : \"Package-ID\",\"id\" : \"cn.wps.moffice.client\", " +
                    "\"Security-Level\" : \"Full-access\", \"Authorization\"  : " +
                    "\"abxxdsewrwsds1875ss\" }," +
                    "]";


    private static final String JSON_DATA_EMPTY = "[" + "]";
    protected AgentMessageService service = null;
    private boolean mIsValidPackageName = true;

    public OfficeServiceAgentImpl(AgentMessageService service) {
        this.service = service;
    }

    /**
     * 该方法的结果，根据isValidPackage来决定
     */
    @Override
    public int getClients(String[] clients, int[] expiredDays) throws RemoteException {

//        String str = Util.assetsFileRead(Constant.ASSET_JSON, SandBoxCenter.getInstance()
//                .getContext
//                        ()).trim();


//        String JSON_DATA =
//                "[" +
//                        "{ \"name\" : \"" + client + "\"," +
//                        " \"type\" : \"Package-ID\",\"id\" : \"cn.wps.moffice.client\", " +
//                        "\"Security-Level\" : \"Full-access\", \"Authorization\"  : " +
//                        "\"abxxdsewrwsds1875ss\" }," +
//                        "]";

        try {
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:getClients");

//            JSONObject jsonfile = new JSONObject(str);
//            if (jsonfile.has("client")) {
            String client = SandboxUtils.getOfficeServiceClient(SandBoxCenter.getInstance()
                    .getContext());
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("name", client);
            jsonObject.put("type", "Package-ID");
            jsonObject.put("id", "cn.wps.moffice.client");
            jsonObject.put("Security-Level", "Full-access");
            jsonObject.put("Authorization", "abxxdsewrwsds1875ss");
            jsonArray.put(jsonObject);
            SandBoxCenter.logger.debug(Constant.TAG, "WPS:JSON_DATA->" + jsonArray.toString());
            clients[0] = mIsValidPackageName ? jsonArray.toString() : JSON_DATA_EMPTY;
            expiredDays[0] = 1;
            setAutoTestParam();            //加解密自动化测试的初始化
//            } else {
//                SandBoxCenter.logger.error(Constant.TAG, "WPS:JSON_DATA  client key not " +
//                        "found in " +
//                        "json");
//            }
//
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 判断可变的第三方应用包名,在wps内部，每次调用getclients之前，都会调用该方法，以确保验证包名
     *
     * @param originalPackage  根据渠道写入到wps中的定制包名
     * @param realThirdPackage 可变的第三方应用包名
     * @return
     * @throws RemoteException
     */
    @Override
    public boolean isValidPackage(String originalPackage, String realThirdPackage) throws
            RemoteException {//此段代码是某些企业的特殊需求，可以忽略
        SandBoxCenter.logger.debug(Constant.TAG, "WPS:OfficeServiceAgentImpl-isValidPackage" +
                "originalPackage" + originalPackage + "," +
                "realThirdPackage" + realThirdPackage);
//		mIsValidPackageName = false;
//		if (originalPackage.equals(service.getPackageName()) && realThirdPackage.equals("cn.wps
// .moffice"))
//		{
//			mIsValidPackageName = true;
//			return true;
//		}
        return true;
    }

    /**
     * 用来设置加解密测试的参数的初始化
     */
    private void setAutoTestParam() {
        AutoTestParam.IsOpenCorrect = false;
    }
}