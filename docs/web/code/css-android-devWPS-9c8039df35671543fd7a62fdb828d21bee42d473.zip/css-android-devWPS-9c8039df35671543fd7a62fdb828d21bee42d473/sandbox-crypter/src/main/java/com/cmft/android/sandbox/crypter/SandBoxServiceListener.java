package com.cmft.android.sandbox.crypter;

public interface SandBoxServiceListener {
    void onServerStart(String ip);

    void onServerError(String error);

    void onServerStop();
}