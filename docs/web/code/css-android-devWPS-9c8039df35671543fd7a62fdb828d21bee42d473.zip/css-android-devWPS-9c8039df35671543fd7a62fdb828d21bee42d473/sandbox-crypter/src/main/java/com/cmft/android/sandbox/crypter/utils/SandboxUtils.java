package com.cmft.android.sandbox.crypter.utils;


import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.support.v4.content.FileProvider;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;

import com.cmft.android.sandbox.crypter.core.Constant;
import com.cmft.android.sandbox.crypter.core.SandBoxCenter;
import com.cmft.android.sandbox.crypter.model.FileType;
import com.yanzhenjie.andserver.http.multipart.MultipartFile;
import com.yanzhenjie.andserver.util.StringUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


import static com.cmft.android.sandbox.crypter.core.Constant.COSID;

public class SandboxUtils {

    public static FileType getFileType(String docPath) {
        docPath.toLowerCase();
        if (docPath.endsWith(".doc")) {
            return FileType.DOC;
        } else if (docPath.endsWith(".docx")) {
            return FileType.DOCX;
        } else if (docPath.endsWith(".wps")) {
            return FileType.WPS;
        } else if (docPath.endsWith(".txt")) {
            return FileType.TXT;
        } else if (docPath.endsWith(".xls")) {
            return FileType.XLS;
        } else if (docPath.endsWith(".xlsx")) {
            return FileType.XLSX;
        } else if (docPath.endsWith(".ppt")) {
            return FileType.PPT;
        } else if (docPath.endsWith(".pptx")) {
            return FileType.PPTX;
        } else if (docPath.endsWith(".pdf")) {
            return FileType.PDF;
        } else {
            return FileType.UNKNOW;
        }
    }


    public static String getSaveDir(String rootPath, String date) {
        return rootPath + File.separator + date;
    }

    public static String fileSavePath(String rootPath, String fileName, String date) {
        File file = new File(fileName);
        String parentPath = file.getParent();
        if (parentPath == null) {
            return getSaveDir(rootPath, date) + File.separator + fileName;
        } else {
            return getSaveDir(rootPath, date) + File.separator + parentPath + File.separator +
                    file.getName();
        }
    }

    public static boolean perpareDir(String savePath) {
        File sandboxDir = new File(savePath);
        if (sandboxDir.exists()) {
            return true;
        } else {
            return sandboxDir.mkdirs();
        }
    }


    public static String MD5(String sourceStr) {
        try {
            // 获得MD5摘要算法的 MessageDigest对象
            MessageDigest mdInst = MessageDigest.getInstance("MD5");
            // 使用指定的字节更新摘要
            mdInst.update(sourceStr.getBytes());
            // 获得密文
            byte[] md = mdInst.digest();
            // 把密文转换成十六进制的字符串形式
            StringBuffer buf = new StringBuffer();
            for (int i = 0; i < md.length; i++) {
                int tmp = md[i];
                if (tmp < 0)
                    tmp += 256;
                if (tmp < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(tmp));
            }
            //return buf.toString().substring(8, 24);// 16位加密
            return buf.toString();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 从assets目录下拷贝文件
     *
     * @param context            上下文
     * @param assetsFilePath     文件的路径名如：SBClock/0001cuteowl/cuteowl_dot.png
     * @param targetFileFullPath 目标文件路径如：/sdcard/SBClock/0001cuteowl/cuteowl_dot.png
     */
    public static void copyFileFromAssets(Context context, String assetsFilePath, String
            targetFileFullPath) {
        SandBoxCenter.logger.debug(Constant.TAG, "APK:copyFileFromAssets ");
        InputStream assestsFileImputStream;
        try {
            assestsFileImputStream = context.getAssets().open(assetsFilePath);
            copyFile(assestsFileImputStream, targetFileFullPath);
        } catch (IOException e) {
            SandBoxCenter.logger.debug(Constant.TAG, "APK:copyFileFromAssets " + "IOException-" +
                    e.getMessage());
            e.printStackTrace();
        }
    }


    public static String getApkSavePath(String apkName) {
        String mPath = Environment.getExternalStorageDirectory() + File.separator + Constant
                .SDK_NAME;
        File rootDir = new File(mPath);
        if (!rootDir.exists()) {
            rootDir.mkdirs();
        }
        return mPath + File.separator + apkName;
    }

    public static void copyFile(InputStream in, String targetPath) {
        try {
            FileOutputStream fos = new FileOutputStream(new File(targetPath));
            byte[] buffer = new byte[2048];
            int byteCount = 0;
            while ((byteCount = in.read(buffer)) != -1) {// 循环从输入流读取
                // buffer字节
                fos.write(buffer, 0, byteCount);// 将读取的输入流写入到输出流
            }
            fos.flush();// 刷新缓冲区
            in.close();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 检查手机上是否安装了指定的软件
     *
     * @param context
     * @param packageName
     * @return
     */
    public static boolean isAPKInstalled(Context context, String packageName) {
        final PackageManager packageManager = context.getPackageManager();
        List<PackageInfo> packageInfos = packageManager.getInstalledPackages(0);
        List<String> packageNames = new ArrayList<String>();

        if (packageInfos != null) {
            for (int i = 0; i < packageInfos.size(); i++) {
                String packName = packageInfos.get(i).packageName;
                packageNames.add(packName);
            }
        }
        // 判断packageNames中是否有目标程序的包名，有TRUE，没有FALSE
        return packageNames.contains(packageName);
    }


    //https://mp.weixin.qq.com/s/EhaV1Uk_aO-MUEtjc0t4LQ  Android App更新安装APK
    public static void checkInstallApkPermission(Context context, String filePath, String
            fileProvider) {
        SandBoxCenter.logger.debug(Constant.TAG, "APK:检测APK安装包权限:" + filePath);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (context.getPackageManager().canRequestPackageInstalls()) {
                SandBoxCenter.logger.debug(Constant.TAG, "APK:能发起安装apk请求");
                installApkFile(context, filePath, fileProvider);
            } else {
                SandBoxCenter.logger.debug(Constant.TAG, "APK:不能发起安装apk请");
                installApkFile(context, filePath, fileProvider);
            }
        } else {
            installApkFile(context, filePath, fileProvider);
        }
    }

    public static void installApkFile(Context context, String filePath, String fileProvider) {
        File file = new File(filePath);
        SandBoxCenter.logger.debug(Constant.TAG, "APK:开始安装apk " + file);
        if (context != null && file != null && file.exists()) {
            try {
                ///storage/emulated/0/Android/data/com.touchrom
                /// .yuliao/files/storage/emulated/0/yuliao/temp/yuliao(3).apk
                Intent intent = new Intent(Intent.ACTION_VIEW);
                // 由于没有在Activity环境下启动Activity,设置下面的标签
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (Build.VERSION.SDK_INT >= 24) { //判读版本是否在7.0以上
                    //参数1 上下文, 参数2 Provider主机地址 和配置文件中保持一致   参数3  共享的文件
                    //file:///storage/emulated/0/fjz/update/fanjianzhi.apk
//                    String packageName = context.getPackageName();
//                    Timber.d("path = " + file.getAbsolutePath() + "packageName = " + packageName);
//                    Uri apkUri = FileProvider.getUriForFile(context, "com.cmft.android.sandbox" +
//                            ".crypter.provider", file);
                    Uri apkUri = FileProvider.getUriForFile(context, fileProvider, file);

                    //添加这一句表示对目标应用临时授权该Uri所代表的文件
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
                } else {
                    intent.setDataAndType(Uri.fromFile(file), "application/vnd.android" +
                            ".package-archive");
                }
                boolean result = canTurn(context, intent);
                SandBoxCenter.logger.debug(Constant.TAG, "APK:安装结果：" + result);
                if (result)
//                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (file != null) {
            SandBoxCenter.logger.debug(Constant.TAG, "APK:安装包是否存在：" + file.exists());
        }
    }


    /**
     * 判断intent是否可以安全跳转(主要是隐式跳转)
     */
    public static boolean canTurn(Context context, Intent intent) {
        return context != null && intent != null && intent.resolveActivity(context
                .getPackageManager()) != null;
    }

    /**
     * Create a random file based on mimeType.
     *
     * @param file file.
     * @return file object.
     */
    public static File createRandomFile(String path, MultipartFile file) {
        String extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(file
                .getContentType().toString());
        if (StringUtils.isEmpty(extension)) {
            extension = MimeTypeMap.getFileExtensionFromUrl(file.getFilename());
        }
        String uuid = UUID.randomUUID().toString();
        return new File(path, uuid + "." + extension);
    }


    public static String generateToken(String uuid) {
//        String uuid = UUID.randomUUID().toString();
        String token = uuid + System.currentTimeMillis();
        SandBoxCenter.logger.debug(Constant.TAG, "generateToken:" + token);
        return EncryptData.getMD5(uuid + token);
    }

    public static String generateKey(Context context, String uuid) {
//        String uuid = UUID.randomUUID().toString();
        String deviceId = DeviceUtils.getInstance(context).getDeviceId();
        //todo +文件随机数
        return EncryptData.getMD5(uuid + deviceId).substring(0, 16);
    }


    public static String randomString() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public static String fileKey(Context context, String key, String identification) {
        String deviceId = DeviceUtils.getInstance(context).getDeviceId();
        return EncryptData.getMD5(deviceId + key + identification).substring(0, 16);
    }

    public static String cosKey(String identification) {
        return EncryptData.getMD5(COSID + identification).substring(0, 16);
//        return (COSID + identification).substring(0, 16);
    }


    public static String getFileProvider(Context context) {
        return context.getPackageName() + ".mailProvider";
    }

    public static String getOfficeServiceAgent(Context context) {
        return context.getPackageName() + ".OfficeServiceAgent";
    }


    public static String getOfficeServiceClient(Context context) {
        return context.getPackageName() + ".OfficeServiceClient";
    }

    public static <T> T throwIfNull(T item) {
        if (item == null) {
            throw new NullPointerException();
        }
        return item;
    }

    public static <T1, T2> void throwIfNull(T1 item1, T2 item2) {
        throwIfNull(item1);
        throwIfNull(item2);
    }

    public static <T1, T2, T3> void throwIfNull(T1 item1, T2 item2, T3 item3) {
        throwIfNull(item1);
        throwIfNull(item2);
        throwIfNull(item3);
    }

    public static void throwIfNot(boolean condition) {
        if (!condition) {
            throw new IllegalStateException();
        }
    }

    public static boolean isFileExists(Context context, String
            saveFilePath, File file) {
        boolean isExists = false;
        try {
            if (saveFilePath.contains(Constant.SANDBOX_ROOT)) {
                String cocoData = saveFilePath.substring(saveFilePath.indexOf("/" + Constant
                        .SANDBOX_ROOT), saveFilePath.lastIndexOf("/"));
                String fileName = file.getName();
                File fileStreamPath = context.getExternalFilesDir(cocoData);
                if (!fileStreamPath.exists()) {
                    isExists = false;
                } else {
                    String[] filelist = fileStreamPath.list();
                    for (String dirFile : filelist) {
                        if (TextUtils.equals(dirFile, fileName)) {
                            isExists = true;
                        }
                    }
                }
            } else {
                if (!file.exists()) {
                    isExists = false;
                } else {
                    isExists = true;
                }
            }
            return isExists;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return isExists;
        }
    }


    public static boolean isInMainProcess(Context context) {
        String pkgName = context.getPackageName();
        String processName = getProcessName(context);
        if (processName == null || processName.length() == 0) {
            processName = "";
        }

        return pkgName.equals(processName);
    }

    private static String processName = null;

    /**
     * add process name cache
     *
     * @param context
     * @return
     */
    public static String getProcessName(final Context context) {
        if (processName != null) {
            return processName;
        }
        //will not null
        processName = getProcessNameInternal(context);
        return processName;
    }

    private static String getProcessNameInternal(final Context context) {
        int myPid = android.os.Process.myPid();

        if (context == null || myPid <= 0) {
            return "";
        }

        ActivityManager.RunningAppProcessInfo myProcess = null;
        ActivityManager activityManager =
                (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);

        if (activityManager != null) {
            List<ActivityManager.RunningAppProcessInfo> appProcessList = activityManager
                    .getRunningAppProcesses();

            if (appProcessList != null) {
                try {
                    for (ActivityManager.RunningAppProcessInfo process : appProcessList) {
                        if (process.pid == myPid) {
                            myProcess = process;
                            break;
                        }
                    }
                } catch (Exception e) {
                    SandBoxCenter.logger.error(Constant.TAG, "getProcessNameInternal exception:" +
                            e.getMessage());
                }

                if (myProcess != null) {
//                    return "Process: " + myProcess.processName + ", PID: " + myPid;
                    return myProcess.processName;
                }
            }
        }

        byte[] b = new byte[128];
        FileInputStream in = null;
        try {
            in = new FileInputStream("/proc/" + myPid + "/cmdline");
            int len = in.read(b);
            if (len > 0) {
                for (int i = 0; i < len; i++) { // lots of '0' in tail , remove them
                    if (b[i] <= 0) {
                        len = i;
                        break;
                    }
                }
                return new String(b, 0, len, Charset.forName("UTF-8"));
            }

        } catch (Exception e) {
            SandBoxCenter.logger.error(Constant.TAG, "getProcessNameInternal exception:" + e
                    .getMessage());
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e) {
                SandBoxCenter.logger.error(Constant.TAG, e.getMessage());
            }
        }
        return "";
    }


    public static String getSPUserId(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(Constant.SDK_NAME,
                Context.MODE_PRIVATE);
        return prefs.getString(Constant.SP_USER_ID_KEY, "");
    }

    public static String saveSPUserId(Context context, String userid) {
        SharedPreferences prefs = context.getSharedPreferences(Constant.SDK_NAME,
                Context.MODE_PRIVATE);
        final SharedPreferences.Editor prefEditor = prefs.edit();
        prefEditor.putString(Constant.SP_USER_ID_KEY, userid);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            prefEditor.apply();
        } else {
            prefEditor.commit();
        }
        return userid;
    }
}
