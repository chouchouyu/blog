package com.cmft.android.sandbox.crypter.wps.agent;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.os.Build;

import cn.wps.moffice.agent.OfficeServiceAgent;

import static android.app.Notification.VISIBILITY_PUBLIC;


public class AgentMessageService extends Service {
    private final static String TAG = AgentMessageService.class.getSimpleName();

    protected final OfficeServiceAgent.Stub mBinder = new OfficeServiceAgentImpl(this);

    @Override
    public void onCreate() {
        Log.i(TAG, "onCreate(): " + this.hashCode());
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.i(TAG, "onBind(): " + this.hashCode() + ", " + intent.toString());
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.i(TAG, "onUnbind(): " + this.hashCode() + ", " + intent.toString());
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        Log.i(TAG, "onDestroy(): " + this.hashCode());
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        compatAndroidO(this.getClass().getSimpleName());
        return super.onStartCommand(intent, flags, startId);
    }

    private void compatAndroidO(String clazzName) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String CHANNEL_ONE_ID = clazzName + "id";
            String CHANNEL_ONE_NAME = clazzName + "name";
            NotificationChannel notificationChannel;
            notificationChannel = new NotificationChannel(CHANNEL_ONE_ID,
                    CHANNEL_ONE_NAME, NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.enableLights(false);
            notificationChannel.setShowBadge(false);
            notificationChannel.setSound(null, null);
            notificationChannel.enableVibration(false);
            notificationChannel.setLockscreenVisibility(VISIBILITY_PUBLIC);
            NotificationManager manager = (NotificationManager) getSystemService
                    (NOTIFICATION_SERVICE);
            manager.createNotificationChannel(notificationChannel);
            startForeground(1, new Notification.Builder(this, CHANNEL_ONE_ID)
                    .build());
        }
    }

}
