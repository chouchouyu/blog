package com.cmft.android.sandbox.crypter.wps.client;


import android.os.RemoteException;

import cn.wps.moffice.client.OfficeAuthorization;


public class OfficeAuthorizationImpl extends OfficeAuthorization.Stub
{
	
	protected MOfficeClientService service = null;
	
	public OfficeAuthorizationImpl( MOfficeClientService service ) 
	{
		this.service = service;
	}

	@Override
	public int getAuthorization( String[] auth_code ) throws RemoteException
	{
		auth_code[0] = "abxxdsewrwsds1875ss";
		return 0;
	}
}
