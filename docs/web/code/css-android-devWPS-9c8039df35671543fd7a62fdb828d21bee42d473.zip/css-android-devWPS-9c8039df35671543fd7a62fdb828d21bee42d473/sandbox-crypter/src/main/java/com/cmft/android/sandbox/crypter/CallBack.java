package com.cmft.android.sandbox.crypter;

public interface CallBack<T> {
    void onSuccess(T response);

    void onFail(String string);
}