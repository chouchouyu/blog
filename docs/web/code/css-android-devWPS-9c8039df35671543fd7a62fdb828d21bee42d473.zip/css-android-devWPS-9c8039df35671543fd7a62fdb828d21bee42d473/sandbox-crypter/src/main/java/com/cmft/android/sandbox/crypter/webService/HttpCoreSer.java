package com.cmft.android.sandbox.crypter.webService;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import com.yanzhenjie.andserver.AndServer;
import com.yanzhenjie.andserver.Server;

import java.util.concurrent.TimeUnit;

import static android.app.Notification.VISIBILITY_PUBLIC;
import static com.cmft.android.sandbox.crypter.core.Constant.PORT;

public class HttpCoreSer extends Service {
    public HttpCoreSer() {
    }

    private Server mServer;

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mServer = AndServer.serverBuilder()
                .inetAddress(NetUtils.getLocalIPAddress())
                .port(PORT)
                .timeout(10, TimeUnit.SECONDS)
                .listener(new Server.ServerListener() {
                    @Override
                    public void onStarted() {
                        String hostAddress = mServer.getInetAddress().getHostAddress();
                        ServerManager.onServerStart(HttpCoreSer.this, hostAddress);
                    }

                    @Override
                    public void onStopped() {
                        ServerManager.onServerStop(HttpCoreSer.this);
                    }

                    @Override
                    public void onException(Exception e) {
                        ServerManager.onServerError(HttpCoreSer.this, e.getMessage());
                    }
                })
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startServer();
        compatAndroidO(getClass().getSimpleName());
        return START_STICKY;
    }


    private void compatAndroidO(String clazzName) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String CHANNEL_ONE_ID = clazzName + "id";
            String CHANNEL_ONE_NAME = clazzName + "name";
            NotificationChannel notificationChannel;
            notificationChannel = new NotificationChannel(CHANNEL_ONE_ID,
                    CHANNEL_ONE_NAME, NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.enableLights(false);
            notificationChannel.setShowBadge(false);
            notificationChannel.setSound(null, null);
            notificationChannel.enableVibration(false);
            notificationChannel.setLockscreenVisibility(VISIBILITY_PUBLIC);
            NotificationManager manager = (NotificationManager) getSystemService
                    (NOTIFICATION_SERVICE);
            manager.createNotificationChannel(notificationChannel);
            startForeground(1, new Notification.Builder(this, CHANNEL_ONE_ID)
                    .build());
        }
    }

    @Override
    public void onDestroy() {
        stopServer();
        super.onDestroy();
    }

    /**
     * Start server.
     */
    private void startServer() {
        if (mServer.isRunning()) {
            String hostAddress = mServer.getInetAddress().getHostAddress();
            ServerManager.onServerStart(HttpCoreSer.this, hostAddress);
        } else {
            mServer.startup();
        }
    }

    /**
     * Stop server.
     */
    private void stopServer() {
        mServer.shutdown();
    }
}
