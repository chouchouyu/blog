package com.cmft.android.sandbox.crypter.utils;

import com.cmft.android.sandbox.crypter.core.Constant;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public interface ILogger {

    List<LogListener> mListeners = new CopyOnWriteArrayList<>();

    boolean isShowLog = true;
    boolean isShowStackTrace = true;
    String defaultTag = Constant.TAG;

    void showLog(boolean isShowLog);

    void showStackTrace(boolean isShowStackTrace);

    void debug(String tag, String message);

    void info(String tag, String message);

    void warning(String tag, String message);

    void error(String tag, String message);

    void monitor(String message);

    boolean isMonitorMode();

    String getDefaultTag();

    void registerListener(LogListener listener);
}