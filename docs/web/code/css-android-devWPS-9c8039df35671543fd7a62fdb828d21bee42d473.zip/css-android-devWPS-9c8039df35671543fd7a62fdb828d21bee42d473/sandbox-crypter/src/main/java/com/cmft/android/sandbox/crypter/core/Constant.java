package com.cmft.android.sandbox.crypter.core;


public class Constant {
    public static final String SDK_NAME = "sandbox";
    public static final String TAG = SDK_NAME + "::";
    public static final String SANDBOX_ROOT = "COCO-DATA";

    public static final int PORT = 8080;
    public static final String COSID = "cmft1875cmft1875cmft1875";
    public static final String WPS_KEY = "4GTMW7Q2DQ8A6N8RBPKQRYT3G";
    public static final String SP_USER_ID_KEY = "Sandbox.userid";




    /**
     * https://coco.cmhk.com/lappst/versionGrade/versionUpgrade?versionChannel=01&build=0
     * &hostPlatformId=0c18eb0ea485e1efde9ab870cfc8f5b7
     * 打开网页返回json
     * {"success":true,"data":{"versionNo":"11.4.1","updateDesc":"1、金科专用企业版",
     * "resourceUrl":"https://cos.cmhk
     * .com/cos-download/v2/dopf/appstore-public-bucket/56f20c396671a087b5c693a61edcd384/moffice
     * .apk","resourceMd5":"e540ed022da4ac8975c2d52255e112fe","isUpgrade":"Y","build":390,
     * "updateLevel":"A","sysVersionNo":1,"fileSize":4.0173144E7},"message":"请求成功"}
     * build 390
     */
    public static final int WPS_BUILD_VERSION = 390;
    public static final String WPS_DOWNLOAD_SITE = "https://coco.cmhk" +
            ".com/appMo/static/dl/?dlkey=foda";

    public static final String WPS_CHECK_VERSION = "https://coco.cmhk" +
            ".com/lappst/versionGrade/versionUpgrade?versionChannel=01&build=0&hostPlatformId" +
            "=0c18eb0ea485e1efde9ab870cfc8f5b7";

    public static String baseUrl = "http://127.0.0.1:8080";
}
