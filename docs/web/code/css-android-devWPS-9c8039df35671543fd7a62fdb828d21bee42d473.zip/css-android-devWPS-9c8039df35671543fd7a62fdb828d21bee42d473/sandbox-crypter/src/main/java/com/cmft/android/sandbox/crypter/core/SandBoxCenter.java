package com.cmft.android.sandbox.crypter.core;


import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Looper;
import android.os.StrictMode;
import android.support.v4.app.ActivityCompat;
import android.text.TextUtils;
import android.util.Log;

import com.cmft.android.sandbox.crypter.CallBack;
import com.cmft.android.sandbox.crypter.model.FileContent;
import com.cmft.android.sandbox.crypter.utils.ActivityTracker;
import com.cmft.android.sandbox.crypter.utils.DefaultLogger;
import com.cmft.android.sandbox.crypter.utils.ILogger;
import com.cmft.android.sandbox.crypter.utils.LogListener;
import com.cmft.android.sandbox.crypter.utils.SortByName;
import com.cmft.android.sandbox.crypter.model.FileEntity;
import com.cmft.android.sandbox.crypter.model.FileInfor;
import com.cmft.android.sandbox.crypter.model.FileType;
import com.cmft.android.sandbox.crypter.utils.SandboxUtils;
import com.cmft.android.sandbox.crypter.wps.WPSService;
import com.cmft.android.sandbox.crypter.wps.client.MOfficeClientService;
import com.cmft.android.sandbox.crypter.wps.util.Define;
import com.cmft.android.sandbox.crypter.wps.util.SettingPreference;
import com.cmft.android.sandbox.crypter.wps.util.Util;
import com.yanzhenjie.andserver.util.IOUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import cn.wps.moffice.client.OfficeInputStream;
import cn.wps.moffice.client.OfficeOutputStream;

import static com.cmft.android.sandbox.crypter.core.Constant.TAG;
import static com.cmft.android.sandbox.crypter.core.Constant.WPS_BUILD_VERSION;
import static com.cmft.android.sandbox.crypter.core.Constant.WPS_CHECK_VERSION;

/**
 * 沙箱核心处理类
 */
public class SandBoxCenter {

    private volatile static String mUserName;
    private volatile static String mPath; //文件路径
    private volatile static String mEncryptKey; //加密密钥
    private volatile static SandBoxProtocol sandBoxProtocol;
    private volatile static Context context;
    private volatile static SettingPreference settingPreference;
    private volatile static String token;
    private volatile static String WPSSavePath;
    public static ILogger logger = new DefaultLogger(TAG);

    public String getWPSSavePath() {
        return WPSSavePath;
    }

    public Context getContext() {
        return context;
    }

    public String getUserPath() {
        if (TextUtils.isEmpty(mUserName)) {
            mUserName = SandboxUtils.getSPUserId(context);
            if (TextUtils.isEmpty(mUserName)) {
                throw new RuntimeException("Please call SandBox.getInstance().setUserName() first");
            } else {
                return SandboxUtils.getSaveDir(mPath, mUserName);
            }
        } else {
            return SandboxUtils.getSaveDir(mPath, mUserName);
        }
    }


    public void setUserName(String userName) {
        mUserName = SandboxUtils.saveSPUserId(context, userName);
    }


    private volatile static SandBoxCenter instance = null;
    private volatile static boolean hasInit = false;

    public static synchronized boolean init(SandBoxConfig config) {
        if (!config.isValid()) {
            throw new NullPointerException("config's param is invalid");
        }
        context = config.getContext();
        mPath = config.sandboxPath;

        logger.showLog(config.isBuggable());
        logger.debug(TAG, "===== sandbox 开启 =====");

        mEncryptKey = config.mEncryptKey;

        sandBoxProtocol = new SandBoxProtocol(mEncryptKey, context);

        settingPreference = new SettingPreference(context);
        settingPreference.setSettingParam(Define.WATERMASK_TEXT, config.getWaterMark());

        //attach成功后会启动 沙箱本地服务
        ProcessMonitor.attach(config.getApplication());

        boolean isTrackingActivities = ActivityTracker.get().beginTrackingIfPossible(
                config.getApplication());
        if (!isTrackingActivities) {
            logger.debug(TAG, "Automatic activity tracking not available on this API level, " +
                    "caller " +
                    "must " +
                    "invoke " +
                    "ActivityTracker methods manually!");
        }

        //取出8.0对Uri的限制，方便WPS Intent打开时传值
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
        }

        if (Thread.currentThread() == Looper.getMainLooper().getThread()) {
            token = SandboxUtils.generateToken(mEncryptKey);
        }
        hasInit = true;
        return true;
    }

    public static SandBoxCenter getInstance() {
        if (!hasInit) {
            throw new RuntimeException("Please initialize SandBox first");
        } else {
            if (instance == null) {
                synchronized (SandBoxCenter.class) {
                    if (instance == null) {
                        instance = new SandBoxCenter();
                    }
                }
            }
            return instance;
        }
    }


    public void checkVersion() {
        Thread httpThread = new Thread() {
            @Override
            public void run() {
                Looper.prepare();
                doGet();
                Looper.loop();

            }
        };

        httpThread.start();
    }


    private void doGet() {
        //get方式请求数据是在url中拼接的
        String url = WPS_CHECK_VERSION;
//		URLEncoder.encode(name,"utf-8");//转码，防止中文乱码
        try {
            URL httpUrl = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) httpUrl.openConnection();
            conn.setReadTimeout(3000);
            conn.setRequestMethod("GET");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn
                    .getInputStream()));
            String str;
            StringBuffer sb = new StringBuffer();
            while ((str = bufferedReader.readLine()) != null) {
                sb.append(str);
            }
            logger.debug(TAG, "WPS专业版-web: " + sb.toString());
            JSONObject jsonObject = new JSONObject(sb.toString());
            if (jsonObject.has("success") && jsonObject.getBoolean("success")) {
                JSONObject dataObj = jsonObject.getJSONObject("data");
                if (dataObj.has("build") && dataObj.getInt("build") > WPS_BUILD_VERSION) {
                    logger.debug(TAG, "WPS专业版-跳转下载 ");
                    final Intent intent = new Intent(context, UpdateActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    ActivityCompat.startActivity(context, intent, null);
                } else {
                    logger.debug(TAG, "WPS专业版-不需要更新 build >" +
                            WPS_BUILD_VERSION);
                }
            } else {
                logger.debug(TAG, "WPS专业版-web 请求失败");
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public String getToken() {
        return token;
    }


    //+++++++++++++++++++++++是否是加密文件++++++++++++++++++++++++++
    public boolean isEncrypted(File file) {
        File saveFile;
        if (file.getAbsolutePath().contains(Constant.SANDBOX_ROOT)) {
            saveFile = file.getAbsoluteFile();
        } else {
            saveFile = new File(SandboxUtils.fileSavePath(mPath, file.getAbsolutePath(),
                    mUserName));
        }
        logger.debug(TAG, "文件是否加密:路径->" + saveFile.getAbsolutePath());

        if (!SandboxUtils.isFileExists(context, saveFile.getAbsolutePath(), file)) {
            logger.debug(TAG, "文件是否加密:" + file.getAbsolutePath() + " 沙箱内没有此路径.");
            return false;
        } else {
            boolean isEncrypted = sandBoxProtocol.csandbox_isSecurityFile(saveFile
                    .getAbsolutePath());
            logger.debug(TAG, "文件是否加密:结果-" + isEncrypted + "；文件名 " + saveFile.getName());
            return isEncrypted;
        }
    }


    ///sdcard/Download/avatar/wsm.doc
    ///storage/emulated/0/Download/avatar/wsm.doc
    public boolean isEncrypted(String path) {
        boolean isEncrypted = false;
        try {
            isEncrypted = sandBoxProtocol.csandbox_isSecurityFile(path);
            logger.debug(TAG, "isEncrypted 解密时 打开文件加密状态：" + isEncrypted);
            return isEncrypted;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return isEncrypted;
        }

    }


    public long getFileSize(File file) {
        File saveFile;
        if (file.getAbsolutePath().contains(Constant.SANDBOX_ROOT)) {
            saveFile = file.getAbsoluteFile();
        } else {
            saveFile = new File(SandboxUtils.fileSavePath(mPath, file.getAbsolutePath(),
                    mUserName));
        }
        logger.debug(TAG, "获取文件大小:路径->" + saveFile.getAbsolutePath());

        if (!SandboxUtils.isFileExists(context, saveFile.getAbsolutePath(), saveFile)) {
            logger.debug(TAG, "获取文件大小:" + saveFile.getAbsolutePath() + " 沙箱内没有此路径.");
            return 0;
        } else {
            return saveFile.length();
        }
    }

    //+++++++++++++++++++++++WPS++++++++++++++++++++++++++
    public void editWithWPS(final String filePath, String savePath) {
        WPSSavePath = SandboxUtils.fileSavePath(mPath, savePath, mUserName);
        File file = new File(SandboxUtils.fileSavePath(mPath, filePath, mUserName));
        boolean isEncrypted = isEncrypted(file);
        installWPS(file, "EditMode", isEncrypted, SandboxUtils.getFileProvider(context));
    }

    public void openWithWPS(final String filePath) {
        WPSSavePath = null;
        File file = new File(SandboxUtils.fileSavePath(mPath, filePath, mUserName));
        boolean isEncrypted = isEncrypted(file);
        installWPS(file, "ReadOnly", isEncrypted, SandboxUtils.getFileProvider(context));
    }


    private void installWPS(File file, String openMode, boolean isEncrypted, String fileProvider) {
        if (Util.IsWPSFile(file)) {
            logger.debug(TAG, "WPS 打开文件 -> " + file.getAbsolutePath());
            if (!SandboxUtils.isAPKInstalled(context, WPSService.packageName)) {

                logger.debug(TAG, "未监测到WPS专业版");
                final Intent intent = new Intent(context, InstallActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ActivityCompat.startActivity(context, intent, null);
            } else {
                Activity activity = ActivityTracker.get().tryGetTopActivity();
                logger.debug(TAG, "已经安装WPS专业版-" + activity.getClass().getSimpleName());
                bindService(context, activity);
                settingPreference.setSettingParam(Define.OPEN_MODE, openMode);
                settingPreference.setSettingParam(Define.ENCRYPT_FILE, isEncrypted);
                startWPSIntent(file.getAbsolutePath(), activity);
            }


        } else {
            logger.debug(TAG, " WPS 不支持的文件类型 ->" + file.getName());
        }
    }


    private boolean startWPSIntent(String path, Activity activity) {
        Intent intent = Util.getOpenIntent(context, path, true);
        if (null == intent) {
            return false;
        }

        try {
            activity.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();

            return false;
        }

        return true;
    }

    private void bindService(Context contex, Activity activity) {
        //启动service
        logger.debug(TAG, "WPS MOfficeClientService 启动");
        Intent intent = new Intent(contex, MOfficeClientService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //android8.0以上通过startForegroundService启动service
            activity.startForegroundService(intent);
        } else {
            activity.startService(intent);
        }

    }

    //+++++++++++++++++++++++decrypt++++++++++++++++++++++++++

    /**
     * 这个 方法 和 传String的方法区别是 这里的File是正常的路径，但是String方法后面取的是沙盒的相对路径
     *
     * @param fileid
     * @param outputStream
     * @return
     */
    public void decrypt(final File fileid, final OutputStream outputStream, final CallBack<Boolean>
            callBack) {
        sandBoxProtocol.decrypt(fileid, outputStream, new CallBack<Boolean>() {
            @Override
            public void onSuccess(Boolean response) {
                callBack.onSuccess(response);
            }

            @Override
            public void onFail(String string) {
                callBack.onFail(string);
            }
        });
    }


    public void decrypt(String fileid, final OutputStream outputStream, final CallBack<Boolean>
            callBack) {
        /**
         * /storage/emulated/0/Android/data/com.cmft.jniproject.dev/files/COCO-DATA/avatar/wsm.doc
         * path -/storage/emulated/0/Android/data/com.cmft.jniproject.dev/files/COCO-DATA
         sourcePath - /sdcard/Download/wsm.doc
         mUserName - avatar
         */
        String saveFilePath = SandboxUtils.fileSavePath(mPath, fileid, mUserName);
        final File file = new File(saveFilePath);
        sandBoxProtocol.decrypt(file, outputStream, new CallBack<Boolean>() {


            @Override
            public void onSuccess(Boolean response) {
                callBack.onSuccess(response);
            }

            @Override
            public void onFail(String string) {
                callBack.onFail(string);

            }
        });
    }


    public long decryptFileSize(File file) {
        if (SandboxUtils.isFileExists(context, file.getAbsolutePath(), file)) {
            FileContent fileContent = new FileContent();
            sandBoxProtocol.decryptFileSize(file.getAbsolutePath(), fileContent);
            return fileContent.getFileSize();
        } else {
            logger.debug(TAG, "解密的文件 ->" + file.getAbsolutePath() + " is not exist ");
            return 0;
        }

    }


    public void decrypt(String path, OfficeOutputStream output) {
        sandBoxProtocol.decrypt(path, output);
    }

//+++++++++++++++++++++++encrypt++++++++++++++++++++++++++


    public void encryptSaveFile(OfficeInputStream input, File path) {

        FileType fileType = SandboxUtils.getFileType(path.getName());

        String identification = SandboxUtils.randomString();
        if (TextUtils.isEmpty(WPSSavePath)) {
            //没有指定path 正常加密
            logger.debug(TAG, "WPS 加密： 没有指定path 正常加密-> " + path);
            sandBoxProtocol.encryptSaveFile(input, identification, SandboxUtils.fileKey(context,
                    mEncryptKey, identification), path.getAbsolutePath(), fileType, 0x0101, new
                    CallBack<Boolean>() {


                        @Override
                        public void onSuccess(Boolean response) {

                        }

                        @Override
                        public void onFail(String string) {

                        }
                    });
        } else {
            //有指定path 另存为
            logger.debug(TAG, "WPS 加密： 有指定path 另存为-> " + WPSSavePath);
            File saveFile = new File(WPSSavePath);
            SandboxUtils.perpareDir(saveFile.getParent());
            sandBoxProtocol.encryptSaveFile(input, identification, SandboxUtils.fileKey(context,
                    mEncryptKey, identification), WPSSavePath, fileType, 0x0101, new
                    CallBack<Boolean>() {


                        @Override
                        public void onSuccess(Boolean response) {

                        }

                        @Override
                        public void onFail(String string) {

                        }
                    });
        }

    }

    public void encrypt(final String fileName, InputStream inputStream, final CallBack<String>
            callBack) {
        //1.生成fileEntity，并按规则创建目录
        FileEntity fileEntity = perpareFile(fileName, SandboxUtils.getFileType(fileName));
        //2.生成加密key
        String identification = SandboxUtils.randomString();
        //加密
        encryptCore(inputStream, identification, SandboxUtils.fileKey(context, mEncryptKey,
                identification), fileEntity, 0x0101, new CallBack<Boolean>() {
            @Override
            public void onSuccess(Boolean response) {
                if (response == true) {
                    callBack.onSuccess(fileName);
                } else {

                }
            }

            @Override
            public void onFail(String string) {
                callBack.onFail(string);
            }
        });
    }

    public void encryptCosKey(final String fileName, InputStream inputStream, final CallBack<String>
            callBack) {
//        FileEntity fileEntity = new FileEntity(file.getAbsolutePath(), file.getName(),
//                SandboxUtils.getFileType(file.getName()), mUserName);
        FileEntity fileEntity = perpareFile(fileName, SandboxUtils.getFileType(fileName));
        String identification = SandboxUtils.randomString();
        encryptCore(inputStream, identification, SandboxUtils.cosKey(identification),
                fileEntity, 0x1010, new CallBack<Boolean>() {
                    @Override
                    public void onSuccess(Boolean response) {
                        callBack.onSuccess(fileName);
                    }

                    @Override
                    public void onFail(String string) {
                        callBack.onFail(string);
                    }
                });
    }

    //下载解密cos文件/非加密文件，存储不加密数据
    public void cosSaveToSandbox(final String fileName, String sourcePath, final CallBack<String>
            callBack) {
        try {
            File file = new File(sourcePath);
            FileEntity fileEntity = perpareFile(fileName, SandboxUtils.getFileType(fileName));
//            String fileName = file.getName();
            if (isEncrypted(sourcePath)) {
                logger.debug(TAG, "cos:Save - 加密文件 解密保存" + sourcePath);
                new File(fileEntity.getFilePath()).createNewFile();
                OutputStream outputStream = new FileOutputStream(fileEntity.getFilePath());
                sandBoxProtocol.decrypt(file, outputStream, new CallBack<Boolean>() {
                    @Override
                    public void onSuccess(Boolean response) {
                        callBack.onSuccess(fileName);
                    }

                    @Override
                    public void onFail(String string) {
                        callBack.onFail(string);
                    }
                });

            } else {
                logger.debug(TAG, "cos:Save -没加密文件 直接保存 " + sourcePath);
                InputStream inputStream = new FileInputStream(file);
                SandboxUtils.copyFile(inputStream, fileEntity.getFilePath());
                callBack.onSuccess(fileName);
            }
        } catch (Exception e) {
//            e.printStackTrace();
            callBack.onFail(e.toString());
        }
    }


    /**
     * 1. 判断是否加密
     * 2.加密后 outputStream
     * 3.不加密   cos加密后  outputStream
     *
     * @param fileid
     * @param outputStream
     * @param callBack
     */
    public void cosUpload(String fileid, final OutputStream outputStream, final CallBack<Boolean>
            callBack) {
        try {
            final String sandboxpath = SandboxUtils.fileSavePath(mPath, fileid, mUserName);
            File file = new File(sandboxpath);
            if (isEncrypted(sandboxpath)) {
                logger.debug(TAG, "cos:Upload--加密文件 直接返回 流 " + sandboxpath);
                IOUtils.write(new FileInputStream(sandboxpath), outputStream);
                callBack.onSuccess(true);
            } else {
                logger.debug(TAG, "cos:Upload - 没加密文件 cos加密" + sandboxpath);
                final String tempFilePath = file.getParent() + File.separator + "costemp" + file
                        .getName().substring(file.getName().lastIndexOf("."));
                final File tempFile = new File(tempFilePath);
                if (!tempFile.exists()) {
                    tempFile.createNewFile();
                }
                logger.debug(TAG, "cos:Upload - 没加密文件  临时文件path ：" + tempFilePath);

                InputStream inputStream = new FileInputStream(sandboxpath);
                String identification = SandboxUtils.randomString();
                FileEntity fileEntity = new FileEntity(tempFilePath, tempFile.getName(),
                        SandboxUtils.getFileType(file.getName()));
                encryptCore(inputStream, identification, SandboxUtils.cosKey(identification),
                        fileEntity, 0x1010, new CallBack<Boolean>() {
                            @Override
                            public void onSuccess(Boolean response) {

                                try {
                                    IOUtils.write(new FileInputStream(tempFilePath), outputStream);
                                    //  删除temp
                                    tempFile.delete();
                                    logger.debug(TAG, "cos:Upload - 没加密文件  删除 临时文件 ：");


                                    callBack.onSuccess(true);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    //  删除temp
                                    tempFile.delete();
                                    logger.debug(TAG, "cos:Upload - 没加密文件  删除 临时文件 ：");
                                    callBack.onFail(e.toString());
                                }

                            }

                            @Override
                            public void onFail(String string) {
                                //  删除temp
                                tempFile.delete();
                                logger.debug(TAG, "cos:Upload - 没加密文件  删除 临时文件 ：");

                                callBack.onFail(string);
                            }
                        });

            }

        } catch (Exception e) {
            e.printStackTrace();
            callBack.onFail(e.toString());
        }
    }

    /**
     * 这个方法第一个参数为File和第一次参数为String的区别，file路径是全路径，String的路径是相对于sandbox相对路径
     *
     * @param file
     * @param inputStream
     * @return
     * @throws IOException
     */
    public void encryptFileKey(File file, InputStream inputStream, final CallBack<Boolean>
            callBack) {
        FileEntity fileEntity = new FileEntity(file.getAbsolutePath(), file.getName(),
                SandboxUtils.getFileType(file.getName()));
        String identification = SandboxUtils.randomString();
        encryptCore(inputStream, identification, SandboxUtils.fileKey(context,
                mEncryptKey, identification), fileEntity, 0x0101, new CallBack<Boolean>() {
            @Override
            public void onSuccess(Boolean response) {
                callBack.onSuccess(response);
            }

            @Override
            public void onFail(String string) {
                callBack.onFail(string);
            }
        });
    }


    /**
     * 如果 SandboxUtils.cosKey 对应 0x1010
     * SandboxUtils.fileKey 对应 0x0101
     *
     * @param inputStream
     * @param identification
     * @param Key
     * @param fileEntity
     * @param fileType
     * @return
     */
    private void encryptCore(final InputStream inputStream, final String identification, final
    String Key, final FileEntity fileEntity, final int fileType, final
                             CallBack<Boolean> callBack) {
        if (fileEntity != null) {

            if (isEncrypted(new File(fileEntity.getFilePath()))) {
                //不能两次加密
                callBack.onSuccess(true);
            } else {
                sandBoxProtocol.encryptSaveFile(identification, Key, fileEntity, inputStream,
                        fileType, new CallBack<Boolean>() {
                            @Override
                            public void onSuccess(Boolean response) {
                                callBack.onSuccess(response);

                            }

                            @Override
                            public void onFail(String string) {
                                callBack.onFail(string);

                            }
                        });
            }


        }
    }


    private FileEntity perpareFile(String fileName, FileType fileType) {
        String savePath = SandboxUtils.getSaveDir(mPath, mUserName);
        if (SandboxUtils.perpareDir(savePath)) {
            String saveFilePath = SandboxUtils.fileSavePath(mPath, fileName, mUserName);

            File saveFile = new File(saveFilePath);
            if (SandboxUtils.isFileExists(context, saveFilePath, saveFile)) {
                saveFile.delete();
            } else {
//                saveFile.getParentFile().mkdirs();
            }
            logger.debug(TAG, "加密:准备加密保存路径-> " + saveFilePath);
            return new FileEntity(saveFilePath, fileName, fileType);

        } else {
            logger.debug(TAG, "加密: 准备加密保存路径不存在 ! -> " + savePath);
            return null;
        }
    }


    //+++++++++++++++++++其他++++++++++++++++++++++++++
    public List<FileInfor> getFileListWithPath(String path) {
        List<FileInfor> list = new ArrayList<>();
        String parentPath = SandBoxCenter.getInstance().getUserPath();
        File rootDir = new File(parentPath, path);
        if (rootDir.exists()) {
            File[] currentFiles = rootDir.listFiles();
            SortByName sort = new SortByName();
            if (sort.hideFileNum(currentFiles) == currentFiles.length) {//如果目录下都是隐藏文件就返回
//                    Toast.makeText(this,"当前路径下没有文件", Toast.LENGTH_LONG).show();
                logger.debug(TAG, "获取文件夹列表：当前路径下没有文件");
            }
            currentFiles = sort.sort(currentFiles);

            for (File file : currentFiles) {
                FileInfor fileInfor = null;
                if (file.isFile()) {
                    fileInfor = new FileInfor("file", file.getName(), file.length(), file
                            .getAbsolutePath().substring(parentPath.length()));
                } else if (file.isDirectory()) {
                    fileInfor = new FileInfor("dir", file.getName(), 0, file.getAbsolutePath()
                            .substring(parentPath.length()));
                }
                list.add(fileInfor);
            }
        }
        return list;


    }


    public boolean MKdirWithPath(String path, String name) {
        File rootDir = new File(SandBoxCenter.getInstance().getUserPath() + path, name);
        if (rootDir.exists()) {
            return true;
        }
        return rootDir.mkdirs();
    }

    public boolean RMWithPath(String path) {
        File rootDir = new File(SandBoxCenter.getInstance().getUserPath(), path);
        if (rootDir.exists()) {
            return rootDir.delete();
        }
        return true;
    }


    public FileOutputStream getFileWithPath(String path, String name) {
        try {
            File file = new File(SandBoxCenter.getInstance().getUserPath() + path, name);
            SandboxUtils.perpareDir(file.getParent());
            file.createNewFile();
            return new FileOutputStream(file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    public FileOutputStream getInnerOutStream(String path) {

        try {
            File file = new File(SandBoxCenter.getInstance().getUserPath(), path);
            SandboxUtils.perpareDir(file.getParent());
            logger.debug(TAG, "目标地址：getInnerOutStream " + file.getAbsolutePath());
            if (SandboxUtils.isFileExists(context, file.getAbsolutePath(), new File(path))) {
                return new FileOutputStream(file.getAbsolutePath());
            } else {
                if (file.createNewFile()) {
                    return new FileOutputStream(file.getAbsolutePath());
                } else {
                    logger.debug(TAG, "目标地址：getInnerOutStream  file.createNewFile失败");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    public boolean isSecurityFileData(byte[] fileHead) {
        return sandBoxProtocol.csandbox_isSecurityFileData(fileHead);
    }

    //先解密，加密，删除temp文件
    public void cosSave(final File rootDir) {
        try {
            final String tempFilePath = rootDir.getParent() + File.separator + rootDir.getName()
                    + "" +
                    ".temp";
            final File tempFile = new File(tempFilePath);
            if (!tempFile.exists()) {
                tempFile.createNewFile();
            }
            final FileOutputStream outputStream = new FileOutputStream(tempFilePath);
            sandBoxProtocol.decrypt(rootDir, outputStream, new CallBack<Boolean>() {
                @Override
                public void onSuccess(Boolean response) {
                    try {
                        logger.debug(TAG, "解密：cosFile 解密完成");
                        FileInputStream inputStream = new FileInputStream(tempFilePath);
                        FileEntity fileEntity = new FileEntity(rootDir.getAbsolutePath(), rootDir
                                .getName
                                        (), SandboxUtils.getFileType(rootDir.getName()));
                        String identification = SandboxUtils.randomString();
                        encryptCore(inputStream, identification, SandboxUtils.fileKey(context,
                                mEncryptKey, identification), fileEntity, 0x1010, new
                                CallBack<Boolean>() {


                                    @Override
                                    public void onSuccess(Boolean response) {
                                        logger.debug(TAG, "解密：fileKey 加密完成");
                                        tempFile.delete();
                                    }

                                    @Override
                                    public void onFail(String string) {
                                        tempFile.delete();
                                    }
                                });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFail(String string) {
                    tempFile.delete();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * todo 文件写入temp,temp写入文件 ，文件上传，删除文件
     * <p>
     * public void cosUpload(final File file) {
     * isEncrypted(file, new CallBack<Boolean>() {
     *
     * @Override public void onSuccess(Boolean isEncrypted) {
     * try {
     * FileInputStream inputStream = null;
     * String tempFilePath = file.getParent() + File.separator + file.getName()
     * + "" +
     * ".temp";
     * File tempFile = new File(tempFilePath);
     * //解密
     * if (!tempFile.exists()) {
     * tempFile.createNewFile();
     * }
     * if (isEncrypted) {
     * FileOutputStream outputStream = new FileOutputStream(tempFilePath);
     * int result = sandBoxProtocol.decrypt(file, isEncrypted, outputStream);
     * if (result == 0) {
     * inputStream = new FileInputStream(tempFile);
     * }
     * if (encryptCosKey(file, inputStream)) {
     * //cos加密
     * <p>
     * //TODO 上传file
     * }
     * } else {
     * inputStream = new FileInputStream(file);
     * if (encryptCosKey(tempFile, inputStream)) {
     * //cos加密
     * <p>
     * //TODO 上传file
     * }
     * }
     * } catch (IOException e) {
     * e.printStackTrace();
     * }
     * }
     * @Override public void onFail(String string) {
     * <p>
     * }
     * });
     * <p>
     * <p>
     * }
     */
    public boolean delete(String savePath) {
        String saveFilePath = SandboxUtils.fileSavePath(mPath, savePath, mUserName);
        File file = new File(saveFilePath);
        if (file.exists()) {
            file.delete();
            return true;
        } else {
            logger.debug(TAG, "Delete " + saveFilePath + " 不存在！");
            return false;
        }
    }


    public void setLogListener(LogListener logListener) {
        logger.registerListener(logListener);
    }


    public boolean isFileExists(String path) {
        File file = new File(SandBoxCenter.getInstance().getUserPath(), path);
        SandboxUtils.perpareDir(file.getParent());
        logger.debug(TAG, "目标地址：getInnerOutStream " + file.getAbsolutePath());
        if (SandboxUtils.isFileExists(context, file.getAbsolutePath(), new File(path))) {
            return true;
        } else {
            return false;
        }
    }

    public byte[] decryptSession(byte[] content) {
        return sandBoxProtocol.decryptSession(mEncryptKey, content);
    }

    public byte[] encryptSession(byte[] content) {
        return sandBoxProtocol.encryptSession(mEncryptKey, content);
    }


}

