package com.cmft.android.sandbox.crypter.core;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.cmft.android.sandbox.crypter.R;

import static com.cmft.android.sandbox.crypter.core.Constant.WPS_DOWNLOAD_SITE;

public class UpdateActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);


        findViewById(R.id.negtive).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UpdateActivity.this.finish();
            }
        });

        findViewById(R.id.positive).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction("android.intent.action.VIEW");
                Uri content_url = Uri.parse(WPS_DOWNLOAD_SITE);
                intent.setData(content_url);
                startActivity(intent);
                UpdateActivity.this.finish();
            }
        });
    }
}