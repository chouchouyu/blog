package com.cmft.android.sandbox.crypter.utils;

import android.text.TextUtils;
import android.util.Log;

import com.cmft.android.sandbox.crypter.core.Constant;


/**
 * Default logger
 *
 * @author zhilong <a href="mailto:zhilong.liu@aliyun.com">Contact me.</a>
 * @version 1.0
 * @since 2015-12-08 21:44:10
 */
public class DefaultLogger implements ILogger {

    private static boolean isShowLog = false;
    private static boolean isShowStackTrace = false;
    private static boolean isMonitorMode = false;
    private static int LOG_DEUGE = 1;
    private static int LOG_WARE = 2;
    private static int LOG_ERROR = 3;
    private static int LOG_INF = 4;


    private String defaultTag = Constant.TAG;

    @Override
    public void showLog(boolean showLog) {
        isShowLog = showLog;
    }

    @Override
    public void showStackTrace(boolean showStackTrace) {
        isShowStackTrace = showStackTrace;
    }

    public void showMonitor(boolean showMonitor) {
        isMonitorMode = showMonitor;
    }

    public DefaultLogger() {
    }

    public DefaultLogger(String defaultTag) {
        this.defaultTag = defaultTag;
    }

    @Override
    public void debug(String tag, String message) {
        StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
        if (isShowLog) {
            log(tag, LOG_DEUGE, message, stackTraceElement);
        }

        for (LogListener listener : mListeners) {
            listener.onLog(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, message + getExtInfo
                    (stackTraceElement));
        }
    }

    @Override
    public void info(String tag, String message) {
        StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
        if (isShowLog) {
            log(tag, LOG_INF, message, stackTraceElement);

        }
        for (LogListener listener : mListeners) {
            listener.onLog(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, message + getExtInfo
                    (stackTraceElement));
        }
    }

    @Override
    public void warning(String tag, String message) {
        StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
        if (isShowLog) {
            log(tag, LOG_WARE, message, stackTraceElement);

        }
        for (LogListener listener : mListeners) {
            listener.onLog(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, message + getExtInfo
                    (stackTraceElement));
        }
    }

    @Override
    public void error(String tag, String message) {
        StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
        if (isShowLog) {
            log(tag, LOG_ERROR, message, stackTraceElement);

        }
        for (LogListener listener : mListeners) {
            listener.onLog(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, message + getExtInfo
                    (stackTraceElement));
        }
    }

    @Override
    public void monitor(String message) {
        StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];

        if (isShowLog && isMonitorMode()) {
            log(defaultTag + "::monitor", LOG_DEUGE, message, stackTraceElement);
        }

        for (LogListener listener : mListeners) {
            listener.onLog(defaultTag + "::monitor", message + getExtInfo(stackTraceElement));
        }
    }

    @Override
    public boolean isMonitorMode() {
        return isMonitorMode;
    }

    @Override
    public String getDefaultTag() {
        return defaultTag;
    }

    @Override
    public void registerListener(LogListener listener) {
        mListeners.add(listener);
    }


    public static String getExtInfo(StackTraceElement stackTraceElement) {

        String separator = " & ";
        StringBuilder sb = new StringBuilder("[");

        if (isShowStackTrace) {
            String threadName = Thread.currentThread().getName();
            String fileName = stackTraceElement.getFileName();
            String className = stackTraceElement.getClassName();
            String methodName = stackTraceElement.getMethodName();
            long threadID = Thread.currentThread().getId();
            int lineNumber = stackTraceElement.getLineNumber();

            sb.append("ThreadId=").append(threadID).append(separator);
            sb.append("ThreadName=").append(threadName).append(separator);
            sb.append("FileName=").append(fileName).append(separator);
            sb.append("ClassName=").append(className).append(separator);
            sb.append("MethodName=").append(methodName).append(separator);
            sb.append("LineNumber=").append(lineNumber);
        }

        sb.append(" ] ");
        return sb.toString();
    }


    private void log(String tag, int type, String msg, StackTraceElement stackTraceElement) {
        //信息太长,分段打印
        //因为String的length是字符数量不是字节数量所以为了防止中文字符过多，
        //  把4*1024的MAX字节打印长度改为2001字符数
        int max_str_length = 2001 - tag.length();
        //大于4000时
        while (msg.length() > max_str_length) {

            if (type == LOG_WARE) {
                Log.w(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, msg + getExtInfo
                        (stackTraceElement));
            } else if (type == LOG_ERROR) {
                Log.e(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, msg + getExtInfo
                        (stackTraceElement));
            } else if (type == LOG_INF) {
                Log.i(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, msg + getExtInfo
                        (stackTraceElement));
            } else {
                Log.d(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, msg + getExtInfo
                        (stackTraceElement));
            }


            msg = msg.substring(max_str_length);
        }
        //剩余部分
        if (type == LOG_WARE) {
            Log.w(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, msg + getExtInfo
                    (stackTraceElement));
        } else if (type == LOG_ERROR) {
            Log.e(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, msg + getExtInfo
                    (stackTraceElement));
        } else if (type == LOG_INF) {
            Log.i(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, msg + getExtInfo
                    (stackTraceElement));
        } else {
            Log.d(TextUtils.isEmpty(tag) ? getDefaultTag() : tag, msg + getExtInfo
                    (stackTraceElement));
        }
    }
}
