package com.cmft.android.sandbox.crypter.model;

/**
 * 沙箱file描述类，用做和c层传递
 */
public class FileEntity {

    //fileid目标存沙箱绝对路径地址
    private String filePath;

    //沙箱相对路径
    private String fileid;

    //doc,ppt。。。
    private FileType fileType;

    public FileEntity(String filePath, String fileid, FileType fileType) {
        this.filePath = filePath;
        this.fileid = fileid;
        this.fileType = fileType;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getfileid() {
        return fileid;
    }

    public void setfileid(String fileid) {
        this.fileid = fileid;
    }

    public FileType getFileType() {
        return fileType;
    }

    public void setFileType(FileType fileType) {
        this.fileType = fileType;
    }


    @Override
    public String toString() {
        return "FileEntity{" +
                ", filePath='" + filePath + '\'' +
                ", fileid='" + fileid + '\'' +
                ", fileType=" + fileType +
                '}';
    }
}
