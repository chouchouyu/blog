/**
 *	 文件名：AutoTestParam.java
 * 	创建者:fanguangcheng
 * 	创建时间:2013.8.5
 * 	作用：用来标记某次解密文件是否成功
 */
package com.cmft.android.sandbox.crypter.wps.test;

public class AutoTestParam 
{
	public static boolean IsOpenCorrect = false;		//	测试能否正常打开解密
//	public static boolean IsSaveCorrect = false;		//  测试能否正常保存加密
}
