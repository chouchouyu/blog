package com.cmft.android.sandbox.crypter.webService;

import android.text.TextUtils;

import com.cmft.android.sandbox.crypter.CallBack;
import com.cmft.android.sandbox.crypter.core.Constant;
import com.cmft.android.sandbox.crypter.utils.SortByName;
import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.android.sandbox.crypter.core.SandBoxCenter;
import com.yanzhenjie.andserver.annotation.GetMapping;
import com.yanzhenjie.andserver.annotation.PostMapping;
import com.yanzhenjie.andserver.annotation.QueryParam;
import com.yanzhenjie.andserver.annotation.RequestMapping;
import com.yanzhenjie.andserver.annotation.RequestParam;
import com.yanzhenjie.andserver.annotation.RestController;
import com.yanzhenjie.andserver.framework.body.JsonBody;
import com.yanzhenjie.andserver.framework.body.StringBody;
import com.yanzhenjie.andserver.http.HttpResponse;
import com.yanzhenjie.andserver.http.ResponseBody;
import com.yanzhenjie.andserver.http.multipart.MultipartFile;
import com.yanzhenjie.andserver.http.multipart.StandardMultipartFile;
import com.yanzhenjie.andserver.util.MediaType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import static com.cmft.android.sandbox.crypter.wps.util.EncryptClass.BUFFER_SIZE;


@RestController
@RequestMapping(path = "/sandbox")
public class SanBoxController {


    @GetMapping(path = "/gettoken", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    String getToken() {
        return formatResponse(true, SandBox.getInstance().getToken(), " token获取成功");
    }


    @PostMapping(path = "/downloadCosFile", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    String downloadCosFile(@RequestParam(name = "token") String token,
                           @RequestParam(name = "savepath") String savepath,
                           @RequestParam(name = "canOverWrite") boolean canOverWrite,
                           @RequestParam(name = "url") String url) {
        if (!tokenVerify(token)) {
            return formatResponse(false, "", " token not verify");
        }

        String rootpath = SandBoxCenter.getInstance().getUserPath();
        File rootDir = new File(rootpath, savepath);
        if (rootDir.exists()) {
            if (canOverWrite) {
                sendRequestWithHttpURLConnection(savepath, url);
            } else {
                return formatResponse(false, "", "文件已存在，[canOverWrite] 为false");
            }
        } else {
            sendRequestWithHttpURLConnection(savepath, url);
        }


        return formatResponse(true, "已经下载", "success");

    }

    private void sendRequestWithHttpURLConnection(final String savepath, final String urlSite) {
        new Thread(new Runnable() {//开启xian
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL(urlSite);//新建URL
                    connection = (HttpURLConnection) url.openConnection();//发起网络请求
                    connection.setRequestMethod("GET");//请求方式
                    connection.setConnectTimeout(8000);//连接最大时间
                    connection.setReadTimeout(8000);//读取最大时间
                    InputStream in = connection.getInputStream();


                    String rootpath = SandBoxCenter.getInstance().getUserPath();
                    final File rootDir = new File(rootpath, savepath);


                    if (saveFile(in, rootDir.getAbsolutePath())) {
                        boolean isFileEncrypted = SandBoxCenter.getInstance().isEncrypted(rootDir);
                        if (isFileEncrypted) {
                            //如果是加密文件走 cos解密，fileKey加密
                            SandBoxCenter.getInstance().cosSave(rootDir);
                        }
                    }

                      /*
                    SandBoxCenter.getInstance().encrypt(fileName, in);
                    */
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        }).start();
    }

    private boolean saveFile(InputStream in, String absolutePath) throws IOException {
        FileOutputStream fos = new FileOutputStream(absolutePath);
        byte[] b = new byte[BUFFER_SIZE];
        int length;
        while ((length = in.read(b)) > 0) {
            fos.write(b, 0, length);
        }
        in.close();
        fos.close();

        return true;
    }


    /**
     * 获取文件夹列表
     *
     * @param token
     * @param dir
     * @return
     */
    //http://192.168.232.2:8016/sandbox/ls?token=tokene&path=/
    @GetMapping(path = "/ls", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    String ls(@QueryParam("token") String token,
              @QueryParam("path") String dir) {

        if (!tokenVerify(token)) {
            return formatResponse(false, "", " token not verify");
        }

        String rootpath = SandBoxCenter.getInstance().getUserPath();
        File rootDir = new File(rootpath, dir);
        if (rootDir.exists()) {
            File[] currentFiles = rootDir.listFiles();
            SortByName sort = new SortByName();
            if (sort.hideFileNum(currentFiles) == currentFiles.length) {//如果目录下都是隐藏文件就返回
//                    Toast.makeText(this,"当前路径下没有文件", Toast.LENGTH_LONG).show();
                return formatResponse(false, "当前路径下没有文件", "failed");
            }
            currentFiles = sort.sort(currentFiles);
            try {

                JSONArray jsonArray = new JSONArray();
                for (File file : currentFiles) {
                    JSONObject jsonObject = new JSONObject();
                    if (file.isFile()) {
                        jsonObject.put("type", "file");
                        jsonObject.put("name", file.getName());
                        jsonObject.put("size", file.length());
                        jsonObject.put("path", file.getAbsolutePath().substring(rootpath.length()));
                    } else if (file.isDirectory()) {
                        jsonObject.put("type", "dir");
                        jsonObject.put("name", file.getName());
                        jsonObject.put("path", file.getAbsolutePath().substring(rootpath.length()));
                    }
                    jsonArray.put(jsonObject);
                }
                return formatResponse(true, jsonArray.toString(), "success");
            } catch (JSONException e) {
                e.printStackTrace();
                return formatResponse(false, "", e.getMessage());
            }
        }
        return formatResponse(true, dir + " not exist", "success");

    }


    /**
     * 创建文件夹
     *
     * @param token
     * @param name
     * @param dir
     * @return
     */
    //http://192.168.232.2:8016/sandbox/mkdir?token=tokene&path=/&name=wsm
    @GetMapping(path = "/mkdir", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    String mkdir(@QueryParam("token") String token,
                 @QueryParam("name") String name,
                 @QueryParam("path") String dir) {

        if (!tokenVerify(token)) {
            return formatResponse(false, "", " token not verify");
        }

        File rootDir = new File(SandBoxCenter.getInstance().getUserPath() + File.separator + dir,
                name);
        if (rootDir.exists()) {
            return formatResponse(true, "dir already exists", "success");
        } else {
            rootDir.mkdirs();
            return formatResponse(true, "mkdirs " + dir + "/" + name + " successed", "success");
        }
    }


    /**
     * 删除文件，文件夹
     *
     * @param token
     * @param dir
     * @return
     */
    //http://192.168.232.2:8016/sandbox/rm?token=tokene&path=/wsm
    @GetMapping(path = "/rm", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    String rm(@QueryParam("token") String token,
              @QueryParam("path") String dir) {

        if (!tokenVerify(token)) {
            return formatResponse(false, "", " token not verify");
        }

        File rootDir = new File(SandBoxCenter.getInstance().getUserPath(), dir);
        if (rootDir.exists()) {
            try {
                if (rootDir.delete()) {
                    return formatResponse(true, dir + " is deleted", "success");
                }
            } catch (SecurityException e) {
                e.printStackTrace();
                return formatResponse(false, "", e.getMessage());
            }
        }
        return formatResponse(false, "", dir + " not exist");

    }


    /**
     * 重命名
     *
     * @param token
     * @param rename
     * @param dir
     * @return
     */
    //http://192.168.232.2:8016/sandbox/rename?token=tokene&path=/2019-07-08&rename=god
    @GetMapping(path = "/rename", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    String rename(@QueryParam("token") String token,
                  @QueryParam("rename") String rename,
                  @QueryParam("name") String name,
                  @QueryParam(name = "path", required = false) String dir) {

        if (!tokenVerify(token)) {
            return formatResponse(false, "", " token not verify");
        }

        File rootDir = new File(SandBoxCenter.getInstance().getUserPath() + File.separator + dir,
                name);

        try {
            if (!rootDir.exists()) {
                return formatResponse(false, "", dir + "/" + name + " not exist");
            }
            if (rootDir.renameTo(new File(SandBoxCenter.getInstance().getUserPath() + File
                    .separator + dir, rename))) {
                return formatResponse(true, dir + "/" + name + " rename success", "success");
            } else {
                return formatResponse(false, "", dir + "/" + name + " rename failed");
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
            return formatResponse(false, "", e.getMessage());
        }
    }

    /**
     * 查看文件内容
     *
     * @param response
     */
    //http://192.168.232.2:8016/sandbox/write?token=tokene&canOverWriter=true&filePath=test.doc
    ///sdcard/Download/wsm.txt
    //http://192.168.232.2:8016/sandbox/read/wsm.txt
    @GetMapping(path = "/readfile")
    void read(@QueryParam("token") String token,
              @QueryParam("name") String name,
              @QueryParam("path") String dir,
              HttpResponse response) {

        if (!tokenVerify(token)) {
            SandBoxCenter.logger.debug(Constant.TAG, "SandboxController:" + formatResponse(false,
                    "", " token not verify"));
        }
        File file = new File(SandBoxCenter.getInstance().getUserPath() + File.separator + dir,
                name);
        SandBoxFileBody sandBoxFileBody = null;
        if (file.exists()) {
            sandBoxFileBody = new SandBoxFileBody(file);
        } else {

            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("code", 201);
                jsonObject.put("message", "文件不存在");
                jsonObject.put("result", "");
                response.setBody(new JsonBody(jsonObject.toString()));
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        ResponseBody responseBody = sandBoxFileBody;
        response.setBody(responseBody);
    }


    @PostMapping(path = "/writefile", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    void saveData(@RequestParam(name = "token") String token,
                  @RequestParam(name = "canOverWriter") boolean canOverWriter,
                  @RequestParam(name = "path") String dir,
                  @RequestParam(name = "name") String fileName,
                  @RequestParam(name = "file") MultipartFile file, HttpResponse response) {

        if (!tokenVerify(token)) {
            response.setBody(new StringBody(formatResponse(false, "", " token not verify")));
        }

        try {
            if (file.getBytes().length == 0) {
                response.setBody(new StringBody(formatResponse(false, "", " param [file] is " +
                        "empty")));
            }

            File tagetFile = new File(SandBoxCenter.getInstance().getUserPath() + File.separator
                    + dir, fileName);

            if (tagetFile.exists()) {
                if (canOverWriter) {
                    tagetFile.delete();
                    saveFile(file, tagetFile, response);
                } else {
                    response.setBody(new StringBody(formatResponse(false, "", dir + "/" +
                            fileName + " already exist ,and " +
                            "param [canOverWriter] is :" + canOverWriter)));
                }
            } else {
                File parentFile = new File(tagetFile.getParent());
                if (!parentFile.exists()) {
                    parentFile.mkdirs();
                }
                tagetFile.createNewFile();
                saveFile(file, tagetFile, response);
            }


        } catch (Exception e) {
            e.printStackTrace();
            response.setBody(new StringBody(formatResponse(false, "", e.toString())));
        }
    }

    private void saveFile(MultipartFile file, final File localFile, final HttpResponse response)
            throws
            IOException {
//        File localFile = SandboxUtils.createRandomFile(SandBoxCenter.getInstance().getUserPath
// (), file);
        final String rootpath = SandBoxCenter.getInstance().getUserPath();
        InputStream inputStream = ((StandardMultipartFile) file).getFileItem().getInputStream();
        SandBoxCenter.getInstance().encryptFileKey(localFile, inputStream, new CallBack<Boolean>() {


            @Override
            public void onSuccess(Boolean result) {
                if (result) {
                    response.setBody(new StringBody(formatResponse(true, localFile.getAbsolutePath()
                            .substring(rootpath.length())
                            + " saved ", "success")));
                } else {
                    response.setBody(new StringBody(formatResponse(false, "", localFile
                            .getAbsolutePath()
                            .substring
                                    (rootpath
                                            .length()) + " saved failed when encrypt ")));
                }
            }

            @Override
            public void onFail(String string) {
                response.setBody(new StringBody(formatResponse(false, "", string)));
            }
        });

    }


    /**
     * 创建⽂文件/更新⽂文件
     *
     * @param token
     * @param openMode
     * @param dir
     * @return
     */
    ///sandbox/wps?token=tokene&openMode=ReadOnly&filePath=test.doc
    ///sandbox/wps?token=tokene&openMode=editMode&filePath=test.doc
    @GetMapping(path = "/openwps", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    void writeFile(@QueryParam("token") String token,
                   @QueryParam("editenable") boolean openMode,
                   @QueryParam("path") String dir,
                   @QueryParam(name = "savePath", required = false) String savePath) {

        if (!tokenVerify(token)) {
            SandBoxCenter.logger.debug(Constant.TAG, "SandboxController:" + formatResponse(false,
                    "", " token not verify"));
        }

        File rootDir = new File(dir);

        if (rootDir.isDirectory()) {
            SandBoxCenter.logger.debug(Constant.TAG, "SandboxController:" + formatResponse(false,
                    "", dir + " should be a File,not directory"));
        }

        if (openMode) {
            if (TextUtils.isEmpty(savePath)) {
                SandBoxCenter.logger.debug(Constant.TAG, "SandboxController:" + formatResponse
                        (false, "", " editMode need indentify [savePath] param "));
            } else {
                SandBox.getInstance().editWithWPS(dir, savePath);
            }
        } else {
            SandBox.getInstance().openWithWPS(dir);
        }
    }


    //{"code":true,"body":null,"message":"数据上报成功"}
    private String formatResponse(boolean staue, String body, String message) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("code", staue);
            jsonObject.put("body", body);
            jsonObject.put("message", message);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonObject.toString();
    }


    private boolean tokenVerify(String token) {
        String tok = SandBoxCenter.getInstance().getToken();
        SandBoxCenter.logger.debug(Constant.TAG, "SandboxController:请求token" + token);
        SandBoxCenter.logger.debug(Constant.TAG, "SandboxController:getToken" + tok);
        return TextUtils.equals(token, tok);
    }
}
