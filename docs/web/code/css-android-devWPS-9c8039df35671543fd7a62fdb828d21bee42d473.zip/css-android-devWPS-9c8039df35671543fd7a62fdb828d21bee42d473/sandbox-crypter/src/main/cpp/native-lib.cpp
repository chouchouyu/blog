#include <jni.h>
#include <string>
#include <android/log.h>
#include "decry_stream.h"
#include "encry_stream.h"
#include "encryption.h"

#if 1
#define TAG "sandbox:::"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL, TAG ,__VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG ,__VA_ARGS__)
#else
#define LOGI(...)
#define LOGD(...)
#define LOGE(...)
#define LOGF(...)
#define LOGW(...)
#endif

using namespace css;

/**
 * int值转为 file_type
 * @param fileType_
 * @return
 */
FileType getFileType(jint fileType_) {
    FileType type;
    switch (fileType_) {
        case 0x00:
            type = file_type_unknow;
            break;
        case 0x01:
            type = file_type_doc;
            break;
        case 0x02:
            type = file_type_docx;
            break;
        case 0x03:
            type = file_type_wps;
            break;
        case 0x04:
            type = file_type_txt;
            break;
        case 0x05:
            type = file_type_xls;
            break;
        case 0x06:
            type = file_type_xlsx;
            break;
        case 0x07:
            type = file_type_ppt;
            break;
        case 0x08:
            type = file_type_pptx;
            break;
        case 0x09:
            type = file_type_pdf;
            break;
        default:
            type = file_type_unknow;
            break;
    }
    return type;
}

extern "C"
JNIEXPORT jlong JNICALL
Java_com_cmft_android_sandbox_crypter_core_SandBoxProtocol_csandbox_1decryptCreate(JNIEnv *env,
                                                                                   jobject instance,
                                                                                   jstring filePath_,
                                                                                   jobject fileContent) {

    const char *encryptedFilePath = env->GetStringUTFChars(filePath_, 0);

    DecryStream *decryStream = new DecryStream(FileType::file_type_unknow);

    if (!decryStream) {
        LOGE("Decrypt Create error.");
        env->ReleaseStringUTFChars(filePath_, encryptedFilePath);
        return 0;
    }

    int MaxOpenCount = 0;
    bool is_open = false;

    decryStream->Open(encryptedFilePath, READ_SIGN);

    if (!decryStream->IsOpen() || decryStream->IsEnd()) {
        std::string str_error =
                "Decrypt Open File error, FileName[" + std::string(encryptedFilePath) + "]";
        LOGE("[%s][%d][%s]", str_error.c_str(), decryStream->GetError(), strerror(decryStream->GetError()));
        env->ReleaseStringUTFChars(filePath_, encryptedFilePath);
        decryStream->Close();
        delete decryStream;
        decryStream = NULL;
        return 0;
    }


    jstring fileId = env->NewStringUTF(decryStream->GetFileID().c_str());

    jclass jcls = env->GetObjectClass(fileContent);

    jfieldID jbuffrLength = env->GetFieldID(jcls, "buffrLength", "I");
    jfieldID jfileype = env->GetFieldID(jcls, "fileype", "I");
    jfieldID jkey = env->GetFieldID(jcls, "key", "Ljava/lang/String;");

    env->SetIntField(fileContent, jbuffrLength, decryStream->PlainLength());
    env->SetIntField(fileContent, jfileype, decryStream->GetKeyType());
    env->SetObjectField(fileContent, jkey, fileId);

    env->ReleaseStringUTFChars(filePath_, encryptedFilePath);

    return reinterpret_cast<jlong>(decryStream);

}

extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_cmft_android_sandbox_crypter_core_SandBoxProtocol_csandbox_1decrypt(JNIEnv *env,
                                                                             jobject instance,
                                                                             jlong object,
                                                                             jstring filePath_,
                                                                             jstring mKey_) {

    DecryStream *decryStream = reinterpret_cast<DecryStream *>(object);

    const char *filePath = env->GetStringUTFChars(filePath_, 0);
    const char *mKey = env->GetStringUTFChars(mKey_, 0);
    jbyteArray array;

    if (decryStream && !decryStream->IsEnd()) {

        decryStream->SetFilekey(mKey);

        std::vector<unsigned char> decry_buff;
        int res = decryStream->ReadOneSegment(decry_buff);

        if (res == CSS_SUCCEEDED) {
            array = env->NewByteArray(decry_buff.size());
            env->SetByteArrayRegion(array, 0, decry_buff.size(), (jbyte *) &decry_buff[0]);
        } else if(res == CSS_ERROR_UNKNOW) {
            LOGE("Decrypt data error.");
            array = env->NewByteArray(0);
        }else{
            array = env->NewByteArray(0);
        }


    } else {
        array = env->NewByteArray(0);
    }

    env->ReleaseStringUTFChars(filePath_, filePath);
    env->ReleaseStringUTFChars(mKey_, mKey);
    return array;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_cmft_android_sandbox_crypter_core_SandBoxProtocol_csandbox_1decryptClose(JNIEnv *env,
                                                                                  jobject instance,
                                                                                  jlong object) {

    LOGD("解密完成");

    DecryStream *decryStream = reinterpret_cast<DecryStream *>(object);

    if (decryStream) {
        decryStream->Close();
        delete decryStream;
        decryStream = NULL;
    }

}

extern "C"
JNIEXPORT jlong JNICALL
Java_com_cmft_android_sandbox_crypter_core_SandBoxProtocol_csandbox_1encryptCreate(JNIEnv *env,
                                                                                   jobject instance,
                                                                                   jstring filePath_,
                                                                                   jstring fileId_,
                                                                                   jstring key_,
                                                                                   jint fileType,
                                                                                   jint keyType,
                                                                                   jboolean isSecurity) {

    const char *filePath = env->GetStringUTFChars(filePath_, 0);
    const char *fileId = env->GetStringUTFChars(fileId_, 0);
    const char *key = env->GetStringUTFChars(key_, 0);

    FileType type = getFileType(fileType);
    EncryStream *encryStream = new EncryStream(type);

    if (!encryStream) {
        LOGE("Encrypt create error.");
        env->ReleaseStringUTFChars(filePath_, filePath);
        env->ReleaseStringUTFChars(fileId_, fileId);
        env->ReleaseStringUTFChars(key_, key);
        return 0;
    }

    if (isSecurity) {
        encryStream->Open(filePath, WRITE_SIGN, type);
    } else {
        encryStream->OpenNormal(filePath, WRITE_SIGN, type);
    }

    if (!encryStream->IsOpen()) {
        std::string str_error = "Encrypt Open File error, FileName[" + std::string(filePath) + "]";
        LOGE("%s", str_error.c_str());
        env->ReleaseStringUTFChars(filePath_, filePath);
        env->ReleaseStringUTFChars(fileId_, fileId);
        env->ReleaseStringUTFChars(key_, key);

        encryStream->Close();
        delete encryStream;
        encryStream = nullptr;
        return 0;
    }

    encryStream->SetFileID(fileId);
    encryStream->SetFilekey(key);
    encryStream->setKeyType(keyType);

    env->ReleaseStringUTFChars(filePath_, filePath);
    env->ReleaseStringUTFChars(fileId_, fileId);
    env->ReleaseStringUTFChars(key_, key);

    return reinterpret_cast<jlong>(encryStream);
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_cmft_android_sandbox_crypter_core_SandBoxProtocol_csandbox_1encrypt(JNIEnv *env,
                                                                             jobject instance,
                                                                             jlong object,
                                                                             jstring randomString_,
                                                                             jstring path_,
                                                                             jstring key_,
                                                                             jbyteArray content_,
                                                                             jint fileType,
                                                                             jboolean security,
                                                                             jlong bufferSize,
                                                                             jint type) {

    EncryStream *encryStream = reinterpret_cast<EncryStream *>(object);

    if (!encryStream) {
        LOGE("Encrypt data error.");
        return JNI_FALSE;
    }

    const char *randomString = env->GetStringUTFChars(randomString_, 0);
    const char *filePath = env->GetStringUTFChars(path_, 0);
    const char *key = env->GetStringUTFChars(key_, 0);
    jbyte *content = env->GetByteArrayElements(content_, NULL);

    char *cContent = reinterpret_cast<char *>(content);

    int result = encryStream->Write(cContent, static_cast<uint64_t>(bufferSize));

    if (result != CSS_SUCCEEDED) {
        LOGE("Encrypt data error.");
    }

    env->ReleaseStringUTFChars(path_, filePath);
    env->ReleaseStringUTFChars(key_, key);
    env->ReleaseByteArrayElements(content_, content, 0);

    return static_cast<jboolean>(result == CSS_SUCCEEDED);

}

extern "C"
JNIEXPORT void JNICALL
Java_com_cmft_android_sandbox_crypter_core_SandBoxProtocol_csandbox_1encryptClose(JNIEnv *env,
                                                                                  jobject instance,
                                                                                  jlong object) {

    LOGD("加密完成");
    EncryStream *encryStream = reinterpret_cast<EncryStream *>(object);

    if (encryStream) {
        encryStream->Close();
        delete encryStream;
        encryStream = NULL;
    }

}

/**
 * 判断文件是否是加密文件
 */
extern "C"
JNIEXPORT jboolean JNICALL
Java_com_cmft_android_sandbox_crypter_core_SandBoxProtocol_csandbox_1isSecurityFile(JNIEnv *env,
                                                                                    jobject instance,
                                                                                    jstring filePath_) {

    const char *filePath = env->GetStringUTFChars(filePath_, 0);

    std::string path(filePath);
    DecryStream decryStream(file_type_unknow);
    env->ReleaseStringUTFChars(filePath_, filePath);

    return static_cast<jboolean>(decryStream.IsSecurityFile(path));
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_cmft_android_sandbox_crypter_core_SandBoxProtocol_csandbox_1isSecurityFileData(JNIEnv *env,
                                                                                        jobject instance,
                                                                                        jbyteArray fileHead_) {
    jbyte *fileHead = env->GetByteArrayElements(fileHead_, NULL);
    DecryStream decryStream(file_type_unknow);
    const char *cContent = reinterpret_cast<const char *>(fileHead_);
    uint64_t buf_len = static_cast<uint64_t>(env->GetArrayLength(fileHead_));
    env->ReleaseByteArrayElements(fileHead_, fileHead, 0);
    return static_cast<jboolean>(decryStream.IsSecurityFileData(const_cast<char *>(cContent),
                                                                buf_len));
}extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_cmft_android_sandbox_crypter_core_SandBoxProtocol_csandbox_1decryptSession(JNIEnv *env,
                                                                                    jobject thiz,
                                                                                    jstring key,
                                                                                    jbyteArray input) {
    jbyte* jbuffer = env->GetByteArrayElements(input, NULL);
    const char* decode_key = env->GetStringUTFChars(key, 0);

    unsigned char* buffer = reinterpret_cast<unsigned char *>(jbuffer);
    int buf_len = env->GetArrayLength(input);
    std::vector<unsigned char> input_vector(buffer, buffer + buf_len);
    std::vector<unsigned char> output_vector;

    css::Encryption::FullDecrypt(input_vector, decode_key, output_vector);

    jbyteArray res_array = env->NewByteArray(output_vector.size());

    if(output_vector.size() > 0){
        env->SetByteArrayRegion(res_array, 0, output_vector.size(), (jbyte *) &output_vector[0]);
    }

    env->ReleaseByteArrayElements(input, jbuffer, 0);
    env->ReleaseStringUTFChars(key, decode_key);

    return res_array;

}extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_cmft_android_sandbox_crypter_core_SandBoxProtocol_csandbox_1encryptSession(JNIEnv *env,
                                                                                    jobject thiz,
                                                                                    jstring key,
                                                                                    jbyteArray input) {
    jbyte* jbuffer = env->GetByteArrayElements(input, NULL);
    const char* encode_key = env->GetStringUTFChars(key, 0);

    unsigned char* buffer = reinterpret_cast<unsigned char *>(jbuffer);
    int buf_len = env->GetArrayLength(input);
    std::vector<unsigned char> input_vector(buffer, buffer + buf_len);
    std::vector<unsigned char> output_vector;

    css::Encryption::FullEncrypt(input_vector, encode_key, output_vector);

    jbyteArray res_array = env->NewByteArray(output_vector.size());

    if(output_vector.size() > 0){
        env->SetByteArrayRegion(res_array, 0, output_vector.size(), (jbyte *) &output_vector[0]);
    }

    env->ReleaseByteArrayElements(input, jbuffer, 0);
    env->ReleaseStringUTFChars(key, encode_key);

    return res_array;
}