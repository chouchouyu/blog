package com.cmft.jniproject;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.http.SslError;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

import com.cmft.android.sandbox.crypter.core.Constant;
import com.cmft.android.sandbox.crypter.webService.HttpCoreSer;

public class H5Activity extends AppCompatActivity {//implements HttpStatusListener {


    WebView webView;
    EditText button;
    Button bt_click;
    //    private ServerManager mServerManager;
    EditText et_service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_h5);

        Intent intent = new Intent(this, HttpCoreSer.class);
//        mServerManager = new ServerManager(this, intent);
//        mServerManager.register();


        et_service = findViewById(R.id.et_service);
        findViewById(R.id.bt_openService).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                mServerManager.startServer();
            }
        });

        findViewById(R.id.bt_closeService).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                mServerManager.stopServer();
            }
        });


        webView = (WebView) findViewById(R.id.webview);
        button = findViewById(R.id.button);
        bt_click = findViewById(R.id.bt_click);
        bt_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webView.loadUrl("http://10.200.88.198:8080");
            }
        });

        WebSettings webSettings = webView.getSettings();
        // 设置与Js交互的权限
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        // 设置允许JS弹窗
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webView.setWebViewClient(new WebViewClient() {

            //todo 监听url改变
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d("webview->url ", url);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError
                    sslError) {
                if (sslError.getPrimaryError() == android.net.http.SslError.SSL_INVALID) {//
                    // 校验过程遇到了bug
                    handler.proceed();
                } else {
                    handler.cancel();
                }
            }
        });

    }

/*
    @Override
    public void unregisterHttpReceiver(BroadcastReceiver receiver) {
        unregisterReceiver(receiver);
    }

    @Override
    public void registerHttpReceiver(BroadcastReceiver receiver, IntentFilter filter) {
        registerReceiver(receiver, filter);
    }


    @Override
    public void startHttpService(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //android8.0以上通过startForegroundService启动service
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    @Override
    public void stopHttpService(Intent intent) {
        stopService(intent);
    }

    @Override
    public void onServerStart(String ip) {
        String mRootUrl = "http://" + ip + ":" + Constant.PORT;
        et_service.setText(mRootUrl);
    }

    @Override
    public void onServerError(String error) {
        et_service.setText(error);
    }

    @Override
    public void onServerStop() {
        et_service.setText("服务器停止");
//        et_mkdir.setText("");
//        et_rm.setText("");
//        et_rename.setText("");
//        et_viewcontent.setText("");
//        et_wpsopen.setText("");
//        et_wpsedit.setText("");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        mServerManager.unRegister();
    }

*/
}
