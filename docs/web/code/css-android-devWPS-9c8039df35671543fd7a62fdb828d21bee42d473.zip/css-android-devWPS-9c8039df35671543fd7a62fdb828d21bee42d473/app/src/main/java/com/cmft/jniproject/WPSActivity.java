package com.cmft.jniproject;

import android.Manifest;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.cmft.android.sandbox.crypter.CallBack;
import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.android.sandbox.crypter.core.SandBoxConfig;
import com.cmft.android.sandbox.crypter.utils.SandboxUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class WPSActivity extends AppCompatActivity implements View.OnClickListener {
    TextView tv_path_isecrypt;

    //    TextView tv_fileId_result;
    EditText et_enceryt_result;
    EditText et_cosenceryt_result;
    EditText et_fileId_query;
    EditText et_filePath;
    EditText et_cosfilePath;
    EditText et_decerpyt_target;
    EditText et_decerpyt_source;

    //    EditText et_cosdecerpyt_target;
//    EditText et_cosdecerpyt_source;
    ImageView image;


    EditText et_content;
    EditText tv_content_enceryt;
    EditText et_content_decrpt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wps);
        et_filePath = findViewById(R.id.et_filePath);
        et_cosfilePath = findViewById(R.id.et_cosfilePath);

        tv_path_isecrypt = findViewById(R.id.tv_path_isecrypt);
        Button bt_path_isecrypt = findViewById(R.id.bt_path_isecrypt);

        image = findViewById(R.id.image);


//        tv_fileId_result = findViewById(R.id.tv_fileId_result);
//        Button bt_fileId_query = findViewById(R.id.bt_fileId_query);
        et_fileId_query = findViewById(R.id.et_fileId_query);

        Button bt_enceryt = findViewById(R.id.bt_enceryt);
        Button bt_cosenceryt = findViewById(R.id.bt_cosenceryt);
        Button bt_cossaveenceryt = findViewById(R.id.bt_cossaveenceryt);
        et_enceryt_result = findViewById(R.id.tv_enceryt_result);
        et_cosenceryt_result = findViewById(R.id.tv_cos_enceryt_result);

        et_decerpyt_target = findViewById(R.id.et_decerpyt_target);
//        et_cosdecerpyt_target = findViewById(R.id.et_cosdecerpyt_target);
        et_decerpyt_source = findViewById(R.id.et_decerpyt_source);
//        et_cosdecerpyt_source = findViewById(R.id.et_cosdecerpyt_source);
        Button bt_photo_read = findViewById(R.id.bt_photo_read);
        Button bt_decerpyt = findViewById(R.id.bt_decerpyt);
        Button bt_cosdecerpyt = findViewById(R.id.bt_cosdecerpyt);
        Button bt_fileId_read = findViewById(R.id.bt_fileId_read);
        Button bt_fileId_edit = findViewById(R.id.bt_fileId_edit);


        et_content = findViewById(R.id.et_content);
        Button bt_content_enceryt = findViewById(R.id.bt_content_enceryt);

        tv_content_enceryt = findViewById(R.id.tv_content_enceryt);
//        Button bt_content_decrpt = findViewById(R.id.bt_content_decrpt);

        et_content_decrpt = findViewById(R.id.et_content_decrpt);
        bt_content_enceryt.setOnClickListener(this);
//        bt_content_decrpt.setOnClickListener(this);
        bt_decerpyt.setOnClickListener(this);
        bt_cosdecerpyt.setOnClickListener(this);
        bt_cosenceryt.setOnClickListener(this);
        bt_cossaveenceryt.setOnClickListener(this);
        bt_fileId_read.setOnClickListener(this);
        bt_photo_read.setOnClickListener(this);
        bt_fileId_edit.setOnClickListener(this);
        bt_enceryt.setOnClickListener(this);
        bt_path_isecrypt.setOnClickListener(this);
//        bt_fileId_query.setOnClickListener(this);

        init();
    }

    private void init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0x221);
        }

        String name = "ENTKMO_2019-12-19.txt";
        File file = new File(Environment.getExternalStorageDirectory(), name);
        try {
            if (!file.exists()) {
                ///storage/emulated/0/ENTKMO_2019-10-08.txt
                Log.d("OFFICEWSM", file.getAbsolutePath());
                file.createNewFile();
            } else {
                Log.d("OFFICEWSM2", file.getAbsolutePath());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_path_isecrypt:
//                for (int i = 0; i < 100; i++) {
//                    String path = "/storage/emulated/0/Android/data/com.cmft" +
//                            ".jniproject.dev/files/COCO-DATA/avatar/wsm.doc";
//                    if (SandboxUtils.isFileExists(this, path, new File(path))) {
//                        Log.d("exist", "文件存在");
//                    } else {
//                        Log.d("exist", "文件不存在");
//                    }
//                }

                String filePaht = et_filePath.getText().toString();
                boolean isFileEncrypted = SandBox.getInstance().isEncrypted(new File(filePaht));
                long size = SandBox.getInstance().getFileSize(new File(filePaht));

                if (isFileEncrypted) {
                    tv_path_isecrypt.setText("是 文件大小 " + size);
                } else {
                    tv_path_isecrypt.setText("否 文件大小 " + size);
                }
                break;

//            case R.id.bt_fileId_query:
//                String queryFileId = et_fileId_query.getText().toString();
//                SandBox.queryFilePath(queryFileId, new IResult() {
//                    @Override
//                    public void onSuccess(final String msg) {
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                tv_fileId_result.setText(msg);
//                            }
//                        });
//
//                    }
//
//                    @Override
//                    public void onFail() {
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                tv_fileId_result.setText("没查到");
//                            }
//                        });
//
//                    }
//                });
//
//                break;

            case R.id.bt_enceryt:
                String sourcePath = et_filePath.getText().toString();
                File sourcePathFile = new File(sourcePath);
                Log.d(" 加密", sourcePathFile + "文件原始大小:" + sourcePathFile.length());
                try {
                    FileInputStream inputStream = new FileInputStream(sourcePath);
                    SandBox.getInstance().encrypt(sourcePathFile.getName(), inputStream, new
                            CallBack<String>() {
                                @Override
                                public void onSuccess(String fileid) {
                                    et_enceryt_result.setText(fileid);

                                }

                                @Override
                                public void onFail(String errorString) {

                                }
                            });
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            case R.id.bt_decerpyt:

                String sourceFileid = et_decerpyt_source.getText().toString();
//                String targetFileid = et_decerpyt_target.getText().toString();

                final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                SandBox.getInstance().decrypt(sourceFileid, outputStream, new CallBack<Boolean>() {


                    @Override
                    public void onSuccess(Boolean response) {
                        try {
                            Log.d("TEST", outputStream.toString("UTF-8"));
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFail(String string) {

                    }
                });

//
//                for (int i = 0; i < 100; i++) {
//                    final int finalI = i;
//                    new Thread(new Runnable() {
//                        @Override
//                        public void run() {
//                            decrept("wsm.doc", finalI + ".doc");
//                        }
//                    }).start();
//                    new Thread(new Runnable() {
//                        @Override
//                        public void run() {
//                            decrept("wsm.doc", "2.doc");
//                        }
//                    }).start();
//                    new Thread(new Runnable() {
//                        @Override
//                        public void run() {
//                            decrept("wsm.doc", "3.doc");
//                        }
//                    }).start();
//                    new Thread(new Runnable() {
//                        @Override
//                        public void run() {
//                            decrept("wsm.doc", "4.doc");
//                        }
//                    }).start();


                break;


            case R.id.bt_photo_read:
                String phototPath = et_fileId_query.getText().toString();
                final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                SandBox.getInstance().decrypt(phototPath, byteArrayOutputStream, new
                        CallBack<Boolean>() {


                            @Override
                            public void onSuccess(Boolean response) {
                                Glide.with(WPSActivity.this).load(byteArrayOutputStream
                                        .toByteArray()).into
                                        (image);
                            }

                            @Override
                            public void onFail(String string) {

                            }
                        });

//                Bitmap bitmap = SandBox.getImageBitmap(phototPath);
//                Glide.with(WPSActivity.this).load(bitmap.).into(imageView);
                break;
            case R.id.bt_fileId_read:
                String filePath = et_fileId_query.getText().toString();
                SandBox.getInstance().openWithWPS(filePath);
                break;
            case R.id.bt_fileId_edit:
                String currentFile = et_fileId_query.getText().toString();
                File file = new File(currentFile);
                SandBox.getInstance().editWithWPS(currentFile, "/wsm" + File.separator + file
                        .getName());
                break;
            case R.id.bt_cosenceryt:
                // 直接下载的逻辑
                String cosSourcePath = et_cosfilePath.getText().toString();
                File cosSourcePathFile = new File(cosSourcePath);
                Log.d(" 加密", cosSourcePathFile + "文件原始大小:" + cosSourcePathFile.length());
                try {
                    FileInputStream inputStream = new FileInputStream(cosSourcePath);
                    SandBox.getInstance().cosEncrypt(cosSourcePathFile.getName(), inputStream, new
                            CallBack<String>() {
                                @Override
                                public void onSuccess(String response) {
                                    et_cosenceryt_result.setText(response);

                                }

                                @Override
                                public void onFail(String string) {
                                    et_cosenceryt_result.setText(string);
                                }
                            });
                } catch (IOException e) {
                    e.printStackTrace();
                }

                break;
            case R.id.bt_cosdecerpyt:
                try {
                    String fileid = et_cosenceryt_result.getText().toString();
                    String savepath = "/sdcard/Download/" +
                            "costemp" + fileid.substring(fileid.lastIndexOf("."));
                    final File saveFile = new File(savepath);
                    if (!saveFile.exists()) {
                        saveFile.createNewFile();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(saveFile);
                    SandBox.getInstance().cosUpload(fileid, fileOutputStream, new
                            CallBack<Boolean>() {

                                @Override
                                public void onSuccess(Boolean response) {
                                    Log.d(" cosUpload", saveFile.getAbsolutePath() + "加密后大小:" +
                                            saveFile.length());
                                    Toast.makeText(WPSActivity.this, "cos加密完成", Toast.LENGTH_SHORT)
                                            .show();
                                }

                                @Override
                                public void onFail(String string) {

                                }
                            });
                } catch (Exception e) {
                    e.printStackTrace();
                }


                break;
            case R.id.bt_cossaveenceryt:
                //生成cos下载
                String cosFilePath = et_cosfilePath.getText().toString();
                File cosfile = new File(cosFilePath);
                SandBox.getInstance().cosSaveToSandbox(cosfile.getName(), cosFilePath, new
                        CallBack<String>() {
                            @Override
                            public void onSuccess(String response) {
                                //response 为返回的fileid
                                et_cosenceryt_result.setText(response);
                            }

                            @Override
                            public void onFail(String string) {
                                //String 为返回的error string
                                et_cosenceryt_result.setText(string);
                            }
                        });
                break;
            case R.id.bt_content_enceryt:
                //加密
                byte[] enCryptResult = SandBox.getInstance().encryptSession(
                        et_content.getText()
                                .toString().getBytes());
                tv_content_enceryt.setText(new String(enCryptResult).toString());

                //解密
                byte[] decryptResult = SandBox.getInstance().decryptSession(
                        enCryptResult.clone());
                et_content_decrpt.setText(new String(decryptResult).toString());
                break;
        }

    }

    private void decrept(String srcPath, String targetPath) {
        FileOutputStream outputStream = SandBox.getInstance().getInnerOutStream(targetPath);
        SandBox.getInstance().decrypt(srcPath, outputStream, new CallBack<Boolean>() {
            @Override
            public void onSuccess(Boolean response) {
//                Toast.makeText(WPSActivity.this, "解密完成", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onFail(String string) {

            }
        });
    }


}
