package com.cmft.jniproject;

import android.app.Application;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.android.sandbox.crypter.core.SandBoxConfig;
import com.facebook.stetho.Stetho;
import com.yanzhenjie.andserver.AndServer;
import com.yanzhenjie.andserver.Server;


public class App extends Application {
    private static App mInstance;
    private Server mServer;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        Stetho.initializeWithDefaults(this);



        SandBoxConfig boxConfig = new SandBoxConfig.Builder()
                .isBuggable(true)//是否打日志
                .setEncryptKey("1234567890123456") //加密filekey
                .setWaterMark("招商金科") //wps打开时水印
                .build(this);
        SandBox.init(boxConfig);
        SandBox.getInstance().setUserName("avatar");//初始化后，设置setUserName后，所有的文件操作都会存在userName目录下




        Stetho.initializeWithDefaults(this);

    }

    public static App get() {
        return mInstance;
    }
}
