package com.cmft.jniproject;

import android.util.Log;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.android.sandbox.crypter.core.Constant;


import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;

public class GitHubService {
    Retrofit retrofit;
    private APIService service;
    public static HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor().
            setLevel(HttpLoggingInterceptor.Level.BODY);

    public void initNet() {

        OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient.Builder()
                .addInterceptor(interceptor);

        okHttpClientBuilder
                .retryOnConnectionFailure(true)
                .connectTimeout(18, TimeUnit.MINUTES)
                .readTimeout(18, TimeUnit.MINUTES)
                .writeTimeout(18, TimeUnit.MINUTES);

        OkHttpClient okhttpclient = okHttpClientBuilder.build();


        retrofit = new Retrofit.Builder()
                .baseUrl(Constant.baseUrl + "/" + Constant.SDK_NAME + "/")
                .client(okhttpclient)
//                .addConverterFactory(GsonConverterFactory.create())
                .build();


        service = retrofit.create(APIService.class);
    }


    public void downloadCosFile(String url) {
//            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("token", SandBox.getToken());
//            jsonObject.put("savepath", "/" + System.currentTimeMillis() + ".txt");
//            jsonObject.put("url", url);
//            RequestBody requestBody = RequestBody.create(MediaType.parse("application/json;
// charset=utf-8"), jsonObject.toString());
        service.downloadCosFile(SandBox.getInstance().getToken(), System.currentTimeMillis() + ".doc", url,
                false).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Log.d("web", "onResponse --" + response.message());
//                Log.d("web", "onResponse"+response.isSuccessful());
//                if (response.isSuccessful()) {
//                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d("web", "onFailure-" + t.getMessage());
            }
        });
    }

    public void upload() {
        File file = new File("/sdcard/Download/wsm1.doc");
        // 创建 RequestBody，用于封装构建RequestBody
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
//        RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpg"), file);

        // MultipartBody.Part  和后端约定好Key，这里的partName是用file
        MultipartBody.Part body = MultipartBody.Part.createFormData("file", file.getName(),
                requestFile);

        // 添加描述
//        String descriptionString = "hello, 这是文件描述";
//        RequestBody description = RequestBody.create(MediaType.parse("multipart/form-data"),
// descriptionString);


        Map<String, RequestBody> params = new HashMap<>();
        params.put("token", convertToRequestBody(SandBox.getInstance().getToken()));
        params.put("canOverWriter", convertToRequestBody(String.valueOf(false)));
        params.put("path", convertToRequestBody("/wsm"));
        params.put("name", convertToRequestBody("file.doc"));


        // 执行请求
        service.writefile(params, body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Log.d("web", "onResponse --" + response.message());
//                Log.d("web", "onResponse"+response.isSuccessful());
//                if (response.isSuccessful()) {
//                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d("web", "onFailure-" + t.getMessage());
            }
        });
    }

    private RequestBody convertToRequestBody(String param) {
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain"), param);
        return requestBody;
    }


    interface APIService {

        @Multipart
        @POST("writefile")
        Call<ResponseBody> writefile(@PartMap Map<String, RequestBody> partMap, @Part
                MultipartBody.Part file);

        //        @Multipart
//        @POST("upload")
//        Call<ResponseBody> upload(@Part MultipartBody.Part file);
        @FormUrlEncoded
        @POST("downloadCosFile")
        Call<ResponseBody> downloadCosFile(@Field("token") String token, @Field("savepath")
                String savepath, @Field("url") String url, @Field("canOverWrite") boolean
                                                   canOverWrite);//构造一个实体对象
    }
}

