package com.cmft.jniproject;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.android.sandbox.crypter.core.Constant;
import com.cmft.android.sandbox.crypter.webService.HttpCoreSer;
import com.cmft.android.sandbox.crypter.webService.HttpStatusListener;
import com.cmft.android.sandbox.crypter.webService.ServerManager;

import java.io.File;

import static com.cmft.android.sandbox.crypter.core.Constant.SDK_NAME;

public class WebServiceActivity extends AppCompatActivity implements HttpStatusListener, View
        .OnClickListener {


    private TextView mStart, mStop;
    private String mRootUrl;
    private ServerManager mServerManager;
    private Button mUpload, bt_ls, bt_mkdir, bt_rm, bt_rename, bt_viewcontent, bt_wpsopen,
            bt_wpsedit, bt_downloadCosFile;
    private EditText et_ls, et_mkdir, et_rm, et_rename, et_viewcontent, et_wpsopen, et_wpsedit,
            et_downloadCosFile;
    String url = "https://cos-cdn-di1.sit.cmrh" +
            ".com/cos-download/v1/downloadFile/0/coco-private-bucket" +
            "/3535a2b75a980c8007fecd8b0e1d0276/活动申请表" +
            ".docx?expires=1879580686&signature=0101bazXI8K3" +
            ":ODE2RUVENTRBQzA1NUVBQ0Y4MzY5NUE3QTM0RjU3NUE1RTM1Q0VBRA==";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webservice);

        mStart = findViewById(R.id.start_server);
        mStop = findViewById(R.id.stop_server);
        mUpload = findViewById(R.id.upload);
        et_ls = findViewById(R.id.et_ls);
        et_mkdir = findViewById(R.id.et_mkdir);
        et_rm = findViewById(R.id.et_rm);
        et_rename = findViewById(R.id.et_rename);
        et_viewcontent = findViewById(R.id.et_viewcontent);
        et_wpsopen = findViewById(R.id.et_wpsopen);
        et_wpsedit = findViewById(R.id.et_wpsedit);
        bt_downloadCosFile = findViewById(R.id.bt_downloadCosFile);
        et_downloadCosFile = findViewById(R.id.et_downloadCosFile);


        bt_ls = findViewById(R.id.bt_ls);
        bt_mkdir = findViewById(R.id.bt_mkdir);
        bt_rm = findViewById(R.id.bt_rm);
        bt_rename = findViewById(R.id.bt_rename);
        bt_viewcontent = findViewById(R.id.bt_viewcontent);
        bt_wpsopen = findViewById(R.id.bt_wpsopen);
        bt_wpsedit = findViewById(R.id.bt_wpsedit);


        mStart.setOnClickListener(this);
        mStop.setOnClickListener(this);
        mUpload.setOnClickListener(this);
        bt_downloadCosFile.setOnClickListener(this);
        bt_ls.setOnClickListener(this);
        bt_mkdir.setOnClickListener(this);
        bt_rm.setOnClickListener(this);
        bt_rename.setOnClickListener(this);
        bt_viewcontent.setOnClickListener(this);
        bt_wpsopen.setOnClickListener(this);
        bt_wpsedit.setOnClickListener(this);

        Intent intent = new Intent(this, HttpCoreSer.class);
        mServerManager = new ServerManager(this, intent);
        mServerManager.register();


    }

    @Override
    public void unregisterHttpReceiver(BroadcastReceiver receiver) {
        unregisterReceiver(receiver);
    }

    @Override
    public void registerHttpReceiver(BroadcastReceiver receiver, IntentFilter filter) {
        registerReceiver(receiver, filter);
    }

    @Override
    public void startHttpService(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //android8.0以上通过startForegroundService启动service
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    @Override
    public void stopHttpService(Intent intent) {
        stopService(intent);
    }

    @Override
    public void onServerStart(String ip) {
        mRootUrl = "http://" + ip + ":" + Constant.PORT;
        et_ls.setText(mRootUrl + "/" + SDK_NAME + "/ls?token=" + getToken() + "&path=/");
//        mRootUrl = "http://" + ip + ":8080/test_file.pdf";

        et_mkdir.setText(mRootUrl + "/" + SDK_NAME + "/mkdir?token=" + getToken() +
                "&path=/&name=wsm");
        et_rm.setText(mRootUrl + "/" + SDK_NAME + "/rm?token=" + getToken() + "&path=/wsm");
        et_rename.setText(mRootUrl + "/" + SDK_NAME + "/rename?token=" + getToken() +
                "&path=/&rename=god&name=test");
        et_viewcontent.setText(mRootUrl + "/" + SDK_NAME + "/readfile?token=" + getToken() +
                "&path=/&name=wsm.txt");
        et_wpsopen.setText(mRootUrl + "/" + SDK_NAME + "/openwps?token=" + getToken() +
                "&editenable=false&path=wsm.doc");
        et_wpsedit.setText(mRootUrl + "/" + SDK_NAME + "/openwps?token=" + getToken() +
                "&editenable=ture&path=wsm.doc&savePath=/test/wsm.doc");
        et_downloadCosFile.setText(mRootUrl + "/" + SDK_NAME + "/downloadCosFile?token=" +
                getToken() + "&savepath=/活动申请表.docx&url=" + url);
    }

    public String getToken() {
        return SandBox.getInstance().getToken();
    }

    @Override
    public void onServerError(String error) {
        et_ls.setText(error);
    }

    @Override
    public void onServerStop() {
        et_ls.setText("服务器停止");
        et_mkdir.setText("");
        et_rm.setText("");
        et_rename.setText("");
        et_viewcontent.setText("");
        et_wpsopen.setText("");
        et_wpsedit.setText("");
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.start_server:
                mServerManager.startServer();
                break;
            case R.id.stop_server:
                mServerManager.stopServer();
                break;
            case R.id.upload:
                GitHubService service = new GitHubService();
                service.initNet();
                service.upload();
//                service.writeFile();
                break;
            case R.id.bt_ls:
                browser(et_ls.getText().toString());
                break;
            case R.id.bt_mkdir:
                browser(et_mkdir.getText().toString());
                break;
            case R.id.bt_rm:
                browser(et_rm.getText().toString());
                break;
            case R.id.bt_rename:
                browser(et_rename.getText().toString());
                break;
            case R.id.bt_viewcontent:
                browser(et_viewcontent.getText().toString());
                break;
            case R.id.bt_wpsopen:
                browser(et_wpsopen.getText().toString());
                break;
            case R.id.bt_wpsedit:
                browser(et_wpsedit.getText().toString());
                break;
            case R.id.bt_downloadCosFile:

//                SandBoxCenter.getInstance().cosUpload(new File("/sdcard/Download/wsm.doc"));


//                GitHubService service2 = new GitHubService();
//                service2.initNet(mRootUrl);
//                service2.downloadCosFile(url);

//                browser(et_downloadCosFile.getText().toString());
                break;
        }
    }

    private void browser(String url) {
        //et_ls.getText().toString()
        if (!TextUtils.isEmpty(mRootUrl)) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setData(Uri.parse(url));
            startActivity(intent);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mServerManager.unRegister();
    }
}
