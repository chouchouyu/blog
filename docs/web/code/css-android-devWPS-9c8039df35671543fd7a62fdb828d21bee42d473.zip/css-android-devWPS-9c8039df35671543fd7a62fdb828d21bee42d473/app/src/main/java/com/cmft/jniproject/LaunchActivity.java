package com.cmft.jniproject;

import android.app.ActivityManager;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class LaunchActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);
        findViewById(R.id.bt_web).setOnClickListener(this);
        findViewById(R.id.bt_wps).setOnClickListener(this);
        findViewById(R.id.bt_h5).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_web:
                startActivity(new Intent(LaunchActivity.this, WebServiceActivity.class));
                break;
            case R.id.bt_wps:
                startActivity(new Intent(LaunchActivity.this, WPSActivity.class));
                break;
            case R.id.bt_h5:
                startActivity(new Intent(LaunchActivity.this, H5Activity.class));
                break;
        }
    }


}