# ANDROID  SANDBOX sdk

SANDBOX是一个文件沙盒， 跟目录对外不暴露，和其他的文件加解密的过程不同的是，我们是通过文件流的方式加解密文件，做到文件不落地。
现有基础功能有:
1. cos加解密对接
2. 文件流的加解密，
3. 判断文件是否为加密文件，
4. 加密文件通过wps打开/编辑
5. 在手机里启用服务器，以供外部通过web请求操作沙盒内文件。


# 第一部分 初始化
1. 依赖包

> api 'com.cmft:sandbox:2.0.0-SNAPSHOT'
最新版本号，见  [maven](http://nexus.cmrh.com:8084/nexus/content/repositories/android-snapshot/com/cmft/sandbox/)

2. application初始化

```        
        SandBoxConfig boxConfig = new SandBoxConfig.Builder()
                .isBuggable(false) //是否打印日志
//                .setEncryptKey(UUID.randomUUID().toString())
                .setEncryptKey("1234567890123456") //加密时使用的filekey,必须16位
                .setWaterMark("招商金科")//水印
                .build(config.getApplication());
        SandBox.init(boxConfig);
        SandBox.setLogListener(new com.cmft.android.sandbox.crypter.utils.LogListener() {
            @Override
            public void onLog(String s, String s1) {
                logger.debug(s, s1); //也可以isBuggable为false时，从这里拿到沙箱里的日志
            }
        });
```

3. 权限申请

沙箱作为文件存储，需要 读写权限

```
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0x221);
        }
```

3. AndroidManifest.xml 添加 调用wps需要的service

  ```
    <service android:name="com.cmft.android.sandbox.crypter.wps.agent.AgentMessageService">
            <intent-filter>
                <action android:name="${applicationId}.OfficeServiceAgent"></action>
            </intent-filter>
        </service>
        <service android:name="com.cmft.android.sandbox.crypter.wps.client.MOfficeClientService">
            <intent-filter>
                <action android:name="${applicationId}.OfficeServiceClient" />
            </intent-filter>
        </service>
```

 1. setUserName用户信息
```
SandBox.getInstance().setUserName(userId);
//设置userid后，所有的文件操作都会存在userid目录下
```
 
 #如果初始化这部分完成后，才能调用下面各个功能
------ 
# 第二部分 cos加解密对接功能
![cos流程](http://git.dev.cmrh.com/sandbox/css-android/raw/devWPS/cos%E6%B5%81%E7%A8%8B.png)

### 下载相关接口

```
    /**
     * cos下载 下载解密cos文件/非加密文件，存储不加密数据
     *
     * @param fileid     沙箱相对路径
     * @param sourcePath 待加密文件路径
     * @param callBack   成功时返回 filedid ,失败返回error string
     */
    public void cosSaveToSandbox(String fileid, String sourcePath, CallBack<String>
            callBack) {

        SandBoxCenter.getInstance().cosSaveToSandbox(fileid, sourcePath, callBack);
    }
```
### eg:
```
            //生成cos下载
                String cosFilePath = "/sdcard/Download/test.doc";
                SandBox.getInstance().cosSaveToSandbox(cosfile.getName(), cosFilePath, new
                        CallBack<String>() {
                            @Override
                            public void onSuccess(String response) {
                                //response 为返回的fileid
                             }

                            @Override
                            public void onFail(String string) {
                                //String 为返回的error string
                             }
                        });
```
### 上传相关接口
 ```
     /**
     * cos 上传 必须cos加密
     *
     * @param fileid  沙箱相对路径
     * @param outputStream  cos加密了的文件流
     * @param callBack true成功 false 失败
     */
    public void cosUpload(String fileid, OutputStream outputStream, CallBack<Boolean>
            callBack) {
        SandBoxCenter.getInstance().cosUpload(fileid, outputStream, callBack);
    }
 ```
 
### eg:

```
        try {
                    String fileid = cosSaveToSandbox回调里的response 
                    String savepath = "/sdcard/Download/test.doc";
                    final File saveFile = new File(savepath);
                    if (!saveFile.exists()) {
                        saveFile.createNewFile();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(saveFile);
                    SandBox.getInstance().cosUpload(fileid, fileOutputStream, new
                            CallBack<Boolean>() {

                                @Override
                                public void onSuccess(Boolean response) {
                                    Log.d(" cosUpload", saveFile.getAbsolutePath() + "加密后大小:" +
                                            saveFile.length());
                                    Toast.makeText(WPSActivity.this, "cos加密完成", Toast.LENGTH_SHORT)
                                            .show();
                                }

                                @Override
                                public void onFail(String string) {

                                }
                            });
                } catch (Exception e) {
                    e.printStackTrace();
                }
```
#如果只是cos接入，看到这里就可以了。下面不用看
------
##第三部分  对String的加解密
由于String有可能不完整，沙箱支持的传入byte[]方式，封装了2个接口
>   /**
     * 字节解密
     * @param content 内容
     * @return
     */
    public byte[] decryptSession( byte[] content)
       /**
     * 字节加密
     * @param content 内容
     * @return
     */
    public byte[] encryptSession( byte[] content)
    
    
**eg：**
     
```
      //加密
          byte[] enCryptResult = SandBox.getInstance().encryptSession(
                        et_content.getText()
                                .toString().getBytes());
                                
                                  //解密
                byte[] decryptResult = SandBox.getInstance().decryptSession(
                        enCryptResult.clone());
```       
     

-------

## 2. 文件操作接口
###文件是否是加密过的文件 

```
    public static boolean isEncrypted(File file) {
    
```
####eg:
```
       boolean isFileEncrypted = SandBox.isEncrypted(new File(filePaht));
                if (isFileEncrypted) {
                    tv_path_isecrypt.setText("是");
                } else {
                    tv_path_isecrypt.setText("否");
                }
```
###通过WPS编辑文档

```
    public static void editWithWPS(String filePath,String savePath) {
    

```
eg:

```
File file = new File(currentFile);
        SandBox.editWithWPS(currentFile, "/wsm" + File.separator + file.getName());
```
### 通过WPS打开文档

```
    public static void openWithWPS(String filePath) {
```
#### eg 
```
    String filePath = et_fileId_query.getText().toString();
                SandBox.openWithWPS(filePath);
```

### 沙箱加密文件流，存储

```
 public static boolean encrypt(String fileName, FileInputStream inputStream)
```
### eg

```
    String sourcePath = et_filePath.getText().toString();
                File sourcePathFile = new File(sourcePath);
                Log.d(" 加密", sourcePathFile + "文件原始大小");
                try {
                    FileInputStream inputStream = new FileInputStream(sourcePath);
                    boolean result = SandBox.encrypt(sourcePathFile.getName(), inputStream);
                    if (result) {
                        et_enceryt_result.setText("解密完成");
                    } else {
                        et_enceryt_result.setText("解密失败");
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
```
### 网络请求Token

```
 public static String getToken(){
```
### 沙箱解密文件流

```
   public static int decrypt(String sourcePath, OutputStream outputStream) throws IOException {
```
## eg
```
  String srcPath = et_decerpyt_source.getText().toString();
                String targetPath = et_decerpyt_target.getText().toString();
                try {
                    FileOutputStream outputStream = SandBox.getInnerOutStream(targetPath);
                    int result = SandBox.decrypt(srcPath, outputStream);
                    if (result == 0) {
                        Toast.makeText(WPSActivity.this, "解密完成", Toast.LENGTH_SHORT).show();
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
```
```
文本解密实用例子：
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        int result = SandBox.decrypt(saveDir + File.separator + mailFile, outputStream);
        if (result == 0) {
            try {
                mailBodyStr = outputStream.toString(charsetName);
                Cmail.logger.debug(Constant.TAG, "邮件正文-> " + outputStream.toString(charsetName));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }

图片解密实用例子：
                          if (!TextUtils.isEmpty(phototPath)) {
                               ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                               if (SandBox.isEncrypted(new File(phototPath))) {
                                   int result = SandBox.decrypt(phototPath, byteArrayOutputStream);
                                   if (result == 0) {
                                       Glide.with(ImageActivity.this).load(byteArrayOutputStream.toByteArray()).into
                                               (photoView);
                                   }
                               } else {
                                   Glide.with(ImageActivity.this).load(phototPath).into
                                           (photoView);
                               }

                           }

```
### 获取路径path下的文件列表

```
  public static List<FileInfor> getFileListWithPath(String path){
```
#### 在path路径下创建文件夹，名字为name，成功返回true，否则false
```
 public static boolean MKdirWithPath(String path, String name){
```
###  删除path路径的文件或者文件夹，成功返回true，否则false

```
 public static boolean RMWithPath(String path){
```
### 往path路径下写文件，文件流为data，文件名为name,是否可以覆盖为flag,写成功返回true，否则false

```
    public static boolean writeFileWithPath(String path,String name,boolean canOverWriter,FileInputStream inputStream){

```

## 手机服务器
    implementation 'com.yanzhenjie.andserver:api:2.0.4'
    annotationProcessor 'com.yanzhenjie.andserver:processor:2.0.4'
### 初始化 
```
    SandBoxService service = new SandBoxService();
        service.register(this, new SandBoxServiceListener() {
            @Override
            public void onServerStart(String s) {

            }

            @Override
            public void onServerError(String s) {

            }

            @Override
            public void onServerStop() {

            }
        });
```
##  startServer

```
service.startServer();
```
### stopServer

```
	service.stopServer
```
###  Activity注销
在activity onDestroy 注销service
```
    @Override
    protected void onDestroy() {
        super.onDestroy();
        service.unRegister();
    }
```
### SandBoxServiceListener 

#### onServerStart
sdk中ip地址写死为127.0.0.1:8080,也可以通过返回的ip，获取即时的。
```
 @Override
    public void onServerStart(String ip) {
```
#### onServerError
```
  @Override
    public void onServerError(String error)
```
#### onServerStop 

```
 @Override
    public void onServerStop() {
        et_ls.setText("服务器停止");
    }
```

### 服务器cos接口
#### 0.获取token
http://127.0.0.1:8080/sandbox/gettoken
```
    @GetMapping(path = "/gettoken", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    String getToken() {
        return formatResponse(true, SandBox.getToken(), " token获取成功");
    }
```
#### 1.文件下载
```
@PostMapping(path = "/downloadCosFile", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
 String downloadCosFile(@RequestParam(name = "token") String token,
								@RequestParam(name = "savepath") String savepath,
								@RequestParam(name = "canOverWrite") boolean canOverWrite,
								@RequestParam(name = "url") String url) {
						
```
#### 2.下载后的文件通过wps打开/编辑
eg：
 * http://127.0.0.1:8080/sandbox/wps?token=tokene&editenable=false&path=wsm.doc
 *  http://127.0.0.1:8080/sandbox/wps?token=tokene&editenable=ture&path=wsm.doc&savePath=/test/wsm.doc
```
@GetMapping(path = "/openwps", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
									void writeFile(@QueryParam("token") String token,
												   @QueryParam("editenable") boolean openMode,
												   @QueryParam("path") String dir,
												   @QueryParam(name = "savePath", required = false) String savePath) {
```
1. editenable true 表示编辑模式打开，false 表示只读模式打开
2. path 为沙盒用户目录的相对路径
3. 可以看到savePath参数为可选项，因为当是只读模式（editenable = false）时不需要传入这个参数，当编辑模式（editenable = ture）时必须传入savePath，如果不想存其他路径可以填和“path”一样的路径。




AnService
json
    implementation 'com.yanzhenjie.andserver:api:2.0.4'
    annotationProcessor 'com.yanzhenjie.andserver:processor:2.0.4'

