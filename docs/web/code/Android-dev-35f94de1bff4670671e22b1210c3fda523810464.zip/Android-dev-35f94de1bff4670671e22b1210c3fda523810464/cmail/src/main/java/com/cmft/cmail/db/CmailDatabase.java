package com.cmft.cmail.db;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.Database;
import android.content.Context;
import android.support.annotation.NonNull;

import com.cmft.cmail.db.dao.MailAccountDao;
import com.cmft.cmail.db.dao.MailAttachmentDao;
import com.cmft.cmail.db.dao.MailFolderDao;
import com.cmft.cmail.db.dao.MailHeaderDao;
import com.cmft.cmail.db.dao.MailPhrasesDao;
import com.cmft.cmail.db.dao.MailInfoDao;
import com.cmft.cmail.db.dao.RecentContactDao;
import com.cmft.cmail.db.dao.TobeSendDao;
import com.cmft.cmail.db.model.MailAccount;
import com.cmft.cmail.db.model.MailAttachment;
import com.cmft.cmail.db.model.MailFolder;
import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.db.model.MailInfo;
import com.cmft.cmail.db.model.MailPhrases;
import com.cmft.cmail.db.model.RecentContactModel;
import com.cmft.cmail.db.model.TobeSend;
import com.cmft.cmail.utils.CmailInfoSp;


import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;

import static com.cmft.cmail.utils.Constant.ISENCRYPT;


@Database(entities = {MailFolder.class, MailAccount.class, MailAttachment.class,
        MailInfo.class, MailPhrases.class, MailHeader.class, TobeSend.class, RecentContactModel
        .class}, version = 8)
@TypeConverters({Converters.class})
public abstract class CmailDatabase extends RoomDatabase {

    public abstract MailAccountDao getMailAccountDao();

    public abstract MailFolderDao getMailFolderDao();

    public abstract MailInfoDao getMailInfoDao();

    public abstract MailPhrasesDao mailPhrasesDao();

    public abstract MailAttachmentDao mailAttachmentDao();

    public abstract MailHeaderDao getMailHeaderDao();

    public abstract RecentContactDao getRecentContactDao();


//    public abstract MailDraftsDao getMailDraftsDao();

    public abstract TobeSendDao getTobeSendDao();


    private volatile static CmailDatabase INSTANCE;

    public static CmailDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (CmailDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = buildDatabase(context.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }


    private static CmailDatabase buildDatabase(final Context context) {


        RoomDatabase.Builder builder = Room.databaseBuilder(context,
                CmailDatabase.class, getDBName(context))
                .fallbackToDestructiveMigration()
//                .addMigrations(Migrations.MIGRATION_2_3)
                .addCallback(new RoomDatabase.Callback() {
                    @Override
                    public void onCreate(@NonNull SupportSQLiteDatabase db) {
                    }

                    @Override
                    public void onOpen(@NonNull SupportSQLiteDatabase db) {
                    }
                })
                .fallbackToDestructiveMigration();
        if (ISENCRYPT) {
            //TODO 加密数据库待验证
//            final byte[] passphrase = net.sqlcipher.database.SQLiteDatabase.getBytes(Constant
//                    .DATABASE_PASSWORD.toCharArray());
//            final SupportFactory factory = new SupportFactory(passphrase);
//            builder.openHelperFactory((SupportSQLiteOpenHelper.Factory) factory);
        }

        return (CmailDatabase) builder.build();
    }

    public static String getDBName(Context context) {
        return CmailInfoSp.getUserId() + ".db";
    }


}

