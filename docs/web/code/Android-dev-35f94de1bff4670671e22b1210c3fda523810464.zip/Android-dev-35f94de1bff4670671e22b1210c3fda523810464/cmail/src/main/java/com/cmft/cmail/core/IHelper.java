package com.cmft.cmail.core;

import android.content.Context;

import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.web.RetrofitService;

import java.util.concurrent.ThreadPoolExecutor;

public interface IHelper {
    void init(Context context, RetrofitService retrofit, CmailDatabase database,
              ThreadPoolExecutor executor, ILogger logger,HelperSandbox sandbox);

    String getTag();
}
