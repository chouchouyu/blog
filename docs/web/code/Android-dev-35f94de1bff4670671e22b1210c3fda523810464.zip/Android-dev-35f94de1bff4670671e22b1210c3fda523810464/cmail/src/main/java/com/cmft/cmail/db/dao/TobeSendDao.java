package com.cmft.cmail.db.dao;

import com.cmft.cmail.db.model.TobeSend;

import java.util.List;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

@Dao
public interface TobeSendDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertTobeSend(TobeSend tobeSend);


    @Query("select * from TobeSend where mailAccount ==:mailAccount and originUid ==:originUid")
    TobeSend queryTobeSend(String mailAccount, long originUid);

    @Query("select * from TobeSend where mailAccount == :mailAccount order by originUid desc")
    List<TobeSend> queryTobeSendByMail(String mailAccount);

    @Query("select * from TobeSend where mailAccount ==:mailAccount and " +
            "originUid > :uid ORDER BY mailTime DESC")
    List<TobeSend> queryTobeSendByMail(String mailAccount, long uid);

    @Delete
    void deleteTobeSend(TobeSend tobeSend);

    @Query("DELETE  FROM TobeSend where   mailAccount ==:mailAccount and originUid ==:originUid")
    void delete(String mailAccount, long originUid);
}
