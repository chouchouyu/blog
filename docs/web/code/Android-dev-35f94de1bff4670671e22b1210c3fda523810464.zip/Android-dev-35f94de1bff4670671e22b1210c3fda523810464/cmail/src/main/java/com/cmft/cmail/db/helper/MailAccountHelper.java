package com.cmft.cmail.db.helper;

import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailAccountDao;
import com.cmft.cmail.db.model.MailAccount;

import java.util.List;

public class MailAccountHelper {

    private MailAccountHelper() {
    }

    private static MailAccountHelper mInstance = new MailAccountHelper();

    public static MailAccountHelper getInstance() {
        return mInstance;
    }

    private MailAccountDao getMailAccountDao() {
        return CmailDatabase.getInstance(CmailCenter.getContext())
                .getMailAccountDao();
    }

    /**
     * 插入一条数据
     *
     * @param mailAccount
     * @return
     */
    public long insertMailAccount(MailAccount mailAccount) {
        return getMailAccountDao().insertMailAccount(mailAccount);
    }

    /**
     * 插入多条数据
     *
     * @param data
     * @return
     */
    public long[] insertMailAccounts(List<MailAccount> data) {
        return getMailAccountDao().insertMailAccount(data);
    }

    /**
     * 删除一条数据
     *
     * @param mailAccount
     */
    public void deleteMailAccount(final MailAccount mailAccount) {
        getMailAccountDao().deleteMailAccount(mailAccount);
    }

    /**
     * 根据邮箱账号获取账号的其他信息
     *
     * @param mailAccount
     * @return
     */
    public MailAccount getMailAccount(String mailAccount) {
        return getMailAccountDao().queryByMailAccount(mailAccount);
    }

    /**
     * 获取当前用户的邮箱账号列表
     *
     * @param userId
     * @return
     */
    public List<MailAccount> getMailAccounts(String userId) {
        return getMailAccountDao().queryByUserId(userId);
    }


  /**
     * 获取当前用户的邮箱账号列表
     *
     * @param userId
     * @return
     */
    public List<String> getMailListByUserId(String userId) {
        return getMailAccountDao().getMailListByUserId(userId);
    }

    /**
     * 更新某条数据
     *
     * @param mailAccount
     * @return
     */
    public int updateMailAccount(MailAccount mailAccount) {
        return getMailAccountDao().updateMailAccount(mailAccount);
    }

    /**
     * 获取邮件签名
     *
     * @param mailAccount
     * @return
     */
    public String getMailSign(String mailAccount) {
        return getMailAccountDao().getMailSign(mailAccount);
    }
}
