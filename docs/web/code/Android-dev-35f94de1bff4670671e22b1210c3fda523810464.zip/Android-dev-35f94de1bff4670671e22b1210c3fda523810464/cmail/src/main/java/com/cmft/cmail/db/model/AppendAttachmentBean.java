package com.cmft.cmail.db.model;

public class AppendAttachmentBean {

    /**
     * fileName : IMG_20190730_150527.jpg
     * fileSize : 1.79mb
     * filePath : /storage/emulated/0/Pictures/Screenshots/Screenshot_20190917-150138.jpg
     */

    private String fileName;
    private String fileSize;
    private String filePath;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
