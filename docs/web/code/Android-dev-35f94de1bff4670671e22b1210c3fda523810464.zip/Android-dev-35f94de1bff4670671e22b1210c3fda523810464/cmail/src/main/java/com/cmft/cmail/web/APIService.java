package com.cmft.cmail.web;

import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.db.model.MailStatusRes;
import com.cmft.cmail.web.reqBean.BindAccountReq;
import com.cmft.cmail.web.reqBean.MoveEmailReq;
import com.cmft.cmail.web.resBean.BaseRes;
import com.cmft.cmail.web.resBean.MailBox;
import com.cmft.cmail.web.resBean.MailContentRes;
import com.cmft.cmail.web.resBean.MailStatusBean;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.Streaming;
import rx.Observable;


public interface APIService {
    /**
     * 获取范围内的邮件状态
     * 同步邮件的已读,星标,是否已删除状态的接口
     *
     * @param email
     * @param smallerUid
     * @param largerUid
     * @return
     */
    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @GET("mail/proxy/{email}/box/mailState/range")
    Call<BaseRes<List<MailStatusRes>>> getMailListState(@Path("email") String email, @Query
            ("boxName") String boxName,
                                                        @Query
                                                                ("smallerUid") long smallerUid,
                                                        @Query
                                                                ("largerUid") long
                                                                largerUid);

    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @GET("mail/proxy/domains")
    Call<BaseRes> getMailDomains();


    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @GET("mail/proxy/{email}/box/mail/new/{uid}")
    Call<BaseRes<Boolean>> hasNewMailRequest(@Path("uid") long uid, @Path("email") String email,
                                             @Query
            ("boxName") String boxName);

    /**
     * 获取邮箱账号状态
     *
     * @param mail
     * @return
     */
    @GET("mail/proxy/{email}/status")
    Call<BaseRes<MailStatusBean>> getMailStatus(@Path("email") String mail);


    /**
     * 获取账号邮件夹列表
     *
     * @param email 邮箱账号
     * @return
     */
    @GET("mail/proxy/{mail}/boxes")
    Call<BaseRes<List<MailBox>>> getMailBox(@Path("mail") String email);


    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @GET("mail/proxy/{email}/boxes/map")
    Call<BaseRes> getMailBoxMap(@Path("email") String email);


    /**
     * 绑定
     *
     * @param bindAccountReq
     * @return
     */
    @POST("mail/proxy/bind")
    Observable<BaseRes<String>> bindMailAccount(@Body BindAccountReq bindAccountReq);


    /**
     * 获取用户已绑定的邮箱账号
     */
    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @GET("mail/proxy/user/accounts")
    Call<BaseRes<List<String>>> bindedMailList();

    /**
     * 解绑
     *
     * @param mail
     * @return
     */
    @DELETE("mail/proxy/{email}/unbind")
    Observable<BaseRes<String>> unBindMainAccount(@Path("email") String mail);

    /**
     * 冻结邮箱账号
     *
     * @param mail
     * @return
     */
    @POST("mail/proxy/{email}/freeze")
    Call<BaseRes> freezeMail(@Path("email") String mail);

    /**
     * 解冻邮箱账号
     *
     * @param mail
     * @return
     */
    @POST("mail/proxy/{email}/unfreeze")
    Call<BaseRes> unfreeze(@Path("email") String mail);


    /**
     * 获取邮件夹下邮件头信息列表
     *
     * @param email    邮箱账号
     * @param boxName  邮件夹名称
     * @param fetchUid
     * @return
     */
    @GET("mail/proxy/{email}/box/mailHeader")
    Observable<BaseRes<List<MailHeader>>> getMailHeader(
            @Path("email") String email,
            @Query("boxName") String boxName, @Query("mode") int mode,
            @Query("fetchUid") long fetchUid, @Query("fetchSize") int fetchSize);

    @GET("mail/proxy/{email}/box/mailHeader")
    Call<BaseRes<List<MailHeader>>> simpleGetHeaders(
            @Path("email") String email,
            @Query("boxName") String boxName, @Query("mode") int mode,
            @Query("fetchUid") long fetchUid, @Query("fetchSize") int fetchSize);

    /**
     * 移动邮件
     *
     * @param email
     * @param moveEmailReq
     * @return
     */
    @POST("mail/proxy/{email}/box/mail/move")
    Observable<BaseRes<String>> moveEmail(@Path("email") String email, @Body MoveEmailReq
            moveEmailReq);

    /**
     * @param email
     * @return
     */
//    @POST("mail/proxy/{email}/box/rename")
//    Observable<BaseRes> rename(@Path("email") String email, @Body Map<String, String> param);

//    @POST("mail/proxy/{email}/box/create")
//    Observable<BaseRes> createFolder(@Path("email") String email, @Body Map<String, String>
// param);

    /**
     * 删除邮件夹
     *
     * @param email
     * @param boxName
     * @return
     */
    @HTTP(method = "DELETE", path = "mail/proxy/{email}/box/delete", hasBody = true)
    Observable<BaseRes<String>> deleteFolder(@Path("email") String email, @Query("boxName")
            String boxName);

    /**
     * 清空邮件夹
     *
     * @param email
     * @param boxName
     * @return
     */
    @HTTP(method = "DELETE", path = "mail/proxy/{email}/box/mail/clear", hasBody = true)
    Observable<BaseRes<String>> clearFolder(@Path("email") String email, @Query("boxName") String
            boxName);

    /**
     * 删除邮件
     *
     * @param email
     * @param boxName
     * @param uidList
     * @return
     */
    @HTTP(method = "DELETE", path = "mail/proxy/{email}/box/mail/delete", hasBody = true)
    Observable<BaseRes<String>> deleteMail(@Path("email") String email, @Query("boxName") String
            boxName, @Body List<Long> uidList);


    /**
     * 标记邮件夹全部已读/未读
     *
     * @param email
     * @return
     */
    @POST("mail/proxy/{email}/box/seen")
    Observable<BaseRes<String>> modifyFolderStatus(@Path("email") String email, @Query("boxName")
            String boxName, @Query("mode") int mode);

    //-----------------------------------mail-fetch-controller 邮件获取
    //根据uid获取邮件内容
    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @GET("mail/proxy/{email}/box/mail/{uid}")
    Call<BaseRes<MailContentRes>> getMailContent(@Path("email") String email, @Path("uid") long
            uid, @Query("boxName") String boxName);


    //下载附件
    @Streaming
    @GET("mail/proxy/{email}/box/{uid}/attachment/{attachmentIndex}")
    Call<ResponseBody> getMailAttachMent(@Path("uid") long uid, @Path("attachmentIndex") int
            attachmentIndex, @Path("email") String email, @Query("boxName") String boxName);


    //取消邮件
    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @POST("mail/proxy/{email}/cancel")
    Call<BaseRes> cancel(@Path("email") String email, @Body RequestBody requestBody);


    @Multipart
    @POST("mail/proxy/{email}/send")
    Call<BaseRes> mailSend(@Path("email") String email, @Part("mailSendDTOJson") RequestBody
            requestBody, @Part()
                                   List<MultipartBody.Part> parts);

    /**
     * 标记邮件星标状态
     *
     * @param email
     * @param boxName
     * @param mode
     * @param uidList
     * @return
     */
    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @POST("mail/proxy/{email}/box/mail/flag")
    Call<BaseRes<String>> setFlag(@Path("email") String email, @Query("boxName")
            String boxName, @Query("mode") int mode, @Body List<Long> uidList);


    /**
     * 标记为已读\未读
     *
     * @return
     */
    @POST("mail/proxy/{email}/box/mail/seen")
    Call<BaseRes<String>> modifyMailStatus(@Path("email") String email, @Query("boxName")
            String boxName, @Query("mode") int mode, @Body List<Long> uidList);

}