package com.cmft.cmail.waltz;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.cmft.cmail.Cmail;
import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.utils.Constant;
import com.cmft.waltz.core.Waltz;

import org.json.JSONException;
import org.json.JSONObject;


import static com.cmft.cmail.utils.Constant.CALLBACK;
import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.FAILED;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.NET_ERROR_CODE;
import static com.cmft.cmail.utils.Constant.RESULT;
import static com.cmft.cmail.utils.Constant.SUCCESS;


/**
 *  和华尔兹交互，以及'原生-JS沟通'日志
 */
public class CallJsUtils {

    private static void callJs(Context context, String responseId, JSONObject body, String option) {
        try {

            CmailCenter.logger.warning(Constant.TAG, "{原生返JS}  " + "【msg】  " + body.toString() +
                    "【option】 "
                    + option);
            Waltz.getSingleton().postNotification(context, Constant.HANDLE_NATIVE_NAME, body,
                    option);

//            LocalBroadcastManager broadcastManager = LocalBroadcastManager.getInstance(context);
//            Intent intent = new Intent(Constant.NOTICE_NAME);
//            intent.putExtra("data", ret.toString());
//            broadcastManager.sendBroadcast(intent);
        } catch (Exception e) {
            CmailCenter.logger.debug(Constant.TAG, e.getMessage());
        }
    }

    public static void callJs(JSONObject body, String option) {
        if (TextUtils.isEmpty(option)) {
            CmailCenter.logger.debug(Constant.TAG, " CallJsUtils.callJs 内 option 为空 不返回h5 ");
        } else {
            try {
                JSONObject jsonObject = new JSONObject(option);
                String responseId = jsonObject.getString(CALLBACK);
                CallJsUtils.callJs(CmailCenter.getContext(), responseId, body, option);
            } catch (Exception e) {
                CmailCenter.logger.debug(Constant.TAG, "报错-> " + e.toString());
                e.printStackTrace();
            }
        }

    }


    public static void bindResultToJs(boolean success, String option) {
        if (TextUtils.isEmpty(option)) {
            return;
        }
        try {
            JSONObject body = new JSONObject();
            body.put(CODE, success ? 0 : NET_ERROR_CODE);
            body.put(MESSAGE, success ? SUCCESS : FAILED);
            body.put(RESULT, success ? SUCCESS : FAILED);
            CallJsUtils.callJs(body, option);
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

    public static void failResultToJs(int code, String msg, String option) {
        if (TextUtils.isEmpty(option)) {
            return;
        }
        try {
            JSONObject body = new JSONObject();
            body.put(CODE, code);
            body.put(MESSAGE, msg);
            body.put(RESULT, "");
            CallJsUtils.callJs(body, option);
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }


    static void printJSCall(String data, String
            option) {
        CmailCenter.logger.warning(Constant.TAG, "{JS调用原生}  " + "【msg】 " + data + "【option】 "
                + option);

    }
}
