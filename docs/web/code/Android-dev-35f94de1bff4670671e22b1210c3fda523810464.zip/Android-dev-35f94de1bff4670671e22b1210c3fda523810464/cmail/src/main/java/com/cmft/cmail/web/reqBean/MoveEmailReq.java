package com.cmft.cmail.web.reqBean;

import java.util.List;

public class MoveEmailReq {

    /**
     * sourceBoxName : string
     * targetBoxName : string
     * uidList : [0]
     */

    private String sourceBoxName;
    private String targetBoxName;
    private List<Long> uidList;

    public String getSourceBoxName() {
        return sourceBoxName;
    }

    public void setSourceBoxName(String sourceBoxName) {
        this.sourceBoxName = sourceBoxName;
    }

    public String getTargetBoxName() {
        return targetBoxName;
    }

    public void setTargetBoxName(String targetBoxName) {
        this.targetBoxName = targetBoxName;
    }

    public List<Long> getUidList() {
        return uidList;
    }

    public void setUidList(List<Long> uidList) {
        this.uidList = uidList;
    }
}
