package com.cmft.cmail;

public interface CallBack<T> {
    void onSuccess(T response);

    void onFail(String string);
}