package com.cmft.cmail.core;

import com.cmft.android.sandbox.crypter.CallBack;
import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.web.RetrofitService;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.logging.Logger;

public class HelperSandbox {
    private static final String TAG = Constant.TAG + "." + "Sandbox";

    private static HelperSandbox instance;
    private final ILogger logger;

    public HelperSandbox(ILogger logger) {
        this.logger = logger;
    }

    public static HelperSandbox getInstance(ILogger logger) {
        if (null == instance) {
            synchronized (RetrofitService.class) {
                if (null == instance) {
                    instance = new HelperSandbox(logger);
                }
            }
        }
        return instance;
    }


    public void saveSanboxPassword(String email, String password) {
        String saveDir = saveToSandBox(email, Constant.SANDBOX_ACCOUNT);
        String fileName = email;
//        File attachmentFile = new File(attachmentPath);
//        String fileName = attachmentFile.getName();
        logger.debug(TAG, "账号" + email + "-密码" + password + " saveToSandBox " +
                "->  " + saveDir + File
                .separator +
                fileName);
//        FileInputStream inputStream = new FileInputStream(attachmentPath);
        final InputStream inputStream = new ByteArrayInputStream(password.getBytes());
        SandBox.getInstance().encrypt(saveDir + File.separator +
                        fileName,
                inputStream, new CallBack<String>() {
                    @Override
                    public void onSuccess(String s) {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (Exception e) {
                                e.printStackTrace();
                                logger.error(TAG, "报错-> " + e.toString());
                            }
                        }
                    }

                    @Override
                    public void onFail(String s) {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (Exception e) {
                                e.printStackTrace();
                                logger.error(TAG, "报错-> " + e.toString());
                            }
                        }
                    }
                });

    }

    public void getSanboxPassword(final String email,
                                  final CallBack<String>
                                          callBack) {
        String saveDir = saveToSandBox(email, Constant.SANDBOX_ACCOUNT);
        String fileName = email;
        File file = new File(saveDir + File
                .separator +
                fileName);
//        String fileName = attachmentFile.getName();
        logger.debug(TAG, " saveToSandBox ->  " + file.getAbsolutePath());
        if (SandBox.getInstance().isEncrypted(file)) {
            final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            SandBox.getInstance().decrypt(saveDir + File.separator + fileName, outputStream, new
                    CallBack<Boolean>() {


                        @Override
                        public void onSuccess(Boolean aBoolean) {
                            try {
                                String password = outputStream.toString(Constant.CHARSET_NAME);
                                logger.debug(TAG, "账号:" + email + "  ,密码: " + outputStream
                                        .toString
                                                (Constant.CHARSET_NAME));
                                callBack.onSuccess(password);
                                if (null != outputStream) {
                                    outputStream.close();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                callBack.onFail(e.toString());
                                logger.error(TAG, "报错-> " + e.toString());
                            }
                        }

                        @Override
                        public void onFail(String s) {
                            try {
                                if (null != outputStream) {
                                    outputStream.close();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                callBack.onFail(e.toString());
                                logger.error(TAG, "报错-> " + e.toString());
                            }
                        }
                    });
        } else {
            callBack.onFail("file is not Ecrtpt");
        }


    }


    public String saveToSandBox(String currentMailAccount, String
            folderName) {
        String saveDir = File.separator + currentMailAccount;
        String[] parentDir = folderName.split(File.separator);
        if (parentDir.length > 0) {
            saveDir = saveDir + File.separator + parentDir[0];
        }
        return saveDir;
    }


}
