package com.cmft.cmail.db.model;

import java.util.List;

public class PullFreshDataBean {

    /**
     * fetchList : [{"boxname":"INBOX","fetchPage":1,"fetchSize":20,"mailAccount":"daliyjb11@163.com","fetchUid":1568252643}]
     * fetchType : 0
     * mode : 1
     */

    private int fetchType;
    private int mode;
    private List<GetMailDataBean> fetchList;

    public int getFetchType() {
        return fetchType;
    }

    public void setFetchType(int fetchType) {
        this.fetchType = fetchType;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public List<GetMailDataBean> getFetchList() {
        return fetchList;
    }

    public void setFetchList(List<GetMailDataBean> fetchList) {
        this.fetchList = fetchList;
    }


}
