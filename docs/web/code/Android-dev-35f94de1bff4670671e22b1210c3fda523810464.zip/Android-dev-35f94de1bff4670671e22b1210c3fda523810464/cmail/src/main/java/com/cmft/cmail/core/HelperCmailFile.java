package com.cmft.cmail.core;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.cmail.CallBack;
import com.cmft.cmail.NetCallBack;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailAttachmentDao;
import com.cmft.cmail.db.model.MailAttachment;
import com.cmft.cmail.utils.ActivityTracker;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.waltz.CallJsUtils;
import com.cmft.cmail.web.RetrofitService;
import com.cmft.cmail.web.resBean.BaseRes;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

import static com.cmft.cmail.utils.Constant.COCOPAN_INDEX;
import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.LOCALFILE_INDEX;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.NET_FAILED;
import static com.cmft.cmail.utils.Constant.RESULT;
import static com.cmft.cmail.utils.Constant.TAKEPHOTO_INDEX;
import static com.cmft.cmail.utils.Constant.TDS_INDEX;
import static com.cmft.cmail.waltz.CallJsUtils.failResultToJs;

public class HelperCmailFile extends HelperCmail {
    private static final String TAG = Constant.TAG + "." + "File";

    @Override
    public synchronized void init(Context context, RetrofitService retrofit, CmailDatabase
            database, ThreadPoolExecutor executor, ILogger logger, HelperSandbox sandbox) {
        super.init(context, retrofit, database, executor, logger, sandbox);
    }


    public void deleteUploadFile(String mailAccount, JSONObject mailBody, JSONArray
            appendAttachment, final String option) {

        getRetrofit().deleteUploadFile(mailAccount, mailBody, new NetCallBack<BaseRes>() {
            @Override
            public void onSuccess(BaseRes response) {
                String s = new Gson().toJson(response);
                JSONObject body = new JSONObject();
                try {
                    body.put(RESULT, s);
                    CallJsUtils.callJs(body, option);

                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }

            @Override
            public void onFail(BaseRes response) {
                failResultToJs(response.code, response.message, option);

            }

            @Override
            public void onError() {
                failResultToJs(Constant.NET_ERROR_CODE, NET_FAILED, option);

            }


        });
    }


    public void addAttachment(String mailAccount, int type, String option, String
            attachmentPath) {

        switch (type) {
            case LOCALFILE_INDEX:
                //本地文件
                pickFile(mailAccount, type, option, attachmentPath);
                break;
            case TAKEPHOTO_INDEX:
                // 拍照
                pickFile(mailAccount, type, option, attachmentPath);
                break;
            case COCOPAN_INDEX:
                //coco盘
                break;
            case TDS_INDEX:
                //tds盘
                break;
            default:
                break;

        }


    }

    private void pickFile(String mailAccount, int type, final String option, final String
            attachmentPath) {
        if (TextUtils.isEmpty(attachmentPath)) {
            //第二个参数是需要申请的权限
            if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission
                    .WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            } else {
                String[] perms = {"android.permission.WRITE_EXTERNAL_STORAGE"};
                ActivityCompat.requestPermissions(ActivityTracker.get().tryGetTopActivity(), perms, 0);
                getLogger().debug(TAG, "permisson.WRITE_EXTERNAL_STORAGE is not " +
                        "granted");
                return;
            }
            if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission
                    .CAMERA) == PackageManager.PERMISSION_GRANTED) {
            } else {
                String[] perms = {"android.permission.CAMERA"};
                ActivityCompat.requestPermissions(ActivityTracker.get().tryGetTopActivity(), perms, 0);
                getLogger().debug(TAG, "permisson.CAMERA is not granted");
                return;
            }

            final Intent intent = new Intent(getContext(), AlbumActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("mailAccount", mailAccount);
            intent.putExtra("option", option);
            intent.putExtra("type", type);
            ActivityCompat.startActivity(getContext(), intent, null);
        } else {
            final File attachmentFile = new File(attachmentPath);
            getLogger().debug(TAG, "选择的文件-和目标目录 文件大小：" + attachmentFile.length());

            String saveDir = getSandbox().saveToSandBox(mailAccount, Constant
                    .SANDBOX_ACC_ATTACHMNET);
            String fileName = attachmentFile.getName();
            File encreptedFile = new File(saveDir + File
                    .separator +
                    fileName);
            getLogger().debug(TAG, " 选择的文件- 目标目录saveToSandBox fileid ->  " + encreptedFile
                    .getAbsolutePath());

            try {
                if (attachmentPath.contains(com.cmft.android.sandbox.crypter.core.Constant.SANDBOX_ROOT)) {
                    getLogger().debug(TAG, "选择的文件-在sandbox  :" + attachmentPath);
                    getLogger().debug(TAG, "选择的文件-getContext().getPackageName()  :" + getContext().getPackageName());

                    if (attachmentPath.contains(getContext().getPackageName()) && attachmentPath.contains(Constant.SANDBOX_ACC_ATTACHMNET)) {
                        // 在本应用内
                        getLogger().debug(TAG, "选择的文件-在在本应用的 sandbox 内");

                        try {
                            JSONObject body = new JSONObject();
                            JSONObject file = new JSONObject();
                            file.put("fileName", attachmentFile.getName());
                            file.put("fileSize", attachmentFile.length());
                            file.put("filePath", encreptedFile.getAbsolutePath());
                            body.put("result", file.toString());
                            body.put(CODE, 0);
                            body.put(MESSAGE, "success");
                            CallJsUtils.callJs(body, option);
                        } catch (Exception e) {
                            e.printStackTrace();
                            getLogger().error(TAG, "报错-> " + e.toString());
                        }
                    } else {
                        getLogger().debug(TAG, "选择的文件-在在本应用的 sandbox 外");

                        try {
                            FileInputStream inStream = new FileInputStream(attachmentFile);
                            FileOutputStream outStream = SandBox.getInstance().getInnerOutStream
                                    (encreptedFile.getAbsolutePath());
                            FileChannel in = inStream.getChannel();
                            FileChannel out = outStream.getChannel();
                            in.transferTo(0, in.size(), out);

                            if (null != inStream) {
                                inStream.close();
                            }
                            if (null != in) {
                                in.close();
                            }
                            if (null != outStream) {
                                outStream.close();
                            }
                            if (null != out) {
                                out.close();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            getLogger().error(TAG, "报错-> " + e.toString());
                        } finally {
                            try {
                                JSONObject body = new JSONObject();
                                JSONObject file = new JSONObject();
                                file.put("fileName", attachmentFile.getName());
                                file.put("fileSize", attachmentFile.length());
                                getLogger().debug(TAG, "选择的文件-和目标目录 不同" + attachmentFile.length());
                                file.put("filePath", encreptedFile.getAbsolutePath());
                                body.put("result", file.toString());
                                body.put(CODE, 0);
                                body.put(MESSAGE, "success");
                                CallJsUtils.callJs(body, option);
                            } catch (Exception e) {
                                e.printStackTrace();
                                getLogger().error(TAG, "报错-> " + e.toString());
                            }

                        }
                    }
                } else {
                    getLogger().debug(TAG, "选择的文件-sandbox没加密  :" + attachmentPath);
                    final FileInputStream inputStream = new FileInputStream(attachmentPath);
                    SandBox.getInstance().encrypt(encreptedFile.getAbsolutePath(),
                            inputStream, new com.cmft.android.sandbox.crypter.CallBack<String>() {
                                @Override
                                public void onSuccess(String result) {

                                    try {
                                        JSONObject body = new JSONObject();
                                        JSONObject file = new JSONObject();
                                        file.put("fileName", attachmentFile.getName());
                                        file.put("fileSize", attachmentFile.length());
                                        file.put("filePath", result);
                                        body.put("result", file.toString());
                                        body.put(CODE, 0);
                                        body.put(MESSAGE, "success");
                                        CallJsUtils.callJs(body, option);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        getLogger().error(TAG, "报错-> " + e.toString());
                                    }
                                }

                                @Override
                                public void onFail(String s) {
                                }
                            });
                }


            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }


    }

    public boolean deleteAttachment(String mailAccount, String fileName, String option) {
        String saveDir = getSandbox().saveToSandBox(mailAccount, Constant.SANDBOX_ACC_ATTACHMNET);
        getLogger().debug(TAG, " delete file Path ->  " + saveDir + File
                .separator +
                fileName);
        return SandBox.getInstance().delete(saveDir + File
                .separator +
                fileName);
    }

    public void openSendAttachment(String mailAccount, String fileName, String filePath, String
            option) {
        String saveDir = getSandbox().saveToSandBox(mailAccount, Constant.SANDBOX_ACC_ATTACHMNET);
        getLogger().debug(TAG, " open SendAttachment Path ->  " + saveDir + File
                .separator +
                fileName);
        openAttachment(saveDir + File
                .separator +
                fileName, option);
    }


    public void openAttachment(String path, String option) {
        File file = new File(path);
        if (SandBox.getInstance().isWPSFile(file)) {
            getLogger().debug(TAG, "是WPS文件");
            CallJsUtils.bindResultToJs(true, option);
            SandBox.getInstance().openWithWPS(path);
        } else if (SandBox.getInstance().isImagelFile(file.getAbsolutePath())) {
            showImageActivity(path);
            CallJsUtils.bindResultToJs(true, option);
        } else {
            getLogger().debug(TAG, "不是WPS文件");
            CallJsUtils.bindResultToJs(false, option);
        }
    }

    private void showImageActivity(String path) {
        final Intent intent = new Intent(getContext(), ImageActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("path", path);
        ActivityCompat.startActivity(getContext(), intent, null);
    }

    public void saveAndOpenAttachment(final String email, final String folderName, final long uid,
                                      int attachmentIndex, final String fileName, final String
                                              option) {

        getRetrofit().getMailAttachMent(email, folderName, uid, attachmentIndex, new
                CallBack<InputStream>() {

                    @Override
                    public void onSuccess(final InputStream response) {
//                final String result = saveToSandBox(email, response, folderName,
//                        uid + File.separator + fileName);


                        final String saveDir = getSandbox().saveToSandBox(email, folderName);
                        final String attachmentFile = uid + File.separator + fileName;
                        getLogger().debug(TAG, " saveToSandBox ->  " + saveDir + File
                                .separator +
                                attachmentFile);
                        getExecutor().execute(new Runnable() {
                            @Override
                            public void run() {
                                SandBox.getInstance().encrypt(saveDir + File.separator +
                                                attachmentFile,
                                        response, new com.cmft.android.sandbox.crypter.CallBack<String>() {
                                            @Override
                                            public void onSuccess(final String result) {
                                                if (response != null) {
                                                    try {
                                                        response.close();
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                        getLogger().error(TAG, "报错-> " + e.toString());
                                                    }
                                                }


                                                MailAttachmentDao mailAttachmentDao = getDatabase
                                                        ().mailAttachmentDao();
                                                List<MailAttachment> mailAttachment =
                                                        mailAttachmentDao
                                                                .getMailAttachment
                                                                        (uid, folderName, email,
                                                                                fileName);
                                                if (mailAttachment != null && mailAttachment.size
                                                        () != 0) {
                                                    mailAttachment.get(0).filePath = result;
                                                    getDatabase().mailAttachmentDao()
                                                            .update(mailAttachment.get(0));
                                                    openAttachment(result, option);

                                                } else {
                                                    CallJsUtils.bindResultToJs(false, option);
                                                }


                                            }

                                            @Override
                                            public void onFail(String s) {
                                                if (response != null) {
                                                    try {
                                                        response.close();
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                        getLogger().error(TAG, "报错-> " + e.toString());
                                                    }
                                                }
                                            }
                                        });

                            }
                        });
                    }

                    @Override
                    public void onFail(String string) {
                        failResultToJs(Constant.NET_ERROR_CODE, NET_FAILED, option);
                    }
                });

    }

    public void readAttachment(String sandBoxPath) {
        SandBox.getInstance().openWithWPS(sandBoxPath);
    }

    @Override
    public String getTag() {
        return HelperCmailFile.TAG;
    }
}
