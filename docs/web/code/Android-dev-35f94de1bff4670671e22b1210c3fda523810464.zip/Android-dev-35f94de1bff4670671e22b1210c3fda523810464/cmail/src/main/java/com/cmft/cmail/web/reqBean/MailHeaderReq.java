package com.cmft.cmail.web.reqBean;

public class MailHeaderReq {
    private String email;
    private String boxName;
    private int mode;
    private int fetchUid;
    private int fetchSize;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBoxName() {
        return boxName;
    }

    public void setBoxName(String boxName) {
        this.boxName = boxName;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public int getFetchUid() {
        return fetchUid;
    }

    public void setFetchUid(int fetchUid) {
        this.fetchUid = fetchUid;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }
}
