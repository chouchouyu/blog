package com.cmft.cmail.db.helper;

import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailFolderDao;
import com.cmft.cmail.db.model.MailFolder;

import java.util.List;

public class MailFolderHelper {
    private static MailFolderHelper mInstance = new MailFolderHelper();

    private MailFolderHelper() {
    }

    public static MailFolderHelper getInstance() {
        return mInstance;
    }

    private MailFolderDao getMailFolderDao() {
        return CmailDatabase.getInstance(CmailCenter.getContext()).getMailFolderDao();
    }

    /**
     * 插入单个文件夹
     *
     * @param mailFolder
     * @return
     */
    public long insertFolder(MailFolder mailFolder) {
        return getMailFolderDao().insertFolder(mailFolder);
    }

    /**
     * 插入文件夹列表
     *
     * @param list
     * @return
     */
    public long[] insertFolder(List<MailFolder> list) {
        return getMailFolderDao().insertFolder(list);
    }

    /**
     * 删除某个文件夹
     *
     * @param mailFolder
     */
    public void deleteFolder(MailFolder mailFolder) {
        getMailFolderDao().deleteFolder(mailFolder);
    }

    /**
     * 获取邮箱账号的文件夹列表
     *
     * @param mailAccount
     * @return
     */
    public List<MailFolder> queryFolders(String mailAccount) {
        return getMailFolderDao().queryByMailAccount(mailAccount);
    }

    /**
     * 获取多个邮箱账号的文件夹列表
     *
     * @param mailAccounts
     * @return
     */
    public List<MailFolder> queryFolders(List<String> mailAccounts) {
        return getMailFolderDao().queryByMailAccounts(mailAccounts);
    }

    public MailFolder queryByMailAccounts(String mailAccount, String boxName) {
        return getMailFolderDao().queryByMailAccounts(mailAccount, boxName);
    }

    public void updateFolder(MailFolder folder) {
        getMailFolderDao().updateFolderList(folder);
    }
}
