package com.cmft.cmail.waltz;

import android.webkit.JavascriptInterface;

import com.cmft.cmail.waltz.delegate.MailLoginDelegate;

import java.io.Serializable;

public class MailLogin implements Serializable {

    private MailLoginDelegate mMailLoginDelegate;

    public MailLogin(MailLoginDelegate mailLoginDelegate) {
        mMailLoginDelegate = mailLoginDelegate;
    }

    /**
     * 绑定邮箱账号
     *
     * @param data {"mailAccount":"test"}
     */
    @JavascriptInterface
    public void bindMailAccount(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.bindMailAccount(data, option);
    }

    /**
     * 设置主账号
     *
     * @param data {"mailAccount":"test"}
     */
    @JavascriptInterface
    public void setMainMailAccount(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.setMainMailAccount(data, option);
    }

    /**
     * 设置签名
     *
     * @param data
     */
    @JavascriptInterface
    public void setMailSignature(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.setMailSignature(data, option);
    }

    /**
     * 获取账号列表，列表数据从coco来
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void getMailAccountList(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.getMailAccountList(data, option);
    }

    /**
     * 添加常用语
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void addIdiomList(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.addIdiomList(data, option);
    }


    /**
     * 移动邮件到指定邮件夹
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void moveMailBox(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.moveMailBox(data, option);
    }

    /**
     * 邮件夹下邮件头历史列表
     */
    @JavascriptInterface
    public void getMailDataList(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.getMailDataList(data, option);
    }

    /**
     * 修改邮件状态
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void modifyMailStatus(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.modifyMailStatus(data, option);
    }

    /**
     * 修改邮件夹状态
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void modifyFolderStatus(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.modifyFolderStatus(data, option);
    }

    /**
     * 获取邮件夹列表
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void getMailBox(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.getMailBox(data, option);
    }

    /**
     * 修改账号状态 停用、启用、解绑
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void useMailAccount(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.useMailAccount(data, option);
    }

    /**
     * 删除、清空邮件夹
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void deleteOrClearBoxName(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.deleteOrClearBoxName(data, option);
    }

    /**
     * 彻底删除邮件
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void deleteMailList(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.deleteMailList(data, option);
    }


    @JavascriptInterface
    public void getAllAccountMailBox(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.getAllAccountMailBox(data, option);
    }

    @JavascriptInterface
    public void pullRefreshMailList(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.pullRefreshMailList(data, option);
    }

    @JavascriptInterface
    public void addAttachment(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.addAttachment(data, option);
    }


    @JavascriptInterface
    public void supportMailDomain(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.supportMailDomain(data, option);
    }


    @JavascriptInterface
    public void getUserInfo(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.getUserInfo(data, option);
    }

    @JavascriptInterface
    public void recentContacts(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        mMailLoginDelegate.recentContacts(data, option);
    }
}
