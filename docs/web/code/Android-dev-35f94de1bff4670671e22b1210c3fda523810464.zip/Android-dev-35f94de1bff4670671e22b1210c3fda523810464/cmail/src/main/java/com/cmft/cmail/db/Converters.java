package com.cmft.cmail.db;

import com.cmft.cmail.db.model.AppendAttachmentBean;
import com.cmft.cmail.db.model.ReceiverBCCBean;
import com.cmft.cmail.db.model.ReceiverBean;
import com.cmft.cmail.db.model.ReceiverCCBean;
import com.cmft.cmail.utils.CmailUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import android.arch.persistence.room.TypeConverter;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * @author ex-yangjb001
 * @date 2018/4/12.
 */
public class Converters {
    @TypeConverter
    public static String listToString(List<ReceiverBean> receiver) {
        return new Gson().toJson(receiver);
    }

    @TypeConverter
    public static List<ReceiverBean> stringToReceiverBean(String s) {
        Type type = new TypeToken<List<ReceiverBean>>() {
        }.getType();
        return new Gson().fromJson(s, type);
    }

    @TypeConverter
    public static LinkedHashMap<String, String> stringToReceiverMap(String s) {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        if (!TextUtils.isEmpty(s)) {
            try {
                JSONArray jsonArray = new JSONArray(s);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                    Iterator<String> it = jsonObject.keys();
                    while (it.hasNext()) {
                        String key = it.next();
                        String value = jsonObject.getString(key);
                        map.put(key, value);
                    }
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }finally {
                return map;
            }

        }else {
            return map;
        }

    }


    @TypeConverter
    public static String listBCCToString(List<ReceiverBCCBean> receiverBCC) {
        return new Gson().toJson(receiverBCC);
    }


    @TypeConverter
    public static List<ReceiverBCCBean> stringToBBCBean(String s) {
        Type type = new TypeToken<List<ReceiverBCCBean>>() {
        }.getType();
        return new Gson().fromJson(s, type);
    }


    @TypeConverter
    public static String listCCToString(List<ReceiverCCBean> receiverCC) {
        return new Gson().toJson(receiverCC);
    }


    @TypeConverter
    public static String mapCCToString(LinkedHashMap<String, String> receiverCC) {
        JSONArray jsonArray = new JSONArray();
        for (Map.Entry<String, String> entry : receiverCC.entrySet()) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put(entry.getKey(), entry.getValue());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            jsonArray.put(jsonObject);
        }
        return jsonArray.toString();
    }

    @TypeConverter
    public static List<ReceiverCCBean> stringToCCBean(String s) {
        Type type = new TypeToken<List<ReceiverCCBean>>() {
        }.getType();
        return new Gson().fromJson(s, type);
    }

    @TypeConverter
    public static String listStringToString(List<String> list) {
        return new Gson().toJson(list);
    }

    @TypeConverter
    public static List<String> StringToListStr(String s) {
        Type type = new TypeToken<List<String>>() {
        }.getType();
        return new Gson().fromJson(s, type);
    }

    @TypeConverter
    public static String listIntToString(List<Integer> list) {
        return new Gson().toJson(list);
    }

    @TypeConverter
    public static List<Integer> StringToListInt(String s) {
        Type type = new TypeToken<List<Integer>>() {
        }.getType();
        return new Gson().fromJson(s, type);
    }

    @TypeConverter
    public static List<AppendAttachmentBean> stringToAppendAtt(String s) {
        Type type = new TypeToken<List<AppendAttachmentBean>>() {
        }.getType();
        return new Gson().fromJson(s, type);
    }

    @TypeConverter
    public static String AppendAttToString(List<AppendAttachmentBean> list) {
        return new Gson().toJson(list);
    }
}