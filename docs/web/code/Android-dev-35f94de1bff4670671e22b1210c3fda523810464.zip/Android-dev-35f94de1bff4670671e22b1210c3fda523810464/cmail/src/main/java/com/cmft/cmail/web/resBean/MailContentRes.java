package com.cmft.cmail.web.resBean;

import java.util.List;

public class MailContentRes {


    /**
     * uid : 1564744180
     * subject : test send related
     * sender : {"name":"","address":"testapp01@cmrhic.com"}
     * receiver : [{"name":"","address":"testapp01@cmrhic.com"}]
     * receiverCC : [{"name":"","address":"testapp20@cmrhic.com"}]
     * receiverBCC : []
     * content : <p>
     * <strong><span style="font-family:&quot;Microsoft YaHei&quot;;font-size:16px;color:#E53333;
     * " class="ke-content-forecolor">for test</span></strong>
     * </p>
     * <p>
     * <strong><span style="font-family:&quot;Microsoft YaHei&quot;;font-size:16px;color:#E53333;
     * " class="ke-content-forecolor"><img
     * src="cid:CID-2575d2c9-680b-4daa-a12e-f1d76c45b50e@IQSZ0D0467" alt=""><img
     * src="cid:CID-14565b22-27c5-44a8-aba7-7f2d37a65602@IQSZ0D0467" alt=""><br>
     * </span></strong>
     * </p>
     * <p>
     * <br>
     * </p>
     * <p>
     * <br>
     * </p>
     * timestamp : 1565782007000
     * attachmentCount : 1
     * attachmentFile : [{"name":"pom.xml","size":8431,"index":0}]
     * relatedItem : [{"contentId":"CID-2575d2c9-680b-4daa-a12e-f1d76c45b50e@IQSZ0D0467",
     * "contentType":"image/jpeg","name":"aaa.jpg"},
     * {"contentId":"CID-14565b22-27c5-44a8-aba7-7f2d37a65602@IQSZ0D0467",
     * "contentType":"image/jpeg","name":"bbb.jpg"}]
     * unseen : false
     * flagged : false
     */

    private int uid;
    private String subject;
    private SenderBean sender;
    private String content;
    private long timestamp;
    private int attachmentCount;
    private boolean unseen;
    private boolean flagged;
    private List<ReceiverBean> receiver;
    private List<ReceiverBean> receiverCC;
    private List<ReceiverBean> receiverBCC;
    private List<AttachmentFileBean> attachmentFile;
//    private List<RelatedItemBean> relatedItem;

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public SenderBean getSender() {
        return sender;
    }

    public void setSender(SenderBean sender) {
        this.sender = sender;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public int getAttachmentCount() {
        return attachmentCount;
    }

    public void setAttachmentCount(int attachmentCount) {
        this.attachmentCount = attachmentCount;
    }

    public boolean isUnseen() {
        return unseen;
    }

    public void setUnseen(boolean unseen) {
        this.unseen = unseen;
    }

    public boolean isFlagged() {
        return flagged;
    }

    public void setFlagged(boolean flagged) {
        this.flagged = flagged;
    }

    public List<ReceiverBean> getReceiver() {
        return receiver;
    }

    public void setReceiver(List<ReceiverBean> receiver) {
        this.receiver = receiver;
    }

    public List<ReceiverBean> getReceiverCC() {
        return receiverCC;
    }

    public void setReceiverCC(List<ReceiverBean> receiverCC) {
        this.receiverCC = receiverCC;
    }

    public List<ReceiverBean> getReceiverBCC() {
        return receiverBCC;
    }

    public void setReceiverBCC(List<ReceiverBean> receiverBCC) {
        this.receiverBCC = receiverBCC;
    }

    public List<AttachmentFileBean> getAttachmentFile() {
        return attachmentFile;
    }

    public void setAttachmentFile(List<AttachmentFileBean> attachmentFile) {
        this.attachmentFile = attachmentFile;
    }

//    public List<RelatedItemBean> getRelatedItem() {
//        return relatedItem;
//    }
//
//    public void setRelatedItem(List<RelatedItemBean> relatedItem) {
//        this.relatedItem = relatedItem;
//    }


    @Override
    public String toString() {
        return "MailContentRes{" +
                "uid=" + uid +
                ", subject='" + subject + '\'' +
                ", sender=" + sender +
                ", content='" + content + '\'' +
                ", timestamp=" + timestamp +
                ", attachmentCount=" + attachmentCount +
                ", unseen=" + unseen +
                ", flagged=" + flagged +
                ", receiver=" + receiver +
                ", receiverCC=" + receiverCC +
                ", receiverBCC=" + receiverBCC +
                ", attachmentFile=" + attachmentFile +
                '}';
    }

    public static class SenderBean {
        /**
         * name :
         * address : testapp01@cmrhic.com
         */

        private String name;
        private String address;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        @Override
        public String toString() {
            return "SenderBean{" +
                    "name='" + name + '\'' +
                    ", address='" + address + '\'' +
                    '}';
        }
    }

    public static class ReceiverBean {
        /**
         * name :
         * address : testapp01@cmrhic.com
         */

        private String name;
        private String address;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        @Override
        public String toString() {
            return "ReceiverBean{" +
                    "name='" + name + '\'' +
                    ", address='" + address + '\'' +
                    '}';
        }
    }

//    public static class ReceiverCCBean {
//        /**
//         * name :
//         * address : testapp20@cmrhic.com
//         */
//
//        private String name;
//        private String address;
//
//        public String getName() {
//            return name;
//        }
//
//        public void setName(String name) {
//            this.name = name;
//        }
//
//        public String getAddress() {
//            return address;
//        }
//
//        public void setAddress(String address) {
//            this.address = address;
//        }
//    }

    public static class AttachmentFileBean {
        /**
         * name : pom.xml
         * size : 8431
         * index : 0
         */

        private String name;
        private int size;
        private int index;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        @Override
        public String toString() {
            return "AttachmentFileBean{" +
                    "name='" + name + '\'' +
                    ", size=" + size +
                    ", index=" + index +
                    '}';
        }
    }

//    public static class RelatedItemBean {
//        /**
//         * contentId : CID-2575d2c9-680b-4daa-a12e-f1d76c45b50e@IQSZ0D0467
//         * contentType : image/jpeg
//         * name : aaa.jpg
//         */
//
//        private String contentId;
//        private String contentType;
//        private String name;
//
//        public String getContentId() {
//            return contentId;
//        }
//
//        public void setContentId(String contentId) {
//            this.contentId = contentId;
//        }
//
//        public String getContentType() {
//            return contentType;
//        }
//
//        public void setContentType(String contentType) {
//            this.contentType = contentType;
//        }
//
//        public String getName() {
//            return name;
//        }
//
//        public void setName(String name) {
//            this.name = name;
//        }
//    }
}
