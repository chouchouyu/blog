package com.cmft.cmail.db.dao;

import android.arch.persistence.db.SupportSQLiteQuery;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.RawQuery;

import com.cmft.cmail.db.model.MailAccount;
import com.cmft.cmail.db.model.MailAttachment;
import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.db.model.RecentContactModel;
import com.cmft.cmail.db.model.TobeSend;

import java.util.List;

@Dao
public interface RecentContactDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(RecentContactModel recentContact);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long[] insert(List<RecentContactModel> recentContactList);

    @RawQuery(observedEntities = RecentContactModel.class)
    List<RecentContactModel> query(SupportSQLiteQuery query);

    @Query("SELECT * FROM  recentContacts where address = :address")
    RecentContactModel query(String address);

}
