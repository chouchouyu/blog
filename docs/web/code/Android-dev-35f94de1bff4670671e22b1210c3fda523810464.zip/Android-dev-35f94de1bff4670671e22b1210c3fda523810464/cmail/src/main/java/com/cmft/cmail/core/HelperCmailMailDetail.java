package com.cmft.cmail.core;

import android.arch.persistence.db.SimpleSQLiteQuery;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.android.sandbox.crypter.utils.EncryptData;
import com.cmft.cmail.CallBack;
import com.cmft.cmail.Cmail;
import com.cmft.cmail.NetCallBack;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailHeaderDao;
import com.cmft.cmail.db.dao.RecentContactDao;
import com.cmft.cmail.db.dao.TobeSendDao;
import com.cmft.cmail.db.model.MailAttachment;
import com.cmft.cmail.db.model.MailDetail;
import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.db.model.MailInfo;
import com.cmft.cmail.db.model.RecentContactModel;
import com.cmft.cmail.db.model.TobeSend;
import com.cmft.cmail.utils.CmailUtils;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.waltz.CallJsUtils;
import com.cmft.cmail.web.RetrofitService;
import com.cmft.cmail.web.resBean.BaseRes;
import com.cmft.cmail.web.resBean.MailContentRes;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadPoolExecutor;

import static com.cmft.cmail.utils.Constant.ACCOUNT_FAILED;
import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.NET_FAILED;
import static com.cmft.cmail.utils.Constant.RESULT;
import static com.cmft.cmail.utils.Constant.SANDBOX_READ_SERVICE;
import static com.cmft.cmail.utils.Constant.SANDBOX_WRITE_SERVICE;
import static com.cmft.cmail.waltz.CallJsUtils.failResultToJs;

public class HelperCmailMailDetail extends HelperCmail {
    private static final String TAG = Constant.TAG + "." + "Detail";

    @Override
    public synchronized void init(Context context, RetrofitService retrofit, CmailDatabase
            database, ThreadPoolExecutor executor, ILogger logger, HelperSandbox sandbox) {
        super.init(context, retrofit, database, executor, logger, sandbox);

    }

    /**
     * 发送邮件
     *
     * @param email
     * @param jsonObject
     * @param option
     */
    public void mailSend(final String email, final JSONObject jsonObject, final String
            option) {
        try {
            long uid = 0;
            if (jsonObject.has("originUid")) {
                uid = jsonObject.getLong("originUid");
                if (uid > Integer.MAX_VALUE) {
                    int trimUid = (int) (uid / 1000);
                    jsonObject.remove("originUid");
                    jsonObject.put("originUid", trimUid);
                }
            }

            final Set<RecentContactModel> contactList = detractContacts(jsonObject);

            final List<File> fileNameList = new ArrayList<>();
//            String saveDir = saveToSandBox(email, Constant.SANDBOX_ACC_ATTACHMNET);

            if (jsonObject.has("appendAttachment")) {
//            fileNameList.add(new File
//                    ("/storage/emulated/0/DCIM/Camera/IMG_20190120_205246.jpg"));
                JSONArray jsonArray = jsonObject.getJSONArray("appendAttachment");
                for (int i = 0; i < jsonArray.length(); i++) {
                    if (jsonArray.getJSONObject(i) != null) {
                        String fileName = jsonArray.getJSONObject(i).getString("filePath");
//                        getLogger().debug(TAG, " saveToSandBox ->  " + saveDir + File
//                                .separator +
//                                fileName);
                        fileNameList.add(new File(fileName));
                    }
                }
                jsonObject.remove("appendAttachment");
            }
            if (jsonObject.has("appendRelatedItem")) {
                jsonObject.remove("appendRelatedItem");
            }

            if (!jsonObject.has("originAttachment")) {
                jsonObject.remove("originBoxName");
                jsonObject.remove("originUid");
            }

            if (!jsonObject.has("receiver")) {
                JSONArray jsonArray = new JSONArray();
                JSONObject receiver = new JSONObject();
                receiver.put("address", "");
                receiver.put("name", "");
                jsonArray.put(receiver);
                jsonObject.put("receiver", jsonArray);
            }
            String writeUrl = null;
            if (jsonObject.has("writeUrl") && !TextUtils.isEmpty(jsonObject.getString("writeUrl")
            )) {
                writeUrl = jsonObject.getString("writeUrl");
                getLogger().debug(TAG, "发送大邮件时urlPath" + writeUrl);
                Uri writeUri = Uri.parse(writeUrl);
                String path = writeUri.getQueryParameter("path");
                String name = writeUri.getQueryParameter("name");
//                uid = Long.parseLong(name.substring(0, name.indexOf(".txt")));
                final long finalUid = uid;
                final String finalWriteUrl = writeUrl;
                sandboxDecrypt(path + File.separator + name, new CallBack<String>() {


                    @Override
                    public void onSuccess(String decreptContent) {
                        try {
                            jsonObject.remove("content");
                            jsonObject.put("content", decreptContent);
                            if (jsonObject.has("urlPath")) {
                                jsonObject.remove("urlPath");
                            }
                            if (jsonObject.has("writeUrl")) {
                                jsonObject.remove("writeUrl");
                            }


                            sendMailRequest(email, jsonObject, option, finalUid, contactList,
                                    fileNameList,
                                    finalWriteUrl);
                        } catch (Exception e) {
                            e.printStackTrace();
                            getLogger().error(TAG, "报错-> " + e.toString());
                        }

                    }

                    @Override
                    public void onFail(String string) {
                        getLogger().error(TAG, "报错-> " + string);

                    }
                });


            } else {
                if (jsonObject.has("urlPath")) {
                    jsonObject.remove("urlPath");
                }
                if (jsonObject.has("writeUrl")) {
                    jsonObject.remove("writeUrl");
                }


                sendMailRequest(email, jsonObject, option, uid, contactList, fileNameList,
                        writeUrl);
            }


        } catch (Exception e) {
            e.printStackTrace();
            getLogger().error(TAG, "报错-> " + e.toString());
        }
    }

    private void sendMailRequest(final String email, final JSONObject jsonObject, final String
            option, long uid, final Set<RecentContactModel> contactList, List<File> fileNameList,
                                 String writeUrl) {
        final long finalUid = uid;
        final String finalWriteUrl = writeUrl;
        getRetrofit().mailSend(email, jsonObject, fileNameList, new NetCallBack<BaseRes>() {
            @Override
            public void onSuccess(BaseRes response) {
                String s = new Gson().toJson(response);
                JSONObject body = new JSONObject();
                try {
                    body.put(CODE, 0);
                    body.put(RESULT, s);
                    CallJsUtils.callJs(body, option);
                    if (response.code == 0) {
                        deleteFromDrafts(email, finalUid);

                        getExecutor().execute(new Runnable() {
                            @Override
                            public void run() {
                                RecentContactDao dao = getDatabase().getRecentContactDao();
                                List<RecentContactModel> insertContactList = new ArrayList<>();
                                for (RecentContactModel contact : contactList) {
                                    String address = contact.getAddress();
//                                    if (TextUtils.equals(address, email)) {
//                                        continue;
//                                    }
                                    if (dao.query(address) == null) {
                                        insertContactList.add(contact);
                                    }
                                }
                                dao.insert(insertContactList);
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }

            @Override
            public void onFail(BaseRes response) {

                TobeSend tobeSend = new TobeSend();
                tobeSend.setMailAccount(email);
                tobeSend.setMailBody(new Gson().fromJson(jsonObject.toString(), TobeSend
                        .MailBody.class));
                TobeSend.MailBody mailBody = tobeSend.getMailBody();
                long timeMillis = CmailUtils.currentTimeMillis();
                if (mailBody.getOriginUid() == 0) {
                    int originUid = (int) (timeMillis / 1000);
                    mailBody.setOriginUid(originUid);
                    mailBody.setMailTime(timeMillis);
                }
                saveMailToDrafts(tobeSend, finalWriteUrl, "");
                if (response.code == Constant.ACCOUNTEXPIRE_ERROR_CODE) {
                    failResultToJs(response.code, ACCOUNT_FAILED, option);
                } else {
                    failResultToJs(response.code, response.message, option);
                }
            }

            @Override
            public void onError() {

                failResultToJs(Constant.NET_ERROR_CODE, NET_FAILED, option);
            }

        });
    }

    /**
     * 从待发送中删除
     *
     * @param email
     * @param originUid
     */
    private void deleteFromDrafts(final String email, final long originUid) {
        //从草稿箱中删除对应邮件
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                //删除邮件头列表

                getLogger().debug(TAG, "deleteFromDrafts : email-" + email +
                        "，originUid ：" + originUid);
                //删除邮件
                TobeSendDao tobeSendDao =
                        getDatabase().getTobeSendDao();
                TobeSend tobeSend = tobeSendDao.queryTobeSend(email, originUid);
                if (tobeSend != null) {
                    tobeSendDao.deleteTobeSend(tobeSend);
                    getLogger().debug(TAG, "deleteFromDrafts-删除成功");
                } else {
                    getLogger().debug(TAG, "deleteFromDrafts-未找到该草稿");
                }
            }
        });
    }


    private Set<RecentContactModel> detractContacts(JSONObject jsonObject) throws JSONException {
        Set<RecentContactModel> contactList = new HashSet<>();
        if (jsonObject.has("receiver")) {
            JSONArray jsonArray = jsonObject.getJSONArray("receiver");
            for (int i = 0; i < jsonArray.length(); i++) {
                RecentContactModel recentContact = new RecentContactModel();
                recentContact.setAddress(jsonArray.getJSONObject(i).getString("address"));
                recentContact.setName(jsonArray.getJSONObject(i).getString("name"));
                recentContact.setTimestamp(System.currentTimeMillis());
                contactList.add(recentContact);
            }
        }
        if (jsonObject.has("receiverBCC")) {
            JSONArray jsonArray = jsonObject.getJSONArray("receiverBCC");
            for (int i = 0; i < jsonArray.length(); i++) {
                RecentContactModel recentContact = new RecentContactModel();
                recentContact.setAddress(jsonArray.getJSONObject(i).getString("address"));
                recentContact.setName(jsonArray.getJSONObject(i).getString("name"));
                recentContact.setTimestamp(System.currentTimeMillis());
                contactList.add(recentContact);
            }
        }
        if (jsonObject.has("receiverCC")) {
            JSONArray jsonArray = jsonObject.getJSONArray("receiverCC");
            for (int i = 0; i < jsonArray.length(); i++) {
                RecentContactModel recentContact = new RecentContactModel();
                recentContact.setAddress(jsonArray.getJSONObject(i).getString("address"));
                recentContact.setName(jsonArray.getJSONObject(i).getString("name"));
                recentContact.setTimestamp(System.currentTimeMillis());
                contactList.add(recentContact);
            }
        }
        return contactList;
    }

    /**
     * 最近联系人
     *
     * @param keyword
     * @param limit
     * @param option
     */
    public void recentContacts(String keyword, int limit, String option) {
        try {
            SimpleSQLiteQuery querysql = new
                    SimpleSQLiteQuery("SELECT * FROM recentContacts WHERE address LIKE '%" +
                    keyword +
                    "%' OR name LIKE '%" + keyword + "%' " + "ORDER BY timestamp DESC LIMIT " + limit);
            getLogger().debug(TAG, "recentContacts:sql: " +
                    querysql.getSql());
            List<RecentContactModel> list = getDatabase().getRecentContactDao().query(querysql);
            JSONObject body = new JSONObject();
            Gson gson = new Gson();

            body.put(CODE, 0);
            body.put(MESSAGE, "success");
            body.put(RESULT, gson.toJson(list).toString());
            CallJsUtils.callJs(body, option);
        } catch (Exception e) {
            e.printStackTrace();
            getLogger().error(TAG, "报错-> " + e.toString());
        }
    }

    public void saveMailContent(final String email, final String boxName, final long uid,
                                final NetCallBack<BaseRes<MailContentRes>> callBack) {
        getRetrofit().getMailContent(email, boxName, uid, new NetCallBack<BaseRes<MailContentRes>>
                () {
            @Override
            public void onSuccess(final BaseRes<MailContentRes> response) {
                getLogger().debug(TAG, "saveMailContent-:" + response.result.toString());
                final MailContentRes mailDetailRes = response.result;
                Gson gson = new Gson();

                final MailInfo mailDetail = new MailInfo();

                mailDetail.mailUid = mailDetailRes.getUid();

                mailDetail.folderName = boxName;
                //发送人
                mailDetail.sender = mailDetailRes.getSender().getAddress();
                mailDetail.sendername = mailDetailRes.getSender().getName();
                mailDetail.receivers = gson.toJson(mailDetailRes.getReceiver());
                mailDetail.receiversBCC = gson.toJson(mailDetailRes.getReceiverBCC());
                mailDetail.receiversCC = gson.toJson(mailDetailRes.getReceiverCC());
                mailDetail.subject = mailDetailRes.getSubject();


                mailDetail.timeStamp = mailDetailRes.getTimestamp();
                mailDetail.hasReaded = mailDetailRes.isUnseen();
                mailDetail.hasflaged = mailDetailRes.isFlagged();
                if (mailDetailRes.getAttachmentCount() > 0) {
                    mailDetail.hasAttachments = true;
                } else {
                    mailDetail.hasAttachments = false;
                }
//

                saveMailContentTOSandBox(email, mailDetailRes.getUid(),
                        boxName, mailDetailRes.getContent(), new CallBack<String>() {
                            @Override
                            public void onSuccess(final String filePath) {
                                if (!TextUtils.isEmpty(filePath)) {
                                    mailDetail.emailPath = filePath;
                                    mailDetail.emailSize = SandBox.getInstance().getFileSize(new
                                            File
                                            (mailDetail.emailPath));
                                }
                                //存入当前mailAccount
                                mailDetail.mailAccount = email;
                                mailDetail.id = EncryptData.MD5_32(mailDetail.mailUid +
                                        mailDetail.folderName +
                                        mailDetail.mailAccount);

                                final List<MailAttachment> dbAttachmentList = new ArrayList<>();

                                // ------------------保存附件信息----------
                                if (mailDetail.hasAttachments) {
                                    List<MailContentRes.AttachmentFileBean> attachmentFileList =
                                            mailDetailRes
                                                    .getAttachmentFile();
                                    for (int i = 0; i < attachmentFileList.size(); i++) {
                                        MailAttachment mailAttachmentBean = new MailAttachment();
                                        mailAttachmentBean.attachmentName = attachmentFileList
                                                .get(i).getName();
                                        mailAttachmentBean.fileSize = attachmentFileList.get(i)
                                                .getSize();
                                        mailAttachmentBean.attachmentIndex = i;
                                        mailAttachmentBean.mailUid = mailDetailRes.getUid();
                                        mailAttachmentBean.folderName = boxName;
                                        mailAttachmentBean.mailAccount = email;
                                        mailAttachmentBean.id = EncryptData.MD5_32
                                                (mailAttachmentBean.mailUid +
                                                        mailAttachmentBean.folderName +
                                                        mailAttachmentBean
                                                                .attachmentName + mailAttachmentBean
                                                        .attachmentIndex +
                                                        mailAttachmentBean.mailAccount);
                                        mailAttachmentBean.mailId = EncryptData.MD5_32
                                                (mailAttachmentBean.mailUid +
                                                        mailAttachmentBean.folderName +
                                                        mailAttachmentBean.mailAccount);
                                        dbAttachmentList.add(mailAttachmentBean);
                                    }

                                }
                                getExecutor().execute(new Runnable() {
                                    @Override
                                    public void run() {
                                        getLogger().debug(TAG, " 邮件详情存储" + mailDetail.toString());
                                        getDatabase().getMailInfoDao().insert(mailDetail);
                                        if (dbAttachmentList.size() > 0) {
                                            getDatabase().mailAttachmentDao().insert
                                                    (dbAttachmentList);
                                        }
                                        callBack.onSuccess(response);
                                    }
                                });

                            }

                            @Override
                            public void onFail(String string) {
                                callBack.onError();
                            }
                        });


            }

            @Override
            public void onFail(BaseRes<MailContentRes> response) {
                callBack.onFail(response);
            }

            @Override
            public void onError() {
                callBack.onError();
            }


        });
    }


    /**
     * 保存到待发送
     *
     * @param tobeSend
     * @param writeUrl
     * @param option
     */
    public void saveMailToDrafts(final TobeSend tobeSend, final String writeUrl, final String
            option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                final JSONObject body = new JSONObject();
                try {
                    final TobeSend.MailBody mailBody = tobeSend.getMailBody();
                    final TobeSendDao tobeSendDao = getDatabase().getTobeSendDao();
                    if (TextUtils.isEmpty(writeUrl)) {
                        //修改mailPath
                        saveMailContentTOSandBox(tobeSend.getMailAccount
                                        (), mailBody.getMailTime(),
                                Constant.TobeSent, mailBody.getContent(), new CallBack<String>() {
                                    @Override
                                    public void onSuccess(String contentPath) {
                                        try {
                                            mailBody.setContent(contentPath);
                                            long fileSize = SandBox.getInstance().getFileSize(new
                                                    File
                                                    (contentPath));
                                            mailBody.setSize(fileSize);
                                            tobeSend.setMailBody(mailBody);
                                            //修改mailPath
                                            if (tobeSend != null) {
                                                tobeSendDao.insertTobeSend(tobeSend);
                                            }
                                            body.put(CODE, 0);
                                            body.put(MESSAGE, "success");
                                            body.put(RESULT, mailBody.getOriginUid());
                                            getLogger().debug("OriginUid", "OriginUid" + mailBody
                                                    .getOriginUid());

                                            CallJsUtils.callJs(body, option);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                            getLogger().error(TAG, "报错-> " + e.toString());
                                        }

                                    }

                                    @Override
                                    public void onFail(String string) {
                                        getLogger().error(TAG, "报错-> " + string);

                                    }
                                });

                    } else {
                        Uri writeUri = Uri.parse(writeUrl);
                        String path = writeUri.getQueryParameter("path");
                        String name = writeUri.getQueryParameter("name");
                        String filePath = path + File.separator + name;
                        mailBody.setContent(filePath);
                        //存大小
                        long fileSize = SandBox.getInstance().getFileSize(new File
                                (filePath));
                        mailBody.setSize(fileSize);
                        tobeSend.setMailBody(mailBody);
                        //修改mailPath
                        if (tobeSend != null) {
                            tobeSendDao.insertTobeSend(tobeSend);
                        }
                        body.put(CODE, 0);
                        body.put(MESSAGE, "success");
                        body.put(RESULT, mailBody.getOriginUid());
                        getLogger().debug("OriginUid", "OriginUid" + mailBody.getOriginUid());
                        CallJsUtils.callJs(body, option);
                    }


                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }
        });
    }

    private void saveMailContentTOSandBox(String email, long mailUID, String boxName, String
            mailContent, final CallBack<String> callBack) {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(mailContent.getBytes());
        String saveDir = getSandbox().saveToSandBox(email, boxName);
        String mailFile = mailUID + ".txt";
        getLogger().debug(TAG, " saveToSandBox ->  " + saveDir + File.separator +
                mailFile);
        SandBox.getInstance().encrypt(saveDir + File.separator + mailFile, inputStream, new com
                .cmft.android
                .sandbox.crypter.CallBack<String>() {

            @Override
            public void onSuccess(String content) {
                getLogger().debug(TAG, "上下一封邮件附件 成功" + content);
                callBack.onSuccess(content);
            }

            @Override
            public void onFail(String s) {
                getLogger().debug(TAG, "上下一封邮件附件 失败" + s);

                callBack.onFail(s);
            }
        });
    }


    public void getMailContent(final String mailAccount, final String folderName, final long uid,
                               final CallBack<MailDetail> callBack) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                String id = EncryptData.MD5_32(uid + folderName +
                        mailAccount);
                getLogger().debug(TAG, "查看mailContent后修改文件unSeen为false" + "；mailUId " +
                        uid + ";" +
                        "boxName " + folderName + ";mailAccount " + mailAccount);


                MailDetail mailDetail = getDatabase().getMailInfoDao().getMailAllInfo(id);
                MailHeaderDao mailHeaderDao = getDatabase().getMailHeaderDao();
                if (mailHeaderDao != null) {
                    MailHeader mailHeaders = mailHeaderDao.queryMailHeader(mailAccount,
                            folderName, uid);
                    if (mailHeaders != null) {
//                        mailHeaders.setUnseen(false);
                        if (mailDetail != null) {
                            mailHeaders.setAttachmentCount(mailDetail.mailAttachmentList.size());
                        }
                        mailHeaderDao.updateMailHeader(mailHeaders);
                    }
                }

                if (null == mailDetail) {
                    callBack.onFail(null);
                } else {
                    callBack.onSuccess(mailDetail);
                }

            }
        });
    }


    public void getMailBodyFromSandBox(String email, String boxName, long mailUid,
                                       final CallBack<String> callBack) {
        String saveDir = getSandbox().saveToSandBox(email, boxName);
        String mailFile = mailUid + ".txt";
        sandboxDecrypt(saveDir + File.separator +
                mailFile, new CallBack<String>() {
            @Override
            public void onSuccess(String response) {
                callBack.onSuccess(response);
            }

            @Override
            public void onFail(String string) {
                callBack.onFail(string);
            }
        });
    }

    public void sandboxDecrypt(final String path, final CallBack<String> callBack) {
        getLogger().debug(TAG, " saveToSandBox ->  " + path);
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {

                final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

//                if (SandBox.isEncrypted(new File(path))) {
                SandBox.getInstance().decrypt(path, outputStream, new com.cmft.android.sandbox
                        .crypter
                        .CallBack<Boolean>() {


                    @Override
                    public void onSuccess(Boolean aBoolean) {
                        try {
                            String mailBodyStr = outputStream.toString(Constant.CHARSET_NAME);
                            getLogger().debug(TAG, "邮件正文-> " + outputStream.toString(Constant
                                    .CHARSET_NAME));
                            callBack.onSuccess(mailBodyStr);
                        } catch (Exception e) {
                            e.printStackTrace();
                            getLogger().error(TAG, "报错-> " + e.toString());
                        }
                        if (outputStream != null) {
                            try {
                                outputStream.close();
                            } catch (Exception e) {
                                e.printStackTrace();
                                getLogger().error(TAG, "报错-> " + e.toString());
                            }
                        }
                    }

                    @Override
                    public void onFail(String s) {
                        if (outputStream != null) {
                            try {
                                outputStream.close();
                            } catch (Exception e) {
                                e.printStackTrace();
                                getLogger().error(TAG, "报错-> " + e.toString());
                            }
                        }
                        callBack.onFail(s);
                    }
                });
//
            }
        });

    }

    public String getContentURL(String email, String boxName, String mailUid) {
        String saveDir = getSandbox().saveToSandBox(email, boxName);
        String mailFile = mailUid + ".txt";
        return String.format(SANDBOX_READ_SERVICE, SandBox.getInstance().getToken(), saveDir,
                mailFile);
    }


    public String getWriteContentUrl(String email, long mailUid) {
        String saveDir = getSandbox().saveToSandBox(email, Constant.TobeSent);
        String mailFile = mailUid + ".txt";
        return String.format(SANDBOX_WRITE_SERVICE, SandBox.getInstance().getToken(), saveDir,
                mailFile);
    }

    @Override
    public String getTag() {
        return HelperCmailMailDetail.TAG;
    }


}
