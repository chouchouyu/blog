package com.cmft.cmail.db.model;

import android.support.annotation.NonNull;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.util.Log;

@Entity(tableName = "MailAccount")
public class MailAccount {

    @NonNull
    private String userId;

//    private String avatarUrl;

//    private int gender;

//    private String nickName;

    @PrimaryKey
    @NonNull
    public String mailAccount;

    private String lastLogin;

    private String company;

    /**
     * 0：自定义
     * 1：平台提供
     */
    private int accountType;
    /**
     * 0：未激活
     * 1：已激活
     * 2：已停用
     */
    private int accountState;

    private boolean masterAccount;

    private long existCount;

    private long recentCount;

    private long expungeCount;

    private String mailSign;

//    public String getAvatarUrl() {
//        return avatarUrl;
//    }
//
//    public void setAvatarUrl(String avatarUrl) {
//        this.avatarUrl = avatarUrl;
//    }
//
//    public int getGender() {
//        return gender;
//    }
//
//    public void setGender(int gender) {
//        this.gender = gender;
//    }
//
//    public String getNickName() {
//        return nickName;
//    }
//
//    public void setNickName(String nickName) {
//        this.nickName = nickName;
//    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMailAccount() {
        return mailAccount;
    }

    public void setMailAccount(String mailAccount) {
        this.mailAccount = mailAccount;
    }

    public String getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(String lastLogin) {
        this.lastLogin = lastLogin;
    }

    public int getAccountType() {
        return accountType;
    }

    public void setAccountType(int accountType) {
        this.accountType = accountType;
    }

    public int getAccountState() {
        return accountState;
    }

    public void setAccountState(int accountState) {
        this.accountState = accountState;
    }

    public boolean isMasterAccount() {
        return masterAccount;
    }

    public void setMasterAccount(boolean masterAccount) {
        this.masterAccount = masterAccount;
    }

    public long getExistCount() {
        return existCount;
    }

    public void setExistCount(long existCount) {
        this.existCount = existCount;
    }

    public long getRecentCount() {
        return recentCount;
    }

    public void setRecentCount(long recentCount) {
        this.recentCount = recentCount;
    }

    public long getExpungeCount() {
        return expungeCount;
    }

    public void setExpungeCount(long expungeCount) {
        this.expungeCount = expungeCount;
    }

    public String getMailSign() {
        return mailSign;
    }

    public void setMailSign(String mailSign) {
        this.mailSign = mailSign;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    @Override
    public String toString() {
        return "MailAccount{" +
                "userId='" + userId + '\'' +
//                ", avatarUrl='" + avatarUrl + '\'' +
//                ", gender=" + gender +
//                ", nickName='" + nickName + '\'' +
                ", mailAccount='" + mailAccount + '\'' +
                ", lastLogin='" + lastLogin + '\'' +
                ", company='" + company + '\'' +
                ", accountType=" + accountType +
                ", accountState=" + accountState +
                ", masterAccount=" + masterAccount +
                ", existCount=" + existCount +
                ", recentCount=" + recentCount +
                ", expungeCount=" + expungeCount +
                ", mailSign='" + mailSign + '\'' +
                '}';
    }
}
