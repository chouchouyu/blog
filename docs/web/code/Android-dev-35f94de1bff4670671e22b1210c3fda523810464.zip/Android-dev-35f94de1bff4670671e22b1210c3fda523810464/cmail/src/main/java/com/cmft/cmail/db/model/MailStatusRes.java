package com.cmft.cmail.db.model;

public class MailStatusRes {

    /**
     * flagged : false
     * uid : 0
     * unseen : false
     */

    private boolean flagged;
    private int uid;
    private boolean unseen;

    public boolean isFlagged() {
        return flagged;
    }

    public void setFlagged(boolean flagged) {
        this.flagged = flagged;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public boolean isUnseen() {
        return unseen;
    }

    public void setUnseen(boolean unseen) {
        this.unseen = unseen;
    }
}
