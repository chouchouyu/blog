package com.cmft.cmail.web;


import android.text.TextUtils;
import android.util.Log;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.android.sandbox.crypter.utils.EncryptData;
import com.cmft.cmail.CallBack;
import com.cmft.cmail.NetCallBack;
import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.core.HelperCmailAccount;
import com.cmft.cmail.core.HelperSandbox;
import com.cmft.cmail.core.HelperSynLazyTask;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailHeaderDao;
import com.cmft.cmail.db.dao.MailPhrasesDao;
import com.cmft.cmail.db.helper.MailAccountHelper;
import com.cmft.cmail.db.helper.MailFolderHelper;
import com.cmft.cmail.db.model.GetMailDataBean;
import com.cmft.cmail.db.model.MailAccount;
import com.cmft.cmail.db.model.MailFolder;
import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.db.model.MailPhrases;
import com.cmft.cmail.db.model.MailStatusRes;
import com.cmft.cmail.db.model.SYNModel;
import com.cmft.cmail.utils.CmailInfoSp;
import com.cmft.cmail.utils.CmailUtils;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.utils.SSLSocketFactoryUtils;
import com.cmft.cmail.waltz.CallJsUtils;
import com.cmft.cmail.web.reqBean.BindAccountReq;
import com.cmft.cmail.web.reqBean.MoveEmailReq;
import com.cmft.cmail.web.resBean.BaseRes;
import com.cmft.cmail.web.resBean.MailBox;
import com.cmft.cmail.web.resBean.MailContentRes;
import com.cmft.cmail.web.resBean.MailStatusBean;
import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;


import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import rx.Observer;
import rx.schedulers.Schedulers;

import static com.cmft.cmail.core.CmailCenter.accountPasswordMap;
import static com.cmft.cmail.utils.CmailUtils.isEmail;
import static com.cmft.cmail.utils.Constant.ACCOUNT_FAILED;
import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.DEFAULT_SIGN;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.RESULT;
import static com.cmft.cmail.waltz.CallJsUtils.bindResultToJs;
import static com.cmft.cmail.waltz.CallJsUtils.failResultToJs;


public class RetrofitService {
    private static final String TAG = Constant.TAG + "." + "okhttp";
    private final ILogger logger;
    private final HelperSandbox sandbox;

    private Retrofit retrofit;
    private APIService service;
    private static volatile RetrofitService instance;

    OkHttpClient mOkhttpClient;

    HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor(
            new HttpLoggingInterceptor.Logger() {
                @Override
                public void log(String message) {
                    logger.debug(TAG, " okhttp -> " + message);
                }
            });


    public static RetrofitService getInstance(String baseUrl, final Boolean openLog, final
    boolean innerEnv, ILogger logger, HelperSandbox sandbox) {
        if (null == instance) {
            synchronized (RetrofitService.class) {
                if (null == instance) {
                    instance = new RetrofitService(baseUrl, openLog, innerEnv, logger, sandbox);
                }
            }
        }
        return instance;
    }


    private RetrofitService(String baseUrl, final Boolean openLog, final boolean innerEnv,
                            ILogger logger, final HelperSandbox sandbox) {
        this.logger = logger;
        this.sandbox = sandbox;
        OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient.Builder();
        okHttpClientBuilder
                .sslSocketFactory(SSLSocketFactoryUtils.createSSLSocketFactory(),
                        SSLSocketFactoryUtils.createTrustAllManager())
                .hostnameVerifier(new SSLSocketFactoryUtils.TrustAllHostnameVerifier())
                .retryOnConnectionFailure(true)
                .connectTimeout(30, TimeUnit.MINUTES)
                .readTimeout(30, TimeUnit.MINUTES)
                .writeTimeout(30, TimeUnit.MINUTES)
                .addInterceptor(new Interceptor() {
                    @Override
                    public okhttp3.Response intercept(Chain chain) throws IOException {
                        Request request = chain.request();
                        final Request.Builder builder = request.newBuilder();
                        if (!TextUtils.isEmpty(CmailInfoSp.getDeviceId())) {
                            builder.addHeader("e-device", CmailInfoSp.getDeviceId());
                        }
                        if (innerEnv) {
                            builder.addHeader("Cookie", CmailInfoSp.getSession());
                        }

                        for (final String path : request.url().pathSegments()) {
                            Log.d("账号", "path" + path);
                            if (isEmail(path)) {
                                if (accountPasswordMap.containsKey(path)) {
                                    builder.addHeader("e-auth", accountPasswordMap.get(path));
                                } else {
                                    sandbox.getSanboxPassword(path, new com.cmft.android.sandbox
                                            .crypter
                                            .CallBack<String>() {

                                        @Override
                                        public void onSuccess(String password) {
                                            if (!TextUtils.isEmpty(password)) {
                                                Log.d("账号", "password" + password);
                                                if (accountPasswordMap.containsKey(path)) {
                                                    accountPasswordMap.remove(path);
                                                }
                                                accountPasswordMap.put(path, password);
                                                builder.addHeader("e-auth", password);
                                            }
                                        }

                                        @Override
                                        public void onFail(String s) {

                                        }
                                    });

                                }
                            }
                        }

                        request =
                                builder.build();
                        okhttp3.Response response = chain.proceed(request);

//                        Log.d("okhttp","|response.code: " + response.code());//502
//                        Log.d("okhttp","|response.body: " + response.body().string());
// 后端服务502，请确认后台服务是否正常

                        //存入Session
                        if (innerEnv) {
                            String session = response.header("Set-Cookie");
                            if (session != null) {
                                CmailInfoSp.setSession(session);
                            }
                        }
                        return response;
                    }
                });
        if (!innerEnv) {
            okHttpClientBuilder.addInterceptor(new RedirectInterceptor())
                    .followRedirects(false)  //禁制OkHttp的重定向操作，我们自己处理重定向
                    .followSslRedirects(false);
        }

        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);//这里可以选择拦截级别
        okHttpClientBuilder.addInterceptor(loggingInterceptor);


        if (null == mOkhttpClient) {
            mOkhttpClient = okHttpClientBuilder.build();
        }


        if (null == retrofit) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(mOkhttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                    .build();
        }


        if (null == service) {
            service = retrofit.create(APIService.class);
        }
    }


    public void getMailContent(String email, String boxName, long uid, final
    NetCallBack<BaseRes<MailContentRes>> callback) {
        Call<BaseRes<MailContentRes>> call = service.getMailContent(email, uid, boxName);
        call.enqueue(new Callback<BaseRes<MailContentRes>>() {
            @Override
            public void onResponse(Call<BaseRes<MailContentRes>> call,
                                   Response<BaseRes<MailContentRes>> response) {
                if (response.code() == Constant.SERVICE_ERROR_CODE) {
                    BaseRes<MailContentRes> baseRes = new BaseRes<>();
                    baseRes.code = response.code();
                    baseRes.message = CmailUtils.netErrorMsg(baseRes.code);
                    callback.onFail(baseRes);
                } else if (response.isSuccessful() && !TextUtils.isEmpty(response.body().message)) {
                    if (response.body().result != null) {
                        callback.onSuccess(response.body());
                    } else {
                        callback.onFail(response.body());
                    }
                } else {
                    callback.onError();
                }
            }

            @Override
            public void onFailure(Call<BaseRes<MailContentRes>> call, Throwable t) {
                Log.d("okhttp", "|response.邮件详情失败" + t.toString());
                callback.onError();
            }
        });
    }


    public void getMailAttachMent(String email, String boxName, long uid, int attachmentIndex,
                                  final CallBack<InputStream> callback) {
        Call<ResponseBody> call = service.getMailAttachMent(uid, attachmentIndex, email, boxName);


        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                try {
                    if (response.isSuccessful()) {
                        callback.onSuccess(response.body().byteStream());
                    } else {
                        callback.onFail(response.body().string());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error(TAG, "报错-> " + e.toString());
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                callback.onFail(t.getMessage().toString());
            }
        });
    }


    public void mailSend(final String email, JSONObject jsonObject,
                         List<File> appendAttachment,
                         final NetCallBack<BaseRes> callback) {
        final RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"),
                jsonObject.toString());

        List<MultipartBody.Part> parts = null;
        if (appendAttachment.size() != 0) {
            filesToMultipartBodyParts(appendAttachment, new CallBack<List<MultipartBody.Part>>() {

                @Override
                public void onSuccess(List<MultipartBody.Part> parts) {
                    mailSendRequest(email, callback, requestBody, parts);
                }

                @Override
                public void onFail(String string) {

                }
            });
//            filesToMultipartBodyParts(appendAttachment, new CallBack<List<MultipartBody.Part>>() {
//
//
//                @Override
//                public void onSuccess(List<MultipartBody.Part> response) {
//                    mailSendRequest(email, callback, requestBody, parts);
//                }
//
//                @Override
//                public void onFail(String string) {
//
//                }
//            });
        } else {
            mailSendRequest(email, callback, requestBody, parts);
        }

    }

    private void mailSendRequest(String email, final NetCallBack<BaseRes> callback, RequestBody
            requestBody, List<MultipartBody.Part> parts) {
        Call<BaseRes> call = service.mailSend(email, requestBody, parts);
        call.enqueue(new Callback<BaseRes>() {
            @Override
            public void onResponse(Call<BaseRes> call, Response<BaseRes> response) {
                if (response.raw().code() != 200) {
                    BaseRes baseRes = new BaseRes();
                    baseRes.code = response.raw().code();
                    baseRes.message = CmailUtils.netErrorMsg(baseRes.code);
                    callback.onFail(baseRes);
                } else if (response.isSuccessful()) {
                    if (response.body().result != null) {
                        callback.onSuccess(response.body());
                    } else {
                        callback.onFail(response.body());
                    }
                }else {
                    callback.onError();
                }
            }

            @Override
            public void onFailure(Call<BaseRes> call, Throwable t) {
                callback.onError();
            }
        });
    }


//    public List<MultipartBody.Part> filesToMultipartBodyParts(List<File> files) {
//        List<MultipartBody.Part> parts = new ArrayList<>(files.size());
//        for (File file : files) {
//            try {
//                RequestBody requestBody = RequestBody.create(MediaType.parse
//                        ("application/octet-stream"), file);
//
//                MultipartBody.Part part = MultipartBody.Part.createFormData("appendAttachment",
//                        URLEncoder.encode(file
//                                .getName(), Constant.CHARSET_NAME),
//                        requestBody);
//                parts.add(part);
//            } catch (UnsupportedEncodingException e) {
//                e.printStackTrace();
//                logger.error(TAG, "报错-> " + e.toString());
//            }
//        }
//        return parts;
//    }


    private void filesToMultipartBodyParts(final List<File> files,
                                           final CallBack<List<MultipartBody
                                                   .Part>> callBack) {
        final List<MultipartBody.Part> parts = new ArrayList<>(files.size());
        for (final File file : files) {
            if (SandBox.getInstance().isEncrypted(file)) {
                final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                SandBox.getInstance().decrypt(file.getAbsolutePath(), byteArrayOutputStream, new
                        com.cmft
                                .android.sandbox.crypter.CallBack<Boolean>() {


                            @Override
                            public void onSuccess(Boolean aBoolean) {
                                if (aBoolean == true) {
                                    try {
                                        RequestBody requestBody = RequestBody.create(MediaType.parse
                                                ("application/octet-stream"), byteArrayOutputStream
                                                .toByteArray());
                                        MultipartBody.Part part = MultipartBody.Part.createFormData
                                                ("appendAttachment", URLEncoder.encode(file
                                                                .getName(), Constant.CHARSET_NAME),
                                                        requestBody);
                                        parts.add(part);
                                        if (files.size() == parts.size()) {
                                            callBack.onSuccess(parts);
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        logger.error(TAG, "报错-> " + e.toString());
                                    }
                                }

                            }

                            @Override
                            public void onFail(String s) {
                                callBack.onFail(s);
                            }
                        });


            } else {
                try {
                    RequestBody requestBody = RequestBody.create(MediaType.parse
                            ("application/octet-stream"), file);

                    MultipartBody.Part part = MultipartBody.Part.createFormData("appendAttachment",
                            URLEncoder.encode(file
                                    .getName(), Constant.CHARSET_NAME),
                            requestBody);
                    parts.add(part);
                    if (files.size() == parts.size()) {
                        callBack.onSuccess(parts);
                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    logger.error(TAG, "报错-> " + e.toString());
                }
            }
        }
    }


    //由于okhttp header 中的 value 不支持 null, \n 和 中文这样的特殊字符,所以这里
//会首先替换 \n ,然后使用 okhttp 的校验方式,校验不通过的话,就返回 encode 后的字符串
//    private static String getValueEncoded(String value) throws UnsupportedEncodingException {
//        if (value == null) {
//            return "null";
//        }
//        String newValue = value.replace("\n", "");
//        for (int i = 0, length = newValue.length(); i < length; i++) {
//            char c = newValue.charAt(i);
//            if (c <= '\u001f' || c >= '\u007f') {
//                return URLEncoder.encode(newValue, Constant.CHARSET_NAME);
//            }
//        }
//        return newValue;
//    }


    public void deleteUploadFile(String mailAccount, JSONObject jsonObject, final
    NetCallBack<BaseRes> callback) {
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"),
                jsonObject.toString());
        Call<BaseRes> call = service.cancel(mailAccount, requestBody);
        call.enqueue(new Callback<BaseRes>() {
            @Override
            public void onResponse(Call<BaseRes> call, Response<BaseRes> response) {
                if (response.raw().code() != 200) {
                    BaseRes baseRes = new BaseRes();
                    baseRes.code = response.raw().code();
                    baseRes.message = CmailUtils.netErrorMsg(baseRes.code);
                    callback.onFail(baseRes);
                } else if (response.isSuccessful()) {
                    if (response.body().result != null) {
                        callback.onSuccess(response.body());
                    } else {
                        callback.onFail(response.body());
                    }
                }else {
                    callback.onError();
                }
            }

            @Override
            public void onFailure(Call<BaseRes> call, Throwable t) {
                callback.onError();
            }
        });
    }

    public void getMailBox(String email, final NetCallBack<BaseRes<List<MailBox>>> callback) {
        Call<BaseRes<List<MailBox>>> call = service.getMailBox(email);
        call.enqueue(new Callback<BaseRes<List<MailBox>>>() {
            @Override
            public void onResponse(Call<BaseRes<List<MailBox>>> call,
                                   Response<BaseRes<List<MailBox>>> response) {

                if (response.raw().code() != 200) {
                    BaseRes baseRes = new BaseRes();
                    baseRes.code = response.raw().code();
                    baseRes.message = CmailUtils.netErrorMsg(baseRes.code);
                    callback.onFail(baseRes);
                } else if (response.isSuccessful()) {
                    if (response.body().result != null) {
                        callback.onSuccess(response.body());

                    } else {
                        callback.onFail(response.body());
                    }
                }else {
                    callback.onError();
                }
            }

            @Override
            public void onFailure(Call<BaseRes<List<MailBox>>> call, Throwable t) {
                callback.onError();
            }
        });
    }


    public void getMailBoxFodler(final String mailAccount, final CallBack<List<MailFolder>>
            callBack) {

        getMailBoxMap(mailAccount, new NetCallBack<BaseRes>() {
            @Override
            public void onSuccess(BaseRes response) {
                // darft ：草稿箱
                final LinkedTreeMap<String, String> map = (LinkedTreeMap<String, String>)
                        response.result;

                getMailBox(mailAccount, new NetCallBack<BaseRes<List<MailBox>>>() {
                    @Override
                    public void onSuccess(BaseRes<List<MailBox>> response) {
                        List<MailFolder> folderList = new ArrayList<>();
                        List<MailBox> list = response.result;
                        //mailBox.setName(folder.getFolderPathName()); TobeSent
                        //mailBox.setAliasName(folder.getFolderName());  待发送
                        for (MailBox resultBean : list) {
                            MailFolder mailFolder = new MailFolder();
                            String aliaName = null;
                            String folderName = null;
                            String name = resultBean.getName();
                            String simpleName = "";
                            for (String key : map.keySet()) {
                                String value = String.valueOf(map.get(key));
                                if (value.equals(name)) {
                                    name = key;
                                    simpleName = name;
                                    folderName = value;
                                    switch (name.toLowerCase()) {
                                        case "inbox":
                                            aliaName = "收件箱";
//                                            folderName = "INBOX";
                                            break;
                                        case "draft":
                                            aliaName = "草稿箱";
//                                            folderName = "Drafts";
                                            break;
                                        case "sent":
                                            aliaName = "已发送";
//                                            folderName = "Sent Items";
                                            break;
                                        case "trash":
                                            aliaName = Constant.TRASH_FOLDER_AliasNAME;
//                                            folderName = "Trash";
                                            break;
                                        case "junk":
                                            aliaName = "垃圾邮件";
//                                            folderName = "Junk E-mail";
                                            break;
                                        case "virus":
                                            aliaName = "病毒邮件";
//                                            folderName = "Virus Items";
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }
                            if (aliaName == null) {
                                if (name.contains("/")) {
                                    String[] nameArray = name.split("/");
                                    aliaName = nameArray[nameArray.length - 1];
                                } else {
                                    aliaName = name;
                                }
                                folderName = name;
                            }
                            mailFolder.setFolderType(0);
                            mailFolder.setName(simpleName);
                            mailFolder.setAliasName(aliaName);//待发送
                            mailFolder.setFolderKey(folderName);//tobesent
                            mailFolder.setTotalCount(resultBean.getMailCount());
                            mailFolder.setMailAccount(mailAccount);
                            mailFolder.setUnreadCount(resultBean.getUnseenCount());
                            folderList.add(mailFolder);
                        }
                        MailFolder tobeSent = new MailFolder();
                        tobeSent.setAliasName("本地草稿");
                        tobeSent.setFolderType(0);
                        tobeSent.setMailAccount(mailAccount);
                        tobeSent.setUnreadCount(0);
                        tobeSent.setName(Constant.TobeSent);
                        tobeSent.setFolderKey(Constant.TobeSent);
                        folderList.add(1, tobeSent);
                        callBack.onSuccess(folderList);
                    }

                    @Override
                    public void onFail(BaseRes<List<MailBox>> response) {
                        callBack.onFail(response.message);
                    }

                    @Override
                    public void onError() {

                    }

                });
            }

            @Override
            public void onFail(BaseRes response) {

            }

            @Override
            public void onError() {

            }

        });


    }


    /**
     * 1 历史
     * 2.最新
     *
     * @param list
     * @param option
     * @param mailHeaderDao
     * @param mode
     */
    public void getMailHeader(final List<GetMailDataBean> list,
                              final String option, final MailHeaderDao mailHeaderDao,
                              int mode) {
        final List<MailHeader> result = new ArrayList<>();
        final AtomicInteger integer = new AtomicInteger();
        for (GetMailDataBean bean : list) {
            final String email = bean.getMailAccount();
            final String boxname = bean.getBoxName();
            int fetchSize = bean.getFetchSize();
            long uid = bean.getFetchUid();
            int netMode;
            if (uid == 0) {
                netMode = 0;
            } else {
                netMode = mode + 1;
            }
            service.getMailHeader(email, boxname, netMode, uid, fetchSize).observeOn(Schedulers.io
                    ()).observeOn(Schedulers.io())
                    .subscribe(new Observer<BaseRes<List<MailHeader>>>() {
                        @Override
                        public void onCompleted() {

                        }

                        @Override
                        public void onError(Throwable e) {
                            logger.error(TAG, e.getMessage());
                            integer.addAndGet(1);
                            if (integer.get() == list.size()) {
                                callJs(result, option);
                            }
                        }

                        @Override
                        public void onNext(BaseRes<List<MailHeader>> baseRes) {
                            integer.addAndGet(1);
                            if (baseRes.code == 0) {
                                //插入mailAccount和boxName
                                for (MailHeader mailHeader : baseRes.result) {
                                    mailHeader.setMailAccount(email);
                                    mailHeader.setBoxName(boxname);
                                    mailHeader.setMailTime(mailHeader.getTimestamp());
                                    mailHeader.setId(EncryptData.MD5_32(mailHeader.getUid() +
                                            mailHeader.getBoxName()
                                            +
                                            mailHeader.getMailAccount()));
                                    mailHeader.setReceiverMap(CmailUtils.convertReciversListToMap
                                            (mailHeader.getReceiver()));
                                    mailHeader.setReceiverBCCMap(CmailUtils
                                            .convertReciversListToMap(mailHeader.getReceiverBCC()));
                                    mailHeader.setReceiverCCMap(CmailUtils
                                            .convertReciversListToMap(mailHeader.getReceiverCC()));
                                }
                                mailHeaderDao.insertMailHeaders(baseRes.result);
                                result.addAll(baseRes.result);
                                //最后统一返回数据给js
                                if (integer.get() == list.size()) {
                                    callJs(result, option);
                                }
                            } else {
                                if (integer.get() == list.size()) {
                                    callJs(result, option);
                                }
                            }
                        }
                    });

        }
    }

    private void callJs(List<MailHeader> result, String
            option) {
        if (result.size() > 0) {
            String s = new Gson().toJson(result);
            JSONObject body = new JSONObject();
            try {
                JSONArray jsonArray = new JSONArray(s);
                jsonArray = CmailUtils.modifyReciverTORecivers(jsonArray);
                body.put(CODE, 0);
                body.put(MESSAGE, Constant.SUCCESS);
                body.put(RESULT, jsonArray.toString());
            } catch (Exception e) {
                e.printStackTrace();
                logger.error(TAG, "报错-> " + e
                        .toString
                                ());
            } finally {
                CallJsUtils.callJs(body, option);
            }
        } else {
            emptyMailList(0, option);
        }
    }

    private void emptyMailList(int code, String option) {
        try {
            JSONObject body = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            body.put(CODE, code);
            if (code == -1) {
                body.put(MESSAGE, Constant.NET_FAILED);
            } else {
                body.put(MESSAGE, Constant.SUCCESS);
            }
            body.put(RESULT, jsonArray.toString());
            logger.debug(TAG, " mailList " +
                    "-pullRefreshMailList  全局|正常加载|无数据时 网络请求更新数据 无数据返回");
            CallJsUtils.callJs(body, option);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(TAG, "报错-> " + e.toString());
        }

    }

    public void bindAccountToServer(final String mailAccount, String password, final String
            option, final CallBack<List<MailFolder>> callBack, final CallBack<String>
                                            passwordCallback) {

        BindAccountReq bindAccountReq = new BindAccountReq();
        bindAccountReq.setDeviceId(CmailInfoSp.getDeviceId());
        bindAccountReq.setEmail(mailAccount);
        bindAccountReq.setPassword(password);
        service.bindMailAccount(bindAccountReq)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io()).subscribe(new Observer<BaseRes<String>>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                failResultToJs(Constant.NET_ERROR_CODE, Constant.NET_FAILED, option);
            }

            @Override
            public void onNext(final BaseRes<String> baseResponse) {
                if (baseResponse.code == 0) {
                    MailAccountHelper dbhelper = MailAccountHelper.getInstance();
                    MailAccount mailAccountBean;
                    mailAccountBean = dbhelper.getMailAccount(mailAccount);
                    if (mailAccountBean == null) {
                        mailAccountBean = new MailAccount();
                    }
                    mailAccountBean.setMailAccount(mailAccount);
                    mailAccountBean.setMailSign(Constant.DEFAULT_SIGN);
                    mailAccountBean.setUserId(CmailInfoSp.getUserId());
                    mailAccountBean.setAccountState(Constant.ACCOUNTSTATUE_ACTIVE);//激活成功
                    mailAccountBean = CmailUtils.setCompany(mailAccountBean);
                    mailAccountBean.setMailSign(DEFAULT_SIGN);
                    MailAccountHelper.getInstance().insertMailAccount(mailAccountBean);

                    sandbox.saveSanboxPassword(mailAccount, baseResponse.result);


                    bindResultToJs(baseResponse.code == 0, option);
                    //保存默认的常用语
                    MailPhrasesDao mailPhrasesDao = CmailDatabase.getInstance(CmailCenter
                            .getContext()).mailPhrasesDao();
                    MailPhrases mailPhrases1 = new MailPhrases(Constant.PHRASES1);
                    MailPhrases mailPhrases2 = new MailPhrases(Constant.PHRASES2);

                    List<MailPhrases> list = new ArrayList<>();
                    list.add(mailPhrases1);
                    list.add(mailPhrases2);
                    mailPhrasesDao.insert(list);

                    //获取邮件夹信息
                    getMailBoxFodler(mailAccount, new CallBack<List<MailFolder>>() {
                        @Override
                        public void onSuccess(List<MailFolder> response) {
                            callBack.onSuccess(response);
                            passwordCallback.onSuccess(baseResponse.result);

                        }

                        @Override
                        public void onFail(String string) {
                            passwordCallback.onSuccess(baseResponse.result);
                        }
                    });

                } else {
//                    callBack.onFail(String.valueOf(baseResponse.code));
//                    {"code":400004,"message":"邮箱服务器登录失败"}
//                    bindResultToJs(false, option);
                    JSONObject body = new JSONObject();
                    try {
                        body.put(CODE, baseResponse.code);
//                        if (baseResponse.code == Constant.LOGIN_ERROR_CODE) {
//                            body.put(MESSAGE, Constant.PASSWORD_FAILED);
//                        } else if (baseResponse.code == Constant.ACCOUNTEXPIRE_ERROR_CODE) {
//                            body.put(MESSAGE, Constant.ACCOUNTEXPIRE_FAILED);
//                        } else {
                        body.put(MESSAGE, Constant.BIND_FAILED);
//                        }
                        body.put(RESULT, "");
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error(TAG, "报错-> " + e.toString());
                    } finally {
                        CallJsUtils.callJs(body, option);
                    }
                }
            }
        });
    }


    public void unbindAccountToServer(final HelperCmailAccount helperCmailAccount, final String mailAccount, final String
            option) {
        service.unBindMainAccount(mailAccount)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io()).subscribe(new Observer<BaseRes<String>>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                failResultToJs(Constant.NET_ERROR_CODE, Constant.NET_FAILED, option);
            }

            @Override
            public void onNext(BaseRes<String> baseResponse) {
                if (baseResponse.code == 0) {
                    MailAccountHelper mailAccountHelper = MailAccountHelper.getInstance();
                    MailAccount queryAccount = mailAccountHelper.getMailAccount
                            (mailAccount);
                    queryAccount.setAccountState(Constant.ACCOUNTSTATUE_UNACTIVE);//
                    mailAccountHelper.deleteMailAccount(queryAccount);
                    if (queryAccount.getAccountType() == 1) {
                        mailAccountHelper.insertMailAccount(queryAccount);
                        bindResultToJs(true, option);
                        logger.debug(TAG, "useMailAccount--" +
                                mailAccountHelper
                                        .getMailAccount
                                                (mailAccount).toString());
                    } else {
                        bindResultToJs(true, option);
                    }


                    if (null != HelperSynLazyTask.synAccountList && HelperSynLazyTask
                            .synAccountList.size() > 0) {
                        synchronized (HelperSynLazyTask.synAccountList) {
                            Iterator<String> it = HelperSynLazyTask.synAccountList.iterator();
                            while (it.hasNext()) {
                                String model = it.next();
                                if (TextUtils.equals(model, mailAccount)) {
                                    it.remove();
                                }
                            }
                            if (null != HelperSynLazyTask.synAccountList && HelperSynLazyTask
                                    .synAccountList.size() > 0) {
                                synchronized (HelperSynLazyTask.synAccountList) {
                                    for (String ignoreAccount :
                                            HelperSynLazyTask.synAccountList) {
                                        logger.debug("SynTask", " unbindAccountToServer " +
                                                "HelperSynLazyTask" +

                                                ".synAccountList  " + ignoreAccount);

                                    }
                                }
                            } else {
                                logger.debug("SynTask", " unbindAccountToServer HelperSynLazyTask" +
                                        ".synAccountList is null ");
                            }
                        }
                    }

                    if (helperCmailAccount!=null){
                        helperCmailAccount.deletePassword(mailAccount);
                    }

                }else {
                    failResultToJs(Constant.NET_ERROR_CODE, Constant.NET_FAILED, option);
                }
            }
        });
    }


    public void unFreezeMail(final String mailAccount, final NetCallBack<BaseRes>
            callback) {
        Call<BaseRes> call = service.unfreeze(mailAccount);
        call.enqueue(new Callback<BaseRes>() {
            @Override
            public void onResponse(Call<BaseRes> call,
                                   Response<BaseRes> response) {
                if (response.raw().code() != 200) {
                    BaseRes baseRes = new BaseRes();
                    baseRes.code = response.raw().code();
                    baseRes.message = CmailUtils.netErrorMsg(baseRes.code);
                    callback.onFail(baseRes);
                } else if (response.isSuccessful()) {
                    if (response.body().code == 0) {
                        callback.onSuccess(response.body());
                    } else {
                        callback.onFail(response.body());
                    }
                }else {
                    callback.onError();
                }

            }

            @Override
            public void onFailure(Call<BaseRes> call, Throwable t) {
                callback.onError();
            }
        });
    }

//    public void freezeMail(final String mailAccount, final NetCallBack<BaseRes>
//            callback) {
//        Call<BaseRes> call = service.freezeMail(mailAccount);
//        call.enqueue(new Callback<BaseRes>() {
//            @Override
//            public void onResponse(Call<BaseRes> call,
//                                   Response<BaseRes> response) {
//                if (response.isSuccessful()) {
//                    if (response.body().code == 0) {
//                        callback.onSuccess(response.body());
//                    } else {
//                        callback.onFail(response.body());
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<BaseRes> call, Throwable t) {
//                callback.onError();
//            }
//        });
//    }

    /*
      public void getMailStatusList(List<String> mailList, final String option) {


          service.batchStatus(mailList).subscribeOn(Schedulers.io()).observeOn(Schedulers.io())
                  .subscribe(new Observer<BaseRes<List<MailStatusBean>>>() {
                      @Override
                      public void onCompleted() {

                      }

                      @Override
                      public void onError(Throwable e) {
                          logger.debug(TAG, e.getMessage());
                          failResultToJs(Constant.NET_ERROR_CODE, Constant.NET_FAILED, option);
                      }

                      @Override
                      public void onNext(BaseRes<List<MailStatusBean>> baseRes) {
                          JSONObject body = new JSONObject();
                          try {
                              List<MailStatusBean> result = baseRes.result;
                              for (MailStatusBean bean : result) {
                                  MailAccount mailAccount = MailAccountHelper.getInstance()
                                          .getMailAccount(bean.getEmail());
                                  if (mailAccount != null) {
                                      mailAccount.setAccountState(bean.getStatus());
                                      MailAccountHelper.getInstance().updateMailAccount
                                      (mailAccount);
                                  }
                              }
                              body.put(CODE, 0);
                              body.put(MESSAGE, "success");
                          } catch (JSONException e) {
                              e.printStackTrace();
                          } catch (Exception e) {
                              logger.debug(TAG, e.getMessage());
                          } finally {
                              CallJsUtils.callJs(body, option);
                          }
                      }
                  });

      }
  */
    public void moveEmail(final String mailAccount, final String sourceBoxName, String
            targetBixName,
                          final List<Long> uidList, final String option) {
        MoveEmailReq moveEmailReq = new MoveEmailReq();
        moveEmailReq.setSourceBoxName(sourceBoxName);
        moveEmailReq.setTargetBoxName(targetBixName);
        moveEmailReq.setUidList(uidList);
        service.moveEmail(mailAccount, moveEmailReq)
                .subscribeOn(Schedulers.io()).observeOn(Schedulers.io())
                .subscribe(new Observer<BaseRes<String>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        failResultToJs(Constant.NET_ERROR_CODE, Constant.NET_FAILED, option);
                    }

                    @Override
                    public void onNext(BaseRes<String> baseRes) {
                        if (baseRes.code == Constant.ACCOUNTEXPIRE_ERROR_CODE || baseRes.code ==
                                Constant.LOGIN_ERROR_CODE) {
                            failResultToJs(baseRes.code, ACCOUNT_FAILED, option);
                        } else {
                            MailHeaderDao mailHeaderDao = CmailDatabase.getInstance(CmailCenter
                                    .getContext()).getMailHeaderDao();
                            List<MailHeader> mailHeaders = mailHeaderDao.queryMailHeaders
                                    (mailAccount, sourceBoxName, uidList);
                            mailHeaderDao.deleteMailHeaders(mailHeaders);
                            try {
                                String s = new Gson().toJson(baseRes);
                                JSONObject body = new JSONObject(s);
                                CallJsUtils.callJs(body, option);
                            } catch (Exception e) {
                                e.printStackTrace();
                                logger.error(Constant.TAG, "报错-> " + e.toString());
                            }
                        }

                    }
                });
    }

    public void modifyMailStatus(final String email, final String boxName, final int mode, final
    List<Long> uidList, final NetCallBack<BaseRes<String>> callback) {
        if (mode <= 1) {
            Call<BaseRes<String>> call = service.modifyMailStatus(email, boxName, mode, uidList);
            call.enqueue(new Callback<BaseRes<String>>() {
                @Override
                public void onResponse(Call<BaseRes<String>> call, Response<BaseRes<String>>
                        response) {
                    if (response.raw().code() != 200) {
                        BaseRes baseRes = new BaseRes();
                        baseRes.code = response.raw().code();
                        baseRes.message = CmailUtils.netErrorMsg(baseRes.code);
                        callback.onFail(baseRes);
                    } else if (response.isSuccessful()) {
                        if (response.body().code == 0) {
                            callback.onSuccess(response.body());
                        } else {
                            callback.onFail(response.body());
                        }
                    }else {
                        callback.onError();
                    }
                }

                @Override
                public void onFailure(Call<BaseRes<String>> call, Throwable t) {
                    callback.onError();
                }
            });
        } else {
            Call<BaseRes<String>> call = service.setFlag(email, boxName, mode - 2, uidList);
            call.enqueue(new Callback<BaseRes<String>>() {
                @Override
                public void onResponse(Call<BaseRes<String>> call, Response<BaseRes<String>>
                        response) {
                    if (response.raw().code() != 200) {
                        BaseRes baseRes = new BaseRes();
                        baseRes.code = response.raw().code();
                        baseRes.message = CmailUtils.netErrorMsg(baseRes.code);
                        callback.onFail(baseRes);
                    } else if (response.isSuccessful()) {
                        if (response.body().code == 0) {
                            callback.onSuccess(response.body());
                        } else {
                            callback.onFail(response.body());
                        }
                    }else {
                        callback.onError();
                    }
                }

                @Override
                public void onFailure(Call<BaseRes<String>> call, Throwable t) {
                    callback.onError();
                }
            });
        }
    }

    public void modifyFolderStatus(String email, String boxName, int mode, final String option) {
        service.modifyFolderStatus(email, boxName, mode).subscribeOn(Schedulers.io()).observeOn
                (Schedulers.io())
                .subscribe(new Observer<BaseRes<String>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        failResultToJs(Constant.NET_ERROR_CODE, Constant.NET_FAILED, option);
                    }

                    @Override
                    public void onNext(BaseRes<String> stringBaseRes) {
                        try {
                            if (stringBaseRes.code == Constant.LOGIN_ERROR_CODE) {
                                stringBaseRes.message = Constant.ACCOUNT_FAILED;
                            }
                            String s = new Gson().toJson(stringBaseRes);
                            JSONObject body = new JSONObject(s);
                            CallJsUtils.callJs(body, option);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logger.error(Constant.TAG, "报错-> " + e.toString());
                        }
                    }
                });
    }


    public void deleteFolder(final String mailAccount, final String boxName,
                             final String option) {

        service.deleteFolder(mailAccount, boxName)
                .subscribeOn(Schedulers.io()).observeOn(Schedulers.io())
                .subscribe(new Observer<BaseRes<String>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        failResultToJs(Constant.NET_ERROR_CODE, Constant.NET_FAILED, option);
                    }

                    @Override
                    public void onNext(BaseRes<String> baseRes) {
                        try {
                            String s = new Gson().toJson(baseRes);
                            JSONObject body = new JSONObject(s);
                            CallJsUtils.callJs(body, option);

                            MailHeaderDao mailHeaderDao =
                                    CmailDatabase.getInstance(CmailCenter.getContext())
                                            .getMailHeaderDao();
                            List<MailHeader> mailHeaders = mailHeaderDao.queryMailHeaders
                                    (mailAccount, boxName);
                            mailHeaderDao.deleteMailHeaders(mailHeaders);

                            MailFolder mailFolder = MailFolderHelper.getInstance()
                                    .queryByMailAccounts(mailAccount, boxName);
                            MailFolderHelper.getInstance().deleteFolder(mailFolder);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logger.debug(TAG, e.getMessage());
                        }
                    }
                });
    }

    public void clearFolder(final String mailAccount, final String boxName, final String option) {
        service.clearFolder(mailAccount, boxName).subscribeOn(Schedulers.io()).observeOn
                (Schedulers.io())
                .subscribe(new Observer<BaseRes<String>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        failResultToJs(Constant.NET_ERROR_CODE, Constant.NET_FAILED, option);
                    }

                    @Override
                    public void onNext(BaseRes<String> baseRes) {
                        try {
                            String s = new Gson().toJson(baseRes);
                            JSONObject body = new JSONObject(s);
                            CallJsUtils.callJs(body, option);

                            MailHeaderDao mailHeaderDao =
                                    CmailDatabase.getInstance(CmailCenter.getContext())
                                            .getMailHeaderDao();
                            List<MailHeader> mailHeaders = mailHeaderDao.queryMailHeaders
                                    (mailAccount, boxName);
                            mailHeaderDao.deleteMailHeaders(mailHeaders);
                        } catch (Exception e) {
                            e.printStackTrace();
                            logger.debug(TAG, e.getMessage());
                        }
                    }
                });
    }

    public void deleteMail(final String mailAccount, final String boxName, final List<Long>
            uidList, final String option) {
        service.deleteMail(mailAccount, boxName, uidList)
                .subscribeOn(Schedulers.io()).observeOn(Schedulers.io())
                .subscribe(new Observer<BaseRes<String>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        failResultToJs(Constant.NET_ERROR_CODE, Constant.NET_FAILED, option);
                    }

                    @Override
                    public void onNext(BaseRes<String> baseRes) {
                        if (baseRes.code == Constant.ACCOUNTEXPIRE_ERROR_CODE) {
                            failResultToJs(baseRes.code, ACCOUNT_FAILED, option);
                        } else if (baseRes.code == Constant.LOGIN_ERROR_CODE) {
                            failResultToJs(baseRes.code, ACCOUNT_FAILED, option);
                        } else {
                            try {
                                String s = new Gson().toJson(baseRes);
                                JSONObject body = new JSONObject(s);

                                CallJsUtils.callJs(body, option);
                                //删除邮件头
                                MailHeaderDao mailHeaderDao = CmailDatabase.getInstance(CmailCenter
                                        .getContext()).getMailHeaderDao();
                                List<MailHeader> mailHeaders = mailHeaderDao.queryMailHeaders
                                        (mailAccount, boxName, uidList);
                                mailHeaderDao.deleteMailHeaders(mailHeaders);

                                int unseenCount = 0;
                                for (MailHeader mailHeader :
                                        mailHeaders) {
                                    if (mailHeader.isUnseen()) {
                                        unseenCount += 1;
                                    }
                                }

                                //已删除 数量减一
                                MailFolderHelper folderHelper = MailFolderHelper.getInstance();
                                MailFolder delFolder = folderHelper.queryByMailAccounts(mailAccount,
                                        boxName);
                                delFolder.setTotalCount(delFolder.getTotalCount() - uidList.size());
                                delFolder.setUnreadCount(delFolder.getUnreadCount() - unseenCount);
                                folderHelper.updateFolder(delFolder);

                            } catch (Exception e) {
                                e.printStackTrace();
                                logger.error(TAG, "报错-> " + e.toString());
                            }
                        }

                    }
                });
    }


    public void getMailBoxMap(String email, final NetCallBack<BaseRes> callback) {
        Call<BaseRes> call = service.getMailBoxMap(email);
        call.enqueue(new Callback<BaseRes>() {
            @Override
            public void onResponse(Call<BaseRes> call, Response<BaseRes> response) {
                if (response.isSuccessful()) {
                    if (response.body().code == 0) {
                        callback.onSuccess(response.body());
                    } else {
                        callback.onFail(response.body());
                    }
                }else {
                    callback.onError();
                }
            }

            @Override
            public void onFailure(Call<BaseRes> call, Throwable t) {
                callback.onError();
            }
        });
    }

    public void getMailDomains(final NetCallBack<BaseRes> callback) {
        Call<BaseRes> call = service.getMailDomains();
        call.enqueue(new Callback<BaseRes>() {
            @Override
            public void onResponse(Call<BaseRes> call,
                                   Response<BaseRes> response) {
                if (response.raw().code() != 200) {
                    BaseRes baseRes = new BaseRes();
                    baseRes.code = response.raw().code();
                    baseRes.message = CmailUtils.netErrorMsg(baseRes.code);
                    callback.onFail(baseRes);
                } else if (response.isSuccessful()) {
                    if (response.body().code == 0) {
                        callback.onSuccess(response.body());
                    } else {
                        callback.onFail(response.body());
                    }
                }else {
                    callback.onError();
                }
            }

            @Override
            public void onFailure(Call<BaseRes> call, Throwable t) {
                callback.onError();
            }
        });
    }


    public void getMailStatus(final String mail, final NetCallBack<BaseRes<MailStatusBean>>
            callback) {
        Call<BaseRes<MailStatusBean>> call = service.getMailStatus(mail);
        call.enqueue(new Callback<BaseRes<MailStatusBean>>() {
            @Override
            public void onResponse(Call<BaseRes<MailStatusBean>> call,
                                   Response<BaseRes<MailStatusBean>> response) {
                if (response.isSuccessful()) {
                    if (response.body().result != null && response.body().result.isStatus()) {
                        callback.onSuccess(response.body());
                    } else {
                        callback.onFail(response.body());
                    }
                }else {
                    callback.onError();
                }
            }

            @Override
            public void onFailure(Call<BaseRes<MailStatusBean>> call, Throwable t) {
                callback.onError();
            }
        });
    }

    public void getMailListState(final String mail, String boxName, long fromUid, long
            toUid, final NetCallBack<BaseRes<List<MailStatusRes>>>
                                         callback) {
        Call<BaseRes<List<MailStatusRes>>> call = service.getMailListState(mail, boxName, fromUid,
                toUid);
        call.enqueue(new Callback<BaseRes<List<MailStatusRes>>>() {
            @Override
            public void onResponse(Call<BaseRes<List<MailStatusRes>>> call,
                                   Response<BaseRes<List<MailStatusRes>>> response) {
                if (response.isSuccessful() && response.body().result != null) {
                    callback.onSuccess(response.body());
                } else {
                    callback.onFail(response.body());
                }
            }

            @Override
            public void onFailure(Call<BaseRes<List<MailStatusRes>>> call, Throwable t) {
                callback.onError();
            }
        });
    }

    public void getBindedMailList(final NetCallBack<BaseRes<List<String>>>
                                          callback) {
        Call<BaseRes<List<String>>> call = service.bindedMailList();
        call.enqueue(new Callback<BaseRes<List<String>>>() {
            @Override
            public void onResponse(Call<BaseRes<List<String>>> call,
                                   Response<BaseRes<List<String>>> response) {
                if (response.isSuccessful() && response.body().result != null) {
                    callback.onSuccess(response.body());
                } else {
                    callback.onFail(response.body());
                }
            }

            @Override
            public void onFailure(Call<BaseRes<List<String>>> call, Throwable t) {
                callback.onError();
            }
        });
    }


    public void hasNewMailRequest(long uid, String email, String boxName, final
    NetCallBack<BaseRes<Boolean>>
            callback) {
        Call<BaseRes<Boolean>> call = service.hasNewMailRequest(uid, email, boxName);
        call.enqueue(new Callback<BaseRes<Boolean>>() {
            @Override
            public void onResponse(Call<BaseRes<Boolean>> call, Response<BaseRes<Boolean>>
                    response) {
                if (response.raw().code() != 200) {
                    BaseRes baseRes = new BaseRes();
                    baseRes.code = response.raw().code();
                    baseRes.message = CmailUtils.netErrorMsg(baseRes.code);
                    callback.onFail(baseRes);
                } else if (response.isSuccessful()) {
                    if (response.body().code == 0) {
                        callback.onSuccess(response.body());
                    } else {
                        callback.onFail(response.body());
                    }
                }else {
                    callback.onError();
                }
            }

            @Override
            public void onFailure(Call<BaseRes<Boolean>> call, Throwable t) {
                callback.onError();
            }
        });
    }

    /**
     * @param email
     * @param boxName
     * @param fetchUid
     * @param fetchSize
     * @param mode      获取模式（0：初始化获取邮件头；1：获取传入uid之前的邮件头；2：获取传入uid之后的邮件头）
     * @param callback
     */
    public void simpleGetHeaders(String email, String boxName, long fetchUid, int fetchSize, int
            mode,
                                 final NetCallBack<BaseRes<List<MailHeader>>> callback) {
        Call<BaseRes<List<MailHeader>>> call = service.simpleGetHeaders(email, boxName, mode,
                fetchUid, fetchSize);
        call.enqueue(new Callback<BaseRes<List<MailHeader>>>() {
            @Override
            public void onResponse(Call<BaseRes<List<MailHeader>>> call,
                                   Response<BaseRes<List<MailHeader>>>
                                           response) {
                if (response.raw().code() != 200) {
                    BaseRes baseRes = new BaseRes();
                    baseRes.code = response.raw().code();
                    baseRes.message = CmailUtils.netErrorMsg(baseRes.code);
                    callback.onFail(baseRes);
                } else if (response.isSuccessful()) {
                    if (response.body().code == 0) {
                        callback.onSuccess(response.body());
                    } else {
                        callback.onFail(response.body());
                    }
                }else {
                    callback.onError();
                }
            }

            @Override
            public void onFailure(Call<BaseRes<List<MailHeader>>> call, Throwable t) {
                callback.onError();
            }
        });
    }


}
