package com.cmft.cmail.core;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.bumptech.glide.Glide;
import com.cmft.android.sandbox.crypter.CallBack;
import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.cmail.utils.Constant;
import com.github.chrisbanes.photoview.PhotoView;
import com.cmft.cmail.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

public class ImageActivity extends Activity {
    PhotoView photoView;
    String phototPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
        photoView = findViewById(R.id.image);
        photoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        findViewById(R.id.background).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        phototPath = getIntent().getStringExtra("path");

        if (!TextUtils.isEmpty(phototPath)) {
            final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            if (SandBox.getInstance().isEncrypted(new File(phototPath))) {
                SandBox.getInstance().decrypt(phototPath, byteArrayOutputStream, new CallBack<Boolean>() {


                    @Override
                    public void onSuccess(Boolean aBoolean) {
                        if (aBoolean == true) {
                            Glide.with(ImageActivity.this).load(byteArrayOutputStream.toByteArray
                                    ()).into
                                    (photoView);
                        }
                    }

                    @Override
                    public void onFail(String s) {

                    }
                });

            } else {
                Glide.with(ImageActivity.this).load(phototPath).into
                        (photoView);
            }

            if (byteArrayOutputStream != null) {
                try {
                    byteArrayOutputStream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                    CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
                }
            }

        }
    }
}
