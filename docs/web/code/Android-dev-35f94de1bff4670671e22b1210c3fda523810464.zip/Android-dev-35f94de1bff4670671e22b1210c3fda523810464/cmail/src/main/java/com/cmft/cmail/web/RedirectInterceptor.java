package com.cmft.cmail.web;

import android.content.Intent;
import android.support.v4.app.ActivityCompat;
import android.text.TextUtils;
import android.util.Log;

import com.cmft.cmail.Cmail;
import com.cmft.cmail.core.AlbumActivity;
import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.utils.Constant;
import com.cmft.waltz.core.WaltzWebConfig;

import java.io.IOException;
import java.util.List;

import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

import static com.cmft.waltz.core.constant.AppConstants.OAUTH_LOGIN;


/**
 * @author 作者
 * @date 时间
 * @describe 描述
 */
public class RedirectInterceptor implements Interceptor {
    private boolean isOauthing;


    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        if (WaltzWebConfig.getCookiesByHost(request.url().host()) != null) {
            request = request.newBuilder().url(request.url()).header("Cookie", WaltzWebConfig
                    .getCookiesByHost(request.url().host())).build();
        }
        Response response = chain.proceed(request);
        do {
            Headers responeHeaders = response.headers();
            List<String> cookies = responeHeaders.values("Set-Cookie");
            String oauthType = responeHeaders.get("oauth");

//            Log.d("TESTX", "   拦截器 url-> " + response.request().url() +
//                    " code->" + response.code() + " Location->" + responeHeaders.get("Location"));
//            if (TextUtils.isEmpty(oauthType)) {
//                Log.d("TESTX", "   拦截器 oauthType-> null");
//            } else {
//                Log.d("TESTX", "   拦截器 oauthType-> " + oauthType);
//            }

            if (response.code() == 302) {
                isOauthing = true;
                String location = responeHeaders.get("Location");
                String url = response.request().url().host();
//                for (String responsCookie : cookies) {
//                    Log.d("TESTX", "   拦截器 syncCookie-> " + responsCookie + " url->" + url);
//                    WaltzWebConfig.syncCookie(url, responsCookie);
//                }
                if (!TextUtils.isEmpty(oauthType) && oauthType.equals(OAUTH_LOGIN)) {
                    isOauthing = false;
                    return response;
                } else {
                    WaltzWebConfig
                            .getCookiesByUrl(location);
//                    Log.d("TESTX", "   拦截器 getCookiesByUrl-> " + WaltzWebConfig
//                            .getCookiesByUrl(location) + " url->" + location);
                    if (!TextUtils.isEmpty(WaltzWebConfig
                            .getCookiesByUrl(location))) {
                        if (!(location.contains("https://") || location.contains("http://"))) {
                            location = "https://" + url + location;
                        }
                        request = request.newBuilder().url(location).header("Cookie", WaltzWebConfig
                                .getCookiesByHost(HttpUrl.get(location).host())).build();
//                        Log.d("刘凯", location);
                        WaltzWebConfig
                                .getCookiesByHost(HttpUrl.get(location).host());
//                        Log.d("刘凯cookie", WaltzWebConfig
//                                .getCookiesByHost(HttpUrl.get(location).host()));
                        response = chain.proceed(request);

//                        Log.d("TESTX", "   拦截器 2 url-> " + response.request().url() +
//                                " code->" + response.code() + " Location->" + responeHeaders.get
//                                ("Location"));
//                        if (TextUtils.isEmpty(oauthType)) {
//                            Log.d("TESTX", "   拦截器 2 oauthType-> null");
//                        } else {
//                            Log.d("TESTX", "   拦截器 2 oauthType-> " + oauthType);
//                        }

                        for (String responsCookie : cookies) {
//                            Log.d("TESTX", "   拦截器 2 syncCookie-> " + responsCookie + " url->" +
//                                    url);
                            WaltzWebConfig.syncCookie(url, responsCookie);
                        }

                    }


                }

            } else if (response.code() == 200) {
                isOauthing = false;
                if (!TextUtils.isEmpty(oauthType) && oauthType.equals(OAUTH_LOGIN)) {
//                    Log.d("TESTX", "   拦截器 3 跳转登陆页面-> ");
                    final Intent intent = new Intent(CmailCenter.getContext(), AlbumActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("type", Constant.SHOWLOGIN_INDEX);
                    ActivityCompat.startActivity(CmailCenter.getContext(), intent, null);

                    return response;
                }

                String url = response.request().url().host();
                for (String responsCookie : cookies) {
                    WaltzWebConfig.syncCookie(url, responsCookie);
                }
                return response;
            }
        } while (isOauthing);

        return response;
    }

    public Response oauthResponse(Response response) {
        Headers responeHeaders = response.headers();
        List<String> cookies = responeHeaders.values("Set-Cookie");
        String oauthType = responeHeaders.get("oauth");
        if (TextUtils.isEmpty(oauthType)) {

        }
        if (response.code() == 302) {
            String location = responeHeaders.get("Location");
            String url = response.request().url().host();
            for (String responsCookie : cookies) {
//                Log.d("TESTX", "   拦截器 syncCookie-> " + responsCookie + " url->" + url);
                WaltzWebConfig.syncCookie(url, responsCookie);
            }
            if (!TextUtils.isEmpty(oauthType) && oauthType.equals(OAUTH_LOGIN)) {
                return response;
            }
        }
        return response;
    }
}
