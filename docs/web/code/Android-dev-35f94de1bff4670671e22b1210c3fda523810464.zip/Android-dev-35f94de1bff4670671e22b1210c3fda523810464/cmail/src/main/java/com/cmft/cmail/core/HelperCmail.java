package com.cmft.cmail.core;

import android.content.Context;

import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.web.RetrofitService;

import java.util.concurrent.ThreadPoolExecutor;

public abstract class HelperCmail implements IHelper {

    private Context context;
    private RetrofitService retrofit;
    private CmailDatabase database;
    private ThreadPoolExecutor executor;
    private ILogger logger;
    private HelperSandbox sandbox;

    @Override
    public synchronized void init(Context context, RetrofitService retrofit, CmailDatabase
            database, ThreadPoolExecutor executor, ILogger logger, HelperSandbox sandbox) {
        if (context == null || retrofit == null || database == null || executor == null || logger
                == null) {
            throw new RuntimeException("Helper init fail, application or retrofit or database or " +
                    "executor or logger is " +
                    "not null");
        }
        this.context = context;
        this.retrofit = retrofit;
        this.database = database;
        this.executor = executor;
        this.logger = logger;
        this.sandbox = sandbox;
    }

    public HelperSandbox getSandbox() {
        return sandbox;
    }

    public Context getContext() {
        return context;
    }

    public RetrofitService getRetrofit() {
        return retrofit;
    }

    public CmailDatabase getDatabase() {
        return database;
    }

    public ThreadPoolExecutor getExecutor() {
        return executor;
    }

    public ILogger getLogger() {
        return logger;
    }

    @Override
    public String getTag() {
        return getClass().getName();
    }
}
