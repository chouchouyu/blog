package com.cmft.cmail.core;

import android.content.Context;
import android.text.TextUtils;

import com.cmft.cmail.Cmail;
import com.cmft.cmail.NetCallBack;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailHeaderDao;
import com.cmft.cmail.db.dao.TobeSendDao;
import com.cmft.cmail.db.model.MailFolder;
import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.waltz.CallJsUtils;
import com.cmft.cmail.web.RetrofitService;
import com.cmft.cmail.web.resBean.BaseRes;

import org.json.JSONObject;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

import static com.cmft.cmail.utils.Constant.ACCOUNT_FAILED;
import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.NET_FAILED;
import static com.cmft.cmail.utils.Constant.RESULT;
import static com.cmft.cmail.waltz.CallJsUtils.failResultToJs;

public class HelperCmailMailOperate extends HelperCmail {
    private static final String TAG = Constant.TAG + "." + "Operate";

    @Override
    public synchronized void init(Context context, RetrofitService retrofit, CmailDatabase
            database, ThreadPoolExecutor executor, ILogger logger, HelperSandbox sandbox) {
        super.init(context, retrofit, database, executor, logger,sandbox);
    }


    public void modifyMailStatus(Map<String, Map<String, List<Long>>> map, final int mode,
                                 final String
                                         option) {
        final JSONObject body = new JSONObject();

        int count = 0;
        for (Map.Entry<String, Map<String, List<Long>>> entry : map.entrySet()) {
            Map<String, List<Long>> boxAnduidMap = entry.getValue();
            count += boxAnduidMap.size();
        }
        for (Map.Entry<String, Map<String, List<Long>>> entry : map.entrySet()) {
            final String mailAccount = entry.getKey();
            Map<String, List<Long>> boxAnduidMap = entry.getValue();
            for (Map.Entry<String, List<Long>> boxAnduidEntry : boxAnduidMap.entrySet()) {
                final String boxName = boxAnduidEntry.getKey();
                final List<Long> uidList = boxAnduidEntry.getValue();
                count -= 1;
                final int finalCount = count;
                getRetrofit().modifyMailStatus(mailAccount, boxName, mode, uidList, new
                        NetCallBack<BaseRes<String>>() {


                            @Override
                            public void onSuccess(BaseRes<String> response) {
                                getExecutor().execute(new Runnable() {
                                    @Override
                                    public void run() {
                                        //更新数据库
                                        MailHeaderDao mailHeaderDao = getDatabase()
                                                .getMailHeaderDao();
                                        List<MailHeader> mailHeaders = mailHeaderDao
                                                .queryMailHeaders

                                                        (mailAccount,
                                                                boxName, uidList);
                                        for (MailHeader header : mailHeaders) {
                                            if (mode <= 1) {
                                                header.setUnseen(mode == 0);
                                            } else {
                                                header.setFlagged(mode == 3);
                                            }
                                        }
                                        mailHeaderDao.updateMailHeaders(mailHeaders);
                                    }
                                });

                                if (finalCount == 0) {
                                    try {
                                        body.put(CODE, 0);
                                        body.put(MESSAGE, "success");
                                        body.put(RESULT, response.result);
                                        CallJsUtils.callJs(body, option);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        getLogger().error(TAG, "报错-> " + e.toString());
                                    }
                                }
                            }

                            @Override
                            public void onFail(BaseRes<String> response) {
                                if (finalCount == 0) {
                                    try {
                                        body.put(CODE, response.code);
                                        if (response.code == Constant.ACCOUNTEXPIRE_ERROR_CODE) {
                                            body.put(MESSAGE, ACCOUNT_FAILED);
                                        } else {
                                            body.put(MESSAGE, response.message);
                                        }
                                        body.put(RESULT, "");
                                        CallJsUtils.callJs(body, option);

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        getLogger().error(TAG, "报错-> " + e.toString());
                                    }
                                }
                            }

                            @Override
                            public void onError() {
                                if (finalCount == 0) {
                                    failResultToJs(Constant.NET_ERROR_CODE, NET_FAILED, option);
                                }
                            }
                        });
            }
        }
    }

    public void modifyMailStatus(final String email, final String boxName, final int mode, final
    List<Long> uidList,
                                 final String option) {
        final JSONObject body = new JSONObject();

        getRetrofit().modifyMailStatus(email, boxName, mode, uidList, new
                NetCallBack<BaseRes<String>>() {


                    @Override
                    public void onSuccess(BaseRes<String> response) {
                        getExecutor().execute(new Runnable() {
                            @Override
                            public void run() {
                                //更新数据库


                                MailHeaderDao mailHeaderDao = getDatabase().getMailHeaderDao();
                                List<MailHeader> mailHeaders = mailHeaderDao.queryMailHeaders

                                        (email,
                                                boxName, uidList);
                                for (MailHeader header : mailHeaders) {
                                    if (mode <= 1) {
                                        header.setUnseen(mode == 0);
                                    } else {
                                        header.setFlagged(mode == 3);
                                    }
                                }
                                mailHeaderDao.updateMailHeaders(mailHeaders);
                            }
                        });


                        try {
                            body.put(CODE, 0);
                            body.put(MESSAGE, "success");
                            body.put(RESULT, response.result);
                            if (option.contains("modifyMailStatus")) {
                                CallJsUtils.callJs(body, option);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                            getLogger().error(TAG, "报错-> " + e.toString());
                        }

                    }

                    @Override
                    public void onFail(BaseRes<String> response) {

                        try {
                            body.put(CODE, response.code);
                            if (response.code == Constant.ACCOUNTEXPIRE_ERROR_CODE) {
                                body.put(MESSAGE, ACCOUNT_FAILED);
                            } else {
                                body.put(MESSAGE, response.message);
                            }
                            body.put(RESULT, "");
                            if (option.contains("modifyMailStatus")) {
                                CallJsUtils.callJs(body, option);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                            getLogger().error(TAG, "报错-> " + e.toString());
                        }
                    }

                    @Override
                    public void onError() {
                        if (option.contains("modifyMailStatus")) {
                            failResultToJs(Constant.NET_ERROR_CODE, NET_FAILED, option);
                        }
                    }
                });
    }


    public void moveMail(final String mailAccount, final String sourceBoxName, final String
            targetBixName,
                         final List<Long> uidList, final String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                String folderName = targetBixName;
                if (TextUtils.equals(targetBixName, Constant.TRASH_FOLDER_NAME)) {
                    folderName = Constant.TRASH_FOLDER_AliasNAME;
                    MailFolder folder = getDatabase().getMailFolderDao().queryFolderKey(mailAccount,
                            folderName);
                    folderName = folder.getFolderKey();
                }

                getRetrofit().moveEmail(mailAccount, sourceBoxName, folderName,
                        uidList, option);


            }
        });
    }


    public void deleteMail(String mailAccount, String boxName, List<Long> uidList,
                           String option) {
        if (TextUtils.equals(boxName, Constant.TobeSent)) {
            TobeSendDao tobeSendDao = getDatabase().getTobeSendDao();
            for (Long origalUid : uidList) {
                tobeSendDao.delete(mailAccount, origalUid);
            }
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put(Constant.CODE, 0);
                jsonObject.put(Constant.MESSAGE, "操作成功");
                jsonObject.put(Constant.RESULT, "删除成功");
                CallJsUtils.callJs(jsonObject, option);
            } catch (Exception e) {
                e.printStackTrace();
                getLogger().error(TAG, "报错-> " + e.toString());
            }

        } else {
            getRetrofit().deleteMail(mailAccount, boxName, uidList, option);
        }
    }

    @Override
    public String getTag() {
        return HelperCmailMailOperate.TAG;
    }
}
