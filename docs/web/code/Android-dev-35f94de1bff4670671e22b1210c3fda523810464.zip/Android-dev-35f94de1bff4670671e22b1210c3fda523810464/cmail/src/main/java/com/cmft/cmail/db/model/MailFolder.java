package com.cmft.cmail.db.model;

import android.support.annotation.NonNull;
import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;

@Entity(tableName = "MailFolder", primaryKeys = {"aliasName", "mailAccount"},
        foreignKeys = {@ForeignKey(entity = MailAccount.class,
                parentColumns = "mailAccount", childColumns = "mailAccount",
                onDelete = ForeignKey.CASCADE, onUpdate = ForeignKey.CASCADE)})
public class MailFolder {

    private int folderType;


    private String name;

    //aliasName
    @NonNull
    private String aliasName = "";

    private String folderKey;

//    private String folderlevel;

    @ColumnInfo(index = true)
    @NonNull
    private String mailAccount;

    private long unreadCount;

    private long totalCount;

//    private String lastRecvTime;
//
//    private String lastMailUid;


//    public String getFolderPath() {
//        return folderPath;
//    }
//
//    public void setFolderPath(String folderPath) {
//        this.folderPath = folderPath;
//    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFolderType() {
        return folderType;
    }

    public void setFolderType(int folderType) {
        this.folderType = folderType;
    }

    @NonNull
    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(@NonNull String aliasName) {
        this.aliasName = aliasName;
    }

    public String getFolderKey() {
        return folderKey;
    }

    public void setFolderKey(String folderKey) {
        this.folderKey = folderKey;
    }

//    public String getFolderlevel() {
//        return folderlevel;
//    }
//
//    public void setFolderlevel(String folderlevel) {
//        this.folderlevel = folderlevel;
//    }

    public String getMailAccount() {
        return mailAccount;
    }

    public void setMailAccount(String mailAccount) {
        this.mailAccount = mailAccount;
    }

    public long getUnreadCount() {
        return unreadCount;
    }

    public void setUnreadCount(long unreadCount) {
        this.unreadCount = unreadCount;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
    }

//    public String getLastRecvTime() {
//        return lastRecvTime;
//    }
//
//    public void setLastRecvTime(String lastRecvTime) {
//        this.lastRecvTime = lastRecvTime;
//    }
//
//    public String getLastMailUid() {
//        return lastMailUid;
//    }
//
//    public void setLastMailUid(String lastMailUid) {
//        this.lastMailUid = lastMailUid;
//    }
}
