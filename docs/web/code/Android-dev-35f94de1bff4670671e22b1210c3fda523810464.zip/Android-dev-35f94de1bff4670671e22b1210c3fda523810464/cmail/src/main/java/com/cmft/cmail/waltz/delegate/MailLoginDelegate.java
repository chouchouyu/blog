package com.cmft.cmail.waltz.delegate;

import java.io.Serializable;

public interface MailLoginDelegate extends Serializable {

    void bindMailAccount(String data, String option);

    void unBindMailAccount(String data, String option);

    void setMainMailAccount(String data, String option);

    void setMailSignature(String data, String option);

    void getMailAccountList(String data, String option);

    void addIdiomList(String data, String option);

//    void getIdiomList(String data, String option);

    void moveMailBox(String data, String option);

    void getMailDataList(String data, String option);

    void modifyMailStatus(String data, String option);

    void modifyFolderStatus(String data, String option);

    void getMailBox(String data, String option);

    void useMailAccount(String data, String option);

    void deleteOrClearBoxName(String data, String option);

    void deleteMailList(String data, String option);

//    void getSpecialFolderMailList(String data, String option);

    void getAllAccountMailBox(String data, String option);

    void pullRefreshMailList(String data, String option);

    //添加附件 ok
    void addAttachment(String data, String option);
    //获取邮箱的支持域
    void supportMailDomain(String data, String option);

    void getUserInfo(String data, String option);


    void recentContacts(String data, String option);
}
