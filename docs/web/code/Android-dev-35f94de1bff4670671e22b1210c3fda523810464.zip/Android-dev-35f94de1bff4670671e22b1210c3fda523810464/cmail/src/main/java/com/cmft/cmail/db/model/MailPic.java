package com.cmft.cmail.db.model;


import android.support.annotation.NonNull;
import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;

/**
 * 5)邮件内嵌图片表：tbl_pic_info，按邮件账号分表，自定义账号删除，则相应表删除，(内嵌图片在获取邮件详情就需要下载到本地供H5展示）
 */
@Entity(tableName = "pic_info",
        foreignKeys = {@ForeignKey(
                entity = MailAccount.class,
                parentColumns = "mailAccount",
                childColumns = "mailAccount",
                onDelete = ForeignKey.CASCADE,
                onUpdate = ForeignKey.CASCADE)
//                ,@ForeignKey(
//                        entity = MailHeader.class,
//                        parentColumns = "uid",
//                        childColumns = "mailUid",
//                        onDelete = ForeignKey.CASCADE,
//                        onUpdate = ForeignKey.CASCADE)
        })
public class MailPic {

    @NonNull
    public String id;

    @PrimaryKey
    @NonNull
    public String cid;

    @ColumnInfo(index = true)
    @NonNull
    public String mailAccount;

    @ColumnInfo(index = true)
    public int mailUid;

    public String name;


    public String folderName;

    @ColumnInfo
    public String filePath;

    @Override
    public String toString() {
        return "MailPic{" +
                "cid=" + cid +
                ", mailAccount='" + mailAccount + '\'' +
                ", mailUid=" + mailUid +
                ", name='" + name + '\'' +
                ", folderName=" + folderName +
                ", filePath='" + filePath + '\'' +
                '}';
    }
}
