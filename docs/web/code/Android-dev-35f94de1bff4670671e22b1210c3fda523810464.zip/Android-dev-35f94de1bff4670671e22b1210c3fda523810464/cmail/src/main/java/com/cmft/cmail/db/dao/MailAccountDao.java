package com.cmft.cmail.db.dao;

import com.cmft.cmail.db.model.MailAccount;

import java.util.List;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

@Dao
public interface MailAccountDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertMailAccount(MailAccount mailAccount);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long[] insertMailAccount(List<MailAccount> mailAccounts);

    @Delete
    void deleteMailAccount(MailAccount mailAccount);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    int updateMailAccount(MailAccount mailAccount);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    void updateMailAccounts(List<MailAccount> mailAccounts);

    @Query("SELECT * FROM MailAccount WHERE mailAccount == :mailAccount")
    MailAccount queryByMailAccount(String mailAccount);

    @Query("SELECT * FROM MailAccount WHERE masterAccount == :isMaster")
    MailAccount getMasterAccount(boolean isMaster);

    @Query("SELECT * FROM MailAccount WHERE userId == :userId")
    List<MailAccount> queryByUserId(String userId);

    @Query("select mailSign from MailAccount where mailAccount ==:mailAccount")
    String getMailSign(String mailAccount);

    @Query("select mailAccount from MailAccount where userId == :userId")
    List<String> getMailListByUserId(String userId);

    @Query("select * from MailAccount where userId == :userId")
    List<MailAccount> queryUserAll(String userId);
}
