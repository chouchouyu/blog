package com.cmft.cmail.db.model;

import java.util.List;

public class MoveMail {

    /**
     * fromBox : INBOX
     * mailList : [{"mailAccount":"daliyjb11@163.com","uid":1568252642,"unseen":false}]
     * toBox : Trash
     */

    private String fromBox;
    private String toBox;
    private List<MailListBean> mailList;

    public String getFromBox() {
        return fromBox;
    }

    public void setFromBox(String fromBox) {
        this.fromBox = fromBox;
    }

    public String getToBox() {
        return toBox;
    }

    public void setToBox(String toBox) {
        this.toBox = toBox;
    }

    public List<MailListBean> getMailList() {
        return mailList;
    }

    public void setMailList(List<MailListBean> mailList) {
        this.mailList = mailList;
    }

    public static class MailListBean {
        /**
         * mailAccount : daliyjb11@163.com
         * uid : 1568252642
         * unseen : false
         */

        private String mailAccount;
        private long uid;
        private boolean unseen;

        public String getMailAccount() {
            return mailAccount;
        }

        public void setMailAccount(String mailAccount) {
            this.mailAccount = mailAccount;
        }


        public long getUid() {
            return uid;
        }

        public void setUid(long uid) {
            this.uid = uid;
        }

        public boolean isUnseen() {
            return unseen;
        }

        public void setUnseen(boolean unseen) {
            this.unseen = unseen;
        }
    }
}
