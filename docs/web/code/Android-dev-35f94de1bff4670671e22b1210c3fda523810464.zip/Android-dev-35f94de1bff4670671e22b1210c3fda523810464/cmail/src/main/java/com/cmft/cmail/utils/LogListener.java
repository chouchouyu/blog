package com.cmft.cmail.utils;

public interface LogListener {
    void onLog(String tag, String msg);
}
