package com.cmft.cmail.db.model;

import java.util.List;

public class SearchBean {


    /**
     * fetchList : [{"boxName":"INBOX","fetchPage":1,"fetchSize":50,"fetchUid":0,
     * "mailAccount":"susan1875@163.com"},{"boxName":"INBOX","fetchPage":1,"fetchSize":50,
     * "fetchUid":0,"mailAccount":"daliyjb11@163.com"}]
     * fetchType : 0
     * mode : 1
     * searchText : A
     */

    private int searchType;
    private int mode;
    private String searchText;
    private List<FetchListBean> fetchList;


    public int getSearchType() {
        return searchType;
    }

    public void setSearchType(int searchType) {
        this.searchType = searchType;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public String getSearchText() {
        return searchText;
    }

    public void setSearchText(String searchText) {
        this.searchText = searchText;
    }

    public List<FetchListBean> getFetchList() {
        return fetchList;
    }

    public void setFetchList(List<FetchListBean> fetchList) {
        this.fetchList = fetchList;
    }

    public static class FetchListBean {
        /**
         * boxName : INBOX
         * fetchPage : 1
         * fetchSize : 50
         * fetchUid : 0
         * mailAccount : susan1875@163.com
         */

        private String boxName;
        private int fetchPage;
        private int fetchSize;
        private long fetchUid;
        private String mailAccount;

        public String getBoxName() {
            return boxName;
        }

        public void setBoxName(String boxName) {
            this.boxName = boxName;
        }

        public int getFetchPage() {
            return fetchPage;
        }

        public void setFetchPage(int fetchPage) {
            this.fetchPage = fetchPage;
        }

        public int getFetchSize() {
            return fetchSize;
        }

        public void setFetchSize(int fetchSize) {
            this.fetchSize = fetchSize;
        }

        public long getFetchUid() {
            return fetchUid;
        }

        public void setFetchUid(long fetchUid) {
            this.fetchUid = fetchUid;
        }

        public String getMailAccount() {
            return mailAccount;
        }

        public void setMailAccount(String mailAccount) {
            this.mailAccount = mailAccount;
        }
    }
}
