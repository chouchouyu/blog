package com.cmft.cmail.web.reqBean;

import java.util.List;

public class MailSendReq {


    /**
     * uid : 1
     * boxName : boxName
     * content : content
     * subject : content
     * appendAttachment : [{"code":"科技园路.","fileName":"江苏苏州"}]
     * appendRelatedItem : [{"code":"科技园路.","fileName":"江苏苏州"}]
     * receiver : [{"address":"科技园路.","name":"江苏苏州"}]
     * receiverBCC : [{"address":"科技园路.","name":"江苏苏州"}]
     * receiverCC : [{"address":"科技园路.","name":"江苏苏州"}]
     * sender : [{"address":"科技园路.","name":"江苏苏州"}]
     * originAttachment : [1,12]
     */

    private int uid;
    private String boxName;
    private String content;
    private String subject;
    private List<AppendAttachmentBean> appendAttachment;
    private List<AppendRelatedItemBean> appendRelatedItem;
    private List<ReceiverBean> receiver;
    private List<ReceiverBCCBean> receiverBCC;
    private List<ReceiverCCBean> receiverCC;
    private List<SenderBean> sender;
    private List<Integer> originAttachment;

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getBoxName() {
        return boxName;
    }

    public void setBoxName(String boxName) {
        this.boxName = boxName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public List<AppendAttachmentBean> getAppendAttachment() {
        return appendAttachment;
    }

    public void setAppendAttachment(List<AppendAttachmentBean> appendAttachment) {
        this.appendAttachment = appendAttachment;
    }

    public List<AppendRelatedItemBean> getAppendRelatedItem() {
        return appendRelatedItem;
    }

    public void setAppendRelatedItem(List<AppendRelatedItemBean> appendRelatedItem) {
        this.appendRelatedItem = appendRelatedItem;
    }

    public List<ReceiverBean> getReceiver() {
        return receiver;
    }

    public void setReceiver(List<ReceiverBean> receiver) {
        this.receiver = receiver;
    }

    public List<ReceiverBCCBean> getReceiverBCC() {
        return receiverBCC;
    }

    public void setReceiverBCC(List<ReceiverBCCBean> receiverBCC) {
        this.receiverBCC = receiverBCC;
    }

    public List<ReceiverCCBean> getReceiverCC() {
        return receiverCC;
    }

    public void setReceiverCC(List<ReceiverCCBean> receiverCC) {
        this.receiverCC = receiverCC;
    }

    public List<SenderBean> getSender() {
        return sender;
    }

    public void setSender(List<SenderBean> sender) {
        this.sender = sender;
    }

    public List<Integer> getOriginAttachment() {
        return originAttachment;
    }

    public void setOriginAttachment(List<Integer> originAttachment) {
        this.originAttachment = originAttachment;
    }

    public static class AppendAttachmentBean {
        /**
         * code : 科技园路.
         * fileName : 江苏苏州
         */

        private String code;
        private String fileName;

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getFileName() {
            return fileName;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }
    }

    public static class AppendRelatedItemBean {
        /**
         * code : 科技园路.
         * fileName : 江苏苏州
         */

        private String code;
        private String fileName;

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getFileName() {
            return fileName;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }
    }

    public static class ReceiverBean {
        /**
         * address : 科技园路.
         * name : 江苏苏州
         */

        private String address;
        private String name;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class ReceiverBCCBean {
        /**
         * address : 科技园路.
         * name : 江苏苏州
         */

        private String address;
        private String name;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class ReceiverCCBean {
        /**
         * address : 科技园路.
         * name : 江苏苏州
         */

        private String address;
        private String name;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class SenderBean {
        /**
         * address : 科技园路.
         * name : 江苏苏州
         */

        private String address;
        private String name;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}
