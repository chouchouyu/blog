package com.cmft.cmail.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class CmailSpUtils {
    private static String FILE_NAME = "cmail_sp_data";
    private static Context mContext;

    public CmailSpUtils() {
    }

    public static void setFileName(String fileName) {
        FILE_NAME = fileName;
    }

    public static void init(Context context) {
        mContext = context;
        String deviceId = DeviceId.getDeviceId(context, true);
        putString(Constant.SP_DEVICE_ID, deviceId);
    }

    public static boolean getBoolean(String key) {
        return getBoolean(key, false);
    }

    public static boolean getBoolean(String key, boolean value) {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        return sp.getBoolean(key, value);
    }

    public static void putBoolean(String key, boolean value) {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    public static String getString(String key) {
        return getString(key, "");
    }

    public static String getString(String key, String value) {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        return sp.getString(key, value);
    }

    public static void putString(String key, String value) {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static int getInt(String key) {
        return getInt(key, 0);
    }

    public static int getInt(String key, int value) {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        return sp.getInt(key, value);
    }

    public static void putInt(String key, int value) {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt(key, value);
        editor.apply();
    }

    public static long getLong(String key) {
        return getLong(key, 0L);
    }

    public static long getLong(String key, long value) {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        return sp.getLong(key, value);
    }

    public static void putLong(String key, long value) {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putLong(key, value);
        editor.apply();
    }

    public static void clear() {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.clear();
        editor.apply();
    }

    public static void remove(String key) {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.remove(key);
        editor.apply();
    }

    public static boolean contains(String key) {
        SharedPreferences sp = mContext.getSharedPreferences(FILE_NAME, 0);
        return sp.contains(key);
    }
}