package com.cmft.cmail.waltz;

import android.webkit.JavascriptInterface;

import com.cmft.cmail.waltz.delegate.MailDetailDelegate;


import java.io.Serializable;

public class MailDetail implements Serializable {
    private MailDetailDelegate mMailDetailDelegate;

    public MailDetail(MailDetailDelegate MailDetailDelegate) {
        mMailDetailDelegate = MailDetailDelegate;
    }

    @JavascriptInterface
    public void openMailAttachment(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.openMailAttachment(data, option);
        }
    }


    /**
     * 获取邮件详情
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void getMailDetail(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.getMailDetail(data, option);
        }
    }

    @JavascriptInterface
    public void mailOperator(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.mailOperator(data, option);
        }
    }


    /**
     * 邮件搜索
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void mailSearch(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.mailSearch(data, option);
        }
    }

    /**
     * 邮件筛选
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void mailFilter(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.mailFilter(data, option);
        }
    }

    @JavascriptInterface
    public void saveMailToDrafts(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.saveMailToDrafts(data, option);
        }
    }

    /**
     * 添加常用语
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void addIdiomList(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.addIdiomList(data, option);
        }
    }

    /**
     * 获取常用语
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void getIdiomList(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.getIdiomList(data, option);
        }
    }

    @JavascriptInterface
    public void getMailSignList(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.getMailSignList(data, option);
        }
    }


    /**
     * 删除附件
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void deleteAttachment(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.deleteAttachment(data, option);
        }
    }


    /**
     * 取消发送
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void cancelSendEmail(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.cancelSendEmail(data, option);
        }
    }


    /**
     * 打开附件（发件箱）
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void openAttachment(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.openAttachment(data, option);
        }
    }


    /**
     * 删除常用语
     *
     * @param data
     * @param option
     */
    @JavascriptInterface
    public void deleteIdiomList(String data, String option) {
        CallJsUtils.printJSCall(data, option);
        if (mMailDetailDelegate != null) {
            mMailDetailDelegate.deleteIdiomList(data, option);
        }
    }


}