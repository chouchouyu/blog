package com.cmft.cmail.db.dao;

import com.cmft.cmail.db.model.MailAttachment;

import java.util.List;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Relation;
import android.arch.persistence.room.Update;

@Dao
public interface MailAttachmentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<MailAttachment> mailAttachmentBean);

    @Update
    void update(MailAttachment attachment);

    @Query("SELECT * FROM  attachment_info where mailUid = :mailUid AND folderName =:folderName " +
            "AND " +
            "mailAccount =:account AND attachmentName =:attachmentName")
    List<MailAttachment> getMailAttachment(long mailUid, String folderName, String account, String
            attachmentName);


    @Query("SELECT * FROM  attachment_info where mailUid = :mailUid AND folderName =:folderName " +
            "AND " +
            "mailAccount =:account ")
    List<MailAttachment> getMailAttachments(String account, String folderName, long mailUid);

}
