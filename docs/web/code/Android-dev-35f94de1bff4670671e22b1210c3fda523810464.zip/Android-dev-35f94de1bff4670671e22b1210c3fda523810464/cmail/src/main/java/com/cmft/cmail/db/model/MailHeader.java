package com.cmft.cmail.db.model;


import java.util.LinkedHashMap;
import java.util.List;

import android.support.annotation.NonNull;
import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;


@Entity(tableName = "MailHeader",
        foreignKeys = {@ForeignKey(entity = MailAccount.class,
                parentColumns = "mailAccount", childColumns = "mailAccount",
                onDelete = ForeignKey.CASCADE, onUpdate = ForeignKey.CASCADE)})
public class MailHeader implements Comparable<MailHeader> {
    /**
     * uid : 1564744180
     * subject : test send related
     * from : testapp01@cmrhic.com
     * timestamp : 1565782007000
     * attachmentCount : 1
     * size : 100605
     * unseen : false
     * flagged : false
     */
    @PrimaryKey
    @NonNull
    public String id;

    @ColumnInfo(index = true)
    @NonNull
    private long uid;

    private String subject;
    private String from;
    private long timestamp;
    private long mailTime;
    private int attachmentCount;
    private int size;
    private boolean unseen;
    private boolean flagged;
    @ColumnInfo(index = true)
    private String mailAccount;
    private String boxName;
    @Embedded
    private SenderBean sender;

    private List<ReceiverBean> receiver;
    private List<ReceiverBean> receiverBCC;
    private List<ReceiverBean> receiverCC;


    private LinkedHashMap<String, String> receiverMap;
    private LinkedHashMap<String, String> receiverBCCMap;
    private LinkedHashMap<String, String> receiverCCMap;

    public LinkedHashMap<String, String> getReceiverMap() {
        return receiverMap;
    }

    public void setReceiverMap(LinkedHashMap<String, String> receiverMap) {
        this.receiverMap = receiverMap;
    }

    public LinkedHashMap<String, String> getReceiverBCCMap() {
        return receiverBCCMap;
    }

    public void setReceiverBCCMap(LinkedHashMap<String, String> receiverBCCMap) {
        this.receiverBCCMap = receiverBCCMap;
    }

    public LinkedHashMap<String, String> getReceiverCCMap() {
        return receiverCCMap;
    }

    public void setReceiverCCMap(LinkedHashMap<String, String> receiverCCMap) {
        this.receiverCCMap = receiverCCMap;
    }

    @NonNull
    public long getUid() {
        return uid;
    }

    public void setUid(@NonNull long uid) {
        this.uid = uid;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public int getAttachmentCount() {
        return attachmentCount;
    }

    public void setAttachmentCount(int attachmentCount) {
        this.attachmentCount = attachmentCount;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public boolean isUnseen() {
        return unseen;
    }

    public void setUnseen(boolean unseen) {
        this.unseen = unseen;
    }

    public boolean isFlagged() {
        return flagged;
    }

    public void setFlagged(boolean flagged) {
        this.flagged = flagged;
    }

    public String getMailAccount() {
        return mailAccount;
    }

    public void setMailAccount(String mailAccount) {
        this.mailAccount = mailAccount;
    }

    public long getMailTime() {
        return mailTime;
    }

    public void setMailTime(long mailTime) {
        this.mailTime = mailTime;
    }

    public String getBoxName() {
        return boxName;
    }

    public void setBoxName(String boxName) {
        this.boxName = boxName;
    }

    public SenderBean getSender() {
        return sender;
    }

    public void setSender(SenderBean sender) {
        this.sender = sender;
    }

    public List<ReceiverBean> getReceiver() {
        return receiver;
    }

    public void setReceiver(List<ReceiverBean> receiver) {
        this.receiver = receiver;
    }

    public List<ReceiverBean> getReceiverBCC() {
        return receiverBCC;
    }

    public void setReceiverBCC(List<ReceiverBean> receiverBCC) {
        this.receiverBCC = receiverBCC;
    }

    public List<ReceiverBean> getReceiverCC() {
        return receiverCC;
    }

    public void setReceiverCC(List<ReceiverBean> receiverCC) {
        this.receiverCC = receiverCC;
    }

    @Override
    public int compareTo(@android.support.annotation.NonNull MailHeader mailHeader) {
        return (int) (mailHeader.getUid() - this.uid);
    }

    @NonNull
    public String getId() {
        return id;
    }

    public void setId(@NonNull String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "MailHeader{" +
                "id='" + id + '\'' +
                ", uid=" + uid +
                ", subject='" + subject + '\'' +
                ", from='" + from + '\'' +
                ", timestamp=" + timestamp +
                ", mailTime=" + mailTime +
                ", attachmentCount=" + attachmentCount +
                ", size=" + size +
                ", unseen=" + unseen +
                ", flagged=" + flagged +
                ", mailAccount='" + mailAccount + '\'' +
                ", boxName='" + boxName + '\'' +
                ", sender=" + sender +
                ", receiver=" + receiver +
                ", receiverBCC=" + receiverBCC +
                ", receiverCC=" + receiverCC +
                ", receiverMap=" + receiverMap +
                ", receiverBCCMap=" + receiverBCCMap +
                ", receiverCCMap=" + receiverCCMap +
                '}';
    }
}
