package com.cmft.cmail.core;

import android.arch.persistence.db.SimpleSQLiteQuery;
import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;

import com.cmft.android.sandbox.crypter.utils.EncryptData;
import com.cmft.cmail.Cmail;
import com.cmft.cmail.NetCallBack;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailHeaderDao;
import com.cmft.cmail.db.model.GetMailDataBean;
import com.cmft.cmail.db.model.MailFolder;
import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.db.model.MailStatusRes;
import com.cmft.cmail.db.model.SearchBean;
import com.cmft.cmail.db.model.SenderBean;
import com.cmft.cmail.db.model.TobeSend;
import com.cmft.cmail.utils.CmailUtils;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.waltz.CallJsUtils;
import com.cmft.cmail.web.RetrofitService;
import com.cmft.cmail.web.resBean.BaseRes;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.RESULT;

public class HelperCmailMailList extends HelperCmail {

    private static final String TAG = Constant.TAG + "." + "List";

    @Override
    public synchronized void init(Context context, RetrofitService retrofit, CmailDatabase
            database, ThreadPoolExecutor executor, ILogger logger, HelperSandbox sandbox) {
        super.init(context, retrofit, database, executor, logger, sandbox);
    }


    /**
     * 邮件搜索
     *
     * @param mailList
     * @param searchType
     * @param mode
     * @param searchText
     * @param option
     */
    public void mailSearch(final List<SearchBean.FetchListBean> mailList, final int searchType,
                           final int mode, final String searchText, final String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject body = new JSONObject();
                final MailHeaderDao mailHeaderDao = getDatabase().getMailHeaderDao();
                try {
                    List<MailHeader> mailHeaders = new ArrayList<>();
                    String boxName = "";
                    for (SearchBean.FetchListBean bean : mailList) {
                        boxName = bean.getBoxName();
                        String mail = bean.getMailAccount();
                        int fetchSize = bean.getFetchSize();
                        long uid = bean.getFetchUid();
                        if (boxName.equals(Constant.TobeSent)) {
                            switch (searchType) {
                                case 0:
                                    SimpleSQLiteQuery searchAllQuery = new
                                            SimpleSQLiteQuery("SELECT * FROM TobeSend" +
                                            " WHERE (mailAccount LIKE" +
                                            " '" + mail + "' AND receiverMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  OR (mailAccount " +
                                            "LIKE '" + mail + "' AND " +
                                            "receiverBCCMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  OR (mailAccount " +
                                            "LIKE '" + mail + "' AND " +
                                            "receiverCCMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%') OR (mailAccount " +
                                            "LIKE '" + mail + "' AND " +
                                            "subject " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%') ORDER BY uid DESC " +
                                            "LIMIT " +
                                            fetchSize);


                                    getLogger().debug(TAG, "mailSearch:  " +
                                            "searchType-0;boxName-TobeSent;sql: " +
                                            searchAllQuery.getSql());

                                    if (mailHeaderDao != null) {
                                        mailHeaders.addAll(mailHeaderDao.searchAll
                                                (searchAllQuery));
                                    }

                                    break;
                                case 1://发件人
                                    SimpleSQLiteQuery searchByFromQuery = new
                                            SimpleSQLiteQuery("SELECT * FROM TobeSend" +
                                            " WHERE (" +
                                            " mailAccount " +
                                            "LIKE" +
                                            " '%" + searchText + "%') ORDER BY uid DESC " +
                                            "LIMIT " +
                                            fetchSize);

                                    getLogger().debug(TAG, "mailSearch:  " +
                                            "searchType-1;boxName-TobeSent;sql: " +
                                            searchByFromQuery.getSql());
                                    if (mailHeaderDao != null) {
                                        mailHeaders.addAll(mailHeaderDao.searchAll
                                                (searchByFromQuery));
                                    }
                                    break;
                                case 3: //收件人


//                                            SELECT * FROM TobeSend WHERE (mailAccount LIKE
//                                            'daliyjb11@163.com' AND boxName LIKE 'Trash' AND
//                                            receiver LIKE '%d%')
//                                            or(mailAccount LIKE 'daliyjb11@163.com' AND boxName
//                                            LIKE 'Trash' AND receiverBCC LIKE '%d%')
//                                            or(mailAccount LIKE 'daliyjb11@163.com' AND boxName
//                                            LIKE 'Trash' AND receiverCC LIKE '%d%')
//                                            ORDER BY uid DESC


                                    SimpleSQLiteQuery searchByReceiverQuery = new
                                            SimpleSQLiteQuery("SELECT * FROM TobeSend" +
                                            " WHERE (mailAccount LIKE '" + mail + "' AND " +
                                            "receiverMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  OR (mailAccount " +
                                            "LIKE '" + mail + "' AND " +
                                            "receiverBCCMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  OR (mailAccount " +
                                            "LIKE '" + mail + "' AND " +
                                            "receiverCCMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  ORDER BY uid DESC " +
                                            "LIMIT " +
                                            fetchSize);


                                    getLogger().debug(TAG, "mailSearch:  " +
                                            "searchType-3;boxName-TobeSent;sql: " +
                                            searchByReceiverQuery.getSql());
                                    if (mailHeaderDao != null) {

                                        mailHeaders.addAll(mailHeaderDao.searchAll
                                                (searchByReceiverQuery));
                                    }
                                    break;
                                case 2:   // 主题

                                    SimpleSQLiteQuery searchBySubjectQuery = new
                                            SimpleSQLiteQuery("SELECT * FROM TobeSend" +
                                            " WHERE mailAccount LIKE '" + mail + "' AND  " +
                                            "subject " +
                                            "LIKE" +
                                            " '%" + searchText + "%'  ORDER BY uid DESC " +
                                            "LIMIT " +
                                            fetchSize);

                                    getLogger().debug(TAG, "mailSearch:  " +
                                            "searchType-2;boxName-TobeSent;sql: " +
                                            searchBySubjectQuery.getSql());
                                    if (mailHeaderDao != null) {

                                        mailHeaders.addAll(mailHeaderDao.searchAll
                                                (searchBySubjectQuery));
                                    }
                                    break;
                                default:
                                    break;
                            }
                        } else {
                            switch (searchType) {
                                //搜索是否去重

                                case 0:
                                    SimpleSQLiteQuery searchAllQuery = new
                                            SimpleSQLiteQuery("SELECT * FROM " +
                                            "MailHeader" +
                                            " WHERE (mailAccount LIKE '" + mail + "' " +
                                            "AND " +
                                            "uid > '" + uid + "' AND  " +
                                            "address " +
                                            "LIKE" +
                                            " '%" + searchText + "%') OR (mailAccount" +
                                            " " +
                                            "LIKE '" + mail + "' AND " +
                                            "uid > '" + uid + "' AND " +
                                            "name " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%') OR (mailAccount " +
                                            "LIKE" +
                                            " '" + mail + "' AND " +
                                            "uid > '" + uid + "' AND " +
                                            "receiverMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  OR (mailAccount" +
                                            " " +
                                            "LIKE '" + mail + "' AND " +
                                            "uid > '" + uid + "' AND " +
                                            "receiverBCCMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  OR (mailAccount" +
                                            " " +
                                            "LIKE '" + mail + "' AND " +
                                            "uid > '" + uid + "' AND " +
                                            "receiverCCMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%') OR (mailAccount " +
                                            "LIKE '" + mail + "' AND " +
                                            "uid > '" + uid + "' AND " +
                                            "subject " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%') ORDER BY uid " +
                                            "DESC LIMIT " +
                                            fetchSize);


                                    getLogger().debug(TAG, "mailSearch:  " +
                                            "searchType-0;boxName-INBOX;sql: " +
                                            searchAllQuery.getSql());

                                    if (mailHeaderDao != null) {

                                        mailHeaders.addAll(mailHeaderDao.searchAll
                                                (searchAllQuery));
                                    }
                                    break;
                                case 1://发件人
                                    SimpleSQLiteQuery searchByFromQuery = new
                                            SimpleSQLiteQuery("SELECT * FROM " +
                                            "MailHeader" +
                                            " WHERE (mailAccount LIKE '" + mail + "' " +
                                            "AND " +
                                            "uid > '" + uid + "' AND  " +
                                            "address " +
                                            "LIKE" +
                                            " '%" + searchText + "%') OR (mailAccount" +
                                            " " +
                                            "LIKE '" + mail + "' AND " +
                                            "uid > '" + uid + "' AND " +
                                            "name " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  ORDER BY uid " +
                                            "DESC LIMIT " +
                                            fetchSize);

                                    getLogger().debug(TAG, "mailSearch:  " +
                                            "searchType-1;boxName-INBOX;sql: " +
                                            searchByFromQuery.getSql());
                                    if (mailHeaderDao != null) {

                                        mailHeaders.addAll(mailHeaderDao.searchAll
                                                (searchByFromQuery));
                                    }
                                    break;
                                case 3: //收件人


//                                            SELECT * FROM MailHeader WHERE (mailAccount LIKE
//                                            'daliyjb11@163.com' AND boxName LIKE 'Trash' AND
//                                            receiver LIKE '%d%')
//                                            or(mailAccount LIKE 'daliyjb11@163.com' AND boxName
//                                            LIKE 'Trash' AND receiverBCC LIKE '%d%')
//                                            or(mailAccount LIKE 'daliyjb11@163.com' AND boxName
//                                            LIKE 'Trash' AND receiverCC LIKE '%d%')
//                                            ORDER BY uid DESC


                                    SimpleSQLiteQuery searchByReceiverQuery = new
                                            SimpleSQLiteQuery("SELECT * FROM " +
                                            "MailHeader" +
                                            " WHERE (mailAccount LIKE '" + mail + "' " +
                                            "AND " +
                                            "uid > '" + uid + "' AND " +
                                            "receiverMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  OR (mailAccount" +
                                            " " +
                                            "LIKE '" + mail + "' AND " +
                                            "uid > '" + uid + "' AND " +
                                            "receiverBCCMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  OR (mailAccount" +
                                            " " +
                                            "LIKE '" + mail + "' AND " +
                                            "uid > '" + uid + "' AND " +
                                            "receiverCCMap " +
                                            "LIKE" +
                                            " " +
                                            "'%" + searchText + "%')  ORDER BY uid " +
                                            "DESC LIMIT " +
                                            fetchSize);


                                    getLogger().debug(TAG, "mailSearch:  " +
                                            "searchType-3;boxName-INBOX;sql: " +
                                            searchByReceiverQuery.getSql());
                                    if (mailHeaderDao != null) {

                                        mailHeaders.addAll(mailHeaderDao.searchAll
                                                (searchByReceiverQuery));
                                    }
                                    break;
                                case 2:   // 主题
                                    SimpleSQLiteQuery searchBySubjectQuery = new
                                            SimpleSQLiteQuery("SELECT * FROM " +
                                            "MailHeader" +
                                            " WHERE mailAccount LIKE '" + mail + "' " +
                                            "AND " +
                                            "uid > '" + uid + "' AND  " +
                                            "subject " +
                                            "LIKE" +
                                            " '%" + searchText + "%'  ORDER BY uid " +
                                            "DESC LIMIT " +
                                            fetchSize);

                                    getLogger().debug(TAG, "mailSearch:  " +
                                            "searchType-2;boxName-INBOX;sql: " +
                                            searchBySubjectQuery.getSql());
                                    if (mailHeaderDao != null) {

                                        mailHeaders.addAll(mailHeaderDao.searchAll
                                                (searchBySubjectQuery));
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                    }

                    //排序
                    Collections.sort(mailHeaders);
                    String arrList = new Gson().toJson(mailHeaders, new
                            TypeToken<List<MailFolder>>() {
                            }.getType());
                    JSONArray jsonArray = new JSONArray(arrList);
                    //列表待发送 reciver放sender里
//                    if (boxName.equals(Constant.TobeSent)) {
                        jsonArray = CmailUtils.modifyReciverTORecivers(jsonArray);
//                    }
                    body.put(CODE, 0);
                    body.put(MESSAGE, "success");
                    body.put(RESULT, jsonArray.toString());
                    CallJsUtils.callJs(body, option);

                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }
        });
    }

    /**
     * 文件filter栏
     *
     * @param list
     * @param fetchType
     * @param filterType
     * @param mode
     * @param option
     */
    public void mailFilter(final List<GetMailDataBean> list, final int fetchType, final int
            filterType, final int mode,
                           final String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject body = new JSONObject();
                List<MailHeader> mailHeaders = new ArrayList<>();
                MailHeaderDao mailHeaderDao = CmailDatabase.getInstance(CmailCenter
                        .getContext())
                        .getMailHeaderDao();
                for (GetMailDataBean mailDataBean : list) {
//                                    long timestamp = mailHeaderDao.queryTimestampByUid
//                                            (mailDataBean.getMailAccount(),
//                                                    mailDataBean.getBoxName(), mailDataBean
//                                                            .getFetchUid());
                    long uid = mailDataBean.getFetchUid();
                    int fetchSize = mailDataBean.getFetchSize();


                    if (fetchType == 0) {//0 系统邮件夹, 1 未读邮件夹，2 星标邮件夹
                        if (filterType == 1) {
                            getLogger().debug(TAG, " mailList " +
                                    "-mailFilter  全局|附件");
                            //系统附件
                            mailHeaders.addAll(mailHeaderDao
                                    .searchMailHeadersByAttachment(mailDataBean
                                                    .getBoxName(),
                                            uid, mailDataBean
                                                    .getMailAccount(), fetchSize));
                        } else if (filterType == 2) {
                            getLogger().debug(TAG, " mailList " +
                                    "-mailFilter  全局|未读");
                            //系统未读
                            mailHeaders.addAll(mailHeaderDao
                                    .searchMailHeadersByUnseen(mailDataBean
                                                    .getBoxName(),
                                            /*fetchSize,*/ uid,
                                            mailDataBean.getMailAccount(),
                                            true, fetchSize));
                        } else if (filterType == 0) {
                            getLogger().debug(TAG, " mailList " +
                                    "-mailFilter  全局|星标");
                            //系统星标
                            mailHeaders.addAll(mailHeaderDao
                                    .searchMailHeadersByFlagged(mailDataBean
                                                    .getBoxName(),
                                            /*fetchSize,*/ uid,
                                            mailDataBean.getMailAccount(),
                                            true, fetchSize));
                        }

                    } else if (fetchType == 1) {
                        if (filterType == 1) {
                            getLogger().debug(TAG, " mailList " +
                                    "-mailFilter  未读|附件");
                            //附件未读
                            mailHeaders.addAll(mailHeaderDao
                                    .searchMailHeadersByAttachmentWithUnseen
                                            (uid, mailDataBean.getMailAccount(), true,
                                                    fetchSize));
                        } else if (filterType == 2) {
                            getLogger().debug(TAG, " mailList " +
                                    "-mailFilter  未读|未读");
                            //系统未读
                            mailHeaders.addAll(mailHeaderDao
                                    .searchMailHeadersByUnseen(uid,
                                            mailDataBean.getMailAccount(),
                                            true, fetchSize));
                        } else if (filterType == 0) {
                            getLogger().debug(TAG, " mailList " +
                                    "-mailFilter  未读|星标");
                            //未读星标
                            mailHeaders.addAll(mailHeaderDao
                                    .searchMailHeadersByUnseenWithFlag(uid,
                                            mailDataBean.getMailAccount(),
                                            true, true, fetchSize));
                        }

                    } else if (fetchType == 2) {
                        if (filterType == 1) {
                            getLogger().debug(TAG, " mailList " +
                                    "-mailFilter  星标|附件");
                            //   附件星标
                            mailHeaders.addAll(mailHeaderDao
                                    .searchMailHeadersByAttachmentWithFlagged
                                            (uid, mailDataBean.getMailAccount(), true,
                                                    fetchSize));
                        } else if (filterType == 2) {
                            getLogger().debug(TAG, " mailList " +
                                    "-mailFilter  星标|未读");
                            //未读星标
                            mailHeaders.addAll(mailHeaderDao
                                    .searchMailHeadersByUnseenWithFlag(uid,
                                            mailDataBean.getMailAccount(),
                                            true, true, fetchSize));
                        } else if (filterType == 0) {
                            getLogger().debug(TAG, " mailList " +
                                    "-mailFilter  星标|星标");
                            //系统星标
                            mailHeaders.addAll(mailHeaderDao
                                    .searchMailHeadersByFlagged(uid,
                                            mailDataBean.getMailAccount(),
                                            true, fetchSize));
                        }
                    }

                }
                //排序
                Collections.sort(mailHeaders);

                String arrList = new Gson().toJson(mailHeaders, new
                        TypeToken<List<MailFolder>>() {
                        }.getType());


                try {
                    JSONArray jsonArr = new JSONArray(arrList);
                    jsonArr = CmailUtils.modifyReciverTORecivers(jsonArr);
                    body.put(CODE, 0);
                    body.put(MESSAGE, "success");
                    body.put("result", jsonArr.toString());
                    CallJsUtils.callJs(body, option);

                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }
        });
    }


    /**
     * 邮件列表的
     *
     * @param list
     * @param option
     * @param fetchType
     * @param filterType
     * @param searchType
     * @param searchText
     * @param mode
     * @param isReFresh
     */
    public void getMailHeader(final List<GetMailDataBean> list, final String option, final int
            fetchType, final int filterType, final int searchType, final String searchText, final
                              int
                                      mode,
                              final boolean
                                      isReFresh) {

        getExecutor().execute(new Runnable() {

            @Override
            public void run() {
                final MailHeaderDao mailHeaderDao = getDatabase().getMailHeaderDao();
                int flag = 1;
                final List<MailHeader> resultList = new ArrayList<>();
                List<MailHeader> queryList = new ArrayList<>();
                String boxname = "";
                for (GetMailDataBean bean : list) {
                    String email = bean.getMailAccount();
                    boxname = bean.getBoxName();
                    int fetchSize = bean.getFetchSize();
                    long uid = bean.getFetchUid();
                    queryList = new ArrayList<>();

                    getLogger().debug(TAG, "获取邮件列表:" + " boxname-" + boxname + ";" +
                            " email-" + email + "; uid-" + uid + "; fetchSize-" + fetchSize + "; " +
                            "folderType-" + fetchType + "; " + "searchText-" + searchText + "；" +
                            "filterType-" + filterType + "；" + "searchType-" + searchType + "；" +
                            "mode-" + mode + "; " +
                            "isReFresh-" + isReFresh);

                    if (TextUtils.equals(boxname, Constant.TobeSent)) {
                        List<TobeSend> tobeSendList = getDatabase().getTobeSendDao()
                                .queryTobeSendByMail
                                        (email, uid);
                        for (TobeSend tobeSend :
                                tobeSendList) {
                            TobeSend.MailBody mailBody = tobeSend.getMailBody();
                            MailHeader mailHeader = new MailHeader();
                            mailHeader.setBoxName(Constant.TobeSent);
                            mailHeader.setMailTime(mailBody.getMailTime());
                            mailHeader.setMailAccount(tobeSend.getMailAccount());
                            mailHeader.setSubject(mailBody.getSubject());
                            mailHeader.setReceiver(mailBody.getReceiver());
                            mailHeader.setReceiverBCC(mailBody.getReceiverBCC());
                            mailHeader.setReceiverCC(mailBody.getReceiverCC());
                            mailHeader.setUid(mailBody.getOriginUid());
//                            mailHeader.setUid(mailBody.getMailTime());
                            SenderBean senderBean = new SenderBean();
                            senderBean.setAddress(tobeSend.getMailAccount());
                            senderBean.setName("");
                            mailHeader.setSender(senderBean);
                            mailHeader.setId(EncryptData.MD5_32(mailHeader.getUid() +
                                    mailHeader.getBoxName()
                                    +
                                    mailHeader.getMailAccount()));
                            mailHeader.setAttachmentCount(mailBody.getAttachmentCount());
                            resultList.add(mailHeader);
                            queryList.add(mailHeader);
                        }
                    } else {
                        if (isReFresh) { // 是否是下拉刷新或上啦加载

                            ////=======================debug ====================
//                            String mailAccount = "susan1875@163.com";
//                            String boxName = "INBOX";
//                            //                            long maxuid = 99999999999999L;
//                            long maxuid = 1570595923;
//
//
//                            SimpleSQLiteQuery upQuery = new
//                                    SimpleSQLiteQuery("select * from MailHeader " +
//                                    "where " +
//                                    "mailAccount == '" + email +
//                                    "' and boxName == '"
//                                    + boxName + "' and  uid <'" + uid + "' " +
//                                    "ORDER BY uid DESC LIMIT " +
//                                    fetchSize);
//
//                            getLogger().debug(TAG, "getMailHeader:  " +
//                                    "testQuery;sql: " +
//                                    upQuery.getSql());
//
//                            List<MailHeader> testList = mailHeaderDao.searchAll
//                                    (upQuery);
//
//                            getLogger().debug(TAG,
//                                    "getMailHeader:testList 查出大小 :" +
//                                            testList.size());

////=======================debug ====================
                            if (filterType == -1 && searchType >= 0) {
                                if (searchType == 0) {
                                    //全部
                                    if (mode == 0) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  全局|search全部|上拉加载");


                                        SimpleSQLiteQuery searchAllQuery = new
                                                SimpleSQLiteQuery("SELECT * FROM " +
                                                "MailHeader" +
                                                " WHERE (mailAccount LIKE '" + email + "' " +
                                                "AND " +
                                                "uid < '" + uid + "' AND  " +
                                                "address " +
                                                "LIKE" +
                                                " '%" + searchText + "%') OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid < '" + uid + "' AND " +
                                                "name " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%') OR (mailAccount " +
                                                "LIKE" +
                                                " '" + email + "' AND " +
                                                "uid < '" + uid + "' AND " +
                                                "receiverMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid < '" + uid + "' AND " +
                                                "receiverBCCMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid < '" + uid + "' AND " +
                                                "receiverCCMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%') OR (mailAccount " +
                                                "LIKE '" + email + "' AND " +
                                                "uid < '" + uid + "' AND " +
                                                "subject " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%') ORDER BY uid " +
                                                "DESC LIMIT " +
                                                fetchSize);


                                        getLogger().debug(TAG, "mailSearch:  " +
                                                "searchType-0;sql: " +
                                                searchAllQuery.getSql());

                                        queryList = mailHeaderDao.searchAll
                                                (searchAllQuery);
                                        resultList.addAll(queryList);

                                    } else if (mode == 1) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  全局|search全部|下拉刷新");

                                        SimpleSQLiteQuery searchAllQuery = new
                                                SimpleSQLiteQuery("SELECT * FROM " +
                                                "MailHeader" +
                                                " WHERE (mailAccount LIKE '" + email + "' " +
                                                "AND " +
                                                "uid > '" + uid + "' AND  " +
                                                "address " +
                                                "LIKE" +
                                                " '%" + searchText + "%') OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid > '" + uid + "' AND " +
                                                "name " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%') OR (mailAccount " +
                                                "LIKE" +
                                                " '" + email + "' AND " +
                                                "uid > '" + uid + "' AND " +
                                                "receiverMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid > '" + uid + "' AND " +
                                                "receiverBCCMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid > '" + uid + "' AND " +
                                                "receiverCCMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%') OR (mailAccount " +
                                                "LIKE '" + email + "' AND " +
                                                "uid > '" + uid + "' AND " +
                                                "subject " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%') ORDER BY uid " +
                                                "DESC LIMIT " +
                                                fetchSize);


                                        getLogger().debug(TAG, "mailSearch:  " +
                                                "searchType-0;sql: " +
                                                searchAllQuery.getSql());

                                        queryList = mailHeaderDao.searchAll
                                                (searchAllQuery);
                                        resultList.addAll(queryList);


                                    }

                                }
                                if (searchType == 1) {
                                    //发件人
                                    if (mode == 0) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  全局|search发件人|上拉加载");
                                        SimpleSQLiteQuery searchByFromQuery = new
                                                SimpleSQLiteQuery("SELECT * FROM " +
                                                "MailHeader" +
                                                " WHERE (mailAccount LIKE '" + email + "' " +
                                                "AND " +
                                                "uid < '" + uid + "' AND  " +
                                                "address " +
                                                "LIKE" +
                                                " '%" + searchText + "%') OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid < '" + uid + "' AND " +
                                                "name " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  ORDER BY uid " +
                                                "DESC LIMIT " +
                                                fetchSize);

                                        getLogger().debug(TAG, "mailSearch:  " +
                                                "searchType-1;sql: " +
                                                searchByFromQuery.getSql());
                                        queryList = mailHeaderDao.searchAll
                                                (searchByFromQuery);
                                        resultList.addAll(queryList);
                                    } else if (mode == 1) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  全局|search发件人|下拉刷新");
                                        SimpleSQLiteQuery searchByFromQuery = new
                                                SimpleSQLiteQuery("SELECT * FROM " +
                                                "MailHeader" +
                                                " WHERE (mailAccount LIKE '" + email + "' " +
                                                "AND " +
                                                "uid > '" + uid + "' AND  " +
                                                "address " +
                                                "LIKE" +
                                                " '%" + searchText + "%') OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid > '" + uid + "' AND " +
                                                "name " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  ORDER BY uid " +
                                                "DESC LIMIT " +
                                                fetchSize);

                                        getLogger().debug(TAG, "mailSearch:  " +
                                                "searchType-1;sql: " +
                                                searchByFromQuery.getSql());

                                        queryList = mailHeaderDao.searchAll
                                                (searchByFromQuery);
                                        resultList.addAll(queryList);
                                    }

                                }
                                if (searchType == 2) {
                                    //主题
                                    if (mode == 0) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  全局|search主题|上拉加载");
                                        SimpleSQLiteQuery searchBySubjectQuery = new
                                                SimpleSQLiteQuery("SELECT * FROM " +
                                                "MailHeader" +
                                                " WHERE mailAccount LIKE '" + email + "' " +
                                                "AND " +
                                                "uid < '" + uid + "' AND  " +
                                                "subject " +
                                                "LIKE" +
                                                " '%" + searchText + "%'  ORDER BY uid " +
                                                "DESC LIMIT " +
                                                fetchSize);

                                        getLogger().debug(TAG, "mailSearch:  " +
                                                "searchType-2;sql: " +
                                                searchBySubjectQuery.getSql());

                                        queryList = mailHeaderDao.searchAll
                                                (searchBySubjectQuery);
                                        resultList.addAll(queryList);
                                    } else if (mode == 1) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  全局|search主题|下拉刷新");
                                        SimpleSQLiteQuery searchBySubjectQuery = new
                                                SimpleSQLiteQuery("SELECT * FROM " +
                                                "MailHeader" +
                                                " WHERE mailAccount LIKE '" + email + "' " +
                                                "AND " +
                                                "uid > '" + uid + "' AND  " +
                                                "subject " +
                                                "LIKE" +
                                                " '%" + searchText + "%'  ORDER BY uid " +
                                                "DESC LIMIT " +
                                                fetchSize);

                                        getLogger().debug(TAG, "mailSearch:  " +
                                                "searchType-2;sql: " +
                                                searchBySubjectQuery.getSql());

                                        queryList = mailHeaderDao.searchAll
                                                (searchBySubjectQuery);
                                        resultList.addAll(queryList);
                                    }

                                }
                                if (searchType == 3) {
                                    //收件人
                                    if (mode == 0) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  全局|search收件人|上拉加载");
                                        SimpleSQLiteQuery searchByReceiverQuery = new
                                                SimpleSQLiteQuery("SELECT * FROM " +
                                                "MailHeader" +
                                                " WHERE (mailAccount LIKE '" + email + "' " +
                                                "AND " +
                                                "uid < '" + uid + "' AND " +
                                                "receiverMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid < '" + uid + "' AND " +
                                                "receiverBCCMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid < '" + uid + "' AND " +
                                                "receiverCCMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  ORDER BY uid " +
                                                "DESC LIMIT " +
                                                fetchSize);


                                        getLogger().debug(TAG, "mailSearch:  " +
                                                "searchType-3;sql: " +
                                                searchByReceiverQuery.getSql());
                                        queryList = mailHeaderDao.searchAll
                                                (searchByReceiverQuery);
                                        resultList.addAll(queryList);
                                    } else if (mode == 1) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  全局|search收件人|下拉刷新");

                                        SimpleSQLiteQuery searchByReceiverQuery = new
                                                SimpleSQLiteQuery("SELECT * FROM " +
                                                "MailHeader" +
                                                " WHERE (mailAccount LIKE '" + email + "' " +
                                                "AND " +
                                                "uid > '" + uid + "' AND " +
                                                "receiverMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid > '" + uid + "' AND " +
                                                "receiverBCCMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  OR (mailAccount" +
                                                " " +
                                                "LIKE '" + email + "' AND " +
                                                "uid > '" + uid + "' AND " +
                                                "receiverCCMap " +
                                                "LIKE" +
                                                " " +
                                                "'%" + searchText + "%')  ORDER BY uid " +
                                                "DESC LIMIT " +
                                                fetchSize);


                                        getLogger().debug(TAG, "mailSearch:  " +
                                                "searchType-3;sql: " +
                                                searchByReceiverQuery.getSql());
                                        queryList = mailHeaderDao.searchAll
                                                (searchByReceiverQuery);
                                        resultList.addAll(queryList);
                                    }
                                }
                            } else if ((fetchType % 10) == 0) {//全局
                                if (filterType == -1 && searchType == -1) {
                                    //正常加载
                                    if (mode == 1) {
                                        //  更新数据
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  全局|正常加载|下拉刷新：网络请求，更新数据");
                                        queryList = new ArrayList<>();
//                                        SimpleSQLiteQuery downQuery = new
//                                                SimpleSQLiteQuery("select * from MailHeader " +
//                                                "where " +
//                                                "mailAccount == '" + email +
//                                                "' and boxName == '"
//                                                + boxname + "' and  uid >'" + uid + "' " +
//                                                "ORDER BY uid DESC " +
//                                                "LIMIT " +
//                                                fetchSize);
//
//                                        getLogger().debug(TAG, "getMailHeader:  " +
//                                                "downQuery;sql: " +
//                                                downQuery.getSql());
//
//                                        List<MailHeader> rangeList = mailHeaderDao.searchAll
//                                                (downQuery);
//
//                                        getLogger().debug(TAG,
//                                                "getMailHeader:downQuery 查出大小 :" +
//                                                        rangeList.size());
//
//                                        resultList.addAll(rangeList);


                                        //  下拉刷新，同步100条数据
                                        //  如果是下拉刷新 需要 更新
                                        updateEarlyData(mailHeaderDao, resultList, list);

                                    } else if (mode == 0) {

                                        SimpleSQLiteQuery upQuery = new
                                                SimpleSQLiteQuery("select * from MailHeader " +
                                                "where " +
                                                "mailAccount == '" + email +
                                                "' and boxName == '"
                                                + boxname + "' and  uid <'" + uid + "' " +
                                                "ORDER BY uid DESC " +
                                                "LIMIT " +
                                                fetchSize);

                                        getLogger().debug(TAG, "getMailHeader:  " +
                                                "upQuery;sql: " +
                                                upQuery.getSql());

                                        queryList = mailHeaderDao.searchAll
                                                (upQuery);

                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  全局|正常加载|上拉加载" + queryList
                                                .size());

                                        getLogger().debug(TAG,
                                                "getMailHeader:upQuery 查出大小 :" +
                                                        queryList.size());

                                        resultList.addAll(queryList);


                                    }
                                } else if (filterType >= 0 && searchType == -1) {
                                    if (filterType == 0) {
                                        if (mode == 1) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  全局|filter星标|下拉刷新");

                                        } else if (mode == 0) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  全局|filter星标|上拉刷新");
                                            SimpleSQLiteQuery flagUpQuery = new
                                                    SimpleSQLiteQuery("select * from MailHeader " +
                                                    "where " +
                                                    "mailAccount == '" + email +
                                                    "' and boxName == '"
                                                    + boxname + "' and  uid <'" + uid + "' and  " +
                                                    "flagged =='" +
                                                    flag +
                                                    "' ORDER BY uid DESC " +
                                                    "LIMIT " +
                                                    fetchSize);

                                            getLogger().debug(TAG, "getMailHeader:  " +
                                                    "flagUpQuery;sql: " +
                                                    flagUpQuery.getSql());

                                            queryList = mailHeaderDao.searchAll
                                                    (flagUpQuery);

                                            getLogger().debug(TAG,
                                                    "getMailHeader:flagUpList 查出大小 :" +
                                                            queryList.size());

                                            resultList.addAll(queryList);

                                        }
                                    } else if (filterType == 1) {
                                        if (mode == 1) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  全局|filter附件|下拉刷新");
                                        } else if (mode == 0) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  全局|filter附件|上拉刷新");
                                            queryList = mailHeaderDao
                                                    .searchMailHeadersByAttachmentEarly(boxname,
                                                            uid, email, fetchSize);
                                            resultList.addAll(queryList);
                                        }

                                    } else if (filterType == 2) {
                                        if (mode == 1) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  全局|filter未读|下拉刷新");

                                        } else if (mode == 0) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  全局|filter未读|上拉刷新");
                                            SimpleSQLiteQuery unSeenQuery = new
                                                    SimpleSQLiteQuery("select * from MailHeader " +
                                                    "where " +
                                                    "mailAccount == '" + email +
                                                    "' and boxName == '"
                                                    + boxname + "' and  uid <'" + uid + "' and  " +
                                                    "unseen =='" +
                                                    flag +
                                                    "' ORDER BY uid DESC " +
                                                    "LIMIT " +
                                                    fetchSize);

                                            getLogger().debug(TAG, "getMailHeader:  " +
                                                    "unSeenQuery;sql: " +
                                                    unSeenQuery.getSql());

                                            queryList = mailHeaderDao.searchAll
                                                    (unSeenQuery);

                                            getLogger().debug(TAG,
                                                    "getMailHeader:unSeenList 查出大小 :" +
                                                            queryList.size());

                                            resultList.addAll(queryList);
                                        }

                                    }
                                }

                            } else if ((fetchType % 10) == 2) {//星标
// ------------------------------星标 只有 上拉---------------------------------
                                if (filterType == -1 && searchType == -1) {
                                    if (mode == 1) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  星标|正常加载|下拉刷新：网络请求，更新数据");
                                        mailHeaderEmptyJson(option);
//                                        SimpleSQLiteQuery flagDownQuery = new
//                                                SimpleSQLiteQuery("select * from MailHeader " +
//                                                "where " +
//                                                "mailAccount == '" + email +
//                                                "' and boxName == '"
//                                                + boxname + "' and  uid >'" + uid + "' and  " +
//                                                "flagged =='" +
//                                                flag +
//                                                "' ORDER BY uid DESC  ");
//
//                                        getLogger().debug(TAG, "getMailHeader:  " +
//                                                "flagDownQuery;sql: " +
//                                                flagDownQuery.getSql());
//
//                                        List<MailHeader> flagUpList = mailHeaderDao.searchAll
//                                                (flagDownQuery);
//
//                                        getLogger().debug(TAG,
//                                                "getMailHeader:flagDownQuery 查出大小 :" +
//                                                        flagUpList.size());
//
//                                        resultList.addAll(flagUpList);

                                    } else if (mode == 0) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  星标|正常加载|上拉加载");
                                        SimpleSQLiteQuery flagUpQuery = new
                                                SimpleSQLiteQuery("select * from MailHeader " +
                                                "where " +
                                                "mailAccount == '" + email +
                                                "' and  uid <'" + uid + "' and  " +
                                                "flagged =='" +
                                                flag +
                                                "' ORDER BY uid DESC " +
                                                "LIMIT " +
                                                fetchSize);

                                        getLogger().debug(TAG, "getMailHeader:  " +
                                                "flagUpQuery;sql: " +
                                                flagUpQuery.getSql());

                                        queryList = mailHeaderDao.searchAll
                                                (flagUpQuery);

                                        getLogger().debug(TAG,
                                                "getMailHeader:flagUpList 查出大小 :" +
                                                        queryList.size());

                                        resultList.addAll(queryList);

                                    }
                                } else if (filterType >= 0 && searchType == -1) {
                                    if (filterType == 0) {
                                        if (mode == 1) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  星标|filter星标|下拉刷新");
                                            mailHeaderEmptyJson(option);
                                        } else if (mode == 0) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  星标|filter星标|上拉刷新");
                                            SimpleSQLiteQuery flagUpQuery = new
                                                    SimpleSQLiteQuery("select * from MailHeader " +
                                                    "where " +
                                                    "mailAccount == '" + email +
                                                    "' and  uid <'" + uid + "' and  " +
                                                    "flagged =='" +
                                                    flag +
                                                    "' ORDER BY uid DESC " +
                                                    "LIMIT " +
                                                    fetchSize);

                                            getLogger().debug(TAG, "getMailHeader:  " +
                                                    "flagUpQuery;sql: " +
                                                    flagUpQuery.getSql());

                                            queryList = mailHeaderDao.searchAll
                                                    (flagUpQuery);

                                            getLogger().debug(TAG,
                                                    "getMailHeader:flagUpList 查出大小 :" +
                                                            queryList.size());
                                            //星标邮件
                                            resultList.addAll(queryList);

                                        }
                                    } else if (filterType == 1) {
                                        if (mode == 1) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  星标|filter附件|下拉刷新");
                                            mailHeaderEmptyJson(option);
                                        } else if (mode == 0) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  星标|filter附件|上拉刷新");

                                            queryList = mailHeaderDao
                                                    .searchMailHeadersByAttachmentWithFlaggedEarly
                                                            (uid, email, true,
                                                                    fetchSize);
                                            //星标附件
                                            resultList.addAll(queryList);
                                        }

                                    } else if (filterType == 2) {
                                        if (mode == 1) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  星标|filter未读|下拉刷新");
                                            mailHeaderEmptyJson(option);
                                        } else if (mode == 0) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  星标|filter未读|上拉刷新");
                                            queryList = mailHeaderDao
                                                    .searchMailHeadersByUnseenWithFlagEarly(
                                                            /*fetchSize,*/ uid,
                                                            email,
                                                            true, true, fetchSize);
                                            //星标未读
                                            resultList.addAll(queryList);
                                        }

                                    }
                                }

                            } else if ((fetchType % 10) == 1) {//未读
// ----------------------------- -未读 -只有 上拉--------------------------------


                                if (filterType == -1 && searchType == -1) {
                                    //正常加载
                                    if (mode == 1) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  未读|正常加载|下拉刷新：网络请求，更新数据");
                                        mailHeaderEmptyJson(option);
//                                        SimpleSQLiteQuery unSeenDownQuery = new
//                                                SimpleSQLiteQuery("select * from MailHeader " +
//                                                "where " +
//                                                "mailAccount == '" + email +
//                                                "' and boxName == '"
//                                                + boxname + "' and  uid >'" + uid + "' and  " +
//                                                "unseen =='" +
//                                                flag +
//                                                "' ORDER BY uid DESC  ");
//
//                                        getLogger().debug(TAG, "getMailHeader:  " +
//                                                "unSeenDownQuery;sql: " +
//                                                unSeenDownQuery.getSql());
//
//                                        List<MailHeader> unSeenList = mailHeaderDao.searchAll
//                                                (unSeenDownQuery);
//
//                                        getLogger().debug(TAG,
//                                                "getMailHeader:unSeenDownQuery 查出大小 :" +
//                                                        unSeenList.size());
//
//                                        resultList.addAll(unSeenList);

                                    } else if (mode == 0) {
                                        getLogger().debug(TAG, " mailList " +
                                                "-pullRefreshMailList  未读|正常加载|上拉加载");
                                        SimpleSQLiteQuery unSeenQuery = new
                                                SimpleSQLiteQuery("select * from MailHeader " +
                                                "where " +
                                                "mailAccount == '" + email +
                                                "' and  uid <'" + uid + "' and  " +
                                                "unseen =='" +
                                                flag +
                                                "' ORDER BY uid DESC " +
                                                "LIMIT " +
                                                fetchSize);

                                        getLogger().debug(TAG, "getMailHeader:  " +
                                                "unSeenQuery;sql: " +
                                                unSeenQuery.getSql());

                                        queryList = mailHeaderDao.searchAll
                                                (unSeenQuery);

                                        getLogger().debug(TAG,
                                                "getMailHeader:unSeenList 查出大小 :" +
                                                        queryList.size());

                                        resultList.addAll(queryList);

                                    }
                                } else if (filterType >= 0 && searchType == -1) {
                                    if (filterType == 0) {
                                        if (mode == 1) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  未读|filter星标|下拉刷新");
                                            mailHeaderEmptyJson(option);
                                        } else if (mode == 0) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  未读|filter星标|上拉刷新");
                                            queryList = mailHeaderDao
                                                    .searchMailHeadersByUnseenWithFlagEarly(uid,
                                                            email,
                                                            true, true, fetchSize);
                                            //未读星标
                                            resultList.addAll(queryList);
                                        }
                                    } else if (filterType == 1) {
                                        if (mode == 1) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  未读|filter附件|下拉刷新");
                                            mailHeaderEmptyJson(option);
                                        } else if (mode == 0) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  未读|filter附件|上拉刷新");
                                            queryList = mailHeaderDao
                                                    .searchMailHeadersByAttachmentWithUnseenEarly
                                                            (uid, email, true,
                                                                    fetchSize);
                                            //未读附件
                                            resultList.addAll(queryList);
                                        }

                                    } else if (filterType == 2) {
                                        if (mode == 1) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  未读|filter未读|下拉刷新");
                                            mailHeaderEmptyJson(option);
                                        } else if (mode == 0) {
                                            getLogger().debug(TAG, " mailList " +
                                                    "-pullRefreshMailList  未读|filter未读|上拉刷新");
                                            queryList = mailHeaderDao
                                                    .searchMailHeadersByUnseenEarly(
                                                            /*fetchSize,*/ uid,
                                                            email,
                                                            true, fetchSize);
                                            //系统未读
                                            resultList.addAll(queryList);
                                        }

                                    }
                                }

                            }

                        } else { //   正常加载数据
                            switch (fetchType) {
                                case 0:
                                    getLogger().debug(TAG, " mailList " +
                                            "fetchType =0 getMailDataList|全部");
                                    queryList = mailHeaderDao.queryMailHeaders
                                            (email, boxname, fetchSize);
                                    resultList.addAll(queryList);
                                    break;
                                case 2://星标邮件
                                    getLogger().debug(TAG, " mailList " +
                                            "fetchType =1 getMailDataList|星标邮件");
                                    queryList = mailHeaderDao
                                            .searchMailHeadersByFlaggedWithLimit(email
                                                    , true, fetchSize);
                                    resultList.addAll(queryList);
                                    break;
                                case 1://未读邮件
                                    getLogger().debug(TAG, " mailList " +
                                            "fetchType =2 getMailDataList|未读邮件");
                                    queryList = mailHeaderDao
                                            .searchAllMailHeadersByUnseenWithLimit(email, true,
                                                    fetchSize);
                                    resultList.addAll(queryList);
                                    break;

                                default:
                                    break;
                            }
                        }
                    }
                }

                //排序
                Collections.sort(resultList);
                try {
                    JSONObject body = new JSONObject();
                    if (queryList.size() == 0 && !TextUtils.equals(boxname, Constant
                            .TobeSent)) {
                        //本地无数据
                        if ((fetchType % 10) == 0 && list.size() > 0 && filterType
                                == -1 && searchType == -1) {
                            getLogger().debug(TAG, " mailList " +
                                    "-pullRefreshMailList  全局|正常加载|无数据时 网络请求更新数据");
                            getRetrofit().getMailHeader(list, option, mailHeaderDao, mode);
                        } else {
                            JSONArray jsonArray;
                            if (resultList.size() > 0) {
                                String s = new Gson().toJson(resultList);
                                jsonArray = new JSONArray(s);
                                jsonArray = CmailUtils.modifyReciverTORecivers(jsonArray);
                            } else {
                                jsonArray = new JSONArray();
                            }
                            body.put(CODE, 0);
                            body.put(MESSAGE, Constant.SUCCESS);
                            body.put(RESULT, jsonArray.toString());
                            CallJsUtils.callJs(body, option);

                            return;
                        }
                    } else {

                        //本地有数据
                        String s = new Gson().toJson(resultList);
                        JSONArray jsonArray = new JSONArray(s);
//                        if (TextUtils.equals(Constant.TobeSent, boxname)) {
                            jsonArray = CmailUtils.modifyReciverTORecivers(jsonArray);
//                        }

                        body.put(CODE, 0);
                        body.put(MESSAGE, Constant.SUCCESS);
                        body.put(RESULT, jsonArray.toString());
                        CallJsUtils.callJs(body, option);
                        return;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }
        });

    }



    /**
     * 返回空串
     *
     * @param option
     */
    private void mailHeaderEmptyJson(String option) {
//        String s = new Gson().toJson(new ArrayList<>());
        JSONObject body = new JSONObject();
        try {
            JSONArray jsonArray = new JSONArray();
            body.put(CODE, 0);
            body.put(MESSAGE, Constant.SUCCESS);
            body.put(RESULT, jsonArray.toString());
            CallJsUtils.callJs(body, option);

        } catch (Exception e) {
            e.printStackTrace();
            getLogger().error(TAG, "报错-> " + e.toString());
        }
    }

    /**
     * 更新已加载的列表
     *
     * @param mailHeaderDao
     * @param resultList
     * @param list
     */
    private void updateEarlyData(final MailHeaderDao mailHeaderDao, List<MailHeader> resultList,
                                 List<GetMailDataBean> list) {
        getLogger().debug(TAG, " mailList " +
                "-pullRefreshMailList  全局|正常加载|下拉刷新： 更新前面数据数据");
        for (final GetMailDataBean bean : list) {

            SimpleSQLiteQuery refreshPartQuery = new
                    SimpleSQLiteQuery("select * from MailHeader where " +
                    "mailAccount == '" + bean.getMailAccount() + "' and boxName == '"
                    + bean.getBoxName() + "' and  uid <='" + bean.getFetchUid() + "' " +
                    "LIMIT " +
                    bean.getFetchSize());


//                        getLogger().debug(TAG, "getMailHeader:  " +
//                                "frefreshPartQuery;sql: " +
//                                refreshPartQuery.getSql());


            final List<MailHeader> rangeList = mailHeaderDao.searchAll
                    (refreshPartQuery);
//                        getLogger().debug(TAG, "getMailHeader:rangeList 查出大小 :" +
//                                rangeList.size());

            if (resultList != null && rangeList.size() > 0) {
                Collections.sort(rangeList);

                getRetrofit().getMailListState(bean.getMailAccount(), bean.getBoxName(),
                        rangeList.get
                                (rangeList
                                        .size() - 1).getUid(), rangeList.get(0)
                                .getUid(),
                        new
                                NetCallBack<BaseRes<List<MailStatusRes>>>() {

                                    @Override
                                    public void onSuccess(final
                                                          BaseRes<List<MailStatusRes
                                                                  >> response) {
                                        // 更新数据库
                                        getExecutor().execute(new Runnable() {
                                            @Override
                                            public void run() {

                                                List<String> idList = new ArrayList<>();
                                                if (response.result != null && response
                                                        .result.size() > 0) {
                                                    for (MailStatusRes mailStatusRes
                                                            : response
                                                            .result) {
                                                        String id = EncryptData.MD5_32
                                                                (mailStatusRes
                                                                        .getUid() +
                                                                        bean
                                                                                .getBoxName()
                                                                        +
                                                                        bean
                                                                                .getMailAccount());
                                                        idList.add(id);
                                                        MailHeader mailHeader =
                                                                mailHeaderDao
                                                                        .queryByid(id);
//                                                                    getLogger().debug(Constant
// .TAG,
//
// "getMailHeader:queryByid  :"
//                                                                                    + mailHeader
//                                                                                    .toString
//                                                                                            ());
                                                        if (mailHeader != null) {
                                                            mailHeader.setFlagged
                                                                    (mailStatusRes
                                                                            .isFlagged());
                                                            mailHeader.setUnseen
                                                                    (mailStatusRes
                                                                            .isUnseen());
                                                            mailHeaderDao
                                                                    .insertMailHeader
                                                                            (mailHeader);
                                                        }


                                                    }
                                                }

                                                for (MailHeader mailHeader :
                                                        rangeList) {
                                                    String headId = mailHeader.getId();
                                                    boolean isContained = false;
                                                    for (String id : idList) {
                                                        if (TextUtils.equals(headId,
                                                                id)) {
                                                            isContained = true;
                                                        }
                                                    }
                                                    if (!isContained) {
                                                        getLogger().debug(Constant
                                                                        .TAG,

                                                                "getMailHeader:网络被删除的数据" +
                                                                        "  :"
                                                                        + mailHeader
                                                                        .toString
                                                                                ());
                                                        mailHeaderDao
                                                                .deleteMailHeader
                                                                        (mailHeader);
                                                    }
                                                }
                                            }
                                        });


                                    }

                                    @Override
                                    public void onFail(BaseRes<List<MailStatusRes>>
                                                               response) {

                                    }

                                    @Override
                                    public void onError() {

                                    }

                                });
            }

        }
    }

    @Override
    public String getTag() {
        return HelperCmailMailList.TAG;
    }
}
