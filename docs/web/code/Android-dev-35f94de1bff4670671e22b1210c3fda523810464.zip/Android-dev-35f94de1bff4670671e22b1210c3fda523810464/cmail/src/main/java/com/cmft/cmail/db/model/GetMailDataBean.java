package com.cmft.cmail.db.model;

public class GetMailDataBean {


    /**
     * boxName : INBOX
     * mailAccount : daliyjb11@163.com
     * fetchPage : 1
     * fetchSize : 20
     * fetchUid : 0
     */

    private String boxName;
    private String mailAccount;
    private int fetchPage;
    private int fetchSize;
    private long fetchUid;

    public String getBoxName() {
        return boxName;
    }

    public void setBoxName(String boxName) {
        this.boxName = boxName;
    }

    public String getMailAccount() {
        return mailAccount;
    }

    public void setMailAccount(String mailAccount) {
        this.mailAccount = mailAccount;
    }

    public int getFetchPage() {
        return fetchPage;
    }

    public void setFetchPage(int fetchPage) {
        this.fetchPage = fetchPage;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public long getFetchUid() {
        return fetchUid;
    }

    public void setFetchUid(long fetchUid) {
        this.fetchUid = fetchUid;
    }
}
