package com.cmft.cmail.web.resBean;

public class MailBox {
    /**
     * name : INBOX
     * mailCount : 4
     * unseenCount : 0
     */

    private String folderKey;
    private int folderId;
    private String name;
    private int mailCount;
    private int unseenCount;
    private String aliasName;
    private int folderType;

    public String getFolderKey() {
        return folderKey;
    }

    public void setFolderKey(String folderKey) {
        this.folderKey = folderKey;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMailCount() {
        return mailCount;
    }

    public void setMailCount(int mailCount) {
        this.mailCount = mailCount;
    }

    public int getUnseenCount() {
        return unseenCount;
    }

    public void setUnseenCount(int unseenCount) {
        this.unseenCount = unseenCount;
    }

    public int getFolderId() {
        return folderId;
    }

    public void setFolderId(int folderId) {
        this.folderId = folderId;
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }

    public int getFolderType() {
        return folderType;
    }

    public void setFolderType(int folderType) {
        this.folderType = folderType;
    }

    @Override
    public String toString() {
        return "MailBox{" +
                "name='" + name + '\'' +
                ", mailCount=" + mailCount +
                ", unseenCount=" + unseenCount +
                '}';
    }
}
