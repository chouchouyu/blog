package com.cmft.cmail.utils;


import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.db.model.UserInfo;

import org.json.JSONException;
import org.json.JSONObject;

import static com.cmft.cmail.utils.Constant.SP_APP_ENVIRONMENT_KEY;
import static com.cmft.cmail.utils.Constant.SP_COMPANY;
import static com.cmft.cmail.utils.Constant.SP_CURRENT_MAILACCOUNT;
import static com.cmft.cmail.utils.Constant.SP_DOMAINS;
import static com.cmft.cmail.utils.Constant.SP_USERINFO;
import static com.cmft.cmail.utils.Constant.SP_USER_ID_KEY;

public class CmailInfoSp {

    public static String getUserId() {
        return CmailSpUtils.getString(SP_USER_ID_KEY);
    }

    public static void setUserId(String userId) {
        CmailSpUtils.putString(SP_USER_ID_KEY, userId);
    }


    public static String getUserInfo() {
        return CmailSpUtils.getString(SP_USERINFO, (new JSONObject().toString()));
    }

    private static void saveUserInfo(String userInforJson) {
        CmailSpUtils.putString(SP_USERINFO, userInforJson);
    }




    public static void setAppEnvironment(String appEnvironment) {
        CmailSpUtils.putString(SP_APP_ENVIRONMENT_KEY, appEnvironment);
    }

    public static void setLoginMailAccount(String loginMailAccount) {
        CmailSpUtils.putString(SP_CURRENT_MAILACCOUNT, loginMailAccount);
    }

    public static void setDomainsJsonArray(String jsonArray) {
        CmailSpUtils.putString(SP_DOMAINS, jsonArray);
    }

    public static void setCompanyMap(String map) {
        CmailSpUtils.putString(SP_COMPANY, map);
    }

    public static String getDomainsJsonArray() {
        return CmailSpUtils.getString(SP_DOMAINS);
    }

    public static String getCompanyMap() {
        return CmailSpUtils.getString(SP_COMPANY);
    }

    public static String getLoginMailAccount() {
        return CmailSpUtils.getString(SP_CURRENT_MAILACCOUNT);
    }

    public static String getDeviceId() {
        return CmailSpUtils.getString(Constant.SP_DEVICE_ID);
    }

    public static String getSession() {
        return CmailSpUtils.getString(Constant.SESSION_PROXY);
    }

    public static void setSession(String session) {
        CmailSpUtils.putString(Constant.SESSION_PROXY, session);
    }

    public static void saveUserInforToSP(UserInfo userInfo) {
        try {
            JSONObject userObj = new JSONObject();
            userObj.put("avatarUrl", userInfo.getAvatarUrl());
            userObj.put("gender", userInfo.getGender());
            userObj.put("nickName", userInfo.getNickName());
            userObj.put("userName", userInfo.getUserId());
            saveUserInfo(userObj.toString());
        } catch (Exception e) {
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
            e.printStackTrace();
        }
    }
}
