package com.cmft.cmail.utils;


public class Constant {
    public static final String SDK_NAME = "Cmail";
    public static final String TAG = SDK_NAME + "::";
    public static final String SDK_VERSION = "1.0.0" + "  2020-01-06 09:38:44";

//    public static final String APPID = "b5bf36a5cf5142a39c938d62abf5d250";

    public static final String APPID = "60f2a55b7c8b731fb9bf7987c554b1c1"; //生产


    public static final boolean ISENCRYPT = false;
    //    public static final long M = 1024 * 1024;
    public static final long M = 1024 * 300;  //300KB
    //    public static final long M = 0;  //300KB
    public static final long LOOP_REQUEST = 5 * 60 * 1000;  //5分钟 2秒
    public static final int SYN_SIZE = 100;
    public static final int MAILHEADER_START_MODE = 0;
    public static final int MAILHEADER_BEFORE_MODE = 1;
    public static final int MAILHEADER_AFTER_MODE = 2;
    public static final int MAILHEADER_UNCHECK_MODE = -1;


    //sandBox用户文件夹目录 附件
    public static final String SANDBOX_ACC_ATTACHMNET = "attachment";
    public static final String SANDBOX_ACCOUNT = "account";
    public static final String CHARSET_NAME = "utf-8";


    //Sp 存储key
    public static final String SP_USER_ID_KEY = "Cmail.user_id";
    public static final String SP_APP_ENVIRONMENT_KEY = "Cmail.app_environment";
    public static final String SP_DEVICE_ID = "Cmail.device_id";
    public static final String SP_CURRENT_MAILACCOUNT = "Cmail.miallAccount";
    public static final String SP_DOMAINS = "Cmail.domains";
    public static final String SP_COMPANY = "Cmail.company";
    public static final String SP_USERINFO = "Cmail.userInfo";
    //    public static final String SP_SYN_INGORE = "Cmail.ignoreAccount";
    //Waltz相关
    public static final String NOTICE_NAME = "cocoMail";
    public static final String HANDLE_NATIVE_NAME = "Handle_native_name";

    public static final String RESULT = "result";
    public static final String SUCCESS = "操作成功";
    public static final String FAILED = "操作失败";

    public static final String NET_FAILED = "网络异常";
    public static final String BIND_FAILED = "绑定失败";
    public static final String ACCOUNT_FAILED = "账号异常";
//    public static final String ACCOUNTEXPIRE_FAILED_MAILDETAIL = "查看邮件详情失败 重新加载 账号已过期";
//    public static final String ACCOUNTEXPIRE_FAILED_SEND = "发送失败 以保存到待发送 账号已过期";


    public static final String CALLBACK = "callback";
    public static final String CODE = "code";
    public static final String MESSAGE = "message";
    public static final int NET_ERROR_CODE = 201;
    public static final int SERVICE_ERROR_CODE = 502;
    public static final int ACCOUNTEXPIRE_ERROR_CODE = 400008;
    public static final int LOGIN_ERROR_CODE = 400004;
    public static final int ACCOUNTUNACTIVE_ERROR_CODE = 400006;
    public static final int NOPASSWORD = 400011;

    public static final String TobeSent = "TobeSent";
    public static final String PHRASES1 = "好的, 我确认后再给你回复!";
    public static final String PHRASES2 = "收到, 非常感谢您提供的信息";
    public static final String DEFAULT_SIGN = "来自招商随行邮箱"; //default


    //session
    public static final String SESSION_PROXY = "SESSION_PROXY_key";

    /*http://xf16849513.imwork.net:26533/*/

    //    public static final String BASE_URL = "http://10.200.91.4:8088/";
    /*外网地址：  118.31.104.75:8080  */
    public static final String INNER_BASE_URL = "http://10.200.89.37:8090/";
    public static final String OUT_BASE_URL = "http://118.31.104.75:8080/";
    public static final String BASE_URL = OUT_BASE_URL;


    //    public static final String BASE_URL_OUTER = "http://118.31.104.75:8080/";
    public static final String BASE_URL_INNER = "https://gw-api-hk-di1.sit.cmft.com/";
    public static final String BASE_URL_OUTER = "https://gw-api-hk.cmft.com/";
    //    public static final String BASE_URL_INNER = "http://10.200.91.4:8080/";
    public static final String SANDBOX_READ_SERVICE =
            "http://127.0.0.1:8080/sandbox/readfile?token=%s&path=%s&name=%s";
    public static final String SANDBOX_WRITE_SERVICE =
            "http://127.0.0.1:8080/sandbox/writefile?token=%s&path=%s&name=%s&canOverWriter=true";

    public static final String CMFT_COMPANY = "招商金科";
    public static final String TRASH_FOLDER_NAME = "trash";
    public static final String TRASH_FOLDER_AliasNAME = "已删除";

    public static final int ACCOUNTSTATUE_UNACTIVE = 0;//未激活
    public static final int ACCOUNTSTATUE_ACTIVE = 1;//已激活
    public static final int ACCOUNTSTATUE_DISABLED = 2;//已停用
    public static final int ACCOUNTSTATUE_EXPIRE = 3;//已失效
    public static final int ACCOUNTTYPE_FROM_COCO = 1;
    public static final int ACCOUNTTYPE_NOT_FROM_COCO = 0;


    public static final int SHOWLOGIN_INDEX = 10;
    public static final int LOCALFILE_INDEX = 0;
    public static final int TAKEPHOTO_INDEX = 1;
    public static final int COCOPAN_INDEX = 2;
    public static final int TDS_INDEX = 3;

    public static final String INBOX = "INBOX";

    public static final String FILE_GET_ERROR = "文件获取失败";

    public static final String ALL_INBOX_FOLDER = "所有收件箱";
    public static final String ALL_UNREDD_FOLDER = "所有未读";
    public static final String ALL_FLAG_FOLDER = "所有星标";
}
