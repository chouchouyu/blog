package com.cmft.cmail.db.model;


import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;

/**
 * 草稿箱
 */
@Entity(tableName = "TobeSend", primaryKeys = {"originUid", "mailAccount"},
        foreignKeys = {@ForeignKey(entity = MailAccount.class,
                parentColumns = "mailAccount", childColumns = "mailAccount",
                onDelete = ForeignKey.CASCADE, onUpdate = ForeignKey.CASCADE)})
public class TobeSend {

    @ColumnInfo(index = true)
    @NonNull
    private String mailAccount;
    @Embedded
    @NonNull
    private MailBody mailBody;

    @NonNull
    public String getMailAccount() {
        return mailAccount;
    }

    public void setMailAccount(@NonNull String mailAccount) {
        this.mailAccount = mailAccount;
    }

    @NonNull
    public MailBody getMailBody() {
        return mailBody;
    }

    public void setMailBody(@NonNull MailBody mailBody) {
        this.mailBody = mailBody;
    }

    public static class MailBody {
        private List<AppendAttachmentBean> appendAttachment;
        private List<AppendAttachmentBean> appendRelatedItem;
        private String content;
        private long Size;
        private List<Integer> originAttachment;
        private long originUid = 0;
        private int attachmentCount;
        private String originBoxName;
        private int uid;
        private long mailTime;
        private String subject;
        private List<ReceiverBean> receiver;
        private List<ReceiverBean> receiverBCC;
        private List<ReceiverBean> receiverCC;
        //        @Embedded
//        private SenderBean sender;
        private List<String> attachmentFile = new ArrayList<>();

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public long getMailTime() {
            return mailTime;
        }

        public void setMailTime(long mailTime) {
            this.mailTime = mailTime;
        }

//        public SenderBean getSender() {
//            return sender;
//        }
//
//        public void setSender(SenderBean sender) {
//            this.sender = sender;
//        }

        public List<String> getAttachmentFile() {
            return attachmentFile;
        }

        public void setAttachmentFile(List<String> attachmentFile) {
            this.attachmentFile = attachmentFile;
        }


        public List<AppendAttachmentBean> getAppendAttachment() {
            return appendAttachment;
        }

        public void setAppendAttachment(List<AppendAttachmentBean> appendAttachment) {
            this.appendAttachment = appendAttachment;
        }

        public List<AppendAttachmentBean> getAppendRelatedItem() {
            return appendRelatedItem;
        }

        public void setAppendRelatedItem(List<AppendAttachmentBean> appendRelatedItem) {
            this.appendRelatedItem = appendRelatedItem;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public List<Integer> getOriginAttachment() {
            return originAttachment;
        }

        public void setOriginAttachment(List<Integer> originAttachment) {
            this.originAttachment = originAttachment;
        }

        public long getOriginUid() {
            return originUid;
        }

        public void setOriginUid(long originUid) {
            this.originUid = originUid;
        }

        public String getSubject() {
            return subject;
        }

        public void setSubject(String subject) {
            this.subject = subject;
        }

        public List<ReceiverBean> getReceiver() {
            return receiver;
        }

        public void setReceiver(List<ReceiverBean> receiver) {
            this.receiver = receiver;
        }

        public List<ReceiverBean> getReceiverBCC() {
            return receiverBCC;
        }

        public void setReceiverBCC(List<ReceiverBean> receiverBCC) {
            this.receiverBCC = receiverBCC;
        }

        public List<ReceiverBean> getReceiverCC() {
            return receiverCC;
        }

        public void setReceiverCC(List<ReceiverBean> receiverCC) {
            this.receiverCC = receiverCC;
        }

        public String getOriginBoxName() {
            return originBoxName;
        }

        public void setOriginBoxName(String originBoxName) {
            this.originBoxName = originBoxName;
        }

        public int getAttachmentCount() {
            return attachmentCount;
        }

        public void setAttachmentCount(int attachmentCount) {
            this.attachmentCount = attachmentCount;
        }

        public long getSize() {
            return Size;
        }

        public void setSize(long size) {
            Size = size;
        }
    }
}
