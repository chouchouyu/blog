package com.cmft.cmail.db.dao;

import com.cmft.cmail.db.model.MailDetail;
import com.cmft.cmail.db.model.MailInfo;

import java.util.List;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Transaction;

@Dao
public interface MailInfoDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(MailInfo mailDetail);

    @Query("SELECT * FROM mail_info WHERE mailUid == :mailUid AND folderName ==:folderName AND " +
            "mailAccount ==:mailAccount ")
    MailInfo getMailInfo(String mailAccount, int mailUid, String folderName);

    @Transaction
    @Query("select * from mail_info where id = :id")
    MailDetail getMailAllInfo(String id);

}
