package com.cmft.cmail.db.dao;

import com.cmft.cmail.db.model.MailFolder;

import java.util.List;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;


@Dao
public interface MailFolderDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertFolder(MailFolder mailFolder);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long[] insertFolder(List<MailFolder> list);

    @Delete
    void deleteFolder(MailFolder mailFolder);

    @Query("select * from MailFolder")
    List<MailFolder> queryAll();

    @Query("select * from MailFolder where mailAccount == :mailAccount")
    List<MailFolder> queryByMailAccount(String mailAccount);

    @Query("select * from MailFolder where mailAccount IN (:mailAccounts)")
    List<MailFolder> queryByMailAccounts(List<String> mailAccounts);

    @Query("select * from MailFolder where mailAccount ==:mailAccount and folderKey ==:boxName")
    MailFolder queryByMailAccounts(String mailAccount, String boxName);

    @Query("select * from MailFolder where mailAccount ==:mailAccount and aliasName ==:aliasName")
    MailFolder queryFolderKey(String mailAccount, String aliasName);


    @Update(onConflict = OnConflictStrategy.REPLACE)
    void updateFolderList(MailFolder mailFolder);
}
