package com.cmft.cmail.waltz.delegate;


import java.io.Serializable;

public interface MailDetailDelegate extends Serializable {


    //获取邮件详情 ok
    void getMailDetail(String data, String option);

    //邮件发送，转发，回复 ok
    void mailOperator(String data, String option);

    //取消发送（不保存邮件，针对新上传了内嵌内容、附件的情况） ok
    void cancelSendEmail(String data, String option);

    void mailSearch(String data, String option);

    void mailFilter(String data, String option);


    //删除附件(发件箱) ok
    void deleteAttachment(String data, String option);

    //打开附件（发件箱）
    void openAttachment(String data, String option);

    //打开附件（收件箱) ok
    void openMailAttachment(String data, String option);

    void saveMailToDrafts(String data, String option);

    void addIdiomList(String data, String option);

    void getIdiomList(String data, String option);

    void getMailSignList(String data, String option);


    void deleteIdiomList(String data, String option);
}
