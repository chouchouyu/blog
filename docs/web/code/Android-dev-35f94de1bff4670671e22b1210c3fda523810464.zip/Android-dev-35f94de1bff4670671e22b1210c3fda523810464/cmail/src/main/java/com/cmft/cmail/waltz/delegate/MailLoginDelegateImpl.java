package com.cmft.cmail.waltz.delegate;

import android.text.TextUtils;
import android.util.Log;

import com.cmft.cmail.Cmail;
import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailFolderDao;
import com.cmft.cmail.db.dao.MailHeaderDao;
import com.cmft.cmail.db.helper.MailFolderHelper;
import com.cmft.cmail.db.model.GetMailDataBean;
import com.cmft.cmail.db.model.MailFolder;
import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.db.model.MailPhrases;
import com.cmft.cmail.db.model.ModifyMailBean;
import com.cmft.cmail.db.model.MoveMail;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.waltz.CallJsUtils;
import com.cmft.cmail.web.resBean.MailBox;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.RESULT;

public class MailLoginDelegateImpl implements MailLoginDelegate, Serializable {


    public MailLoginDelegateImpl() {

    }


    @Override
    public void addAttachment(String data, String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            String mailAccount = jsonObject.getString("mailAccount");
            int type = jsonObject.getInt("attachmentType");
            String boxName = jsonObject.getString("boxName");
            Cmail.addAttachment(mailAccount, type, option, "");
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }


    @Override
    public void bindMailAccount(String data, String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            String mailAccount = jsonObject.getString("mailAccount");
            String password = jsonObject.getString("password");
            Cmail.bindAccountToServer(mailAccount, password, option);
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

    @Override
    public void unBindMailAccount(String data, String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            String mailAccount = jsonObject.getString("mailAccount");
            Cmail.unBindAccountToServer(mailAccount, option);
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

    @Override
    public void setMainMailAccount(String data, String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            String mainAccount = jsonObject.getString("mailAccount");
            boolean masterAccount = jsonObject.getBoolean("masterAccount");
            Cmail.setMainMailAccount(mainAccount, masterAccount, option);
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

    @Override
    public void setMailSignature(String data, String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            String mailAccount = jsonObject.getString("mailAccount");
            String signature = jsonObject.getString("signature");
            Cmail.setMailSignature(mailAccount, signature, option);
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

    @Override
    public void getMailAccountList(String data, String option) {
        Cmail.getMailAccountList(option);
    }

    @Override
    public void addIdiomList(final String data, final String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            JSONArray idiomArr = jsonObject.getJSONArray("idiomList");
            String mailAccount = jsonObject.getString("mailAccount");
            List<String> idiomList = new Gson().fromJson(idiomArr.toString(), new
                    TypeToken<List<String>>() {
                    }.getType());
            List<MailPhrases> list = new ArrayList<>();
            for (String content : idiomList) {
//                        MailPhrases mailPhrases = new MailPhrases(content, mailAccount);
                MailPhrases mailPhrases = new MailPhrases(content);
                list.add(mailPhrases);
            }

            Cmail.addIdiomList(list, option);

        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }


    @Override
    public void moveMailBox(final String data, final String option) {
        MoveMail moveMail = new Gson().fromJson(data, MoveMail.class);
        String fromBox = moveMail.getFromBox();
        String toBox = moveMail.getToBox();

        List<MoveMail.MailListBean> mailList = moveMail.getMailList();
        List<String> mailAccList = new ArrayList<>();

        for (MoveMail.MailListBean bean : mailList) {
            String mailAccount = bean.getMailAccount();
            if (!mailAccList.contains(mailAccount)) {
                mailAccList.add(mailAccount);
            }
        }

        for (String mailAccount : mailAccList) {
            List<Long> uidList = new ArrayList<>();
            for (MoveMail.MailListBean bean : mailList) {
                if (mailAccount.equals(bean.getMailAccount())) {
                    uidList.add(bean.getUid());
                }
            }
            Cmail.moveMail(mailAccount, fromBox, toBox, uidList, option);
        }
    }

    @Override
    public void getMailDataList(final String data, final String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            if (jsonObject.has("fetchList") && jsonObject.has("fetchType") && jsonObject
                    .has("mode")) {
                JSONArray jsonArray = jsonObject.getJSONArray("fetchList");
                List<GetMailDataBean> list = new Gson().fromJson(jsonArray.toString(), new
                        TypeToken<List<GetMailDataBean>>() {
                        }.getType());
                int fetchType = jsonObject.getInt("fetchType");
                int mode = jsonObject.getInt("mode");
                Cmail.getMailHeader(list, option, fetchType, -1, -1, null, mode, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }

    }

    @Override
    public void modifyMailStatus(final String data, final String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            JSONArray mailList = jsonObject.getJSONArray("mailList");

            List<ModifyMailBean> mailBeanList = new Gson().fromJson(mailList.toString(),
                    new TypeToken<List<ModifyMailBean>>() {
                    }.getType());
            int mode = jsonObject.getInt("mode");
            Map<String, Map<String, List<Long>>> map = new HashMap<>();

            for (ModifyMailBean bean : mailBeanList) {
                if (map.containsKey(bean.getMailAccount())) {
                    Map<String, List<Long>> boxUidMap = map.get(bean.getMailAccount());
                    if (boxUidMap.containsKey(bean.getBoxName())) {
                        List<Long> uidList = boxUidMap.get(bean.getBoxName());
                        boolean iscontainsUid = false;
                        for (Long uid : uidList) {
                            if (uid == bean.getUid()) {
                                iscontainsUid = true;
                            } else {
                                iscontainsUid = false;
                            }
                        }
                        if (!iscontainsUid) {
                            uidList.add(bean.getUid());
                            boxUidMap.remove(bean.getBoxName());
                            boxUidMap.put(bean.getBoxName(), uidList);
                            map.remove(bean.getMailAccount());
                            map.put(bean.getMailAccount(), boxUidMap);
                        }
                    } else {
                        //没有boxName
                        List<Long> uidList = new ArrayList<>();
                        uidList.add(bean.getUid());
                        boxUidMap.put(bean.getBoxName(), uidList);
                        map.remove(bean.getMailAccount());
                        map.put(bean.getMailAccount(), boxUidMap);
                    }
                } else {
                    //没有mailAccount
                    Map<String, List<Long>> boxUidMap = new HashMap<>();
                    List<Long> uidList = new ArrayList<>();
                    uidList.add(bean.getUid());
                    boxUidMap.put(bean.getBoxName(), uidList);
                    map.put(bean.getMailAccount(), boxUidMap);
                }
            }
            Cmail.modifyMailStatus(map, mode, option);


//            for (String mailAccount : mailAccList) {
//                List<Integer> uidList = new ArrayList<>();
//                for (ModifyMailBean bean : mailBeanList) {
//                    if (mailAccount.equals(bean.getMailAccount())) {
//                        uidList.add(bean.getUid());
//                    }
//                }
//            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

    @Override
    public void modifyFolderStatus(final String data, final String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            String boxName = jsonObject.getString("boxName");
            String email = jsonObject.getString("email");
            int mode = jsonObject.getInt("mode");
            Cmail.modifyFolderStatus(email, boxName, mode, option);
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

    @Override
    public void getMailBox(final String data, final String option) {
        try {
            JSONObject dataJson = new JSONObject(data);
            String mail = dataJson.getString("mailAccount");
            List<String> mailList = null;
//            JSONArray mailArr = dataJson.getJSONArray("mailAccount");
//            List<String> mailList = new Gson().fromJson(mailArr.toString(), new
//                    TypeToken<List<String>>() {
//                    }.getType());

            Cmail.getMailBox(mailList, mail, option);

        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }

    }

    @Override
    public void useMailAccount(String data, String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            String mailAccount = jsonObject.getString("mailAccount");
            int status = jsonObject.getInt("status");

            switch (status) {
                case 0://0:停用
                    Cmail.freezeMail(mailAccount, option);
                    break;
                case 1://1:解绑
                    Cmail.unBindAccountToServer(mailAccount, option);
                    break;
                case 2://2:启用
                    Cmail.unFreezeMail(mailAccount, option);
                    break;
                default:
            }

        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

    @Override
    public void deleteOrClearBoxName(String data, String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            String mailAccount = jsonObject.getString("mailAccount");
            String boxName = jsonObject.getString("boxName");
            int type = jsonObject.getInt("type");

            switch (type) {
                case 0://0:删除邮件夹
                    Cmail.deleteFolder(mailAccount, boxName, option);
                    break;
                case 1://1:清空邮件夹
                    Cmail.clearFolder(mailAccount, boxName, option);
                    break;
                default:
            }

        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

    @Override
    public void deleteMailList(String data, String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);

            JSONArray mailList = jsonObject.getJSONArray("mailList");
            List<ModifyMailBean> mailBeanList = new Gson().fromJson(mailList.toString(), new
                    TypeToken<List<ModifyMailBean>>() {
                    }.getType());

            String boxName = jsonObject.getString("fromBox");
            List<String> mailAccList = new ArrayList<>();
            for (ModifyMailBean bean : mailBeanList) {
                String mailAccount = bean.getMailAccount();
                if (!mailAccList.contains(mailAccount)) {
                    mailAccList.add(mailAccount);
                }
            }

            for (String mailAccount : mailAccList) {
                List<Long> uidList = new ArrayList<>();
                for (ModifyMailBean bean : mailBeanList) {
                    if (mailAccount.equals(bean.getMailAccount())) {
                        uidList.add(bean.getUid());
                    }
                }

                //调用服务器接口,彻底删除邮件
                Cmail.deleteMail(mailAccount, boxName, uidList, option);
            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

//    @Override
//    public void getSpecialFolderMailList(String data, String option) {
//        try {
//            JSONObject jsonObject = new JSONObject(data);
//            JSONArray mailArr = jsonObject.getJSONArray("mailAccount");
//            String boxName = jsonObject.getString("folderName");
//
//            List<String> mailList = new Gson().fromJson(mailArr.toString(), new
//                    TypeToken<List<String>>() {
//                    }.getType());
//        } catch (JSONException e) {
//            e.printStackTrace();
//        } catch (Exception e) {
//           CmailCenter.logger.debug(Constant.TAG, e.getMessage());
//        }
//    }

    @Override
    public void getAllAccountMailBox(String data, String option) {
        JSONObject body = new JSONObject();
        MailBox inboxMailBox = new MailBox();
        inboxMailBox.setAliasName(Constant.ALL_INBOX_FOLDER);
        inboxMailBox.setFolderType(0);
        int inboxMailCount = 0;
        int inboxUnReadCount = 0;
        String inboxName = "INBOX";

        MailBox flagMailBox = new MailBox();
        flagMailBox.setAliasName(Constant.ALL_FLAG_FOLDER);
        flagMailBox.setFolderType(2);
        int flagMailCount = 0;
        int flagUnReadCount = 0;
        String flagName = "INBOX";

        MailBox unReadMailBox = new MailBox();
        unReadMailBox.setAliasName(Constant.ALL_UNREDD_FOLDER);
        unReadMailBox.setFolderType(1);
        int unReadMailCount = 0;
        int unReadUnReadCount = 0;
        String unReadName = "INBOX";
        MailHeaderDao mailHeaderDao = CmailDatabase.getInstance(CmailCenter.getContext())
                .getMailHeaderDao();

        MailFolderDao mailFolderDao = CmailDatabase.getInstance(CmailCenter.getContext())
                .getMailFolderDao();
        try {
            JSONObject jsonObject = new JSONObject(data);
            JSONArray mailArr = jsonObject.getJSONArray("mailAccount");

//            List<String> mailList = new Gson().fromJson(mailArr.toString(), new
//                    TypeToken<List<String>>() {
//                    }.getType());
            List<MailBox> mailBoxList = new ArrayList<>();

            for (int i = 0; i < mailArr.length(); i++) {
                String mail = mailArr.get(i).toString();
//                Cmail.getMailBox(mail);
                MailFolder inboxFolder = MailFolderHelper.getInstance().queryByMailAccounts(mail,
                        "INBOX");

                if (null != inboxFolder) {
                    inboxMailCount += inboxFolder.getTotalCount();
                    inboxUnReadCount += inboxFolder.getUnreadCount();
                }


            }

            //未读
            List<MailHeader> unseenList = mailHeaderDao.searchAllMailHeadersByUnseen(true);
            if (null != unseenList && unseenList.size() > 0) {
                unReadUnReadCount = unseenList.size();
                unReadMailCount = unseenList.size();
            }

//            List<MailFolder> unseenList = mailFolderDao.queryAll();
//            if (null != unseenList && unseenList.size() > 0) {
//                for (MailFolder folder : unseenList) {
//                    unReadUnReadCount += folder.getUnreadCount();
//                    unReadMailCount += folder.getUnreadCount();
//                }
//            }

            //星标
            List<MailHeader> flagList = mailHeaderDao.searchAllMailHeadersByFlagged(true);
            if (null != flagList && flagList.size() > 0) {
                flagMailCount = flagList.size();
            }
            List<MailHeader> flagUnseenList = mailHeaderDao.searchAllMailHeadersByFlagUnseen
                    (true, true);
            if (null != flagUnseenList && flagUnseenList.size() > 0) {
                flagUnReadCount = flagUnseenList.size();
            }

            inboxMailBox.setMailCount(inboxMailCount);
            inboxMailBox.setUnseenCount(inboxUnReadCount);
            inboxMailBox.setName(inboxName);
            mailBoxList.add(inboxMailBox);

            unReadMailBox.setMailCount(unReadMailCount);
            unReadMailBox.setUnseenCount(unReadUnReadCount);
            unReadMailBox.setName(unReadName);
            mailBoxList.add(unReadMailBox);

            flagMailBox.setMailCount(flagMailCount);
            flagMailBox.setUnseenCount(flagUnReadCount);
            flagMailBox.setName(flagName);
            mailBoxList.add(flagMailBox);
            JSONArray jsonArr;
            if (mailBoxList.size() > 0) {
                String arrList = new Gson().toJson(mailBoxList, new TypeToken<List<MailBox>>() {
                }.getType());

                jsonArr = new JSONArray(arrList);
            } else {
                jsonArr = new JSONArray();
            }

            body.put(CODE, 0);
            body.put(MESSAGE, "success");
            body.put(RESULT, jsonArr.toString());
            CallJsUtils.callJs(body, option);
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, e.toString() + this.getClass().getName());
        }
    }

    @Override
    public void pullRefreshMailList(String data, String option) {
        JSONObject body = new JSONObject();
        try {
            JSONObject jsonObject = new JSONObject(data);
            if (jsonObject.has("fetchList") && jsonObject.has("fetchType") && jsonObject
                    .has("mode") && jsonObject.has("searchText")) {
                JSONArray jsonArray = jsonObject.getJSONArray("fetchList");
                List<GetMailDataBean> list = new Gson().fromJson(jsonArray.toString(), new
                        TypeToken<List<GetMailDataBean>>() {
                        }.getType());
                int fetchType = jsonObject.getInt("fetchType");
                int searchType = jsonObject.getInt("searchType");
                int filterType = jsonObject.getInt("filterType");
                int mode = jsonObject.getInt("mode");
                String searchText = jsonObject.getString("searchText");
                if (list != null && list.size() > 0) {
                    if (TextUtils.equals(Constant.TobeSent, list.get(0).getBoxName())) {
                        JSONArray resultArray = new JSONArray();
                        body.put(CODE, 0);
                        body.put(MESSAGE, "success");
                        body.put(RESULT, resultArray.toString());
                        CallJsUtils.callJs(body, option);
                    } else {
                        Cmail.getMailHeader(list, option, fetchType, filterType, searchType,
                                searchText, mode, true);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }


    @Override
    public void supportMailDomain(String data, String option) {
        Cmail.supportMailDomain(option);
    }

    @Override
    public void getUserInfo(String data, String option) {
        Cmail.getUserInfo(option);
    }

    @Override
    public void recentContacts(String data, String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            String keyword = jsonObject.getString("keyword");
            int limit = jsonObject.getInt("limit");
            Cmail.recentContacts(keyword, limit, option);

        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }


    }


}
