package com.cmft.cmail.waltz.delegate;

import android.net.Uri;
import android.text.TextUtils;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.cmail.CallBack;
import com.cmft.cmail.Cmail;
import com.cmft.cmail.NetCallBack;
import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.TobeSendDao;
import com.cmft.cmail.db.model.GetMailDataBean;
import com.cmft.cmail.db.model.MailAttachment;
import com.cmft.cmail.db.model.SearchBean;
import com.cmft.cmail.db.model.TobeSend;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.waltz.CallJsUtils;
import com.cmft.cmail.web.resBean.BaseRes;
import com.cmft.cmail.web.resBean.MailContentRes;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.M;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.NET_FAILED;
import static com.cmft.cmail.utils.Constant.RESULT;
import static com.cmft.cmail.waltz.CallJsUtils.failResultToJs;

public class MailDetailDelegateImpl implements MailDetailDelegate, Serializable {


    public MailDetailDelegateImpl() {

    }

    @Override
    public void mailOperator(String data, final String option) {
        try {

            JSONObject jsonObject = new JSONObject(data);
            String mailAccount = jsonObject.getString("mailAccount");

            if (!TextUtils.isEmpty(mailAccount)) {
                String mailBodyStr = jsonObject.getString("mailBody");
                JSONObject jsMailBody = new JSONObject(mailBodyStr);
                Cmail.mailSend(mailAccount, jsMailBody, option);
            } else {
                CmailCenter.logger.debug(Constant.TAG, "mailOperator:JSON  【mailAccount】is Empty");
                CallJsUtils.bindResultToJs(false, option);
            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }


    @Override
    public void cancelSendEmail(String data, final String option) {
        try {

            JSONObject jsonObject = new JSONObject(data);
            String mailAccount = jsonObject.getString("mailAccount");
            JSONObject mailBody = jsonObject.getJSONObject("mailBody");
            JSONArray appendAttachment = jsonObject.getJSONArray("appendAttachment");
            Cmail.deleteUploadFile(mailAccount, mailBody, appendAttachment, option);
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }


    @Override
    public void openMailAttachment(String data, String option) {
        try {

//            data="{\"attachmentIndex\":0,\"attachmentName\":\"移动开发社区20200109测试报告.xlsx\"," +
//                    "\"folderName\":\"INBOX\",\"mailAccount\":\"wusm@cmft.com\"," +
//                    "\"originBoxName\":\"\",\"mailUid\":\"4954\"}";
            JSONObject jsonObject = new JSONObject(data);
            int attachmentIndex = jsonObject.getInt("attachmentIndex");
            String attachmentName = jsonObject.getString("attachmentName");
            String folderName = jsonObject.getString("folderName");
            String mailAccount = jsonObject.getString("mailAccount");
            String originBoxName = null;
            if (jsonObject.has("originBoxName")) {
                originBoxName = jsonObject.getString("originBoxName");
            }
            int mailUid = jsonObject.getInt("mailUid");
            if (!TextUtils.isEmpty(originBoxName)) {
                //优先取这个值，为空再取fileName ，为了解决待发送，转发时原附件
                folderName = originBoxName;
            }

            if (TextUtils.isEmpty(mailAccount)) {
                CmailCenter.logger.debug(Constant.TAG, "openMailAttachment:JSON  【mailAccount】is " +
                        "Empty");
                CallJsUtils.bindResultToJs(false, option);
            } else {
                //1.查数据库有没有filePath
                List<MailAttachment> attachmentList = CmailDatabase.getInstance(CmailCenter
                        .getContext()).mailAttachmentDao()
                        .getMailAttachment(mailUid,
                                folderName, mailAccount, attachmentName);
                String path = attachmentList.get(0).filePath;
                //数据库有值
                if (null != attachmentList && attachmentList.size() > 0 && !TextUtils.isEmpty
                        (path) && SandBox.getInstance().isFileExists(path)) {
                    //有下载过直接打开
                    Cmail.openAttachment(path, option);
                } else {
                    //2.没有下载
                    //3.下载后更新数据库
                    //4.再查到有了之后
                    Cmail.saveAndOpenAttachment(mailAccount, folderName, mailUid, attachmentIndex,
                            attachmentName, option);

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }


    @Override
    public void deleteAttachment(String data, String option) {
        try {

            JSONObject jsonObject = new JSONObject(data);
            String mailAccount = jsonObject.getString("mailAccount");
            String fileName = jsonObject.getString("fileName");
            if (TextUtils.isEmpty(mailAccount)) {
                CmailCenter.logger.debug(Constant.TAG, "deleteAttachment:JSON  【mailAccount】is " +
                        "Empty");
                CallJsUtils.bindResultToJs(false, option);
            } else {
                Cmail.deleteAttachment(mailAccount, fileName, option);
                CallJsUtils.bindResultToJs(true, option);
            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }


    }

    @Override
    public void openAttachment(String data, String option) {
        try {

            JSONObject jsonObject = new JSONObject(data);
            String mailAccount = jsonObject.getString("mailAccount");
            String fileName = jsonObject.getString("fileName");
            String filePath = null;
            if (jsonObject.has("filePath")) {
                filePath = jsonObject.getString("filePath");
            }
            if (TextUtils.isEmpty(mailAccount)) {
                CmailCenter.logger.debug(Constant.TAG, "openAttachment:JSON  【mailAccount】is " +
                        "Empty");
                CallJsUtils.bindResultToJs(false, option);
            } else {
                Cmail.openSendAttachment(mailAccount, fileName, filePath, option);
            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }


    @Override
    public void getMailDetail(String data, final String option) {
        try {

            final JSONObject jsonObject = new JSONObject(data);
            final long mailUid = jsonObject.getLong("mailUid");
            final String folderName = jsonObject.getString("folderName");
            final String mailAccount = jsonObject.getString("mailAccount");
//            final String mailTime = jsonObject.getString("mailTime");

            if (Constant.TobeSent.equals(folderName)) { //如果是草稿箱，取本地数据返回个H5
                TobeSendDao tobeSendDao = CmailDatabase.getInstance(CmailCenter.getContext())
                        .getTobeSendDao();
                TobeSend tobeSend = tobeSendDao.queryTobeSend(mailAccount, mailUid);
                final TobeSend.MailBody mailBody = tobeSend.getMailBody();
                Cmail.sandboxDecrypt(mailBody.getContent(), new CallBack<String>() {


                    @Override
                    public void onSuccess(String mailBodyStr) {
                        String mailReadUrl = Cmail.getContentURL(mailAccount, folderName, String
                                .valueOf(mailBody.getMailTime()));
                        String mailWriteUrl = Cmail.getWriteContentUrl(mailAccount, mailUid);
                        mailBody.setContent(mailBodyStr);

                        //"originAttachment":[0,1,2],"originBoxName":"INBOX","originUid":4538,
                        List<MailAttachment> originalAttachmentList = CmailDatabase.getInstance
                                (CmailCenter.getContext()).mailAttachmentDao().getMailAttachments
                                (mailAccount, mailBody.getOriginBoxName(), mailBody.getOriginUid());


                        JSONObject body = new JSONObject();
                        String s = new Gson().toJson(mailBody);
                        try {
                            JSONObject tobeSentMail = new JSONObject(s);
                            if (mailBody.getSize() > M) {
                                tobeSentMail.remove("content");
                                tobeSentMail.put("content", "");
                                tobeSentMail.put("urlPath", mailReadUrl);
                                tobeSentMail.put("writeUrl", mailWriteUrl);
                            } else {
                                tobeSentMail.put("content", mailBodyStr);
                                tobeSentMail.put("urlPath", "");
                                tobeSentMail.put("writeUrl", "");
                            }
                            JSONArray attachmentArray = new JSONArray();
                            if (originalAttachmentList != null && originalAttachmentList.size() >
                                    0) {
                                for (MailAttachment attachment : originalAttachmentList) {
                                    JSONObject originalAttachmentObject = new JSONObject();
                                    originalAttachmentObject.put("fileName", attachment
                                            .attachmentName);
                                    originalAttachmentObject.put("index", attachment
                                            .attachmentIndex);
                                    originalAttachmentObject.put("size", attachment.fileSize);
                                    originalAttachmentObject.put("url", "");
                                    attachmentArray.put(originalAttachmentObject);
                                }
                            }
                            tobeSentMail.put("originAttachmentFile", attachmentArray);
                            body.put(RESULT, tobeSentMail.toString());
                            body.put(CODE, 0);
                            body.put(MESSAGE, "success");
                            CallJsUtils.callJs(body, option);
                        } catch (Exception e) {
                            e.printStackTrace();
                            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
                        }

                    }

                    @Override
                    public void onFail(String string) {

                    }
                });


            } else {
                //1.数据库有值直接回，
                //2.数据库没值存了再回
                final JSONObject jsObject = new JSONObject();
                final JSONObject rootJson = new JSONObject();
                rootJson.put(CODE, 0);
                rootJson.put(MESSAGE, "success");

                //将邮件标位已读
                modifyMailStatus(mailUid, mailAccount,
                        folderName, option);


                Cmail.getMailContent(mailAccount, folderName, mailUid, new
                        CallBack<com.cmft.cmail.db.model.MailDetail>() {

                            @Override
                            public void onSuccess(com.cmft.cmail.db.model.MailDetail mailDetail) {
                                CmailCenter.logger.debug(Constant.TAG, "-onSuccess" +
                                        mailDetail.toString());
                                //查数据库
                                try {
                                    jsObject.put("uid", mailDetail.mailInfo.mailUid);

                                    JSONObject senderObject = new JSONObject();
                                    senderObject.put("name", mailDetail.mailInfo.sendername);
                                    senderObject.put("address", mailDetail.mailInfo.sender);

                                    jsObject.put("sender", senderObject);
                                    jsObject.put("subject", mailDetail.mailInfo.subject);
                                    jsObject.put("flagged", mailDetail.mailInfo.hasflaged);
                                    jsObject.put("mailTime", mailDetail.mailInfo.timeStamp);
                                    jsObject.put("receiver", new JSONArray(mailDetail.mailInfo
                                            .receivers));
                                    jsObject.put("receiverBCC", new JSONArray(mailDetail.mailInfo
                                            .receiversBCC));
                                    jsObject.put("receiverCC", new JSONArray(mailDetail.mailInfo
                                            .receiversCC));
                                    JSONArray jsonArray = new JSONArray();
                                    if (mailDetail.mailInfo.hasAttachments) {
                                        List<MailAttachment> attachmentList = mailDetail
                                                .mailAttachmentList;
                                        jsObject.put("attachmentCount", attachmentList.size());
                                        CmailCenter.logger.debug(Constant.TAG, " 从数据库中取数据" +
                                                attachmentList

                                                        .size());

                                        for (MailAttachment attachment : attachmentList) {
                                            JSONObject attachmentObject = new JSONObject();
                                            attachmentObject.put("index", attachment
                                                    .attachmentIndex);
                                            attachmentObject.put("fileName", attachment
                                                    .attachmentName);
                                            attachmentObject.put("size", attachment
                                                    .fileSize);
                                            if (!TextUtils.isEmpty(attachment
                                                    .filePath)) {
                                                attachmentObject.put("url", attachment
                                                        .filePath);
                                            }

                                            jsonArray.put(attachmentObject);
                                        }
                                    } else {
                                        jsObject.put("attachmentCount", 0);
                                    }
                                    jsObject.put("attachmentFile", jsonArray);
                                    if (mailDetail.mailInfo.emailSize < M) {
                                        //邮件内容
                                        Cmail.getMailBody(mailAccount, folderName,
                                                mailUid, new CallBack<String>() {
                                                    @Override
                                                    public void onSuccess(String mailBody) {
                                                        try {
                                                            jsObject.put("content", mailBody);
                                                            jsObject.put("urlPath", "");
                                                            jsObject.put("writeUrl", "");
                                                            rootJson.put("result", jsObject
                                                                    .toString());
                                                            CallJsUtils.callJs(rootJson, option);
                                                        } catch (Exception e) {
                                                            e.printStackTrace();
                                                            CmailCenter.logger.error(Constant
                                                                    .TAG, "报错-> " + e.toString());
                                                        }

                                                    }

                                                    @Override
                                                    public void onFail(String string) {
                                                        CallJsUtils.bindResultToJs(false, option);
                                                    }
                                                });

                                    } else {
                                        jsObject.put("content", "");
                                        jsObject.put("urlPath", Cmail.getContentURL(mailAccount,
                                                folderName,
                                                String.valueOf(mailUid)));

                                        jsObject.put("writeUrl", Cmail.getWriteContentUrl
                                                (mailAccount, System
                                                        .currentTimeMillis()));
                                        rootJson.put("result", jsObject.toString());
                                        CallJsUtils.callJs(rootJson, option);
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                    CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
                                }
                            }


                            @Override
                            public void onFail(String string) {
                                CmailCenter.logger.debug(Constant.TAG, "-onFail" + string);
//                               modifyMailStatus(mailUid, mailAccount, folderName,
//                                       option);

                                Cmail.saveMailContent(mailAccount, folderName, mailUid, new
                                        NetCallBack<BaseRes<MailContentRes>>() {

                                            @Override
                                            public void onSuccess(BaseRes<MailContentRes> msg) {
                                                MailContentRes response = msg.result;
                                                CmailCenter.logger.debug(Constant.TAG,
                                                        "-saveMailContent-onSuccess:" +
                                                                response.toString());

                                                try {

                                                    jsObject.put("uid", response.getUid());

                                                    JSONObject senderObject = new JSONObject();
                                                    senderObject.put("name", response.getSender()
                                                            .getName());
                                                    senderObject.put("address", response.getSender()
                                                            .getAddress());
                                                    jsObject.put("sender", senderObject);
                                                    jsObject.put("subject", response.getSubject());
                                                    jsObject.put("flagged", response.isFlagged());
                                                    jsObject.put("mailTime", response
                                                            .getTimestamp());
                                                    jsObject.put("receiver", toJsonObject(response
                                                            .getReceiver()));
                                                    jsObject.put("receiverBCC", toJsonObject
                                                            (response
                                                                    .getReceiverBCC()));
                                                    jsObject.put("receiverCC", toJsonObject(response
                                                            .getReceiverCC()));
                                                    JSONArray jsonArray = new JSONArray();

                                                    if (response.getAttachmentCount() > 0) {
                                                        List<MailContentRes.AttachmentFileBean>
                                                                attachmentList = response
                                                                .getAttachmentFile();
                                                        jsObject.put("attachmentCount",
                                                                attachmentList.size());
                                                        CmailCenter.logger.debug(Constant.TAG, " " +
                                                                "从网络请求数据" +
                                                                attachmentList.size());

                                                        for (MailContentRes.AttachmentFileBean
                                                                attachment :
                                                                attachmentList) {
                                                            JSONObject attachmentObject = new
                                                                    JSONObject();
                                                            attachmentObject.put("index", attachment
                                                                    .getIndex());
                                                            attachmentObject.put("fileName",
                                                                    attachment
                                                                            .getName());
                                                            attachmentObject.put("size", attachment
                                                                    .getSize());
                                                            jsonArray.put(attachmentObject);
                                                        }


                                                    } else {
                                                        jsObject.put("attachmentCount", 0);
                                                    }
                                                    jsObject.put("attachmentFile", jsonArray);

                                                    //邮件内容
                                                    Cmail.getMailBody(mailAccount,
                                                            folderName,
                                                            mailUid, new CallBack<String>() {
                                                                @Override
                                                                public void onSuccess(String mailBody) {
                                                                    try {


                                                                        if (mailBody.length() < M) {
                                                                            //邮件内容
                                                                            jsObject.put
                                                                                    ("content",
                                                                                            mailBody);
                                                                            jsObject.put
                                                                                    ("urlPath", "");
                                                                            jsObject.put
                                                                                    ("writeUrl",
                                                                                            "");
                                                                        } else {
                                                                            jsObject.put
                                                                                    ("content", "");
                                                                            jsObject.put
                                                                                    ("urlPath",
                                                                                            Cmail
                                                                                                    .getContentURL(mailAccount,
                                                                                                            folderName,
                                                                                                            String.valueOf(mailUid)));

                                                                            jsObject.put
                                                                                    ("writeUrl",
                                                                                            Cmail
                                                                                                    .getWriteContentUrl(mailAccount,
                                                                                                            System
                                                                                                                    .currentTimeMillis()));
                                                                        }
                                                                        rootJson.put("result",
                                                                                jsObject.toString
                                                                                        ());
                                                                        CallJsUtils.callJs
                                                                                (rootJson, option);
                                                                    } catch (Exception e) {
                                                                        e.printStackTrace();
                                                                    }
                                                                }

                                                                @Override
                                                                public void onFail(String string) {

                                                                }
                                                            });


                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                    CmailCenter.logger.error(Constant.TAG, "报错-> " +
                                                            "" + e
                                                            .toString());
                                                } finally {
                                                    //将邮件标位已读
//										modifyMailStatus(mailUid, mailAccount,
//												folderName, option);
                                                }

                                            }

                                            @Override
                                            public void onFail(BaseRes<MailContentRes> response) {
                                                //将邮件标位已读
//									modifyMailStatus(mailUid, mailAccount,
//											folderName, option);

                                                JSONObject body = new JSONObject();
                                                try {
                                                    body.put(CODE, response.code);
                                                    if (response.code == Constant
                                                            .ACCOUNTEXPIRE_ERROR_CODE) {
                                                        body.put(MESSAGE, Constant
                                                                .ACCOUNT_FAILED);
                                                    }else if(response.code == Constant.LOGIN_ERROR_CODE){
                                                        //{"code":400004,"message":"邮箱服务器登录失败"}
                                                        body.put(MESSAGE, Constant
                                                                .ACCOUNT_FAILED);
                                                    } else {
                                                        body.put(MESSAGE, response.message);
                                                    }
                                                    body.put(RESULT, "");
                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                    CmailCenter.logger.error(Constant.TAG, "报错-> " +
                                                            "" + e
                                                            .toString());
                                                } finally {
                                                    CallJsUtils.callJs(body, option);
                                                }
                                            }

                                            @Override
                                            public void onError() {
                                                //将邮件标位已读
//									modifyMailStatus(mailUid, mailAccount,
//											folderName, option);
                                                failResultToJs(Constant.NET_ERROR_CODE,
                                                        NET_FAILED, option);
                                            }


                                        });
                            }
                        });
            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }

    }

    private void modifyMailStatus(long mailUid, String mailAccount, String folderName, String
            option) {
        //将邮件标位已读
        List<Long> uidList = new ArrayList<>();
        uidList.add(mailUid);
        Cmail.modifyMailStatus(mailAccount, folderName, 1, uidList, option);
    }

    private JSONArray toJsonObject(List<MailContentRes.ReceiverBean> list) {
        JSONArray jsonArray = new JSONArray();
        try {
            for (MailContentRes.ReceiverBean bean : list) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("name", bean.getName());
                jsonObject.put("address", bean.getAddress());
                jsonArray.put(jsonObject);
            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
        return jsonArray;
    }


    @Override
    public void mailSearch(final String data, final String option) {
        SearchBean searchBean = new Gson().fromJson(data, SearchBean.class);
        final String searchText = searchBean.getSearchText();
        final int searchType = searchBean.getSearchType();
        final int mode = searchBean.getMode();
        final List<SearchBean.FetchListBean> mailList = searchBean.getFetchList();
        Cmail.mailSearch(mailList, searchType, mode, searchText, option);
    }

    @Override
    public void mailFilter(final String data, final String option) {
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(data);
            if (jsonObject.has("fetchList") && jsonObject.has("fetchType") &&
                    jsonObject.has("mode")) {
                JSONArray jsonArray = jsonObject.getJSONArray("fetchList");
                List<GetMailDataBean> list = new Gson().fromJson(jsonArray
                        .toString(), new
                        TypeToken<List<GetMailDataBean>>() {
                        }.getType());
                int fetchType = jsonObject.getInt("fetchType");
                int filterType = jsonObject.getInt("filterType");
                int mode = jsonObject.getInt("mode");
                Cmail.mailFilter(list, fetchType,
                        filterType, mode, option);
            }
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }


    @Override
    public void saveMailToDrafts(final String data, final String option) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            String writeUrl = null;
            if (jsonObject.has("mailBody")) {
                JSONObject mailBody = jsonObject.getJSONObject("mailBody");
                if (mailBody.has("writeUrl")) {
                    writeUrl = mailBody.getString("writeUrl");
                }
            }


            TobeSend tobeSend = new Gson().fromJson(jsonObject.toString(), TobeSend.class);

            TobeSend.MailBody mailBody = tobeSend.getMailBody();
            long originUid = mailBody.getOriginUid();
            mailBody.setOriginUid(originUid);


            long timeMillis = System.currentTimeMillis();
            if (originUid == 0) {
                mailBody.setOriginUid(timeMillis);
            }

            if (!TextUtils.isEmpty(writeUrl)) {
                Uri writeUri = Uri.parse(writeUrl);
                String name = writeUri.getQueryParameter("name");
                timeMillis = Long.parseLong(name.substring(0, name.indexOf(".txt")));
            }
            mailBody.setMailTime(timeMillis);

            mailBody.setAttachmentCount(tobeSend.getMailBody().getOriginAttachment().size() +
                    tobeSend.getMailBody().getAttachmentFile().size());
            Cmail.saveMailToDrafts(tobeSend, writeUrl, option);
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }

    @Override
    public void addIdiomList(final String data, final String option) {
        Cmail.addIdiomList(data, option);
    }

    @Override
    public void getIdiomList(final String data, final String option) {
        Cmail.getIdiomList(data, option);
    }

    @Override
    public void getMailSignList(String data, String option) {
        Cmail.getMailSignList(data, option);
    }

    @Override
    public void deleteIdiomList(String data, String option) {
        try {
            JSONObject body = new JSONObject(data);
            if (!TextUtils.isEmpty(body.getString("idiom")) && !TextUtils.isEmpty(body.getString
                    ("idiom"))) {
                Cmail.deleteIdiomList(body.getString("idiom"),
                        option);
            } else {
                CallJsUtils.bindResultToJs(false, option);
                CmailCenter.logger.debug(Constant.TAG, "deleteIdiomList js 调用原生json格式不正确");
            }

        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }


    }
}
