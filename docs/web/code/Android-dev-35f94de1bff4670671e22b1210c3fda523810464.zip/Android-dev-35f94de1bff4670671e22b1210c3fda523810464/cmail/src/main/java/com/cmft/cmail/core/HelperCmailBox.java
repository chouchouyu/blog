package com.cmft.cmail.core;

import android.content.Context;
import android.util.Log;

import com.cmft.cmail.CallBack;
import com.cmft.cmail.Cmail;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.TobeSendDao;
import com.cmft.cmail.db.helper.MailFolderHelper;
import com.cmft.cmail.db.model.MailFolder;
import com.cmft.cmail.db.model.TobeSend;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.waltz.CallJsUtils;
import com.cmft.cmail.web.RetrofitService;
import com.cmft.cmail.web.resBean.MailBox;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.RESULT;

public class HelperCmailBox extends HelperCmail {
    private static final String TAG = Constant.TAG + "." + "Box";

    @Override
    public synchronized void init(Context context, RetrofitService retrofit, CmailDatabase
            database, ThreadPoolExecutor executor, ILogger logger, HelperSandbox sandbox) {
        super.init(context, retrofit, database, executor, logger, sandbox);
    }

    public void getMailBox(final List<String> mailList, final String mail, final String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject body = new JSONObject();
                List<MailBox> mailBoxList = new ArrayList<>();
                if (mailList != null) {
                    for (String mailAccount : mailList) {
                        Cmail.getMailBox(mailAccount);
                        List<MailFolder> mailFolders = MailFolderHelper.getInstance()
                                .queryFolders(mailAccount);
                        for (MailFolder folder : mailFolders) {
                            MailBox mailBox = new MailBox();
//                                mailBox.setFolderId(0);
                            if (Constant.TobeSent.equals(folder.getFolderKey())) {
                                TobeSendDao tobeSendDao =
                                        getDatabase()
                                                .getTobeSendDao();
                                List<TobeSend> tobeSends = tobeSendDao.queryTobeSendByMail
                                        (mailAccount);
                                mailBox.setMailCount(tobeSends.size());
                                mailBox.setUnseenCount(tobeSends.size());
                            } else {
                                mailBox.setMailCount((int) folder.getTotalCount());
                                mailBox.setUnseenCount((int) folder.getUnreadCount());
                            }
                            mailBox.setName(folder.getFolderKey());
                            mailBox.setFolderKey(folder.getName());
                            mailBox.setAliasName(folder.getAliasName());
                            mailBox.setFolderType(folder.getFolderType());
                            mailBoxList.add(mailBox);
                        }
                    }
                } else {
                    Cmail.getMailBox(mail);
                    List<MailFolder> mailFolders = MailFolderHelper.getInstance()
                            .queryFolders(mail);
                    for (MailFolder folder : mailFolders) {
                        MailBox mailBox = new MailBox();
//                            mailBox.setFolderId(0);
                        if (Constant.TobeSent.equals(folder.getFolderKey())) {
                            TobeSendDao tobeSendDao =
                                    getDatabase()
                                            .getTobeSendDao();
                            List<TobeSend> tobeSends = tobeSendDao.queryTobeSendByMail(mail);
                            mailBox.setMailCount(tobeSends.size());
                            mailBox.setUnseenCount(tobeSends.size());
                        } else {
                            mailBox.setMailCount((int) folder.getTotalCount());
                            mailBox.setUnseenCount((int) folder.getUnreadCount());
                        }
                        mailBox.setName(folder.getFolderKey());
                        mailBox.setAliasName(folder.getAliasName());
                        mailBox.setFolderKey(folder.getName());
                        mailBox.setFolderType(folder.getFolderType());
                        mailBoxList.add(mailBox);
                    }
                }

                String arrList = new Gson().toJson(mailBoxList, new TypeToken<List<MailBox>>() {
                }.getType());
                try {
                    JSONArray jsonArr = new JSONArray(arrList);
                    body.put(CODE, 0);
                    body.put(MESSAGE, "success");
                    body.put(RESULT, jsonArr.toString());
                    CallJsUtils.callJs(body, option);

                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }
        });
    }

    public void getMailBox(final String email, final CallBack callBack) {
        getRetrofit().getMailBoxFodler(email, new CallBack<List<MailFolder>>() {

            @Override
            public void onSuccess(final List<MailFolder> response) {
                getExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        MailFolderHelper.getInstance().insertFolder(response);
                        callBack.onSuccess(null);

                    }
                });
            }

            @Override
            public void onFail(String string) {
            }
        });
    }

    public void modifyFolderStatus(String email, String boxName, int mode, final String option) {
        getRetrofit().modifyFolderStatus(email, boxName, mode, option);
    }

    public void clearFolder(String mail, String boxName, String option) {
        getRetrofit().clearFolder(mail, boxName, option);
    }

    public void deleteFolder(String mail, String boxName, String option) {
        getRetrofit().deleteFolder(mail, boxName, option);
    }


    @Override
    public String getTag() {
        return HelperCmailBox.TAG;
    }
}
