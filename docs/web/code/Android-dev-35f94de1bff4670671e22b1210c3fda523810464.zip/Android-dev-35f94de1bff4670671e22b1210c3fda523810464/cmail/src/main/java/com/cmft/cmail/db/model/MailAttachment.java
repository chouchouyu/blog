package com.cmft.cmail.db.model;


import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;

import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

/**
 * 4)邮件附件信息表：tbl_attachment_info，按邮件账号分表，自定义账号删除，则相应表删除
 */
@Entity(tableName = "attachment_info",
        foreignKeys = {@ForeignKey(
                entity = MailAccount.class,
                parentColumns = "mailAccount",
                childColumns = "mailAccount",
                onDelete = ForeignKey.CASCADE,
                onUpdate = ForeignKey.CASCADE)
//                ,@ForeignKey(
//                        entity = MailHeader.class,
//                        parentColumns = "uid",
//                        childColumns = "mailUid",
//                        onDelete = ForeignKey.CASCADE,
//                        onUpdate = ForeignKey.CASCADE)
        })
public class MailAttachment {
    @ColumnInfo(index = true)
    @NonNull
    public String mailId;


    @PrimaryKey
    @NonNull
    public String id;

    @ColumnInfo(index = true)
    @NonNull
    public String mailAccount;

    @ColumnInfo(index = true)
    public long mailUid;

    public String attachmentName;

    public int attachmentIndex;


    public int fileSize;

    public String folderName;


    @ColumnInfo
    public String filePath;

    @Override
    public String toString() {
        return "MailAttachment{" +
                "id='" + id + '\'' +
                ", mailAccount='" + mailAccount + '\'' +
                ", mailUid=" + mailUid +
                ", attachmentName='" + attachmentName + '\'' +
                ", attachmentIndex=" + attachmentIndex +
                ", fileSize=" + fileSize +
                ", folderName=" + folderName +
                ", filePath='" + filePath + '\'' +
                '}';
    }
}
