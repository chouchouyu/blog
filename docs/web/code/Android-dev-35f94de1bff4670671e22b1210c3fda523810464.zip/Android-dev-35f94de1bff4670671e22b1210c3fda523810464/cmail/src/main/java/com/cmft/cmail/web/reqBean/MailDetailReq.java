package com.cmft.cmail.web.reqBean;

import java.util.List;

public class MailDetailReq {


    /**
     * attachmentCount : 0
     * attachmentFile : [{"name":"string","size":0,"url":"string"}]
     * content : string
     * flagged : false
     * mailTime : string
     * receiver : [{"address":"string","name":"string"}]
     * receiverBCC : [{"address":"string","name":"string"}]
     * receiverCC : [{"address":"string","name":"string"}]
     * relatedItem : [{"cid":"string","name":"string","url":"string"}]
     * sender : {"address":"string","name":"string"}
     * subject : string
     * uid : 0
     * unseen : false
     */

    private int attachmentCount;
    private String content;
    private boolean flagged;
    private String mailTime;
    private SenderBean sender;
    private String subject;
    private int uid;
    private boolean unseen;
    private List<AttachmentFileBean> attachmentFile;
    private List<ReceiverBean> receiver;
    private List<ReceiverBCCBean> receiverBCC;
    private List<ReceiverCCBean> receiverCC;
    private List<RelatedItemBean> relatedItem;

    public int getAttachmentCount() {
        return attachmentCount;
    }

    public void setAttachmentCount(int attachmentCount) {
        this.attachmentCount = attachmentCount;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isFlagged() {
        return flagged;
    }

    public void setFlagged(boolean flagged) {
        this.flagged = flagged;
    }

    public String getMailTime() {
        return mailTime;
    }

    public void setMailTime(String mailTime) {
        this.mailTime = mailTime;
    }

    public SenderBean getSender() {
        return sender;
    }

    public void setSender(SenderBean sender) {
        this.sender = sender;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public boolean isUnseen() {
        return unseen;
    }

    public void setUnseen(boolean unseen) {
        this.unseen = unseen;
    }

    public List<AttachmentFileBean> getAttachmentFile() {
        return attachmentFile;
    }

    public void setAttachmentFile(List<AttachmentFileBean> attachmentFile) {
        this.attachmentFile = attachmentFile;
    }

    public List<ReceiverBean> getReceiver() {
        return receiver;
    }

    public void setReceiver(List<ReceiverBean> receiver) {
        this.receiver = receiver;
    }

    public List<ReceiverBCCBean> getReceiverBCC() {
        return receiverBCC;
    }

    public void setReceiverBCC(List<ReceiverBCCBean> receiverBCC) {
        this.receiverBCC = receiverBCC;
    }

    public List<ReceiverCCBean> getReceiverCC() {
        return receiverCC;
    }

    public void setReceiverCC(List<ReceiverCCBean> receiverCC) {
        this.receiverCC = receiverCC;
    }

    public List<RelatedItemBean> getRelatedItem() {
        return relatedItem;
    }

    public void setRelatedItem(List<RelatedItemBean> relatedItem) {
        this.relatedItem = relatedItem;
    }

    public static class SenderBean {
        /**
         * address : string
         * name : string
         */

        private String address;
        private String name;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class AttachmentFileBean {
        /**
         * name : string
         * size : 0
         * url : string
         */

        private String name;
        private int size;
        private String url;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }

    public static class ReceiverBean {
        /**
         * address : string
         * name : string
         */

        private String address;
        private String name;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class ReceiverBCCBean {
        /**
         * address : string
         * name : string
         */

        private String address;
        private String name;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class ReceiverCCBean {
        /**
         * address : string
         * name : string
         */

        private String address;
        private String name;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class RelatedItemBean {
        /**
         * cid : string
         * name : string
         * url : string
         */

        private String cid;
        private String name;
        private String url;

        public String getCid() {
            return cid;
        }

        public void setCid(String cid) {
            this.cid = cid;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }
}
