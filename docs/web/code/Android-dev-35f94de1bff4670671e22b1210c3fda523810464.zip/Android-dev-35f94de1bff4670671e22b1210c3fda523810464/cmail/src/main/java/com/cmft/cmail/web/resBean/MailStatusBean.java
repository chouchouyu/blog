package com.cmft.cmail.web.resBean;

public class MailStatusBean {


    /**
     * email : wusm@cmft.com
     * status : true
     */

    private String email;
    private boolean status;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
