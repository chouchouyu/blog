package com.cmft.cmail.core;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.cmail.CallBack;
import com.cmft.cmail.Cmail;
import com.cmft.cmail.NetCallBack;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailAccountDao;
import com.cmft.cmail.db.dao.MailPhrasesDao;
import com.cmft.cmail.db.helper.MailAccountHelper;
import com.cmft.cmail.db.helper.MailFolderHelper;
import com.cmft.cmail.db.model.MailAccount;
import com.cmft.cmail.db.model.MailFolder;
import com.cmft.cmail.db.model.MailPhrases;
import com.cmft.cmail.utils.CmailInfoSp;
import com.cmft.cmail.utils.CmailSpUtils;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.waltz.CallJsUtils;
import com.cmft.cmail.web.RetrofitService;
import com.cmft.cmail.web.resBean.BaseRes;
import com.cmft.cmail.web.resBean.MailStatusBean;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

import static com.cmft.cmail.core.CmailCenter.accountPasswordMap;
import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.FAILED;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.NET_FAILED;
import static com.cmft.cmail.utils.Constant.RESULT;
import static com.cmft.cmail.utils.Constant.SUCCESS;
import static com.cmft.cmail.waltz.CallJsUtils.failResultToJs;

public class HelperCmailAccount extends HelperCmail {

    private static final String TAG = Constant.TAG + "." + "Account";

    @Override
    public synchronized void init(Context context, RetrofitService retrofit, CmailDatabase
            database, ThreadPoolExecutor executor, ILogger logger, HelperSandbox sandbox) {
        super.init(context, retrofit, database, executor, logger, sandbox);
    }


    public void addIdiomList(final List<MailPhrases> list, final String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject body = new JSONObject();
                try {
                    getDatabase().mailPhrasesDao().insert
                            (list);
                    body.put(CODE, 0);
                    body.put(MESSAGE, "success");
                    body.put(RESULT, SUCCESS);
                    CallJsUtils.callJs(body, option);

                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }
        });

    }

    public void addIdiomList(final String data, final String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject body = new JSONObject();
                try {
                    JSONObject jsonObject = new JSONObject(data);
                    JSONArray idiomArr = jsonObject.getJSONArray("idiomList");
                    String mailAccount = jsonObject.getString("mailAccount");
                    List<String> idiomList = new Gson().fromJson(idiomArr.toString(), new
                            TypeToken<List<String>>() {
                            }.getType());
                    List<MailPhrases> data = new ArrayList<>();
                    for (String content : idiomList) {
//                                MailPhrases mailPhrases = new MailPhrases(content, mailAccount);
                        MailPhrases mailPhrases = new MailPhrases(content);
                        data.add(mailPhrases);
                    }
                    getDatabase().mailPhrasesDao()
                            .insert(data);
                    body.put(CODE, 0);
                    body.put(MESSAGE, "success");
                    body.put(RESULT, SUCCESS);
                    CallJsUtils.callJs(body, option);

                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }
        });
    }


    public void setMailSignature(final String mailAccount, final String signature, final String
            option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                MailAccount mailAccountBean = MailAccountHelper.getInstance().getMailAccount
                        (mailAccount);
                if (mailAccountBean != null) {
                    mailAccountBean.setMailSign(signature);
                    int i = MailAccountHelper.getInstance().updateMailAccount(mailAccountBean);

                    JSONObject body = new JSONObject();
                    try {
                        body.put(CODE, i != 0 ? 0 : Constant.NET_ERROR_CODE);
                        body.put(MESSAGE, "success");
                        body.put(RESULT, i != 0 ? SUCCESS : FAILED);
                        CallJsUtils.callJs(body, option);

                    } catch (Exception e) {
                        e.printStackTrace();
                        getLogger().error(TAG, "报错-> " + e.toString());
                    }
                }
            }
        });
    }


    public void setMainMailAccount(final String mainAccount, final boolean masterAccount, final
    String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                List<MailAccount> list = MailAccountHelper.getInstance().getMailAccounts(CmailInfoSp
                        .getUserId());

                int i = 0;
                if (list != null && list.size() > 0) {
                    for (MailAccount mailAccount : list) {
                        if (masterAccount) {
                            if (mailAccount.getMailAccount().equals(mainAccount)) {
                                mailAccount.setMasterAccount(masterAccount);
                            } else {
                                mailAccount.setMasterAccount(!masterAccount);
                            }
                            i = MailAccountHelper.getInstance().updateMailAccount(mailAccount);
                        } else {
                            //关掉
                            if (mailAccount.getMailAccount().equals(mainAccount)) {
                                mailAccount.setMasterAccount(masterAccount);
                                i = MailAccountHelper.getInstance().updateMailAccount(mailAccount);
                            }
                        }
                    }


                    JSONObject body = new JSONObject();
                    try {
                        body.put(CODE, i != 0 ? 0 : Constant.NET_ERROR_CODE);
                        body.put(MESSAGE, "success");
                        body.put(RESULT, i != 0 ? SUCCESS : FAILED);
                        CallJsUtils.callJs(body, option);

                    } catch (Exception e) {
                        e.printStackTrace();
                        getLogger().error(TAG, "报错-> " + e.toString());
                    }
                } else {
                    JSONObject body = new JSONObject();
                    try {
                        body.put(CODE, Constant.NET_ERROR_CODE);
                        body.put(MESSAGE, "success");
                        body.put(RESULT, FAILED);
                        CallJsUtils.callJs(body, option);

                    } catch (Exception e) {
                        e.printStackTrace();
                        getLogger().error(TAG, "报错-> " + e.toString());
                    }
                }
            }
        });
    }


    public void getIdiomList(final String data, final String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject body = new JSONObject();
                try {
                    JSONObject jsonObject = new JSONObject(data);
                    List<String> phrasesList = getDatabase().mailPhrasesDao().queryPhrases();
                    String s = new Gson().toJson(phrasesList);
                    body.put(CODE, 0);
                    body.put(MESSAGE, "success");
                    body.put(RESULT, s);
                    CallJsUtils.callJs(body, option);

                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }
        });
    }

    public void deleteIdiomList(final String idiom, final String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                MailPhrasesDao mailPhrasesDao = getDatabase().mailPhrasesDao();
//                MailPhrases mailPhrases = new MailPhrases(idiom, mailAccount);
                mailPhrasesDao.delete(idiom);
                CallJsUtils.bindResultToJs(true, option);
            }
        });
    }

    public void getMailSignList(final String data, final String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject body = new JSONObject();
                try {
                    JSONObject jsonObject = new JSONObject(data);
                    String mailAccount = jsonObject.getString("mailAccount");
                    String mailSign = MailAccountHelper.getInstance().getMailSign(mailAccount);
                    body.put(CODE, 0);
                    body.put(MESSAGE, "success");
                    body.put(RESULT, mailSign == null ? "" : mailSign);
                    CallJsUtils.callJs(body, option);

                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }
        });
    }


    public void bindAccountToServer(final String mailAccount, final String password, String
            option) {
        getRetrofit().bindAccountToServer(mailAccount, password, option, new
                CallBack<List<MailFolder>>() {


                    @Override
                    public void onSuccess(final List<MailFolder> response) {
                        getExecutor().execute(new Runnable() {
                            @Override
                            public void run() {
                                MailFolderHelper.getInstance().insertFolder(response);
                            }
                        });


                    }

                    @Override
                    public void onFail(String string) {
//                        final String mail = mailAccount;
//                        final int code = Integer.valueOf(string);
//                        if (code == 400006 || code == Constant.ACCOUNTEXPIRE_ERROR_CODE) {
//                            executor.execute(new Runnable() {
//                                @Override
//                                public void run() {
//                                    MailAccountDao dao = database.getMailAccountDao();
//                                    MailAccount mailAccount = dao
//                                            .queryByMailAccount(mail);
//                                    if (code == Constant.ACCOUNTUNACTIVE_ERROR_CODE) {
//                                        mailAccount.setAccountState(Constant
//                                                .ACCOUNTSTATUE_UNACTIVE);
//                                    } else if (code == Constant.ACCOUNTEXPIRE_ERROR_CODE) {
//                                        mailAccount.setAccountState(Constant
// .ACCOUNTSTATUE_EXPIRE);
//
//                                    }
//                                    dao.updateMailAccount(mailAccount);
//                                }
//                            });
//                        }
                    }

                }, new CallBack<String>() {
            @Override
            public void onSuccess(String password) {
                if (accountPasswordMap.containsKey(mailAccount)) {
                    accountPasswordMap.remove(mailAccount);
                }
                accountPasswordMap.put(mailAccount, password);

            }

            @Override
            public void onFail(String string) {

            }
        });
    }

    public void unbindAccountToServer(String mailAccount, String option) {
        getRetrofit().unbindAccountToServer(this,mailAccount, option);
    }

    public void freezeMail(final String mail, final String option) {

        /*更新数据库*/
//                getMailStatus(mail);
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                MailAccountDao dao = getDatabase().getMailAccountDao();
                MailAccount mailAccountBean = dao.queryByMailAccount(mail);
//                        MailAccount mailAccountBean = MailAccountHelper.getInstance()
//                                .getMailAccount
//                                        (mail);
                mailAccountBean.setAccountState(Constant.ACCOUNTSTATUE_DISABLED);
                dao.updateMailAccount(mailAccountBean);


                CallJsUtils.bindResultToJs(true, option);
            }
        });
    }

    public void unFreezeMail(final String mail, final String option) {
        final JSONObject body = new JSONObject();
        getRetrofit().unFreezeMail(mail, new NetCallBack<BaseRes>() {
            @Override
            public void onSuccess(final BaseRes response) {


                getExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        MailAccount mailAccountBean = MailAccountHelper.getInstance()
                                .getMailAccount
                                        (mail);
                        mailAccountBean.setAccountState(Constant.ACCOUNTSTATUE_ACTIVE);
                        MailAccountHelper.getInstance().updateMailAccount(mailAccountBean);

                        try {
                            body.put(CODE, 0);
                            body.put(MESSAGE, "success");
                            body.put(RESULT, response.result);
                            CallJsUtils.callJs(body, option);
                        } catch (Exception e) {
                            e.printStackTrace();
                            getLogger().error(TAG, "报错-> " + e.toString());
                        }
                    }
                });
            }

            @Override
            public void onFail(BaseRes response) {
                try {
                    body.put(CODE, response.code);
                    body.put(MESSAGE, response.message);
                    body.put(RESULT, "");
                    CallJsUtils.callJs(body, option);

                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }

            @Override
            public void onError() {
                failResultToJs(Constant.NET_ERROR_CODE, NET_FAILED, option);
            }
        });
    }


    public void getMailAccountList(final String option) {
        getExecutor().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject body = new JSONObject();
                List<MailAccount> mailAccounts = MailAccountHelper.getInstance()
                        .getMailAccounts(CmailInfoSp.getUserId());
                try {
                    JSONArray jsonArray = new JSONArray();
                    for (MailAccount account : mailAccounts) {
//                        if (account.getAccountState() == Constant.ACCOUNTSTATUE_UNACTIVE) {
//                            continue;
//                        }
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("accountState", account.getAccountState());
                        jsonObject.put("accountType", account.getAccountType());
                        jsonObject.put("company", account.getCompany());
                        jsonObject.put("lastLogin", account.getLastLogin());
                        jsonObject.put("mailAccount", account.getMailAccount());
                        jsonObject.put("masterAccount", account.isMasterAccount());
                        jsonArray.put(jsonObject);
                    }
                    body.put(CODE, 0);
                    body.put(MESSAGE, "success");
                    body.put(RESULT, jsonArray.toString());
                    CallJsUtils.callJs(body, option);
                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }

                //更新数据
                for (MailAccount account : mailAccounts) {
                    if (account.getAccountState() == Constant.ACCOUNTSTATUE_ACTIVE) {
                        getMailStatus(account.getMailAccount());
                    }
                }

            }
        });
    }


    private void getMailStatus(final String mail) {
        getRetrofit().getMailStatus(mail, new NetCallBack<BaseRes<MailStatusBean>>() {
            @Override
            public void onSuccess(final BaseRes<MailStatusBean> response) {
                getExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        //更新数据库
                        final MailAccount mailAccount = MailAccountHelper.getInstance()
                                .getMailAccount
                                        (mail);
                        if (mailAccount != null) {
                            if (response.result.isStatus()) {
                                if (accountPasswordMap.containsKey(mail)) {
                                    //password也存在的时候
                                    mailAccount.setAccountState(Constant.ACCOUNTSTATUE_ACTIVE);
                                    MailAccountHelper.getInstance().updateMailAccount(mailAccount);
                                } else {
                                    getSandbox().getSanboxPassword(mail, new com.cmft.android
                                            .sandbox.crypter
                                            .CallBack<String>() {


                                        @Override
                                        public void onSuccess(String s) {
                                            //password也存在的时候
                                            if (accountPasswordMap.containsKey(mail)) {
                                                accountPasswordMap.remove(mail);
                                            }
                                            accountPasswordMap.put(mail, s);
                                            mailAccount.setAccountState(Constant
                                                    .ACCOUNTSTATUE_ACTIVE);
                                            MailAccountHelper.getInstance().updateMailAccount
                                                    (mailAccount);
                                        }

                                        @Override
                                        public void onFail(String s) {

                                        }
                                    });
                                }

                            }
                        }
                    }

                });
                //  修改邮件数量
                Cmail.getMailBox(mail);

            }

            @Override
            public void onFail(final BaseRes<MailStatusBean> response) {
                //"code":Constant.ACCOUNTUNACTIVE_ERROR_CODE,"message":"用户未绑定该邮箱:wusm@cmft.com"
//                {"code":Constant.ACCOUNTUNACTIVE_ERROR_CODE,
// "message":"邮箱账号未绑定激活:testapp03@cmrhic.com"}
                getExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        final MailAccountDao dao = getDatabase().getMailAccountDao();
                        final MailAccount mailAccount = dao
                                .queryByMailAccount(mail);
                        if (response.code == Constant.ACCOUNTUNACTIVE_ERROR_CODE) {
                            if (mailAccount != null) {
                                dao.deleteMailAccount(mailAccount);
                                if (mailAccount.isMasterAccount()) {
                                    mailAccount.setAccountState(Constant
                                            .ACCOUNTSTATUE_UNACTIVE);
                                    dao.insertMailAccount(mailAccount);
                                }
                                MailAccountHelper.getInstance().updateMailAccount(mailAccount);
                            }
                            deletePassword(mail);
                        } else if (response.result != null && !response.result.isStatus() ||
                                (String.valueOf(response.code).startsWith("400"))) {
                            //有无密码 有 过期，无 未激活
                            getSandbox().getSanboxPassword(mail, new com.cmft.android
                                    .sandbox.crypter
                                    .CallBack<String>() {


                                @Override
                                public void onSuccess(String s) {
                                    //password存在的时候 有 过期
                                    if (mailAccount != null) {
                                        mailAccount.setAccountState(Constant.ACCOUNTSTATUE_EXPIRE);
                                        MailAccountHelper.getInstance().updateMailAccount
                                                (mailAccount);
                                    }
                                }

                                @Override
                                public void onFail(String s) {
                                    if (mailAccount != null) {
                                        dao.deleteMailAccount(mailAccount);
                                        if (mailAccount.isMasterAccount()) {
                                            mailAccount.setAccountState(Constant
                                                    .ACCOUNTSTATUE_UNACTIVE);
                                            dao.insertMailAccount(mailAccount);
                                        }
                                        MailAccountHelper.getInstance().updateMailAccount
                                                (mailAccount);
                                    }
                                    deletePassword(mail);
                                }
                            });

                        }
//                        else if (response.code == Constant.LOGIN_ERROR_CODE) {
//                            mailAccount.setAccountState(Constant.ACCOUNTSTATUE_EXPIRE);
//                            deletePassword(mail);
//                        }
                    }
                });
            }

            @Override
            public void onError() {
            }
        });
    }

    /**
     * 删除账号
     * @param mail
     */
    public void deletePassword(String mail) {
        getLogger().debug(TAG, "账号 密码被删除" + mail);
        if (accountPasswordMap.containsKey(mail)) {
            accountPasswordMap.remove(mail);
        }
        String saveDir = getSandbox().saveToSandBox(mail, Constant.SANDBOX_ACCOUNT);
        String fileName = mail;
        getLogger().debug(TAG, " deletefromSandBox ->  " +
                saveDir + File
                .separator +
                fileName);
        File file = new File(saveDir + File
                .separator +
                fileName);
        if (SandBox.getInstance().isEncrypted(file)) {
            if (SandBox.getInstance().delete(saveDir + File
                    .separator +
                    fileName)) {
                getLogger().debug(TAG, "删除未绑定：" + mail + "密码成功");
            } else {
                getLogger().debug(TAG, "删除未绑定：" + mail + "密码失败");
            }
        }
    }

    public void getSupportMailDomain(final String option) {
        final JSONObject body = new JSONObject();
        String domainJson = CmailInfoSp.getDomainsJsonArray();
        if (TextUtils.isEmpty(domainJson)) {
            getRetrofit().getMailDomains(new NetCallBack<BaseRes>() {
                @Override
                public void onSuccess(BaseRes response) {
                    Map<String, String> map = (Map) response.result;

                    JSONArray domainArray = new JSONArray();
                    JSONArray companyArray = new JSONArray();
                    try {
                        for (Map.Entry<String, String> entry : map.entrySet()) {
                            String mapKey = entry.getKey();
                            String value = entry.getValue();
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("key", mapKey);
                            jsonObject.put("value", value);
                            companyArray.put(jsonObject);

                            domainArray.put(mapKey);
                        }
                        CmailInfoSp.setDomainsJsonArray(domainArray.toString());
                        CmailInfoSp.setCompanyMap(companyArray.toString());
                    } catch (Exception e) {
                        e.printStackTrace();
                        getLogger().error(TAG, "报错-> " + e.toString());
                    }
                    if (!TextUtils.isEmpty(option)) {
                        try {
                            body.put(CODE, 0);
                            body.put(MESSAGE, "success");
                            body.put(RESULT, response.result.toString());
                            CallJsUtils.callJs(body, option);

                        } catch (Exception e) {
                            e.printStackTrace();
                            getLogger().error(TAG, "报错-> " + e.toString());
                        }
                    }
                }

                @Override
                public void onFail(BaseRes response) {
                    if (!TextUtils.isEmpty(option) && response != null) {
                        try {
                            body.put(CODE, response.code);
                            body.put(MESSAGE, response.message);
                            body.put(RESULT, "");
                            CallJsUtils.callJs(body, option);

                        } catch (Exception e) {
                            e.printStackTrace();
                            getLogger().error(TAG, "报错-> " + e.toString());
                        }
                    }
                }

                @Override
                public void onError() {
                    if (!TextUtils.isEmpty(option)) {
                        failResultToJs(Constant.NET_ERROR_CODE, NET_FAILED, option);
                    }
                }
            });
        } else {
            if (!TextUtils.isEmpty(option)) {
                try {
                    body.put(CODE, 0);
                    body.put(MESSAGE, "success");
                    body.put(RESULT, domainJson);
                    CallJsUtils.callJs(body, option);

                } catch (Exception e) {
                    e.printStackTrace();
                    getLogger().error(TAG, "报错-> " + e.toString());
                }
            }
        }

    }


    @Override
    public String getTag() {
        return HelperCmailAccount.TAG;
    }
}
