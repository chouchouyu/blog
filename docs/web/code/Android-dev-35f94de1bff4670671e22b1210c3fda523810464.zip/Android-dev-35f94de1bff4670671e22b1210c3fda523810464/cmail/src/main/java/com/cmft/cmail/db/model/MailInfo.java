package com.cmft.cmail.db.model;

import android.support.annotation.NonNull;
import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;

/**
 * //             todo   收件箱是receiveTime, 发件箱是sendTime
 * <p>
 * //                  contentMark  邮件正文摘要（最前面255字符） 待删除
 * https://github.com/sqlcipher/sqlcipher-android-tests/blob
 * /295ac996c6bea9d0322aa5bde6c7493292a8efd3/app/src/main/java/net/zetetic/tests/support/RoomTest
 * .java
 * https://github.com/tb-yangshu/AndroidRoomLibExample/blob/master/app/src/main/java/com/tianbin
 * /androidroomlibexample/model/Category.java
 * 3)用户本地邮件数据列表：tbl_mail_info_(mailAccout)  按邮件账号分表，自定义账号删除，则相应表删除，UID+folderId为索引
 */
@Entity(tableName = "mail_info",
        foreignKeys = {@ForeignKey(
                entity = MailAccount.class,
                parentColumns = "mailAccount",
                childColumns = "mailAccount",
                onDelete = ForeignKey.CASCADE,
                onUpdate = ForeignKey.CASCADE)
//                , @ForeignKey(
//                entity = MailHeader.class,
//                parentColumns = "uid",
//                childColumns = "mailUid",
//                onDelete = ForeignKey.CASCADE,
//                onUpdate = ForeignKey.CASCADE)
        })
public class MailInfo {

    @ColumnInfo(index = true)
    @NonNull
    public String mailAccount;

    @PrimaryKey
    @NonNull
    public String id;

    @ColumnInfo(index = true)
    @NonNull
    public long mailUid;

    @ColumnInfo(index = true)
    public String folderName;

    public String sender;

    public String sendername;

    public String receivers;

    public String receiversCC;

    public String receiversBCC;

    public String subject;


    public long timeStamp;

    public long receivTime;

    public boolean hasReaded;

    public boolean hasflaged;

    public boolean hasAttachments;

    public String emailPath;

    public long emailSize;


    @Override
    public String toString() {
        return "MailInfo{" +
                "mailAccount='" + mailAccount + '\'' +
                ", id='" + id + '\'' +
                ", mailUid=" + mailUid +
                ", folderName='" + folderName + '\'' +
                ", sender='" + sender + '\'' +
                ", sendername='" + sendername + '\'' +
                ", receivers='" + receivers + '\'' +
                ", receiversCC='" + receiversCC + '\'' +
                ", receiversBCC='" + receiversBCC + '\'' +
                ", subject='" + subject + '\'' +
                ", timeStamp=" + timeStamp +
                ", receivTime=" + receivTime +
                ", hasReaded=" + hasReaded +
                ", hasflaged=" + hasflaged +
                ", hasAttachments=" + hasAttachments +
                ", emailPath='" + emailPath + '\'' +
                ", emailSize=" + emailSize +
                '}';
    }

    /*
      @Embedded
    public MailDetail mailDetail;

    @Relation(parentColumn = "mailUid", entityColumn = "mailUid")
    public List<MailAttachment> attachmentList;

    @Override
    public String toString() {
        return "MailInfo{" +
                "mailDetail=" + mailDetail +
                ", attachmentList=" + attachmentList +
                '}';
    }

     */
}
