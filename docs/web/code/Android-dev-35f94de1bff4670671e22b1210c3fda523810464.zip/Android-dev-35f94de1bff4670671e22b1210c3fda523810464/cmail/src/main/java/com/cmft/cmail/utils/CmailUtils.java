package com.cmft.cmail.utils;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.Log;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.cmail.Cmail;
import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.db.model.CompanyModel;
import com.cmft.cmail.db.model.MailAccount;
import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.db.model.ReceiverBean;
import com.cmft.cmail.waltz.CallJsUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.cm.android.cmcore.net.util.FileUtil.getDataColumn;
import static com.cm.android.cmcore.net.util.FileUtil.isDownloadsDocument;
import static com.cm.android.cmcore.net.util.FileUtil.isExternalStorageDocument;
import static com.cm.android.cmcore.net.util.FileUtil.isGooglePhotosUri;
import static com.cm.android.cmcore.net.util.FileUtil.isMediaDocument;
import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.FAILED;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.NET_FAILED;
import static com.cmft.cmail.utils.Constant.RESULT;
import static com.cmft.cmail.utils.Constant.SUCCESS;

public class CmailUtils {


    /**
     * APIlevel 19以上才有
     * 创建项目时，我们设置了最低版本API Level，比如我的是10，
     * 因此，AS检查我调用的API后，发现版本号不能向低版本兼容，
     * 比如我用的“DocumentsContract.isDocumentUri(context, uri)”是Level 19 以上才有的，
     * 自然超过了10，所以提示错误。
     * 添加    @TargetApi(Build.VERSION_CODES.KITKAT)即可。
     * <p>
     * content://com.android.providers.downloads
     * .documents/document/raw%3A%2Fstorage%2Femulated%2F0%2FDownload%2Fwsm.xlsx
     *
     * @param context
     * @param uri
     * @return
     */
    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static String getPath_above19(final Context context, final Uri uri) {
        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;
        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];
                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                CmailCenter.logger.debug(Constant.TAG, "getPath_above19-id:" + id);

                String path = null;
                if (!TextUtils.isEmpty(id)) {
                    if (id.startsWith("raw:")) {
                        path = id.replaceFirst("raw:", "");
                    }
                    try {
                        final Uri contentUri = ContentUris.withAppendedId(
                                Uri.parse("content://downloads/public_downloads"), Long.valueOf
                                        (id));

                        path = getDataColumn(context, contentUri, null, null);
                    } catch (Exception e) {
                        e.printStackTrace();
                        CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
                    }
                    return path;
                }
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");

                final String type = split[0];
                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{
                        split[1]
                };

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            // Return the remote address
            if (isGooglePhotosUri(uri)) {
                return uri.getLastPathSegment();
            }

            if (isQQMediaDocument(uri)) {
                String path = uri.getPath();
                File fileDir = Environment.getExternalStorageDirectory();
                File file = new File(fileDir, path.substring("/QQBrowser".length(), path.length()));
                return file.exists() ? file.toString() : null;
            }
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }

    /**
     * 使用第三方qq文件管理器打开
     *
     * @param uri
     * @return
     */
    public static boolean isQQMediaDocument(Uri uri) {
        return "com.tencent.mtt.fileprovider".equals(uri.getAuthority());
    }

    /**
     * API19以下获取图片路径的方法
     *
     * @param uri
     */
    public static String getFilePath_below19(Context context, Uri uri) {
        //这里开始的第二部分，获取图片的路径：低版本的是没问题的，但是sdk>19会获取不到
        String[] proj = {MediaStore.Images.Media.DATA};
        //好像是android多媒体数据库的封装接口，具体的看Android文档
        Cursor cursor = context.getContentResolver().query(uri, proj, null, null, null);
        //获得用户选择的图片的索引值
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        //将光标移至开头 ，这个很重要，不小心很容易引起越界
        cursor.moveToFirst();
        //最后根据索引值获取图片路径   结果类似：/mnt/sdcard/DCIM/Camera/IMG_20151124_013332.jpg
        String path = cursor.getString(column_index);
        return path;
    }


    private boolean hasPermission(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            // Permission was added in API Level 16
            return ContextCompat.checkSelfPermission(context, Manifest.permission
                    .READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    /**
     * 判断SDCard是否可用
     */
    public static boolean existSDCard() {
        return Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
    }

    /**
     * 根据系统时间、前缀、后缀产生一个文件
     */
    public static File createFile(File folder, String prefix, String suffix) {
        if (!folder.exists() || !folder.isDirectory()) {
            folder.mkdirs();
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA);
        String filename = prefix + dateFormat.format(new Date(System.currentTimeMillis())) + suffix;
        return new File(folder, filename);
    }


    public static long currentTimeMillis() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            return simpleDateFormat.parse(DateFormat.format("yyyy-MM-dd HH:mm:ss", calendar)
                    .toString()).getTime();
        } catch (Exception e) {
            e.printStackTrace();
            CmailCenter.logger.error(Constant.TAG, "报错-> " + e.toString());
        }
        return System.currentTimeMillis();
    }


    public static MailAccount setCompany(MailAccount mailAccountBean) {
        String companyJsonArray = CmailInfoSp.getCompanyMap();
        if (TextUtils.isEmpty(companyJsonArray)) {
            CmailCenter.logger.debug(Constant.TAG, "MailAccount-setCompany sp saved js is empty");
            mailAccountBean.setCompany(Constant.CMFT_COMPANY);
        } else {
            Gson gson = new Gson();
            List<CompanyModel> companyList = gson.fromJson(companyJsonArray, new
                    TypeToken<List<CompanyModel>>() {
                    }.getType());
            for (CompanyModel company : companyList) {
                if (mailAccountBean.getMailAccount().endsWith(company.key)) {
                    mailAccountBean.setCompany(company.value);

                }
            }
            CmailCenter.logger.debug(Constant.TAG, " MailAccount-setCompany：" + mailAccountBean
                    .getMailAccount());
        }
        return mailAccountBean;
    }

    public static String formatStackTrace(StackTraceElement[] stackTrace) {
        StringBuilder sb = new StringBuilder();
        for (StackTraceElement element : stackTrace) {
            sb.append("    at ").append(element.toString());
            sb.append("\n");
        }
        return sb.toString();
    }


    public static boolean isEmail(String email) {
        if (null == email || "".equals(email)) return false;
        //Pattern p = Pattern.compile("\\w+@(\\w+.)+[a-z]{2,3}"); //简单匹配
        Pattern p = Pattern.compile("\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");//复杂匹配
        Matcher m = p.matcher(email);
        return m.matches();
    }

    public static String netErrorMsg(int code) {
        return "网络异常(" + code + ")";
    }


    public static String getFilePathFromURI(Context context, Uri contentUri) {
        File rootDataDir = context.getFilesDir();
        String fileName = getFileName(contentUri);
        if (!TextUtils.isEmpty(fileName)) {
            File copyFile = new File(rootDataDir + File.separator + fileName);
            copyFile(context, contentUri, copyFile);
            return copyFile.getAbsolutePath();
        }
        return null;
    }

    public static String getFileName(Uri uri) {
        if (uri == null) return null;
        String fileName = null;
        String path = uri.getPath();
        int cut = path.lastIndexOf('/');
        if (cut != -1) {
            fileName = path.substring(cut + 1);
        }
        return fileName;
    }

    public static void copyFile(Context context, Uri srcUri, File dstFile) {
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(srcUri);
            if (inputStream == null) return;
            OutputStream outputStream = new FileOutputStream(dstFile);
            copyStream(inputStream, outputStream);
            inputStream.close();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int copyStream(InputStream input, OutputStream output) throws Exception,
            IOException {
        final int BUFFER_SIZE = 1024 * 2;
        byte[] buffer = new byte[BUFFER_SIZE];
        BufferedInputStream in = new BufferedInputStream(input, BUFFER_SIZE);
        BufferedOutputStream out = new BufferedOutputStream(output, BUFFER_SIZE);
        int count = 0, n = 0;
        try {
            while ((n = in.read(buffer, 0, BUFFER_SIZE)) != -1) {
                out.write(buffer, 0, n);
                count += n;
            }
            out.flush();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
            }
            try {
                in.close();
            } catch (IOException e) {
            }
        }
        return count;
    }


    public static LinkedHashMap<String, String> convertReciversListToMap(List<ReceiverBean> list) {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        if (list != null && list.size() > 0) {
            for (ReceiverBean bean : list) {
                map.put(bean.getAddress(), bean.getName());
            }
        }
        return map;
    }


    // //列表待发送 reciver放sender里
    @NonNull
    public static JSONArray modifyReciverTORecivers(JSONArray jsonArray) throws JSONException {
        JSONArray tobeSentArray = new JSONArray();
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            JSONArray receiverArray = new JSONArray();

            if (jsonObject.has("receiver")) {
                JSONArray receiverList = jsonObject.getJSONArray
                        ("receiver");
                if (receiverList.length() > 0) {
                    for (int j = 0; j < receiverList.length(); j++) {
                        receiverArray.put(receiverList.get(j));
                    }
                }
                jsonObject.remove("receiver");
            }

            if (jsonObject.has("receiverBCC")) {
                JSONArray receiverList = jsonObject.getJSONArray("receiverBCC");
                if (receiverList.length() > 0) {
                    for (int j = 0; j < receiverList.length(); j++)
                        receiverArray.put(receiverList.get(j));
                }
                jsonObject.remove("receiverBCC");
            }


            if (jsonObject.has("receiverCC")) {
                JSONArray receiverList = jsonObject.getJSONArray("receiverCC");
                if (receiverList.length() > 0) {
                    for (int j = 0; j < receiverList.length(); j++) {
                        receiverArray.put(receiverList.get(j));
                    }
                }
                jsonObject.remove("receiverCC");
            }


            jsonObject.put("receivers", receiverArray);
            tobeSentArray.put(jsonObject);
        }
        jsonArray = tobeSentArray;
        return jsonArray;
    }
}
