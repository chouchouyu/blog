package com.cmft.cmail.db.model;


public class SYNModel {
    private String account;
    private String boxName;
    private long maxUid;
    private long minuid;
    private int mode;
    private boolean isIgnore;

    public SYNModel(String account, String boxName, long maxUid, long minuid,
                    boolean isIgnore) {
        this.account = account;
        this.boxName = boxName;
        this.maxUid = maxUid;
        this.minuid = minuid;
        this.isIgnore = isIgnore;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getBoxName() {
        return boxName;
    }

    public void setBoxName(String boxName) {
        this.boxName = boxName;
    }

    public long getMaxUid() {
        return maxUid;
    }

    public void setMaxUid(long maxUid) {
        this.maxUid = maxUid;
    }

    public long getMinuid() {
        return minuid;
    }

    public void setMinuid(long minuid) {
        this.minuid = minuid;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public boolean isIgnore() {
        return isIgnore;
    }

    public void setIgnore(boolean ignore) {
        isIgnore = ignore;
    }

    @Override
    public String toString() {
        return "BoxInfoModel{" +
                "account='" + account + '\'' +
                ", boxName='" + boxName + '\'' +
                ", maxUid=" + maxUid +
                ", minuid=" + minuid +
                ", mode=" + mode +
                ", isIgnore=" + isIgnore +
                '}';
    }
}

