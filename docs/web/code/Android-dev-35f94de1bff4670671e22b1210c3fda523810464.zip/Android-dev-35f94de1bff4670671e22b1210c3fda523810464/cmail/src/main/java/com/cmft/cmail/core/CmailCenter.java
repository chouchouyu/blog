package com.cmft.cmail.core;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.cmft.android.sandbox.crypter.SandBox;
import com.cmft.android.sandbox.crypter.core.SandBoxConfig;
import com.cmft.cmail.CallBack;
import com.cmft.cmail.NetCallBack;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.helper.MailAccountHelper;
import com.cmft.cmail.db.model.GetMailDataBean;
import com.cmft.cmail.db.model.MailAccount;
import com.cmft.cmail.db.model.MailDetail;
import com.cmft.cmail.db.model.MailPhrases;
import com.cmft.cmail.db.model.SearchBean;
import com.cmft.cmail.db.model.TobeSend;
import com.cmft.cmail.db.model.UserInfo;
import com.cmft.cmail.utils.ActivityTracker;
import com.cmft.cmail.utils.CmailInfoSp;
import com.cmft.cmail.utils.CmailUtils;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.CrashHandler;
import com.cmft.cmail.utils.DefaultLogger;
import com.cmft.cmail.utils.DefaultPoolExecutor;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.utils.LogListener;
import com.cmft.cmail.waltz.CallJsUtils;
import com.cmft.cmail.web.RetrofitService;
import com.cmft.cmail.web.resBean.BaseRes;
import com.cmft.cmail.web.resBean.MailContentRes;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;


import static com.cmft.cmail.utils.CmailInfoSp.saveUserInforToSP;
import static com.cmft.cmail.utils.Constant.CODE;
import static com.cmft.cmail.utils.Constant.DEFAULT_SIGN;
import static com.cmft.cmail.utils.Constant.MESSAGE;
import static com.cmft.cmail.utils.Constant.RESULT;


public class CmailCenter {

    private CmailConfig config;
    private boolean buggable;
    private static Context context;
    private static CmailCenter mCmailCenter;
    private RetrofitService retrofit;
    private CmailDatabase database;
    public volatile static ThreadPoolExecutor executor = DefaultPoolExecutor.getInstance();
    public volatile static Map<String, String> accountPasswordMap = new HashMap<>();
    public static ILogger logger = new DefaultLogger(Constant.TAG);
    private HelperSandbox sandbox;

    public static Context getContext() {
        return context;
    }

    private CmailCenter(CmailConfig config) {
        if (config.isSaveLog()) {
            CrashHandler.getInstance().init(config.getContext());
        }
        logger.showLog(config.isBuggable(),config.isSaveLog());
        //            logger.showStackTrace(cmailConfig.isBuggable());
        logger.debug(Constant.TAG, "===== cmail " + Constant.SDK_VERSION + " begin =====");

        if (!config.isValid()) {
            throw new NullPointerException("config's param is invalid");
        }
        this.config = config;
        context = config.getContext();
        buggable = config.isBuggable();

        SandBoxConfig boxConfig = new SandBoxConfig.Builder()
                .isBuggable(false)
//                .setEncryptKey(UUID.randomUUID().toString())
                .setEncryptKey("qwweasdfgdsasdfe")
                .setWaterMark("招商金科")
                .build(config.getApplication());
        SandBox.init(boxConfig);
        SandBox.setLogListener(new com.cmft.android.sandbox.crypter.utils.LogListener() {
            @Override
            public void onLog(String s, String s1) {
                logger.debug(s, s1);
            }
        });

        sandbox = HelperSandbox.getInstance(logger);

        boolean isTrackingActivities = ActivityTracker.get().beginTrackingIfPossible(
                config.getApplication());
        if (!isTrackingActivities) {
            logger.debug(Constant.TAG, "Automatic activity tracking not available on this API level, " +
                    "caller " +
                    "must " +
                    "invoke " +
                    "ActivityTracker methods manually!");
        }
        init();
    }


    private void init() {
        if (config.isInnerEnv()) {
            retrofit = RetrofitService.getInstance(Constant.BASE_URL_INNER, buggable, config
                    .isInnerEnv(), logger, sandbox);
        } else {
            retrofit = RetrofitService.getInstance(Constant.BASE_URL_OUTER, buggable, config
                    .isInnerEnv(), logger, sandbox);
        }


    }

    public void registerListener(LogListener logListener) {
        logger.registerListener(logListener);
    }


    public static CmailCenter instance(CmailConfig config) {
        if (mCmailCenter == null) {
            synchronized (CmailConfig.class) {
                if (mCmailCenter == null) {
                    mCmailCenter = new CmailCenter(config);
                }
            }
        }
        return mCmailCenter;
    }


    public void login(final UserInfo userInfo, final List<String> mailAccList) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.getSupportMailDomain(null);
        }
        logger.debug(Constant.TAG, "login userInfo-> " + userInfo.toString());
        if (userInfo != null && !TextUtils.isEmpty(userInfo.getUserName()) && !TextUtils.isEmpty
                (userInfo.getUserId())) {
            String userId = userInfo.getUserId();
            CmailInfoSp.setUserId(userId);
            saveUserInforToSP(userInfo);
            database = CmailDatabase.getInstance(context);
            insertMailAccList(userInfo, mailAccList, true, Constant.ACCOUNTTYPE_FROM_COCO);
            if (TextUtils.isEmpty(userId)) {
                logger.debug(Constant.TAG, "  login -> userId is empty");
            }
            SandBox.getInstance().setUserName(userId);
        }
        if (mailAccList != null && mailAccList.size() > 0) {
            retrofit.getMailBoxMap(mailAccList.get(0), new NetCallBack<BaseRes>() {
                @Override
                public void onSuccess(BaseRes response) {
                    getBindedMailListRequest(userInfo, mailAccList);
                }

                @Override
                public void onFail(BaseRes response) {
                    getBindedMailListRequest(userInfo, mailAccList);
                    HelperSynLazyTask synLazyTask = getHelperByClass(HelperSynLazyTask.class);
                    if (synLazyTask != null) {
                        synLazyTask.onStart();
                        synLazyTask.startLoop();
                    }
                }

                @Override
                public void onError() {
                    getBindedMailListRequest(userInfo, mailAccList);

                }
            });
        } else {
            getBindedMailListRequest(userInfo, mailAccList);
        }


        plugins = new HashSet<>();
        addPlugin(new HelperCmailAccount());
        addPlugin(new HelperCmailBox());
        addPlugin(new HelperCmailMailList());
        addPlugin(new HelperCmailMailDetail());
        addPlugin(new HelperCmailMailOperate());
        addPlugin(new HelperCmailFile());
        addPlugin(new HelperSynLazyTask());
        for (IHelper plugin : plugins) {
            plugin.init(context, retrofit, database, executor, logger, sandbox);
//     todo      最终都上报 waltz pluginListener.onInit(plugin);
        }

    }

    private void getBindedMailListRequest(final UserInfo userInfo, final List<String> mailAccList) {
        retrofit.getBindedMailList(new NetCallBack<BaseRes<List<String>>>() {
            @Override
            public void onSuccess(final BaseRes<List<String>> response) {
                if (response.result.size() > 0) {
                    for (String account : response.result) {
                        logger.debug(Constant.TAG, "  账号 前 response.result" + account);
                    }

                    for (String account : mailAccList) {
                        logger.debug(Constant.TAG, "  账号 前 mailAccList" + account);
                    }
                    response.result.removeAll(mailAccList);
                    for (String account : response.result) {
                        logger.debug(Constant.TAG, "  账号  response.result.removeAll 后" + account);
                    }

                    insertMailAccList(userInfo, response.result, false, Constant
                            .ACCOUNTTYPE_NOT_FROM_COCO);

                    //比较List删除数据库多余的账号
                    final List<String> finalAccountList = new ArrayList<>();
                    finalAccountList.addAll(response.result);
                    finalAccountList.addAll(mailAccList);

                    executor.execute(new Runnable() {
                        @Override
                        public void run() {
                            MailAccountHelper mailAccountHelper = MailAccountHelper.getInstance();
                            List<String> dbMailAccList = mailAccountHelper
                                    .getMailListByUserId
                                            (userInfo.getUserId());
                            for (String dbMailAcc : dbMailAccList) {
                                boolean iscontains = false;
                                for (String currentAcc : finalAccountList) {
                                    if (TextUtils.equals(dbMailAcc, currentAcc)) {
                                        iscontains = true;
                                    }
                                }
                                if (!iscontains) {
                                    MailAccount queryAccount = mailAccountHelper.getMailAccount
                                            (dbMailAcc);
                                    mailAccountHelper.deleteMailAccount(queryAccount);
                                }
                            }


                        }
                    });
                }


            }

            @Override
            public void onFail(BaseRes<List<String>> response) {
            }

            @Override
            public void onError() {

            }
        });
    }

    private HashSet<IHelper> plugins;

    private HashSet<IHelper> addPlugin(IHelper helper) {
        if (helper == null) {
            plugins = new HashSet<>();
        }
        String tag = helper.getTag();
        for (IHelper exist : plugins) {
            if (tag.equals(exist.getTag())) {
                throw new RuntimeException(String.format("plugin with tag %s is already exist",
                        tag));
            }
        }
        plugins.add(helper);
        return plugins;
    }

    public <T extends IHelper> T getHelperByClass(Class<T> pluginClass) {
        if (plugins == null) {
            return null;
        }
        String className = pluginClass.getName();
        for (IHelper plugin : plugins) {
            if (plugin.getClass().getName().equals(className)) {
                return (T) plugin;
            }
        }
        return null;
    }


    public void insertMailAccList(final UserInfo userInfo, final List<String> mailAccList,
                                  final boolean isMaster, final int acountType) {

        executor.execute(new Runnable() {
            @Override
            public void run() {
                List<String> dbMailAccList = MailAccountHelper.getInstance().getMailListByUserId
                        (userInfo.getUserId());
                if (mailAccList != null && mailAccList.size() > 0) {
                    for (final String setMail : mailAccList) {
                        logger.debug(Constant.TAG, "  账号  dbMailAccList 开始检查包含" + setMail);

                        sandbox.getSanboxPassword(setMail, new com.cmft.android.sandbox
                                .crypter
                                .CallBack<String>() {

                            @Override
                            public void onSuccess(String password) {
                                if (!TextUtils.isEmpty(password)) {
                                    Log.d("账号", "邮件" + setMail + "password" + password);
                                    if (accountPasswordMap.containsKey(setMail)) {
                                        accountPasswordMap.remove(setMail);
                                    }
                                    accountPasswordMap.put(setMail, password);
                                }
                            }

                            @Override
                            public void onFail(String s) {

                            }
                        });

                        boolean isContains = false;
                        for (String dbmail :
                                dbMailAccList) {
                            if (TextUtils.equals(dbmail, setMail)) {
                                isContains = true;
                            }
                        }

                        if (!isContains) {
                            logger.debug(Constant.TAG, "  账号  dbMailAccList 包含" + setMail);
                            MailAccount mailAccountBean = new MailAccount();
                            mailAccountBean.setMasterAccount(isMaster);
                            mailAccountBean.setUserId(userInfo.getUserId());
                            mailAccountBean.setMailAccount(setMail);
                            mailAccountBean.setAccountState(Constant.ACCOUNTSTATUE_UNACTIVE);
                            mailAccountBean.setAccountType(acountType);
                            //company
                            mailAccountBean = CmailUtils.setCompany(mailAccountBean);
                            mailAccountBean.setMailSign(DEFAULT_SIGN);
                            logger.debug(Constant.TAG, "MailAccount insert to db" +
                                    mailAccountBean.toString());
                            MailAccountHelper.getInstance().insertMailAccount(mailAccountBean);


                        }
                    }
                } else {
                    for (final String setMail : mailAccList) {
                        logger.debug(Constant.TAG, "  账号  dbMailAccList 包含" + setMail);

                    }
                }
            }
        });
    }


    public void setCurrentMailAccount(String currentMailAccount) {
        CmailInfoSp.setLoginMailAccount(currentMailAccount);
    }


    public void supportMailDomain(String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.getSupportMailDomain(option);
        }
    }

    public void WPScheckVersion() {
        SandBox.getInstance().checkVersion();
    }


    public void getUserInfo(final String option) {
        try {
            JSONObject body = new JSONObject();
            body.put(CODE, 0);
            body.put(MESSAGE, "success");
            body.put(RESULT, CmailInfoSp.getUserInfo());
            CallJsUtils.callJs(body, option);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(Constant.TAG, "报错-> " + e.toString());
        }
    }


    public void mailSearch(List<SearchBean.FetchListBean> mailList, int searchType, int mode,
                           String searchText, String option) {
        HelperCmailMailList helperMailList = getHelperByClass(HelperCmailMailList.class);
        if (helperMailList != null) {
            helperMailList.mailSearch(mailList, searchType, mode, searchText, option);
        }
    }


    public void mailFilter(List<GetMailDataBean> list, int fetchType, int filterType, int mode,
                           String option) {
        HelperCmailMailList helperMailList = getHelperByClass(HelperCmailMailList.class);
        if (helperMailList != null) {
            helperMailList.mailFilter(list, fetchType, filterType, mode, option);
        }
    }


    public void getMailHeader(List<GetMailDataBean> list, String option, int fetchType, int
            filterType, int searchType, String searchText, int mode, boolean isRefresh) {
        HelperCmailMailList helperMailList = getHelperByClass(HelperCmailMailList.class);
        if (helperMailList != null) {
            helperMailList.getMailHeader(list, option, fetchType, filterType, searchType,
                    searchText, mode, isRefresh);
        }
    }

    public void recentContacts(String keyword, int limit, String option) {
        HelperCmailMailDetail helperMailDetail = getHelperByClass(HelperCmailMailDetail.class);
        if (helperMailDetail != null) {
            helperMailDetail.recentContacts(keyword, limit, option);
        }
    }

    public void mailSend(String email, JSONObject jsonObject, String option) {
        HelperCmailMailDetail helperMailDetail = getHelperByClass(HelperCmailMailDetail.class);
        if (helperMailDetail != null) {
            helperMailDetail.mailSend(email, jsonObject, option);
        }
    }

    public void saveMailContent(String email, String folderName, long uid,
                                NetCallBack<BaseRes<MailContentRes>> callBack) {
        HelperCmailMailDetail helperMailDetail = getHelperByClass(HelperCmailMailDetail.class);
        if (helperMailDetail != null) {
            helperMailDetail.saveMailContent(email, folderName, uid, callBack);
        }
    }

    public void sandboxDecrypt(String path, final CallBack<String> callBack) {
        HelperCmailMailDetail helperMailDetail = getHelperByClass(HelperCmailMailDetail.class);
        String content = "";
        if (helperMailDetail != null) {
            helperMailDetail.sandboxDecrypt(path, new CallBack<String>() {
                @Override
                public void onSuccess(String content) {
                    callBack.onSuccess(content);
                }

                @Override
                public void onFail(String string) {
                    callBack.onFail(string);
                }
            });
        }
    }


    public void getMailContent(String mailAccount, String folderName, long uid,
                               CallBack<MailDetail> callback) {
        HelperCmailMailDetail helperMailDetail = getHelperByClass(HelperCmailMailDetail.class);
        if (helperMailDetail != null) {
            helperMailDetail.getMailContent(mailAccount, folderName, uid, callback);
        }
    }

    public void saveMailToDrafts(TobeSend tobeSend, String writeUrl, String option) {
        HelperCmailMailDetail helperMailDetail = getHelperByClass(HelperCmailMailDetail.class);
        if (helperMailDetail != null) {
            helperMailDetail.saveMailToDrafts(tobeSend, writeUrl, option);
        }
    }

    public void getMailBodyFromSandBox(final String email, final String boxName, final long mailUid,
                                       final CallBack<String> callBack) {
        HelperCmailMailDetail helperMailDetail = getHelperByClass(HelperCmailMailDetail.class);
        if (helperMailDetail != null) {
            helperMailDetail.getMailBodyFromSandBox(email, boxName, mailUid, new CallBack<String>
                    () {

                @Override
                public void onSuccess(String content) {
                    if (TextUtils.isEmpty(content)) {
                        getMailBodyFromSandBox(email, boxName, mailUid, callBack);
                    } else {
                        callBack.onSuccess(content);
                    }
                }

                @Override
                public void onFail(String string) {
                    logger.error(Constant.TAG, "报错-> " + string);
                    callBack.onFail(string);
                }
            });
        }

    }

    public String getContentURL(String email, String boxName, String mailUid) {
        HelperCmailMailDetail helperMailDetail = getHelperByClass(HelperCmailMailDetail.class);
        String url = "";
        if (helperMailDetail != null) {
            url = helperMailDetail.getContentURL(email, boxName, mailUid);
        }
        return url;
    }


    public String getWriteContentUrl(String email, long mailUid) {
        HelperCmailMailDetail helperMailDetail = getHelperByClass(HelperCmailMailDetail.class);
        String url = "";
        if (helperMailDetail != null) {
            url = helperMailDetail.getWriteContentUrl(email, mailUid);
        }
        return url;
    }

    public void addIdiomList(List<MailPhrases> list, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.addIdiomList(list, option);
        }
    }

    public void addIdiomList(String data, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.addIdiomList(data, option);
        }
    }

    public void setMailSignature(String mailAccount, String signature, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.setMailSignature(mailAccount, signature, option);
        }
    }


    public void setMainMailAccount(String mainAccount, boolean masterAccount, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.setMainMailAccount(mainAccount, masterAccount, option);
        }
    }

    public void getIdiomList(String data, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.getIdiomList(data, option);
        }
    }

    public void getMailSignList(String data, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.getMailSignList(data, option);
        }
    }

    public void deleteIdiomList(String idiom, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.deleteIdiomList(idiom, option);
        }
    }

    public void bindAccountToServer(String mailAccount, String password, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.bindAccountToServer(mailAccount, password, option);
        }


    }

    public void unbindAccountToServer(String mailAccount, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.unbindAccountToServer(mailAccount, option);
        }
    }

    public void freezeMail(String mail, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.freezeMail(mail, option);
        }
    }

    public void getMailAccountList(String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.getMailAccountList(option);
        }

    }

    public void unFreezeMail(String mail, String option) {
        HelperCmailAccount helperAccount = getHelperByClass(HelperCmailAccount.class);
        if (helperAccount != null) {
            helperAccount.unFreezeMail(mail, option);
        }
    }

    public void modifyMailStatus(String email, String boxName, int mode, List<Long> uidList,
                                 String option) {
        HelperCmailMailOperate helperMailOperate = getHelperByClass(HelperCmailMailOperate.class);
        if (helperMailOperate != null) {
            helperMailOperate.modifyMailStatus(email, boxName, mode, uidList, option);
        }
    }

    public void modifyMailStatus(Map<String, Map<String, List<Long>>> map, int mode, String
            option) {
        HelperCmailMailOperate helperMailOperate = getHelperByClass(HelperCmailMailOperate.class);
        if (helperMailOperate != null) {
            helperMailOperate.modifyMailStatus(map, mode, option);
        }
    }

    public void moveMail(String mailAccount, String sourceBoxName, String targetBixName,
                         List<Long> uidList, String option) {
        HelperCmailMailOperate helperMailOperate = getHelperByClass(HelperCmailMailOperate.class);
        if (helperMailOperate != null) {
            helperMailOperate.moveMail(mailAccount, sourceBoxName, targetBixName, uidList, option);
        }
    }

    public void deleteMail(String mailAccount, String boxName, List<Long> uidList, String option) {
        HelperCmailMailOperate helperMailOperate = getHelperByClass(HelperCmailMailOperate.class);
        if (helperMailOperate != null) {
            helperMailOperate.deleteMail(mailAccount, boxName, uidList, option);
        }
    }


    public void getMailBox(List<String> mailList, String mail, String option) {
        HelperCmailBox helperBox = getHelperByClass(HelperCmailBox.class);
        if (helperBox != null) {
            helperBox.getMailBox(mailList, mail, option);
        }
    }

    public void getMailBox(String email) {
        HelperCmailBox helperBox = getHelperByClass(HelperCmailBox.class);
        if (helperBox != null) {
            helperBox.getMailBox(email, new CallBack() {
                @Override
                public void onSuccess(Object response) {
                    HelperSynLazyTask synLazyTask = getHelperByClass
                            (HelperSynLazyTask.class);
                    if (synLazyTask != null) {
                        synLazyTask.startLoop();
                    }
                }

                @Override
                public void onFail(String string) {

                }
            });
        }
    }

    public void openSendAttachment(String mailAccount, String fileName, String filePath, String
            option) {
        HelperCmailFile helperFile = getHelperByClass(HelperCmailFile.class);
        if (helperFile != null) {
            helperFile.openSendAttachment(mailAccount, fileName, filePath, option);
        }
    }

    public boolean deleteAttachment(String mailAccount, String fileName, String option) {
        HelperCmailFile helperFile = getHelperByClass(HelperCmailFile.class);
        boolean result;
        if (helperFile != null) {
            result = helperFile.deleteAttachment(mailAccount, fileName, option);
        } else {
            result = false;
        }
        return result;
    }

    public void addAttachment(String mailAccount, int type, String option, String attachmentPath) {
        HelperCmailFile helperFile = getHelperByClass(HelperCmailFile.class);
        if (helperFile != null) {
            helperFile.addAttachment(mailAccount, type, option, attachmentPath);
        }
    }

    public void deleteUploadFile(String mailAccount, JSONObject mailBody, JSONArray
            appendAttachment, String option) {
        HelperCmailFile helperFile = getHelperByClass(HelperCmailFile.class);
        if (helperFile != null) {
            helperFile.deleteUploadFile(mailAccount, mailBody, appendAttachment, option);
        }
    }

    public void openAttachment(String path, String option) {
        HelperCmailFile helperFile = getHelperByClass(HelperCmailFile.class);
        if (helperFile != null) {
            helperFile.openAttachment(path, option);
        }
    }

    public void saveAndOpenAttachment(String email, String boxName, int uid, int attachmentIndex,
                                      String fileName, String option) {
        HelperCmailFile helperFile = getHelperByClass(HelperCmailFile.class);
        if (helperFile != null) {
            helperFile.saveAndOpenAttachment(email, boxName, uid, attachmentIndex, fileName,
                    option);
        }
    }

    public void readAttachment(String sandBoxPath) {
        HelperCmailFile helperFile = getHelperByClass(HelperCmailFile.class);
        if (helperFile != null) {
            helperFile.readAttachment(sandBoxPath);
        }
    }


    public void modifyFolderStatus(String email, String boxName, int mode, String option) {
        HelperCmailBox helperBox = getHelperByClass(HelperCmailBox.class);
        if (helperBox != null) {
            helperBox.modifyFolderStatus(email, boxName, mode, option);
        }
    }

    public void deleteFolder(String mail, String boxName, String option) {
        HelperCmailBox helperBox = getHelperByClass(HelperCmailBox.class);
        if (helperBox != null) {
            helperBox.deleteFolder(mail, boxName, option);
        }
    }


    public void clearFolder(String mail, String boxName, String option) {
        HelperCmailBox helperBox = getHelperByClass(HelperCmailBox.class);
        if (helperBox != null) {
            helperBox.clearFolder(mail, boxName, option);
        }
    }


}