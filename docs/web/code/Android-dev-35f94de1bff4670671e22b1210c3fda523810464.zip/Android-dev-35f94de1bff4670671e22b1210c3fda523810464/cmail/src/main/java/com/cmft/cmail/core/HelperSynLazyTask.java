package com.cmft.cmail.core;


import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.cmft.android.sandbox.crypter.utils.EncryptData;
import com.cmft.cmail.NetCallBack;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailAccountDao;
import com.cmft.cmail.db.dao.MailFolderDao;
import com.cmft.cmail.db.dao.MailHeaderDao;
import com.cmft.cmail.db.model.MailAccount;
import com.cmft.cmail.db.model.MailFolder;
import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.db.model.SYNModel;
import com.cmft.cmail.utils.CmailInfoSp;
import com.cmft.cmail.utils.CmailUtils;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.web.RetrofitService;
import com.cmft.cmail.web.resBean.BaseRes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

import static com.cmft.cmail.utils.Constant.MAILHEADER_BEFORE_MODE;

public class HelperSynLazyTask extends HelperCmail implements LazyScheduler.ILazyTask {

    private int LIST_ININTED = 0;
    private int HAS_NEWMAIL = 1;
    private int NO_NEWMAIL = 2;
    private int SAVE_NEWMAIL = 3;
    private int SYN_OLDMAIL = 4;
    private int SAVE_OLDMAIL = 5;
    private int FINISH_OLDMAIL = 6;


    private static final String TAG = Constant.TAG + "." + "SynTask";
    private LazyScheduler mLazyScheduler;
    private List<SYNModel> synDataList;
    public static List<String> synAccountList;
    Handler mHandler = new Handler() {

        //handleMessage为处理消息的方法
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            try {
                if (msg.what == LIST_ININTED) {
                    if (synDataList != null) {
                        getLogger().debug(TAG, "开始同步后台数据 0 账号准备: " +
                                "synDataList: " +
                                synDataList.toString());
                        checkNEWMailList();
                    }
                } else if (msg.what == HAS_NEWMAIL) {
                    if (msg.obj != null) {
                        SYNModel synModel = (SYNModel) msg.obj;
                        //更新新邮件
                        getLogger().debug(TAG, "开始同步后台数据 更新最新邮件头 的 " +
                                "synModel: " +
                                synModel.toString());
                        getMailHeadRequest(synModel, Constant.MAILHEADER_AFTER_MODE);
                    }
                } else if (msg.what == NO_NEWMAIL) {
                            //删除account所有的请求
                    if (msg.obj != null) {
                        SYNModel synModel = (SYNModel) msg.obj;

                        if (synModel.getMode() < 0) {
                            //如果是之前请求不成功 不继续请求该account
                            String account = synModel.getAccount();
                            getLogger().debug(TAG, "开始同步后台数据  网络请求失败  删除account " +
                                    "account: " +
                                    account);
                            if (synDataList != null && synDataList.size() > 0) {
                                synchronized (synDataList) {
                                    Iterator<SYNModel> it = synDataList.iterator();
                                    while (it.hasNext()) {
                                        SYNModel model = it.next();
                                        if (TextUtils.equals(model.getAccount(), account)) {
                                            it.remove();
                                        }
                                    }
                                }
                                checkNEWMailList();
                            }

                        } else {
                            // 删除后重新拉synmode
                            if (synModel != null) {
                                deleteSynModel(synModel);
                            }
                            //直接拉新历史数据
                            checkOldList();
                        }

                    }

                } else if (msg.what == SAVE_NEWMAIL) {
                    if (msg.obj != null) {
                        SYNModel synModel = (SYNModel) msg.obj;
                        deleteSynModel(synModel);
                    }
                    checkNEWMailList();
                } else if (msg.what == SYN_OLDMAIL) {
                    if (msg.obj != null) {
                        SYNModel synModel = (SYNModel) msg.obj;
                        if (synModel.getMode() == MAILHEADER_BEFORE_MODE) {
                            getMailHeadRequest(synModel, MAILHEADER_BEFORE_MODE);
                        } else if (synModel.getMode() == Constant.MAILHEADER_START_MODE) {
                            getMailHeadRequest(synModel, Constant.MAILHEADER_START_MODE);
                        }
                    }
                } else if (msg.what == SAVE_OLDMAIL) {
                    if (msg.obj != null) {
                        final SYNModel synModel = (SYNModel) msg.obj;
                        getLogger().debug(TAG, "开始同步后台数据  SAVE_OLDMAIL synModel " + synModel
                                .toString
                                        ());


                        getExecutor().execute(new Runnable() {
                            @Override
                            public void run() {
                                int index = -1;
                                if (synDataList != null && synDataList.size() > 0) {
                                    synchronized (synDataList) {
                                        for (int i = 0; i < synDataList.size(); i++) {

                                            SYNModel model = synDataList.get(i);

                                            getLogger().debug(TAG, "开始同步后台数据  SAVE_OLDMAIL " +
                                                    "synDataList  model " + model
                                                    .toString
                                                            ());

                                            if (TextUtils.equals(synModel.getAccount(), model
                                                    .getAccount

                                                    ()) &&
                                                    TextUtils.equals(synModel.getBoxName(), model
                                                            .getBoxName())
                                                    && (synModel.getMode() == model.getMode())) {
                                                getLogger().debug(TAG, "开始同步后台数据  SAVE_OLDMAIL " +
                                                        "synDataList  index " + index);
                                                index = i;
                                                break;
                                            }
                                        }
                                    }
                                }

                                //修改minuid
                                //再请求



                                if (index >= 0) {
                                    if (synModel.getMode() == Constant.MAILHEADER_UNCHECK_MODE) {
//                                        String account = synModel.getAccount();
                                        synDataList.remove(index);
                                    } else {
//                                    getLogger().debug(TAG, "开始同步后台数据 检查历史邮件 完成后 修改前 list " +
//                                            "currentmodel" +
//                                            " " +
//                                            "listIndex: " + index + " synModel: " + synModel
//                                            .toString
//                                                    ());

                                        MailHeaderDao mailHeaderDao = getDatabase()
                                                .getMailHeaderDao();
                                        List<MailHeader> mailHeaderList = mailHeaderDao
                                                .queryMailHeaders
                                                        (synModel.getAccount(), synModel
                                                                .getBoxName());
                                        if (mailHeaderList != null && mailHeaderList
                                                .size() > 0) {
//                                long maxuid = mailHeaderList.get(0).getUid();
                                            long minuid = mailHeaderList.get
                                                    (mailHeaderList.size()
                                                            - 1)
                                                    .getUid();
                                            synModel.setMinuid(minuid);
                                            synModel.setMode(Constant.MAILHEADER_BEFORE_MODE);
                                            getLogger().debug(TAG, "开始同步后台数据 检查历史邮件 完成后 修改后 " +
                                                    "minuid " +
                                                    "currentmodel " +
                                                    " newModel: " + synModel.toString
                                                    ());
                                            if (synDataList.size() > 0) {
                                                synDataList.remove(index);
                                            }else {

                                            }
                                            synDataList.add(index, synModel);
                                        }
                                    }
                                    checkOldList();
                                }else {
//                                    synAccountList.add(synAccount);
//                                    getLogger().debug(TAG, "开始同步后台数据 检查旧邮件 currentModel 完成  2");

                                }
                            }
                        });


                    }
                } else if (msg.what == FINISH_OLDMAIL) {
                    if (msg.obj != null) {
                        SYNModel synModel = (SYNModel) msg.obj;
                        if (synModel.getMode() < 0) {
                            //如果是之前请求不成功 不继续请求该account
                            String account = synModel.getAccount();
                            getLogger().debug(TAG, "开始同步后台数据 2 网络请求失败  删除account " +
                                    "account: " +
                                    account);
                            if (synDataList != null && synDataList.size() > 0) {
                                synchronized (synDataList) {
                                    Iterator<SYNModel> it = synDataList.iterator();
                                    while (it.hasNext()) {
                                        SYNModel model = it.next();
                                        if (TextUtils.equals(model.getAccount(), account)) {
                                            it.remove();
                                        }
                                    }
                                }
                                getLogger().debug(TAG, "开始同步后台数据 2 网络请求失败 删除前 NO_OLDMAIL: " +
                                        "synDataList: " +
                                        synDataList.toString());
                            }

                        } else {
                            //删除后重新拉synmode
                            deleteSynModel(synModel);
                        }

                        //直接拉新历史数据
                        checkOldList();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                getLogger().error(TAG, "报错-> " + e.toString());
            }
        }

    };
    private String synAccount;

    private void deleteSynModel(SYNModel synModel) {

        try {
            if (synDataList != null && synDataList.size() > 0) {
                synchronized (synDataList) {
                    Iterator<SYNModel> it = synDataList.iterator();
                    while (it.hasNext()) {
                        SYNModel model = it.next();
                        if (model != null && model.getAccount() != null && TextUtils.equals(synModel
                                .getAccount(), model.getAccount()) &&
                                TextUtils.equals(synModel.getBoxName(), model.getBoxName())
                                && (synModel.getMode() == model.getMode())) {
                            getLogger().debug(TAG, "开始同步后台数据  完成后删除: " +
                                    "synModel: " +
                                    synModel.toString());
                            it.remove();
                        }
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            getLogger().error(TAG, "报错-> " + e.toString());

        }

    }


    @Override
    public synchronized void init(Context context, RetrofitService retrofit, CmailDatabase
            database, ThreadPoolExecutor executor, ILogger logger, HelperSandbox sandbox) {
        super.init(context, retrofit, database, executor, logger, sandbox);
        mLazyScheduler = new LazyScheduler(CmailHandlerThread.getDefaultHandlerThread(), Constant
                .LOOP_REQUEST);
        onStart();
        startLoop();
    }


    @Override
    public void onLoop() {
        startLoop();
    }

    private void getMailHeadRequest(final SYNModel model, final int type) {
        final String account = model.getAccount();
        this.synAccount= account;
        final String boxName = model.getBoxName();
        long uid = 0;
        int mode = 0;
        if (type == Constant.MAILHEADER_AFTER_MODE) {
            uid = model.getMaxUid();
            mode = Constant.MAILHEADER_AFTER_MODE;
        } else if (type == MAILHEADER_BEFORE_MODE) {
            uid = model.getMinuid();
            mode = type;
        } else if (type == Constant.MAILHEADER_START_MODE) {
            uid = model.getMinuid();
            mode = type;
        }

        getLogger().debug(TAG, "开始同步后台数据 获取邮件头 请求 account: " + account + " boxName: " + boxName +
                " uid:" + uid);

        getRetrofit().simpleGetHeaders(account, boxName,
                uid, Constant.SYN_SIZE, mode, new
                        NetCallBack<BaseRes<List<MailHeader>>>() {


                            @Override
                            public void onSuccess
                                    (final BaseRes<List<MailHeader>>
                                             baseRes) {
                                getExecutor().execute(new Runnable() {
                                    @Override
                                    public void run() {

                                        //修改maxuid
                                        if (baseRes.result != null && baseRes.result.size() > 0) {
                                            //插入mailAccount和boxName
                                            for (MailHeader mailHeader : baseRes.result) {
                                                mailHeader.setMailAccount(account);
                                                mailHeader.setBoxName(boxName);
                                                mailHeader.setMailTime(mailHeader.getTimestamp());
                                                mailHeader.setId(EncryptData.MD5_32(mailHeader
                                                        .getUid() +
                                                        mailHeader.getBoxName()
                                                        +
                                                        mailHeader.getMailAccount()));
                                                mailHeader.setReceiverMap(CmailUtils
                                                        .convertReciversListToMap(mailHeader
                                                                .getReceiver()));
                                                mailHeader.setReceiverBCCMap(CmailUtils
                                                        .convertReciversListToMap(mailHeader
                                                                .getReceiverBCC()));
                                                mailHeader.setReceiverCCMap(CmailUtils
                                                        .convertReciversListToMap(mailHeader
                                                                .getReceiverCC()));

                                            }
                                            getDatabase().getMailHeaderDao().insertMailHeaders
                                                    (baseRes
                                                            .result);
                                            if (type == Constant.MAILHEADER_AFTER_MODE) {
                                                Message message = new Message();
                                                message.what = SAVE_NEWMAIL;
                                                message.obj = model;
                                                mHandler.sendMessage(message);
                                            } else if (type == MAILHEADER_BEFORE_MODE || type ==
                                                    Constant
                                                            .MAILHEADER_START_MODE) {
                                                Message message = new Message();
                                                message.what = SAVE_OLDMAIL;
                                                message.obj = model;
                                                mHandler.sendMessage(message);
                                            }
                                        } else {
                                            //停止循环
                                            if (type == MAILHEADER_BEFORE_MODE || type == Constant
                                                    .MAILHEADER_START_MODE) {
                                                Message message = new Message();
                                                message.what = SAVE_OLDMAIL;
                                                model.setMode(Constant.MAILHEADER_UNCHECK_MODE);
                                                message.obj = model;
                                                mHandler.sendMessage(message);
                                            }
                                        }
                                    }
                                });


                            }

                            @Override
                            public void onFail
                                    (BaseRes<List<MailHeader>>
                                             response) {

                            }

                            @Override
                            public void onError() {
                                getLogger().debug(TAG, "开始同步后台数据 获取邮件头 请求error");
                                Message message = new Message();
                                message.what = FINISH_OLDMAIL;
                                model.setMode(Constant.MAILHEADER_UNCHECK_MODE);
                                message.obj = model;
                                mHandler.sendMessage(message);
                            }
                        });
    }

    public void onStart() {
        mLazyScheduler.setUp(this, true);
    }

    public void onStop() {
        mLazyScheduler.cancel();
    }

    private void checkNEWMailList() {
        try {
            if (synDataList != null && synDataList.size() > 0) {
                //开始获取最新邮件
                SYNModel currentModel = null;
                synchronized (synDataList) {
                    Iterator<SYNModel> it = synDataList.iterator();
                    while (it.hasNext()) {
                        SYNModel synModel = it.next();
                        //最新的只拉inbox,如果maxuid为0就直接走回调
                        if (synModel.getMode() == Constant.MAILHEADER_AFTER_MODE) {
                            currentModel = synModel;
                            break;
                        }
                    }
                }
                if (currentModel != null) {
                    getLogger().debug(TAG, "开始同步后台数据 检查新邮件 currentModel " + currentModel.toString
                            ());
                    hasNewMailRequest(currentModel);
                } else {

                    getLogger().debug(TAG, "开始同步后台数据 检查新邮件 currentModel 完成 ");
                    checkOldList();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            getLogger().error(TAG, "报错-> " + e.toString());

        }

    }


    private void checkOldList() {

        try {
            if (synDataList != null && synDataList.size() > 0) {
                //开始历史邮件
                SYNModel currentModel = null;
                synchronized (synDataList) {
                    Iterator<SYNModel> it = synDataList.iterator();
                    while (it.hasNext()) {
                        SYNModel synModel = it.next();
                        //最新的只拉inbox,如果maxuid为0就直接走回调
                        if (synModel.getMode() == MAILHEADER_BEFORE_MODE || synModel.getMode()
                                == Constant.MAILHEADER_START_MODE) {
                            currentModel = synModel;
                            break;
                        }
                    }
                }

                if (currentModel != null) {
                    getLogger().debug(TAG, "开始同步后台数据 检查历史邮件 currentModel " + currentModel
                            .toString());
                    Message message = new Message();
                    message.what = SYN_OLDMAIL;
                    message.obj = currentModel;
                    mHandler.sendMessage(message);
                } else {
                    synDataList = null;
                    synAccountList.add(synAccount);
                    getLogger().debug(TAG, "开始同步后台数据 检查旧邮件 currentModel 完成 ");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            getLogger().error(TAG, "报错-> " + e.toString());

        }

    }

    private void hasNewMailRequest(final SYNModel synModel) {
        getRetrofit().hasNewMailRequest(synModel.getMaxUid(), synModel.getAccount(),
                synModel.getBoxName(), new NetCallBack<BaseRes<Boolean>>() {


                    @Override
                    public void onSuccess(BaseRes<Boolean> response) {
                        if (response.result) {
                            //有新邮件
                            getLogger().debug(TAG, "开始同步后台数据 1 检查新邮件 ：有新邮件" + synModel.toString());
                            Message message = new Message();
                            message.what = HAS_NEWMAIL;
                            message.obj = synModel;
                            mHandler.sendMessage(message);
                        } else {
                            getLogger().debug(TAG, "开始同步后台数据 1 检查新邮件 ：没有新邮件" + synModel.toString());
                            Message message = new Message();
                            message.what = NO_NEWMAIL;
                            message.obj = synModel;
                            mHandler.sendMessage(message);
                        }
                    }

                    @Override
                    public void onFail(BaseRes<Boolean> response) {
                    }

                    @Override
                    public void onError() {
                        getLogger().debug(TAG, "开始同步后台数据 1 检查新邮件 ：网络请求失败" + synModel.toString());
                        Message message = new Message();
                        message.what = NO_NEWMAIL;
                        synModel.setMode(Constant.MAILHEADER_UNCHECK_MODE);
                        message.obj = synModel;
                        mHandler.sendMessage(message);
                    }
                });
    }

    public void startLoop() {

        getLogger().debug(TAG, "开始同步后台数据 0");
        if (synDataList != null) {
            getLogger().debug(TAG, "开始同步后台数据 0" + synDataList.size());
        }

//        if (synDataList == null || synDataList.size() == 0) {
            synDataList = Collections.synchronizedList(new ArrayList<SYNModel>());

            getExecutor().execute(new Runnable() {
                @Override
                public void run() {
                    MailAccountDao mailAccountDao = getDatabase().getMailAccountDao();
                    MailFolderDao mailFolderDao = getDatabase().getMailFolderDao();
                    MailHeaderDao mailHeaderDao = getDatabase().getMailHeaderDao();
                    String userId = CmailInfoSp.getUserId();
                    if (TextUtils.isEmpty(userId)) {
                        return;
                    }
                    //账号和文件夹缓存
                    List<MailAccount> accountList = mailAccountDao.queryUserAll(userId);
                    if (accountList != null && accountList.size() > 0) {
                        for (MailAccount account : accountList) {
                            if (account.getAccountState() == Constant
                                    .ACCOUNTSTATUE_ACTIVE) {

                                //账号
                                String accountName = account.getMailAccount();

                                getLogger().debug(TAG, "开始同步后台数据 0 账号准备: " +
                                        "激活 account: " +
                                        accountName);

                                List<MailFolder> mailFolderList = mailFolderDao
                                        .queryByMailAccount
                                                (account.getMailAccount());
                                if (mailFolderList != null && mailFolderList.size() >
                                        0) {
                                    for (MailFolder mailFolder : mailFolderList) {
                                        //boxName
                                        String boxName = mailFolder.getFolderKey();


                                        getLogger().debug(TAG, "开始同步后台数据 0 账号准备: " +
                                                "文件夹 boxName: " +
                                                boxName);


                                        if (TextUtils.equals(boxName, Constant.TobeSent)) {
                                            continue;
                                        }
                                        List<MailHeader> mailHeaderList = mailHeaderDao
                                                .queryMailHeaders
                                                        (accountName, boxName);
                                        long minUid;
                                        long maxUid;
                                        if (mailHeaderList != null && mailHeaderList
                                                .size() > 0) {
                                            maxUid = mailHeaderList.get(0).getUid();
                                            minUid = mailHeaderList.get
                                                    (mailHeaderList.size() - 1)
                                                    .getUid();

                                        } else {
                                            minUid = 0;
                                            maxUid = 0;
                                        }
                                        SYNModel historyModel = new SYNModel(accountName,
                                                boxName,
                                                maxUid, minUid,
                                                false);
                                        if (minUid == 0) {
                                            historyModel.setMode(Constant.MAILHEADER_START_MODE);
                                        } else {
                                            historyModel.setMode(MAILHEADER_BEFORE_MODE);
                                        }

                                        //如果同步过的就不查询历史
                                        boolean shouldIgnore = false;
                                        if (synAccountList != null && synAccountList.size() > 0) {
                                            synchronized (synAccountList) {
                                                for (String ignoreAccount : synAccountList) {
                                                    if (TextUtils.equals(ignoreAccount, historyModel
                                                            .getAccount())) {
                                                        shouldIgnore = true;
                                                    }
                                                }
                                            }
                                        }

                                        if (!shouldIgnore) {
                                            synDataList.add(historyModel);
                                        }
                                        //如果是inbox提前更新
                                        if (TextUtils.equals(boxName, Constant.INBOX)) {
                                            SYNModel newModel = new SYNModel(historyModel
                                                    .getAccount(), historyModel.getBoxName(),
                                                    historyModel.getMaxUid(), historyModel
                                                    .getMinuid(), false);
                                            if (maxUid == 0) {
                                                newModel.setMode(Constant
                                                        .MAILHEADER_START_MODE);
                                            } else {
                                                newModel.setMode(Constant
                                                        .MAILHEADER_AFTER_MODE);
                                            }
                                            synDataList.add(0, newModel);
                                        }
                                    }
                                }
                                if (synAccountList == null) {
                                    synAccountList = Collections.synchronizedList(new
                                            ArrayList<String>());
                                }

                            }
                        }

                        try {
                            if (HelperSynLazyTask.synAccountList != null) {
                                synchronized (synAccountList) {
                                    for (String ignoreAccount :
                                            HelperSynLazyTask.synAccountList) {
                                        getLogger().debug(TAG, " unbindAccountToServer startLoop " +
                                                "HelperSynLazyTask" +
                                                ".synAccountList  ignoreAccount: " + ignoreAccount);

                                    }
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            getLogger().error(TAG, "报错-> " + e.toString());

                        }


                    }
                    //准备成功
                    Message message = new Message();
                    message.what = LIST_ININTED;
                    mHandler.sendMessage(message);

                }
            });

//        } else {
//            //准备成功
//            Message message = new Message();
//            message.what = LIST_ININTED;
//            mHandler.sendMessage(message);
//        }

    }


    @Override
    public String getTag() {
        return HelperSynLazyTask.TAG;
    }
}
