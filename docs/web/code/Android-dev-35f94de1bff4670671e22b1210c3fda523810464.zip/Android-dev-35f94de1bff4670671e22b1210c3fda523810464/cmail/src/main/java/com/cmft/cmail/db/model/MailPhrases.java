package com.cmft.cmail.db.model;


import android.support.annotation.NonNull;
import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;

/**
 * 邮件惯有语
 */
@Entity
        (tableName = "phrases_info", indices = {@Index(value = {"content"},
                unique = true)})
//        foreignKeys = {@ForeignKey(entity = MailAccount.class,
//                parentColumns = "mailAccount", childColumns = "mailAccount",
//                onDelete = ForeignKey.CASCADE, onUpdate = ForeignKey.CASCADE)})
public class MailPhrases {

    @PrimaryKey(autoGenerate = true)
    public long id;

    @ColumnInfo
    public String content;

//    @ColumnInfo(index = true)
//    @NonNull
//    public String mailAccount;

//    @Ignore
//    public MailPhrases(String content, String mailAccount) {
//        this.content = content;
//        this.mailAccount = mailAccount;
//    }

    @Ignore
    public MailPhrases(String content) {
        this.content = content;
    }

    public MailPhrases() {
    }

//    @Override
//    public String toString() {
//        return "MailPhrases{" +
//                "content='" + content + '\'' +
//                ", mailAccount='" + mailAccount + '\'' +
//                '}';
//    }
}
