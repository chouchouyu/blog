package com.cmft.cmail.web.resBean;

public class BaseRes<T> {
    public int code;
    public String message;
    public T result;
}
