package com.cmft.cmail.db.model;

public class ModifyMailBean {


    /**
     * mailAccount : wusm@cmft.com
     * uid : 10
     * state : false
     * boxName : 已删除邮件
     */

    private String mailAccount;
    private long uid;
    private boolean state;
    private String boxName;

    public String getMailAccount() {
        return mailAccount;
    }

    public void setMailAccount(String mailAccount) {
        this.mailAccount = mailAccount;
    }

    public long getUid() {
        return uid;
    }

    public void setUid(long uid) {
        this.uid = uid;
    }

    public boolean isState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public String getBoxName() {
        return boxName;
    }

    public void setBoxName(String boxName) {
        this.boxName = boxName;
    }
}
