package com.cmft.cmail.db.model;

public class CompanyModel {
    public String key;
    public String value;
}
