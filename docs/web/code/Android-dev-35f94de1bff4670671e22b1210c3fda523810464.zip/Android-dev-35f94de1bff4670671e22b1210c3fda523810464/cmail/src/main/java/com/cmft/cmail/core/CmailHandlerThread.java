package com.cmft.cmail.core;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;

import com.cmft.cmail.utils.Constant;

import java.util.HashSet;
import java.util.Iterator;

/**
 * Created by zhangshaowen on 17/7/5.
 */

public class CmailHandlerThread {
    private static final String TAG = Constant.TAG + ".HandlerThread";

    public static final String Cmail_THREAD_NAME = "default_Cmail_thread";

    /**
     * unite defaultHandlerThread for lightweight work,
     * if you have heavy work checking, you can create a new thread
     */
    private static volatile HandlerThread defaultHandlerThread;
    private static volatile Handler defaultHandler;
    private static volatile Handler defaultMainHandler = new Handler(Looper.getMainLooper());
    private static HashSet<HandlerThread> handlerThreads = new HashSet<>();

    public static Handler getDefaultMainHandler() {
        return defaultMainHandler;
    }

    public static HandlerThread getDefaultHandlerThread() {

        synchronized (CmailHandlerThread.class) {
            if (null == defaultHandlerThread) {
                defaultHandlerThread = new HandlerThread(Cmail_THREAD_NAME);
                defaultHandlerThread.start();
                defaultHandler = new Handler(defaultHandlerThread.getLooper());
                CmailCenter.logger.warning(TAG, "create default handler thread, we should use " +
                        "these thread normal");
            }
            return defaultHandlerThread;
        }
    }

    public static Handler getDefaultHandler() {
        return defaultHandler;
    }

    public static HandlerThread getNewHandlerThread(String name) {
        for (Iterator<HandlerThread> i = handlerThreads.iterator(); i.hasNext(); ) {
            HandlerThread element = i.next();
            if (!element.isAlive()) {
                i.remove();
                CmailCenter.logger.warning(TAG, String.format("warning: remove dead handler " +
                        "thread with name %s", name));
            }
        }
        HandlerThread handlerThread = new HandlerThread(name);
        handlerThread.start();
        handlerThreads.add(handlerThread);
        CmailCenter.logger.warning(TAG, String.format("warning: create new handler thread with " +
                "name %s, alive thread size:%d", name, handlerThreads.size()));
        return handlerThread;
    }
}