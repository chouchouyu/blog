package com.cmft.cmail.db.model;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity(tableName = "recentContacts")
public class RecentContactModel {

    private String name;

    @PrimaryKey
    @NonNull
    private String address;

    private long timestamp;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "RecentContactModel{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}
