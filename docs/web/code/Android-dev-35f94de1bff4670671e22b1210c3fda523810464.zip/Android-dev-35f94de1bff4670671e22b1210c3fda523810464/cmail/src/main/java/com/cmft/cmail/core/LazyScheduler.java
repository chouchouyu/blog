package com.cmft.cmail.core;

import android.os.Handler;
import android.os.HandlerThread;

/**
 * Created by caichongyang on 2017/5/20.
 * <p>
 * This is a timer class.
 * </p>
 */

public class LazyScheduler {

    private final long delay;
    private final Handler mHandler;
    private volatile boolean isSetUp = false;

    public LazyScheduler(HandlerThread handlerThread, long delay) {
        this.delay = delay;
        mHandler = new Handler(handlerThread.getLooper());
    }

    public boolean isSetUp() {
        return isSetUp;
    }

    public void setUp(final ILazyTask task, boolean cycle) {
        if (null != mHandler) {
            this.isSetUp = true;
            mHandler.removeCallbacksAndMessages(null);
            RetryRunnable retryRunnable = new RetryRunnable(mHandler, delay, task, cycle);
            mHandler.postDelayed(retryRunnable, delay);
        }
    }

    public void cancel() {
        if (null != mHandler) {
            this.isSetUp = false;
            mHandler.removeCallbacksAndMessages(null);
        }
    }

    public void setOff() {
        cancel();
    }

    public interface ILazyTask {
        void onLoop();
    }

    static class RetryRunnable implements Runnable {
        private final Handler handler;
        private final long delay;
        private final ILazyTask lazyTask;
        private final boolean cycle;

        RetryRunnable(Handler handler, long delay, ILazyTask lazyTask, boolean cycle) {
            this.handler = handler;
            this.delay = delay;
            this.lazyTask = lazyTask;
            this.cycle = cycle;
        }

        @Override
        public void run() {
            lazyTask.onLoop();
            if (cycle) {
                handler.postDelayed(this, delay);
            }
        }
    }

}