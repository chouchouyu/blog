package com.cmft.cmail.core;

import android.app.Application;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.cmft.cmail.Cmail;
import com.cmft.cmail.utils.CmailSpUtils;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.web.RetrofitService;


public class CmailConfig {

    private Application application;
    private boolean isBuggable;
    private boolean innerEnv;
    private String wlatz_appid;
    private boolean saveLog;

    public String getWlatz_appid() {
        return wlatz_appid;
    }

    public void setWlatz_appid(String wlatz_appid) {
        this.wlatz_appid = wlatz_appid;
    }

    private void isInnerEnv(boolean innerEnv) {
        this.innerEnv = innerEnv;
    }

    public boolean isInnerEnv() {
        return innerEnv;
    }

    public Context getContext() {
        return application.getApplicationContext();
    }

    public void setApplication(Application application) {
        this.application = application;
    }

    public Application getApplication() {
        return application;
    }

    public boolean isBuggable() {
        return isBuggable;
    }

    public void setBuggable(boolean buggable) {
        isBuggable = buggable;
    }

    private CmailConfig(Application application) {
        this.application = application;
        CmailSpUtils.init(getContext());
    }

    public boolean isValid() {
        if (!innerEnv && TextUtils.isEmpty(wlatz_appid)) {
            Log.d(Constant.TAG, "CmailCofig: innerEnv 为true时，Waltz appid不能为空");
            return false;
        } else {
            return true;
        }
    }


    public static final class Builder {
        private boolean isBuggable;
        private boolean innerEnv;
        private String wlatz_appid;
        private boolean savelog;

        public Builder isBuggable(boolean buggable) {
            this.isBuggable = buggable;
            return this;
        }

        public Builder setWlatz_appid(String wlatz_appid) {
            this.wlatz_appid = wlatz_appid;
            return this;
        }


        public Builder isInnerEnv(boolean innerEnv) {
            this.innerEnv = innerEnv;
            return this;
        }

        public Builder isSaveLogToFile(boolean save) {
            this.savelog = save;
            return this;
        }


        public CmailConfig build(Application application) {
            CmailConfig config = new CmailConfig(application);
            config.setBuggable(isBuggable);
            config.isInnerEnv(innerEnv);
            config.isSaveLogToFile(savelog);
            config.setWlatz_appid(wlatz_appid);
            return config;
        }
    }

    private void isSaveLogToFile(boolean savelog) {
        this.saveLog = savelog;
    }

    public boolean isSaveLog() {
        return saveLog;
    }
}
