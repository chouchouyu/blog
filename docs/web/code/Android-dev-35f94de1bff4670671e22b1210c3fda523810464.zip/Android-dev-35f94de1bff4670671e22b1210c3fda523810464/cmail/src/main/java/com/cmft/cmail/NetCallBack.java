package com.cmft.cmail;

public interface NetCallBack<T> {
    void onSuccess(T response);

    void onFail(T response);

    void onError();
}