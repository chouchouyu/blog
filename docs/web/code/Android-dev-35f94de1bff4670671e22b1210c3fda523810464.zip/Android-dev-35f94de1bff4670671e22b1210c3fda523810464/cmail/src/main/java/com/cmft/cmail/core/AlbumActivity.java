package com.cmft.cmail.core;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.cmft.cmail.Cmail;
import com.cmft.cmail.R;
import com.cmft.cmail.utils.CmailUtils;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.FileUtils;
import com.cmft.cmail.utils.RealPathUtil;
import com.cmft.waltz.core.Waltz;

import java.io.File;
import java.io.IOException;

import static com.cmft.cmail.utils.Constant.NET_FAILED;
import static com.cmft.cmail.waltz.CallJsUtils.failResultToJs;
import static com.cmft.waltz.core.utils.WaltzConstant.LOGIN_REQUEST;

/**
 * https://www.cnblogs.com/jukan/p/7241008.html
 * 设置小窗口Activity
 */
public class AlbumActivity extends Activity {

    private static final String TAG = Constant.TAG + "." + "Album";


    private static final int REQUEST_CODE_PICK_FILE = 222;
    private static final int REQUEST_CODE_TAKE_PHOTO = 223;

    private boolean shouldFinish = false;
    private String mailAccount;
    private String option;
    private int type;
    File mTakeImageFile;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //设置1像素
        Window window = getWindow();
        window.setGravity(Gravity.NO_GRAVITY);

        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        WindowManager.LayoutParams params = window.getAttributes();
        params.x = 0;
        params.y = 100;
        params.height = 0;
        params.width = 0;
        params.alpha = 0.0f;
        window.setAttributes(params);
        setContentView(R.layout.activity_album);


        mailAccount = getIntent().getStringExtra("mailAccount");
        option = getIntent().getStringExtra("option");
        type = getIntent().getIntExtra("type", 0);


        switch (type) {
            case 0:
                chooseFile();
                break;
            case 1:
                takePhoto();
                break;
            case Constant.SHOWLOGIN_INDEX:
                shouldFinish = true;
                CmailCenter.logger.debug(TAG, "   拦截器 3 跳转登陆页面-> start" + Cmail.wlatz_appid);
                Waltz.getSingleton().openLoginApp(this, Cmail.wlatz_appid, LOGIN_REQUEST);
                break;
            default:
                break;
        }
    }


    private void chooseFile() {
        shouldFinish = true;
        getFilesManger();
    }

    /**
     * 拍照
     */
    private void takePhoto() {
        shouldFinish = true;
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        takePictureIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            if (CmailUtils.existSDCard()) {
                mTakeImageFile = new File(Environment.getExternalStorageDirectory(),
                        "/DCIM/camera/");
            } else {
                mTakeImageFile = Environment.getDataDirectory();
            }
            mTakeImageFile = CmailUtils.createFile(mTakeImageFile, "IMG_", ".jpg");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ContentValues contentValues = new ContentValues(1);
                contentValues.put(MediaStore.Images.Media.DATA, mTakeImageFile.getAbsolutePath());
                Uri uri = getContentResolver().insert(MediaStore.Images.Media
                        .EXTERNAL_CONTENT_URI, contentValues);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            } else {
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(mTakeImageFile));
            }
        }
        startActivityForResult(takePictureIntent, REQUEST_CODE_TAKE_PHOTO);
    }


    public void getFilesManger() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        //设置类型，我这里是任意类型，任意后缀的可以这样写。
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, REQUEST_CODE_PICK_FILE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Uri uri;
        String path;
        CmailCenter.logger.debug(TAG, "AlbumActivity 的 resultCode" + resultCode);

        if (resultCode != RESULT_OK) {
            finish();
            return;
        }
        switch (requestCode) {
            //拍照
            //获取相册的图片
            case REQUEST_CODE_PICK_FILE:
                shouldFinish = false;
                if (data == null) {
                    return;
                }
                uri = data.getData();
                CmailCenter.logger.debug(TAG, "AlbumActivity 的 uri：" + uri.toString());

                int sdkVersion = Integer.valueOf(Build.VERSION.SDK);
                if (sdkVersion >= 19) {
                    try {
                        path = CmailUtils.getPath_above19(AlbumActivity.this, uri);
                    } catch (Exception e) {
                        path = CmailUtils.getFilePathFromURI(AlbumActivity.this, uri);//新的方式
                    }
                } else {
                    path = CmailUtils.getFilePath_below19(AlbumActivity.this, uri);
                }
                if (TextUtils.isEmpty(path)) {
                    failResultToJs(Constant.NET_ERROR_CODE, Constant.FILE_GET_ERROR, option);
                } else {
                    CmailCenter.logger.debug(TAG, this.getClass().getSimpleName() + ": pick image"
                            + path);
                    Cmail.addAttachment(mailAccount, type, option, path);
                    this.finish();
                }
                break;

            case REQUEST_CODE_TAKE_PHOTO:
                if (mTakeImageFile.exists()) {
                    CmailCenter.logger.debug(TAG, this.getClass().getSimpleName() + ": take " +
                            "photo"
                            + mTakeImageFile.getAbsolutePath());
                    Cmail.addAttachment(mailAccount, type, option, mTakeImageFile.getAbsolutePath
                            ());
                }
                this.finish();
                break;
            case LOGIN_REQUEST:
                shouldFinish = false;
                CmailCenter.logger.debug(TAG, "  跳转登陆页面-> 这里重放请求" + LOGIN_REQUEST);
                break;
            default:
                break;
        }

    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                this.finish();
                break;
            default:
                break;
        }
        return super.onKeyDown(keyCode, event);
    }
}