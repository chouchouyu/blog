package com.cmft.cmail;

import android.support.v4.app.Fragment;

import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.core.CmailConfig;
import com.cmft.cmail.db.model.GetMailDataBean;
import com.cmft.cmail.db.model.MailPhrases;
import com.cmft.cmail.db.model.SearchBean;
import com.cmft.cmail.db.model.TobeSend;
import com.cmft.cmail.db.model.UserInfo;
import com.cmft.cmail.waltz.delegate.MailDetailDelegateImpl;
import com.cmft.cmail.waltz.delegate.MailLoginDelegateImpl;
import com.cmft.cmail.utils.CmailInfoSp;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.utils.LogListener;
import com.cmft.cmail.waltz.MailDetail;
import com.cmft.cmail.waltz.MailLogin;
import com.cmft.cmail.web.resBean.BaseRes;
import com.cmft.cmail.web.resBean.MailContentRes;
import com.cmft.waltz.core.sdk.WaltzWindowManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;


public final class Cmail {
    private static CmailCenter mCmailCenter;
    private static Fragment mailAccountFragment;
    private volatile static boolean hasInit = false;
    public static String wlatz_appid;

    /**
     * @brief Cmail初始化
     */
    public static void init(CmailConfig cmailConfig) {
        if (!hasInit) {
            wlatz_appid = cmailConfig.getWlatz_appid();
            mCmailCenter = CmailCenter.instance(cmailConfig);
            hasInit = true;
        }

    }


    public static void setLogListener(LogListener logListener) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.registerListener(logListener);
    }

    public static void WPScheckVersion() {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.WPScheckVersion();
    }

    public static void login(UserInfo userInfo, List<String> mailAccList) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.login(userInfo, mailAccList);
    }

    public static void setCurrentMailAccount(String mailAccount) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.setCurrentMailAccount(mailAccount);
    }


    public static void readAttachment(String sandBoxPath) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.readAttachment(sandBoxPath);

    }

    public static Fragment getMailFragment(String url, String netEnvironment) {
        if (mailAccountFragment == null) {
            synchronized (Cmail.class) {
                if (mailAccountFragment == null) {
                    CmailInfoSp.setAppEnvironment(netEnvironment);
                    mailAccountFragment = new WaltzWindowManager.Builder()
                            .setUrl(url)
                            .setAppEnvironment(netEnvironment)
                            .setHomeInfoApp(false)
                            .hasCustomInterface(true)
                            .addJavascriptObject(new MailLogin(new MailLoginDelegateImpl()),
                                    new MailDetail(new MailDetailDelegateImpl()))
                            .addJavascriptModuleName("MailAccount", "MailDetail")
                            .setIsHideNativeHeader(true)
                            .setWaterMarkEnable(false)
                            .setFullScreen(false)
                            .setNoticeName(Constant.NOTICE_NAME)
                            .setHandleFromNativeActionName(Constant.HANDLE_NATIVE_NAME)
                            .build().getWaltzFragment();
                }
            }
        }
        return mailAccountFragment;
    }


    public static void saveMailContent(String email, String folderName, long uid,
                                       NetCallBack<BaseRes<MailContentRes>> callBack) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.saveMailContent(email, folderName, uid, callBack);
    }


    public static void getMailContent(String mailAccount, String folderName, long uid,
                                      CallBack<com.cmft.cmail.db.model
                                              .MailDetail> callback) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.getMailContent(mailAccount, folderName, uid, callback);
    }


    public static void saveAndOpenAttachment(String email, String boxName, int uid, int
            attachmentIndex, String fileName, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.saveAndOpenAttachment(email, boxName, uid, attachmentIndex, fileName, option);
    }


    public static void openAttachment(String path, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.openAttachment(path, option);
    }


    public static void bindAccountToServer(String mailAccount, String password, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.bindAccountToServer(mailAccount, password, option);
    }

    public static void unBindAccountToServer(String mailAccount, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.unbindAccountToServer(mailAccount, option);
    }

    public static void freezeMail(String mail, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.freezeMail(mail, option);
    }

    public static void unFreezeMail(String mail, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.unFreezeMail(mail, option);
    }


//    public static void getMailStatusList(List<String> mailList, String option) {
//        if (mCmailCenter == null) {
//            throw new RuntimeException("Please initialize Cmail first");
//        }
//        mCmailCenter.getMailStatusList(mailList, option);
//    }

    public static void clearFolder(String mail, String boxName, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.clearFolder(mail, boxName, option);
    }

    public static void deleteFolder(String mail, String boxName, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.deleteFolder(mail, boxName, option);
    }

    public static void deleteMail(String mailAccount, String boxName, List<Long> uidList,
                                  String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.deleteMail(mailAccount, boxName, uidList, option);
    }

    public static void getMailBox(String email) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.getMailBox(email);
    }

    public static void getMailHeader(List<GetMailDataBean> list, String option, int fetchType, int
            filterType, int searchType,
                                     String searchText, int mode, boolean
                                             isRefresh) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.getMailHeader(list, option,
                fetchType, filterType, searchType, searchText, mode, isRefresh);
    }

    public static void mailSend(String email, JSONObject jsonObject, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.mailSend(email, jsonObject, option);
    }


    public static void deleteUploadFile(String mailAccount, JSONObject mailBody, JSONArray
            appendAttachment, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.deleteUploadFile(mailAccount, mailBody, appendAttachment, option);
    }

    public static void moveMail(String mailAccount, String sourceBoxName, String targetBixName,
                                List<Long> uidList, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.moveMail(mailAccount, sourceBoxName, targetBixName, uidList, option);
    }

    public static void modifyMailStatus(String email, String boxName, int mode, List<Long>
            uidList, final String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.modifyMailStatus(email, boxName, mode, uidList, option);
    }

    public static void modifyFolderStatus(String email, String boxName, int mode, final String
            option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.modifyFolderStatus(email, boxName, mode, option);
    }


    public static void getMailBody(String email, String boxName, long mailUid,
                                   CallBack<String> callBack) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.getMailBodyFromSandBox(email, boxName, mailUid, callBack);
    }


    public static void sandboxDecrypt(String path, CallBack<String> callBack) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.sandboxDecrypt(path, callBack);
    }


    public static void addAttachment(String mailAccount, int type, String option,
                                     String attachmentPath) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.addAttachment(mailAccount, type, option, attachmentPath);
    }

    public static boolean deleteAttachment(String mailAccount, String fileName, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        return mCmailCenter.deleteAttachment(mailAccount, fileName, option);
    }

    public static void openSendAttachment(String mailAccount, String fileName,String filePath, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.openSendAttachment(mailAccount, fileName,filePath, option);
    }


//    public static void saveMailContentTOSandBox(String email, int mailUID, String boxName, String
//            mailContent) {
//        if (mCmailCenter == null) {
//            throw new RuntimeException("Please initialize Cmail first");
//        }
//        mCmailCenter.saveMailContentTOSandBox(email, mailUID, boxName, mailContent);
//    }

    public static void deleteIdiomList(String idiom, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.deleteIdiomList(idiom, option);
    }

    public static void supportMailDomain(String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.supportMailDomain(option);
    }

    public static void getMailAccountList(String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.getMailAccountList(option);
    }

    public static void saveMailToDrafts(TobeSend tobeSend, String writeUrl, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.saveMailToDrafts(tobeSend, writeUrl, option);
    }


    public static void mailSearch(final List<SearchBean.FetchListBean> mailList, final int
            searchType, final int mode, final String searchText, final String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.mailSearch(mailList, searchType, mode, searchText, option);
    }


    public static void getIdiomList(String data, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.getIdiomList(data, option);
    }

    public static void getMailSignList(String data, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.getMailSignList(data, option);
    }

    public static void addIdiomList(String data, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.addIdiomList(data, option);
    }

    public static void mailFilter(final List<GetMailDataBean> list, final int fetchType, final int
            filterType, final int mode,
                                  final String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.mailFilter(list, fetchType, filterType, mode, option);
    }

    public static void setMainMailAccount(final String mainAccount, final boolean masterAccount,
                                          final
                                          String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.setMainMailAccount(mainAccount, masterAccount, option);
    }

    public static void setMailSignature(String mailAccount, String signature, String
            option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.setMailSignature(mailAccount, signature, option);
    }

    public static void addIdiomList(final List<MailPhrases> list, final String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.addIdiomList(list, option);
    }

    public static void getMailBox(final List<String> mailList, final String mail, final String
            option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.getMailBox(mailList, mail, option);
    }


    public static void getUserInfo(String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.getUserInfo(option);
    }

    public static String getContentURL(String email, String boxName, String mailUid) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        return mCmailCenter.getContentURL(email, boxName, mailUid);
    }


    public static String getWriteContentUrl(String email, long mailUid) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        return mCmailCenter.getWriteContentUrl(email, mailUid);
    }

    public static void modifyMailStatus(Map<String, Map<String, List<Long>>> map, int mode,
                                        String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.modifyMailStatus(map, mode, option);
    }

    public static void recentContacts(String keyword, int limit, String option) {
        if (mCmailCenter == null) {
            throw new RuntimeException("Please initialize Cmail first");
        }
        mCmailCenter.recentContacts(keyword, limit, option);
    }
}
