package com.cmft.cmail.db.model;

import java.util.List;

import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Relation;

public class MailDetail {

    @Embedded
    public MailInfo mailInfo;

    //    @Relation(parentColumn = "id", entityColumn = "mailId", projection = {"attachmentIndex",
//            "attachmentName", "fileSize", "filePath"})
    @Relation(parentColumn = "id", entityColumn = "mailId")
    public List<MailAttachment> mailAttachmentList;

    //    @Relation(parentColumn = "id", entityColumn = "id", projection = {"cid", "name",
    // "filePath"})
//    @Relation(parentColumn = "id", entityColumn = "id")
//    public List<MailPic> mailPicList;


    @Override
    public String toString() {
        return "MailDetail{" +
                "mailInfo=" + mailInfo.toString() +
                ", mailAttachmentList=" + mailAttachmentList.toArray().toString() +
                '}';
    }
}
