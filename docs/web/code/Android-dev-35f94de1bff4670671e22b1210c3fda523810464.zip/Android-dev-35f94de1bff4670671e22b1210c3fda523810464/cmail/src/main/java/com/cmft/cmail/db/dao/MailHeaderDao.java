package com.cmft.cmail.db.dao;

import com.cmft.cmail.db.model.MailHeader;

import java.util.Collection;
import java.util.List;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.RawQuery;
import android.arch.persistence.room.Update;
import android.arch.persistence.db.SimpleSQLiteQuery;
import android.arch.persistence.db.SupportSQLiteQuery;

@Dao
public interface MailHeaderDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long[] insertMailHeaders(List<MailHeader> list);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertMailHeader(MailHeader list);

    @Query("select * from MailHeader where id ==:id")
    MailHeader queryByid(String id);

    @Query("select * from MailHeader where mailAccount ==:mail and boxName ==:boxName ORDER BY " +
            "uid DESC LIMIT" +
            ":fetchSize")
    List<MailHeader> queryMailHeaders(String mail, String boxName, int fetchSize);

    @Query("select * from MailHeader where mailAccount ==:mailAccount and " +
            "flagged == :flag and uid > :uid ORDER BY uid DESC LIMIT " +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByFlagged(long
                                                        uid, String mailAccount, boolean flag,
                                                int fetchSize);


    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName ==:boxName and " +
            "flagged == :flag and uid > :uid ORDER BY uid DESC LIMIT " +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByFlagged(String boxName, /*int fetchSize,*/ long
            uid, String mailAccount, boolean flag, int fetchSize);

    @Query("select * from MailHeader where mailAccount == :mailAccount and boxName ==:boxName and" +
            " unseen ==:unseen and attachmentCount > 0 and uid > :uid ORDER BY uid " +
            "DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByAttachmentWithUnseen(String boxName, /*int fetchSize,*/ long
            uid, String mailAccount, boolean unseen, int fetchSize);


    @Query("select * from MailHeader where mailAccount ==:mailAccount and " +
            "flagged == :flag and uid < :uid ORDER BY uid DESC LIMIT " +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByFlaggedEarly(long
                                                             uid, String mailAccount, boolean
            flag, int fetchSize);

    @Query("select * from MailHeader where mailAccount == :mailAccount and" +
            " unseen ==:unseen and flagged ==:flag and uid > :uid ORDER BY uid DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByUnseenWithFlag(long
                                                               uid,
                                                       String mailAccount, boolean unseen,
                                                       boolean flag, int fetchSize);

    @Query("select * from MailHeader where mailAccount == :mailAccount and" +
            " unseen ==:unseen and flagged ==:flag and uid < :uid ORDER BY uid DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByUnseenWithFlagEarly(long
                                                                    uid,
                                                            String mailAccount, boolean unseen,
                                                            boolean flag, int fetchSize);

    @Query("select * from MailHeader where mailAccount == :mailAccount and" +
            " flagged ==:flag and attachmentCount > 0 and uid > :uid ORDER BY uid " +
            "DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByAttachmentWithFlagged(
            long
                    uid, String
                    mailAccount, boolean flag,
            int fetchSize);


    @Query("select * from MailHeader where mailAccount == :mailAccount and" +
            " flagged ==:flag and attachmentCount > 0 and uid < :uid ORDER BY uid " +
            "DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByAttachmentWithFlaggedEarly(long
                                                                           uid, String
                                                                           mailAccount, boolean
                                                                           flag,
                                                                   int fetchSize);


    @Query("select * from MailHeader where mailAccount == :mailAccount and" +
            " unseen ==:unseen and uid > :uid ORDER BY uid DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByUnseen(long uid,
                                               String mailAccount, boolean unseen, int fetchSize);


    @Query("select * from MailHeader where mailAccount == :mailAccount and boxName ==:boxName and" +
            " unseen ==:unseen and uid > :uid ORDER BY uid DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByUnseen(String boxName, /*int fetchSize,*/ long uid,
                                               String mailAccount, boolean unseen, int fetchSize);


    @Query("select * from MailHeader where mailAccount == :mailAccount and boxName ==:boxName and" +
            " unseen ==:unseen and flagged ==:flag and uid > :uid ORDER BY uid DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByUnseenWithFlag(String boxName, /*int fetchSize,*/ long
            uid,
                                                       String mailAccount, boolean unseen,
                                                       boolean flag, int fetchSize);


    @Query("select * from MailHeader where mailAccount == :mailAccount and" +
            " unseen ==:unseen and uid < :uid ORDER BY uid DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByUnseenEarly(long uid,
                                                    String mailAccount, boolean unseen, int
                                                            fetchSize);

    @Query("select * from MailHeader where mailAccount == :mailAccount and" +
            " unseen ==:unseen and attachmentCount > 0 and uid > :uid ORDER BY uid " +
            "DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByAttachmentWithUnseen(long
                                                                     uid, String mailAccount,
                                                             boolean unseen, int fetchSize);

    @Query("select * from MailHeader where mailAccount == :mailAccount and" +
            " unseen ==:unseen and attachmentCount > 0 and uid < :uid ORDER BY uid " +
            "DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByAttachmentWithUnseenEarly(long
                                                                          uid, String
            mailAccount, boolean unseen, int fetchSize);

    @Query("select * from MailHeader where mailAccount == :mailAccount and boxName ==:boxName and" +
            " attachmentCount > 0 and uid > :uid ORDER BY uid DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByAttachment(String boxName, /*int fetchSize,*/ long
            uid, String mailAccount, int fetchSize);


    @Query("select * from MailHeader where mailAccount == :mailAccount and boxName ==:boxName and" +
            " attachmentCount > 0 and uid < :uid ORDER BY uid DESC " +
            "LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByAttachmentEarly(String boxName, /*int fetchSize,*/ long
            uid, String mailAccount, int fetchSize);

    @Query("select * from MailHeader where mailAccount ==:mail and boxName ==:boxName order by " +
            "uid desc")
    List<MailHeader> queryMailHeaders(String mail, String boxName);


//    @Query("select * from MailHeader where mailAccount in (:mailList) and boxName ==:boxName " +
//            "ORDER BY uid DESC")
//    List<MailHeader> queryMailHeadersByMailList(List<String> mailList, String boxName);

    @Query("select * from MailHeader where mailAccount ==:mail and boxName ==:boxName and uid in " +
            "(:uidList) ORDER BY uid DESC")
    List<MailHeader> queryMailHeaders(String mail, String boxName, List<Long> uidList);

    @Query("select * from MailHeader where mailAccount ==:mail and boxName ==:boxName and uid == " +
            ":mailUid")
    MailHeader queryMailHeader(String mail, String boxName, long mailUid);

    @Query("select timestamp from MailHeader where mailAccount ==:mail and boxName==:boxName and " +
            "uid = :mailUid")
    long queryTimestampByUid(String mail, String boxName, long mailUid);


    @RawQuery(observedEntities = MailHeader.class)
    List<MailHeader> searchAll(SupportSQLiteQuery query);


    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName ==:boxName and " +
            "name like '%' || :searchText || '%' ORDER BY uid DESC")
    List<MailHeader> searchMailHeadersByFrom(String boxName, /*int fetchSize,long timestamp,*/
                                             String mailAccount, String searchText);

    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName ==:boxName and " +
            "subject like '%' || :searchText || '%' ORDER BY uid DESC")
    List<MailHeader> searchMailHeadersSubject(String boxName, /*int fetchSize, long timestamp,*/
                                              String mailAccount, String searchText);

    @Query("select * from MailHeader where mailAccount == :mailAccount and boxName ==:boxName and" +
            " receiver like '%' || :receiver || '%' ORDER BY uid DESC")
    List<MailHeader> searchMailHeaderByReceiver(String boxName, /*int fetchSize,long timestamp,*/
                                                String mailAccount, String receiver);


    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName ==:boxName and " +
            "flagged == :flag and unseen ==:unseen and timestamp > :timestamp ORDER BY uid DESC")
    List<MailHeader> searchMailHeadersByFlaggedByUnseen(String boxName, /*int fetchSize,*/ long
            timestamp, String mailAccount, boolean flag, boolean unseen);


    @Query("select * from MailHeader where flagged == :flag")
    List<MailHeader> searchAllMailHeadersByFlagged(boolean
            flag);

    @Query("select * from MailHeader where unseen ==:unseen")
    List<MailHeader> searchAllMailHeadersByUnseen(boolean
            unseen);

    @Query("select * from MailHeader where unseen ==:unseen and " +
            "flagged == :flag ")
    List<MailHeader> searchAllMailHeadersByFlagUnseen( boolean
            flag, boolean unseen);


    //    @Query("select * from MailHeader where mailAccount == :mailAccount and boxName
    // ==:boxName and" +
//            " unseen ==:unseen ORDER BY uid DESC")
//    List<MailHeader> searchAllMailHeadersByUnseen(String mailAccount, String boxName, boolean
//            unseen);
    @Query("SELECT * FROM  MailHeader where mailAccount = :mailAccount AND boxName =:boxName AND " +
            "unseen =:unseen")
    List<MailHeader> searchAllMailHeadersByUnseen(String mailAccount, String boxName
            , boolean unseen);

    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName == :boxName and" +
            " uid < :uid ORDER BY uid DESC  ")
    List<MailHeader> up(String boxName, String mailAccount, long uid);

    //@Query("select * from MailHeader where mailAccount ==:mailAccount and boxName == :boxName
    // and" +
//            "  uid < :uid  LIMIT :limit ")
//    List<MailHeader> upWithLimit(String boxName, String mailAccount, long uid, int limit);

//    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName == :boxName
// and" +
//            " uid > :uid  LIMIT :limit   ")
//    List<MailHeader> downWithLimit(String boxName, String mailAccount, int uid, int limit);


    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName ==:boxName and " +
            "uid > :uid ORDER BY uid DESC")
    List<MailHeader> down(String boxName, String mailAccount, long uid);

    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName ==:boxName and " +
            "uid > :uid ORDER BY uid DESC")
    List<MailHeader> downANDequal(String boxName, String mailAccount, long uid);

    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName ==:boxName and " +
            "uid > :uid AND unseen =:unseen  ORDER BY uid DESC")
    List<MailHeader> unseendown(String boxName, String mailAccount, long uid, boolean unseen);

    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName ==:boxName and " +
            "uid < :uid AND unseen =:unseen  ORDER BY uid DESC")
    List<MailHeader> unseenUp(String boxName, String mailAccount, long uid, boolean unseen);

    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName ==:boxName and " +
            "uid > :uid AND flagged =:flag  ORDER BY uid DESC")
    List<MailHeader> flagDown(String boxName, String mailAccount, long uid, boolean flag);

    @Query("select * from MailHeader where mailAccount ==:mailAccount and boxName ==:boxName and " +
            "uid < :uid AND flagged =:flag  ORDER BY uid DESC")
    List<MailHeader> flagUp(String boxName, String mailAccount, long uid, boolean flag);


    @Update(onConflict = OnConflictStrategy.REPLACE)
    void updateMailHeader(MailHeader mailHeader);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    void updateMailHeaders(List<MailHeader> mailHeader);

    @Delete
    void deleteMailHeader(MailHeader mailHeader);

    @Delete
    void deleteMailHeaders(List<MailHeader> mailHeaders);

    @Query("select * from MailHeader where mailAccount ==:mailAccount and " +
            "flagged == :flag ORDER BY uid DESC LIMIT" +
            ":fetchSize")
    List<MailHeader> searchMailHeadersByFlaggedWithLimit(String mailAccount, boolean
            flag, int fetchSize);

    @Query("SELECT * FROM  MailHeader where mailAccount = :mailAccount AND " +
            "unseen =:unseen ORDER BY uid DESC LIMIT" +
            ":fetchSize")
    List<MailHeader> searchAllMailHeadersByUnseenWithLimit(String mailAccount, boolean unseen, int fetchSize);


}
