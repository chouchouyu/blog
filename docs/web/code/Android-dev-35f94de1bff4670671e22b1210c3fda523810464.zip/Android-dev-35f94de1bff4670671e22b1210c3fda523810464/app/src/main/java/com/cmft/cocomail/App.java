package com.cmft.cocomail;

import android.app.Application;

import com.cmft.cmail.Cmail;
import com.cmft.cmail.core.CmailConfig;
import com.cmft.waltz.core.Waltz;
import com.facebook.stetho.Stetho;

public class App extends Application {
    private static App mInstance;
    //  -------------------------- TODO 线上环境
    public static final String LIGHT_APP_KEY = "b77ced66a29740e7f688390045e1efd4";
    public static final String APPST_HOST = "https://coco.cmhk.com/";
    public static final String LOGIN_KEY = "4816776bd6cc2f8a28640ef6f0759f19";


    //  --------------------------  TODO 测试环境
//    public static final String LIGHT_APP_KEY = "b77ced66a29740e7f688390045e1efd4";
//    public static final String APPST_HOST = "https://coco-di1.sit.cmft.com/";
//    public static final String LOGIN_KEY = "b7ea169e62884d56fcc45862c55bcf4c";

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        Stetho.initializeWithDefaults(this);
        Waltz singleton = Waltz.getSingleton();
        // todo encryptStr不要登录轻应用的话传null
//        singleton.init(this, "CMFT",
//                "b77ced66a29740e7f688390045e1efd4",
//                "https://appst-di1.sit.cmft.com/lappst/",
//                "IOCP_COCO", false, "b7ea169e62884d56fcc45862c55bcf4c", null);


        Waltz.getSingleton().init(this, "CMFT", LIGHT_APP_KEY, APPST_HOST +
                "lappst/", "IOCP_COCO", false, LOGIN_KEY, null);

//        singleton.init(this, "CMFT",
//                "b77ced66a29740e7f688390045e1efd4",
//                "https://appst-di1.sit.cmft.com/lappst/",
//                "IOCP_COCO", false);

        CmailConfig boxConfig = new CmailConfig.Builder()
                .isBuggable(true)
                .isInnerEnv(false)
                .isSaveLogToFile(true)
                .setWlatz_appid("b5bf36a5cf5142a39c938d62abf5d250")
                .build(this);
        Cmail.init(boxConfig);
    }

    public static App get() {
        return mInstance;
    }
}
