package com.cmft.cocomail;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

import com.cmft.cmail.waltz.delegate.MailDetailDelegateImpl;
import com.cmft.cmail.waltz.delegate.MailLoginDelegateImpl;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.waltz.MailDetail;
import com.cmft.cmail.waltz.MailLogin;
import com.cmft.waltz.core.sdk.WaltzWindowManager;

public class TestWaltzActivity extends AppCompatActivity {

    private String mUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_waltz);
        mUrl = getIntent().getStringExtra("url");
        showFragment();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void showFragment() {
//        Toast.makeText(this, "url::" + mUrl, Toast.LENGTH_SHORT).show();
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        Fragment fragment = new WaltzWindowManager.Builder()
                .setUrl(mUrl)
                .setAppEnvironment("develop")
                .setId(Constant.APPID)
                .setHomeInfoApp(false)
                .hasCustomInterface(true)
                .addJavascriptObject(new MailLogin(new MailLoginDelegateImpl()),
                        new MailDetail(new MailDetailDelegateImpl()))
                .addJavascriptModuleName("MailAccount", "MailDetail")
                .setIsHideNativeHeader(true)
                .setWaterMarkEnable(false)
                .setFullScreen(false)
                .setNoticeName(Constant.NOTICE_NAME)
                .setHandleFromNativeActionName(Constant.HANDLE_NATIVE_NAME)
                .build().getWaltzFragment();
        ft.add(R.id.fl, fragment);
        ft.show(fragment);
        ft.commitAllowingStateLoss();
    }
}
