package com.cmft.cocomail;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;


import java.util.ArrayList;

public class CmailTestActivity extends AppCompatActivity {

    /*
    final String account = "testapp01@cmrhic.com";
    final int foldId = 180;
    private String attachmentName = "test.log";
    private CmailDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cmail_test);


        CmailConfig boxConfig = new CmailConfig.Builder()
                .isBuggable(false)
                .build(this.getApplicationContext());
        Cmail.init(boxConfig);
        Cmail.setLogListener(new LogListener() {
            @Override
            public void onLog(String tag, String msg) {
                Log.d(tag, msg);
            }
        });
        ArrayList<String> list = new ArrayList<>();
        list.add("testapp01@cmrhic.com");
        list.add("testapp20@cmrhic.com");
        Cmail.login("小猪佩奇", list);
        Cmail.setCurrentMailAccount(account);


        database = CmailDatabase.getInstance(this.getApplicationContext());

        new Thread() {
            @Override
            public void run() {
                super.run();
                MailAccount mMailAccount = new MailAccount();
                mMailAccount.setUserId("小猪佩奇");
                mMailAccount.setAccountState(1);
                mMailAccount.setAccountType(1);
                mMailAccount.setMailAccount(account);

                MailAccountHelper.getInstance().insertMailAccount(mMailAccount);
            }
        };


    }


    public void savemailContent(View view) {
        Cmail.saveMailContent(account, "inbox", 1564744180, new
                CallBack<MailContentRes>() {


                    @Override
                    public void onSuccess(MailContentRes response) {

                    }

                    @Override
                    public void onFail(String string) {

                    }
                });
    }

    public void getmailContent(View view) {
        //todo 异步
        Cmail.getMailContent("testapp01@cmrhic.com", "inbox", 1564744180, new
                CallBack<MailDetail>() {


                    @Override
                    public void onSuccess(MailDetail response) {

                    }

                    @Override
                    public void onFail(String string) {

                    }
                });
    }

    public void savemailAttachment(View view) {
        Cmail.saveAndOpenAttachment("testapp01@cmrhic.com", "inbox", 1564744180, 0, "pom.xml",
                null);
    }

    //todo 186 待调试
    public void getmailAttachment(View view) {
        Cmail.openAttachment("avatar/test.pptx", "");
//        Cmail.addAttachment("testapp01@cmrhic.com", "option", "");
//        Cmail.getMailAttachment("testapp01@cmrhic.com", 1564744180, "inbox", "pom.xml");
    }

    public void openAttachment(View view) {
        boolean result = Cmail.deleteAttachment("testapp01@cmrhic.com",
                "IMG_20190730_150607.jpg", "option");
        Log.d("delete", " deleteAttachment " + result);
        //        Cmail.openAttachment("/testapp01@cmrhic.com/1564744180.txt", null);
    }


    public void getRelatedItem(View view) {
//        Cmail.saveRelatedItem("testapp01@cmrhic.com", "inbox", 1564744180,
//                "CID-2575d2c9-680b-4daa-a12e-f1d76c45b50e@IQSZ0D0467", "aaa.jpg");
    }
    */
}
