package com.cmft.cocomail;

import android.Manifest;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.cmft.cmail.CallBack;
import com.cmft.cmail.Cmail;
import com.cmft.cmail.core.HelperSandbox;
import com.cmft.cmail.db.model.MailFolder;
import com.cmft.cmail.db.model.UserInfo;
import com.cmft.cmail.utils.ILogger;
import com.cmft.cmail.utils.LogListener;
import com.cmft.waltz.core.Waltz;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private HandlerThread handlerThread;
    private Handler mHandler;
    private ArrayList<MailFolder> mMailFolders = new ArrayList<>();
    private EditText mEditText;
    private TextView mOpen, mOpenX;

    private TextView mPutlicNet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initCmail();
        initView();
        Waltz.getSingleton().openLoginApp(this, "TEst_AppId", 0x864);
        registerReceiver();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 0x2122);
        }
    }


    private void registerReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("loginState");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        service.unRegister();
    }

    private void initView() {
        mPutlicNet = findViewById(R.id.public_net);
        mOpen = findViewById(R.id.open);
        mOpenX = findViewById(R.id.open_X);
        mOpen.setOnClickListener(this);
        mOpenX.setOnClickListener(this);
        mPutlicNet.setOnClickListener(this);
    }

    private void initCmail() {
        ArrayList<String> list = new ArrayList<>();
        list.add("ex-fengyy001@cmft.com");
//        list.add("testapp20@cmrhic.com");
//        Cmail.login("longxy", list);

//        list.add("ex-dengld001@cmft.com");
//        list.add("ex-dengld001@cmft.com");
        UserInfo userInfo = new UserInfo();
        userInfo.setUserName("吴思敏");
        userInfo.setUserId("wusm");
        userInfo.setNickName("susan");
        userInfo.setGender(2);
        userInfo.setAvatarUrl("");
        Cmail.login(userInfo, list);
//        Cmail.setToken
// ("5001609b71ada094c72acf6a43143e1c4af549983d49df079b23cc98a8fc26a48dbd6b6db8d12bf384083cfb335d23b4919f");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.open:
                jump("http://10.200.88.198:8080");
                break;
            case R.id.public_net:
                jump("file:///android_asset/mail/index.html");
                break;
            case R.id.open_X:
                String file = "/storage/emulated/0/Android/data/cocomail.cmft.com" +
                        ".cmail/files/COCO-DATA/ex-dengld001/wusm@cmft.com/INBOX/4813.txt";
//                File fileStreamPath = getExternalFilesDir("COCO-DATA");
                File fileStreamPath = getExternalFilesDir("COCO-DATA/ex-dengld001/wusm@cmft.com/INBOX/4813.txt");

                if (fileStreamPath.exists()) {
                    Log.d("文件存在", "存在");
                } else {
                    Log.d("文件存在", "不存在");
                }
//                jump("http://10.200.89.37:8090");
                break;
            default:
                break;
        }
    }

    private void jump(String url) {
        Intent intent = new Intent(MainActivity.this, TestWaltzActivity.class);
        intent.putExtra("url", url);
        startActivity(intent);
    }


}
