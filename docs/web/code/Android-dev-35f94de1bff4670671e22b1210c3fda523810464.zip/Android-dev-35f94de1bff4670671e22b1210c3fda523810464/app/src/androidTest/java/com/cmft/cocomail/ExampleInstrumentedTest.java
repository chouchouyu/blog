package com.cmft.cocomail;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.text.TextUtils;

import com.cmft.cmail.Cmail;
import com.cmft.cmail.core.CmailConfig;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.helper.MailAccountHelper;
import com.cmft.cmail.db.model.CompanyModel;
import com.cmft.cmail.db.model.MailAccount;
import com.cmft.cmail.utils.CmailInfoSp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    private CmailDatabase database;

    @Before
    public void prepare() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();
        initCmail(appContext);

    }

    MailAccount mMailAccount;

    final String account = "xiaozhu@cmft.com";
    final int foldId = 180;

    private void initCmail(Context context) {
        CmailConfig boxConfig = new CmailConfig.Builder()
                .isBuggable(true)
                .build(context);
        Cmail.init(boxConfig);
        ArrayList<String> list = new ArrayList<>();
        list.add("testapp01@cmrhic.com");
        list.add("testapp20@cmrhic.com");
        Cmail.login("小猪佩奇", list);
        Cmail.setCurrentMailAccount(account);


        database = CmailDatabase.getInstance(context);
//        database.mailPhrasesDao().delete(new MailPhrases("msg", "daliyjb11@163.com"));


        mMailAccount = new MailAccount();
        mMailAccount.setUserId("小猪佩奇");
        mMailAccount.setAccountState(1);
        mMailAccount.setAccountType(1);
        mMailAccount.setMailAccount(account);

        MailAccountHelper.getInstance().insertMailAccount(mMailAccount);
    }

    public static Map<String, String> getStringToMap(String str) {
        //根据逗号截取字符串数组
        String[] str1 = str.split(",");
        //创建Map对象
        Map<String, String> map = new HashMap<>();
        //循环加入map集合
        for (int i = 0; i < str1.length; i++) {
            //根据":"截取字符串数组
            String[] str2 = str1[i].split(":");
            //str2[0]为KEY,str2[1]为值
            map.put(str2[0], str2[1]);
        }
        return map;
    }


    @Test
    public void gson() {
        String companyJsonArray = CmailInfoSp.getCompanyMap();
        if (TextUtils.isEmpty(companyJsonArray)) {

        } else {
            Gson gson = new Gson();
            List<CompanyModel> companyList = gson.fromJson(companyJsonArray, new
                    TypeToken<List<CompanyModel>>() {
                    }.getType());
            for (CompanyModel company : companyList) {
                if (mMailAccount.getMailAccount().endsWith(company.key)) {
                    mMailAccount.setCompany(company.value);
                }
            }


            System.out.print("HHHH" + mMailAccount.toString());


        }


//        database.mailPhrasesDao().delete(new MailPhrases("msg", "daliyjb11@163.com"));

//        long timeMillis = CmailUtils.currentTimeMillis();
//        TimeZone.getDefault();
//        long timeMillis = 1570588780000L;
//        Date date = new Date(timeMillis);
//        Cmail.logger.debug(Constant.TAG, "发送邮件的时间" + date.toLocaleString());
//        String receiverString = "{\"abc\":\"1\",\"hahah\":\"2\"}";
//        try {
//            JSONObject jsonObject1 = new JSONObject(receiverString);
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }

    }
//    public void insertMailDetail() {
////        Cmail.getMailContent("testapp20@cmrhic.com", "INBOX", "1564744174", new
/// RetrofitService.CallBack() {
////            @Override
////            public void onSuccess(String response) {
////                Log.d("TEST", response);
////            }
////
////            @Override
////            public void onFail() {
////
////            }
////        });
//
//
//        String mailStr = "{\n" +
//                "    \"attachmentCount\" : 2,\n" +
//                "    \"attachmentFile\" : [ {\n" +
//                "      \"name\" : \"活动申请表.docx\",\n" +
//                "      \"size\" : 100,\n" +
//                "      \"url\" : \"https://cos-cdn-di1.sit.cmrh
// .com/cos-download/v1/downloadFile/0/coco-private-bucket/3535a2b75a980c8007fecd8b0e1d0276/活动申请表
// .docx?expires=1879580686&signature=0101bazXI8K3
// :ODE2RUVENTRBQzA1NUVBQ0Y4MzY5NUE3QTM0RjU3NUE1RTM1Q0VBRA==\"\n" +
//                "    },\n" +
//                "{\n" +
//                "      \"name\" : \"2b5f1b6298411b0045c5562da02fc6ac-2.jpg\",\n" +
//                "      \"size\" : 100,\n" +
//                "      \"url\" : \"https://cos-cdn-di1.sit.cmrh
// .com/cos-download/v1/downloadFile/0/coco-private-bucket/226d0ee0e1322946698c86ed916c8751
// /2b5f1b6298411b0045c5562da02fc6ac-2.jpg?expires=1879083134&signature=0101bazXI8K3
// :OTE4OEIwQThGRTcxM0ZBMjQ4MjNGRTM1RTgxMURCODIwREU1MUFCQg==\"\n" +
//                "    }\n" +
//                "\n" +
//                "\n" +
//                " ],\n" +
//                "    \"content\" : \"string\",\n" +
//                "    \"flagged\" : false,\n" +
//                "    \"mailTime\" : \"string\",\n" +
//                "    \"receiver\" : [ {\n" +
//                "      \"address\" : \"string\",\n" +
//                "      \"name\" : \"string\"\n" +
//                "    } ],\n" +
//                "    \"receiverBCC\" : [ {\n" +
//                "      \"address\" : \"string\",\n" +
//                "      \"name\" : \"string\"\n" +
//                "    } ],\n" +
//                "    \"receiverCC\" : [ {\n" +
//                "      \"address\" : \"string\",\n" +
//                "      \"name\" : \"string\"\n" +
//                "    } ],\n" +
//                "    \"relatedItem\" : [ {\n" +
//                "      \"cid\" : \"string\",\n" +
//                "      \"name\" : \"string\",\n" +
//                "      \"url\" : \"string\"\n" +
//                "    } ],\n" +
//                "    \"sender\" : {\n" +
//                "      \"address\" : \"string\",\n" +
//                "      \"name\" : \"string\"\n" +
//                "    },\n" +
//                "    \"subject\" : \"string\",\n" +
//                "    \"uid\" : 0,\n" +
//                "    \"unseen\" : false\n" +
//                "  }";
//        Gson gson = new Gson();
//        MailDetailReq mailDetailReq = gson.fromJson(mailStr, MailDetailReq.class);
//        MailDetail mailDetail = new MailDetail();
//
//        mailDetail.mailUid = mailDetailReq.getUid();
//        //todo folderId 请求没有
//        mailDetail.folderId = foldId;
//        //发送人
//        mailDetail.sender = mailDetailReq.getSender().getAddress();
//        mailDetail.sendername = mailDetailReq.getSender().getName();
//        mailDetail.receivers = gson.toJson(mailDetailReq.getReceiver());
//        mailDetail.receiversBCC = gson.toJson(mailDetailReq.getReceiverBCC());
//        mailDetail.receiversCC = gson.toJson(mailDetailReq.getReceiverCC());
//        mailDetail.subject = mailDetailReq.getSubject();
//        //todo contentMark  邮件正文摘要（最前面255字符） 待删除
//        mailDetail.contentMark = "邮件正文摘要（最前面255字符）";
//        mailDetail.sendTime = mailDetailReq.getMailTime();
//        //todo receivTime  邮件接收时间
//        mailDetail.receivTime = String.valueOf(System.currentTimeMillis());
//        mailDetail.hasReaded = mailDetailReq.isUnseen();
//        mailDetail.hasflaged = mailDetailReq.isFlagged();
//        if (mailDetailReq.getAttachmentCount() > 0) {
//            mailDetail.hasAttachments = true;
//        } else {
//            mailDetail.hasAttachments = false;
//        }
//
//
//        //TODO 邮箱内容写入sandbox 确保path一定存在
//        String result = Cmail.saveToSandBox(mailDetailReq.getContent(), foldId, mailDetailReq
// .getUid());
//        mailDetail.emailPath = result;
//
//        //存入当前mailAccount
//        mailDetail.mailAccount = account;
//
//        database.getMailDetailDao().insert(mailDetail);
//
//        //---------------------查询邮件------------
//        MailDetail resultMail = database.getMailDetailDao().getMailDetail(mailDetailReq.getUid
// (), foldId);
//        Log.d("TEST", resultMail.toString());
//
//        // ------------------保存附件信息----------
//        if (mailDetail.hasAttachments) {
//            List<MailDetailReq.AttachmentFileBean> attachmentFileList = mailDetailReq
// .getAttachmentFile();
//            List<MailAttachment> dbAttachmentList = new ArrayList<>();
//            for (int i = 0; i < attachmentFileList.size(); i++) {
//                MailAttachment mailAttachmentBean = new MailAttachment();
//                mailAttachmentBean.attachmentName = attachmentFileList.get(i).getName();
//                mailAttachmentBean.fileSize = attachmentFileList.get(i).getSize();
//                mailAttachmentBean.downloadUrl = attachmentFileList.get(i).getUrl();
//                mailAttachmentBean.attachmentIndex = i;
//                mailAttachmentBean.mailUid = mailDetailReq.getUid();
//                mailAttachmentBean.folderId = foldId;
//                mailAttachmentBean.mailAccount = account;
//                //todo 查看是不是存在，不存在再保存，再设置
////                mailAttachmentBean.filePath = mailDetailReq.getUid();
//                dbAttachmentList.add(mailAttachmentBean);
//            }
//
//            database.mailAttachmentDao().insert(dbAttachmentList);
//
//            //---------------------查询邮件附件------------
//            List<MailAttachment> reultAttachmentList = database.mailAttachmentDao()
// .getMailAttachments(mailDetailReq.getUid(), foldId);
//            Log.d("TEST", reultAttachmentList.toString());
//
//
//            //---------------TODO 下载附件---- ---
//
//
//            // ---------------保存附件 -存入附件数据库----------
//
//
//            // -------------只读模式打开附件-------
//            Cmail.readAttachment(result);
//
//        }
//
//
//    }


    @After
    public void close() {
//        if (null != database || database.isOpen()) {
//            database.close();
//        }
    }
}
