package com.cmft.cocomail;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.cmft.cmail.Cmail;
import com.cmft.cmail.core.CmailCenter;
import com.cmft.cmail.core.CmailConfig;
import com.cmft.cmail.db.CmailDatabase;
import com.cmft.cmail.db.dao.MailHeaderDao;
import com.cmft.cmail.db.helper.MailAccountHelper;
import com.cmft.cmail.db.helper.MailFolderHelper;
import com.cmft.cmail.db.model.MailAccount;
import com.cmft.cmail.db.model.MailFolder;
import com.cmft.cmail.db.model.MailHeader;
import com.cmft.cmail.db.model.MailPhrases;
import com.cmft.cmail.utils.Constant;
import com.cmft.cmail.web.RetrofitService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.List;

@RunWith(AndroidJUnit4.class)
public class MailTest {

    private CmailDatabase database;
    private RetrofitService mRetrofitService;

    @Before
    public void prepare() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();
        mRetrofitService = new RetrofitService(Constant.BASE_URL, true, config.isInnerEnv(), config.getToken());
        initCmail(appContext);
        insertMailAccount();
    }

    final String account = "xiaozhu@cmrh.com";
    final int foldId = 186;

    private void initCmail(Context context) {
        CmailConfig boxConfig = new CmailConfig.Builder()
                .isBuggable(true)
                .build(context);
        Cmail.init(boxConfig);

        ArrayList<String> list = new ArrayList<>();
//        list.add("testapp01@cmrhic.com");
//        list.add("testapp20@cmrhic.com");
//
//        Cmail.login("小猪佩奇", list);
//        Cmail.setCurrentMailAccount(account);
        database = CmailDatabase.getInstance(context);
    }

    @Test
    public void insertMailAccount() {



        List<MailAccount> data = new ArrayList<>();
        MailAccount mMailAccount = new MailAccount();
        mMailAccount.setUserId("小猪佩奇");
        mMailAccount.setAccountState(1);
        mMailAccount.setAccountType(1);
        mMailAccount.setMailAccount(account);

        MailAccount mailAccount1 = new MailAccount();
        mailAccount1.setMasterAccount(false);
        mailAccount1.setUserId("小猪佩奇");
        mailAccount1.setMailAccount("testapp01@cmrhic.com");
        mailAccount1.setAccountState(0);
        mailAccount1.setAccountType(1);

        MailAccount mailAccount2 = new MailAccount();
        mailAccount2.setMasterAccount(false);
        mailAccount2.setUserId("小猪佩奇");
        mailAccount2.setMailAccount("testapp20@cmrhic.com");
        mailAccount2.setAccountState(0);
        mailAccount2.setAccountType(1);
        data.add(mMailAccount);
        data.add(mailAccount1);
        data.add(mailAccount2);
        MailAccountHelper.getInstance().insertMailAccounts(data);

//        Cmail.getMailHeader("testapp01@cmrhic.com", "inbox", 20, 0, 0, "");
    }

    @Test
    public void insertFolder() {
        List<MailFolder> mailFolderList = new ArrayList<>();
        MailFolder mailFolder = new MailFolder();
        mailFolder.setMailAccount("testapp01@cmrhic.com");
        mailFolder.setFolderName("收件箱");
        mailFolder.setUnreadCount(22);
        mailFolder.setTotalCount(122);

        MailFolder mailFolder1 = new MailFolder();
        mailFolder1.setMailAccount("testapp20@cmrhic.com");
        mailFolder1.setFolderName("收件箱");
        mailFolder1.setUnreadCount(202);
        mailFolder1.setTotalCount(2122);

        MailFolder mailFolder2 = new MailFolder();
        mailFolder2.setMailAccount(account);
        mailFolder2.setFolderName("收件箱");
        mailFolder2.setUnreadCount(202);
        mailFolder2.setTotalCount(2122);

        mailFolderList.add(mailFolder);
        mailFolderList.add(mailFolder1);
        mailFolderList.add(mailFolder2);
        MailFolderHelper.getInstance().insertFolder(mailFolderList);
    }


    @Test
    public void testFolderList() {
        List<String> list = new ArrayList<>();
        list.add("testapp01@cmrhic.com");
        list.add("testapp20@cmrhic.com");
        List<MailFolder> mailFolders = MailFolderHelper.getInstance().queryFolders(list);
        mailFolders.size();
    }

    @Test
    public void getMailBox() {
//        mRetrofitService.getMailBoxFodler("testapp01@cmrhic.com","");
    }

    @Test
    public void moveEmail() {
        List<Integer> list = new ArrayList<>();
        list.add(1564744214);
        list.add(1564744213);
//        mRetrofitService.moveEmail("testapp01@cmrhic.com", "INBOX", "Drafts", list);
    }

    @Test
    public void deleteFolder() {
        mRetrofitService.deleteFolder("testapp01@cmrhic.com", "INBOX", "{}");
    }

    @Test
    public void clearFolder() {
        mRetrofitService.clearFolder("testapp01@cmrhic.com", "INBOX", "{}");
    }

    @Test
    public void deleteMail() {
        List<Integer> list = new ArrayList<>();
        list.add(1564744214);
        list.add(1564744213);
        mRetrofitService.deleteMail("testapp01@cmrhic.com", "INBOX", list, "{}");
    }

    @Test
    public void addMailPhrases() {
        List<MailPhrases> data = new ArrayList<>();

//        MailPhrases mailPhrases = new MailPhrases("MailPhrases content", "testapp01@cmrhic.com");
        MailPhrases mailPhrases = new MailPhrases("MailPhrases content");
        data.add(mailPhrases);

        CmailDatabase.getInstance(CmailCenter.getContext()).mailPhrasesDao().insert(data);
    }

    @Test
    public void searchTextMail() {
        MailHeaderDao mailHeaderDao = CmailDatabase.getInstance(CmailCenter.getContext())
                .getMailHeaderDao();

        long timestamp = mailHeaderDao.queryTimestampByUid("testapp01@cmrhic.com", "inbox",
                1564744300);
        List<MailHeader> searchText = mailHeaderDao
                .searchMailHeadersByFrom("inbox", "daliyjb11@163.com", "dali");

        int size = searchText.size();
        searchAttach();
    }

    @Test
    public void searchAttach() {
        MailHeaderDao mailHeaderDao = CmailDatabase.getInstance(CmailCenter.getContext())
                .getMailHeaderDao();
        long timestamp = mailHeaderDao.queryTimestampByUid("testapp01@cmrhic.com", "inbox",
                1564744300);
        List<MailHeader> inbox = mailHeaderDao
                .searchMailHeadersByAttachment("inbox", timestamp, "testapp01@cmrhic.com");

        int size = inbox.size();
        searchFlag();
    }

    @Test
    public void searchFlag() {
        MailHeaderDao mailHeaderDao = CmailDatabase.getInstance(CmailCenter.getContext())
                .getMailHeaderDao();
        long timestamp = mailHeaderDao.queryTimestampByUid("testapp01@cmrhic.com", "inbox",
                1564744300);

        List<MailHeader> inbox = mailHeaderDao.searchMailHeadersByFlagged("inbox", 10,
                "testapp01@cmrhic.com", false);
        int size = inbox.size();
        searchSubject();
    }

    @Test
    public void searchSubject() {
        MailHeaderDao mailHeaderDao = CmailDatabase.getInstance(CmailCenter.getContext())
                .getMailHeaderDao();
        long timestamp = mailHeaderDao.queryTimestampByUid("testapp01@cmrhic.com", "inbox",
                1564744300);

        List<MailHeader> mailHeaders = mailHeaderDao.searchMailHeadersSubject("inbox",
                "testapp01@cmrhic.com", "测试邮件");
        int size = mailHeaders.size();
        searchUnseen();
    }

    @Test
    public void searchUnseen() {
        MailHeaderDao mailHeaderDao = CmailDatabase.getInstance(CmailCenter.getContext())
                .getMailHeaderDao();
        long timestamp = mailHeaderDao.queryTimestampByUid("testapp01@cmrhic.com", "inbox",
                1564744300);
        List<MailHeader> mailHeaders = mailHeaderDao.searchMailHeadersByUnseen("inbox", 10,
                "testapp01@cmrhic.com", false);
        int size = mailHeaders.size();
    }

    @Test
    public void freezeMail() {
//        Cmail.freezeMail("testapp08@cmrhic.com", "");

//        Cmail.getMailStatus("testapp08@cmrhic.com", "");

//        List<String> list = new ArrayList<>();
//        list.add("testapp08@cmrhic.com");
//        list.add("testapp07@cmrhic.com");
//        list.add("testapp09@cmrhic.com");
//        Cmail.getMailStatusList(list, "");
    }

}
