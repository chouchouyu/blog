#ifndef SANDBOX_CRYPTER_SESSION_H
#define SANDBOX_CRYPTER_SESSION_H

namespace css {
struct Session {
  unsigned short length;
};
}  // namespace css
#endif
