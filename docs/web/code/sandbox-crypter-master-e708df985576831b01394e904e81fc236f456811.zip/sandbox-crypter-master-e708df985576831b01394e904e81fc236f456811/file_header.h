//
// Created by admin on 2019-05-22.
//

#ifndef SANDBOX_CRYPTER_FILE_HEADER_H
#define SANDBOX_CRYPTER_FILE_HEADER_H

#include <stdlib.h>

#ifdef ANDROID
#include <endian.h>
#endif

#ifdef _WINDOWS
#include <stdint.h>
#include "define.h"
#endif

namespace css {

constexpr auto SUPPORTED_PPT_PPTX_FILE_FORMAT =
    "ppt pptm pptx pot potx pps ppsx dps dpt ppt pot pps dps dpt dpss";
constexpr auto SUPPORTED_DOC_FILE_FORMAT =
    "wps wpt doc docx dot dotx docm txt rtf wpss";
constexpr auto SUPPORTED_PDF_FILE_FORMAT = "pdf";
constexpr auto SUPPORTED_EXCEL_FILE_FORMAT =
    "xlsx xlsm xls xlt xltx et ett csv ets";

constexpr auto CSS_SUCCEEDED = 0;
constexpr auto CSS_ERROR_UNKNOW = -1;
constexpr auto CSS_FILE_END = -2;

//#define OFFICE_FILE_FORMAT "ppt pptm pptx pot potx pps ppsx dps dpt ppt pot
// pps dps dpt wps wpt doc docx dot dotx docm txt rtf pdf xlsx xlsm xls xlt xltx
// et ett csv wpss ets dpss"

// 当前的版本号
constexpr auto CURRENT_VERSION = 0x01;
// 保留字段值
constexpr auto RESERVE_FIELD = 0x0000;
// 密钥的长度(字节)
constexpr auto KEY_SIZE = 16;

const size_t CHIP_SIZE = 4096;  // 2的次方

const char READ_SIGN[3] = "rb";
const char WRITE_SIGN[3] = "wb";

enum FileType {
  file_type_unknow = 0x00,
  file_type_doc = 0x01,
  file_type_docx = 0x02,
  file_type_wps = 0x03,
  file_type_txt = 0x04,
  file_type_xls = 0x05,
  file_type_xlsx = 0x06,
  file_type_ppt = 0x07,
  file_type_pptx = 0x08,
  file_type_pdf = 0x09
};

struct FileHeader {
  uint8_t version;    // 版本号
  uint8_t file_type;  // 文件类型
  uint16_t keytype;  // 保留字段 //0x0000默认值,0x0101本地加密，0x1010cos加密
  char identification[32];  // 文件标识
  uint16_t checksum;        // 头部校验和
  uint64_t plain_length;    // 明文长度
  uint64_t data_length;     // 文件内容长度
};

struct SegmentHeader {
  uint16_t offet;           // 分段偏移量
  char identification[32];  // 文件标识
  uint32_t plain_length;    // 分片明文长度
  uint32_t data_length;     // 分段内容长度
};

}  // namespace css

#endif  // SANDBOX_CRYPTER_FILE_HEADER_H
