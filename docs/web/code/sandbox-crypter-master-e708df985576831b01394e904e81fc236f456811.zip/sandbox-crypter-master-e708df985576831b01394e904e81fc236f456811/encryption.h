//
// Created by admin on 2019-05-22.
//

#ifndef SANDBOX_CRYPTER_CRYPTER_H
#define SANDBOX_CRYPTER_CRYPTER_H

#include <iostream>
#include <vector>

namespace css {
class Encryption {
 public:
  static int Aes128EcbEncrypt(const std::vector<unsigned char>& data,
                              std::string& key,
                              std::vector<unsigned char>& encry_data);
  static int Aes128EcbDecrypt(const std::vector<unsigned char>& data,
                              std::string& key,
                              const uint64_t plain_length,
                              std::vector<unsigned char>& decry_data);

  static int FullEncrypt(const std::vector<unsigned char>& input,
                         const std::string& key,
                         std::vector<unsigned char>& output);

  static int FullDecrypt(const std::vector<unsigned char>& input,
                         const std::string& key,
                         std::vector<unsigned char>& output);
};
}  // namespace css

#endif  // SANDBOX_CRYPTER_CRYPTER_H
