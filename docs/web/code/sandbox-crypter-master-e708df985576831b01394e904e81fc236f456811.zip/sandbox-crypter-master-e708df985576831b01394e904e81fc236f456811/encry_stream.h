//
// Created by admin on 2019-05-22.
//

#ifndef SANDBOX_CRYPTER_OSFSTREAM_H
#define SANDBOX_CRYPTER_OSFSTREAM_H

#include "base_stream.h"
#include "file_header.h"

namespace css {
    class EncryStream: public BaseStream {

    public:
        EncryStream(FileType fileType = file_type_unknow);
        ~EncryStream();

		virtual void Open(const std::string& path,
                          const std::string& openMode,
                          FileType fileType = file_type_unknow) override;

        void OpenNormal(const std::string& path,
                        const std::string& openMode,
                        FileType fileType = file_type_unknow);

        virtual void Close() override;
        void CloseNormal();

        int Write(char *buffer, uint64_t length);
        int WriteNormal(char *buffer, uint64_t length);

        int Write(char* buffer, uint64_t length, std::vector<unsigned char>& out_data);

        int SetFileID(const char* fileId);
        std::string GetFileID();
        void SetFilekey(const std::string& keyStr);
        int SetFileIdWithoutFile(const char* fileId);
        int setKeyType(uint16_t value);
    private:
        uint16_t offset_;            // 当前的安全文件偏移量
        uint64_t file_pos_;     // 当前的安全文件指针
        uint64_t plain_len_;      // 明文长度
        std::string key_;
    };
}

#endif //SANDBOX_CRYPTER_OSFSTREAM_H
