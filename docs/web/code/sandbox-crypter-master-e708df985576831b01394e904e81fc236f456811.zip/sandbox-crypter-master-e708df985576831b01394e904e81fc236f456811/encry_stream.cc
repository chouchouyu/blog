//
// Created by admin on 2019-05-22.
//

#include "encry_stream.h"
#include "encryption.h"

namespace css {

EncryStream::EncryStream(FileType fileType) : BaseStream(fileType) {
  offset_ = 0;
  file_pos_ = 0;
  plain_len_ = 0;
}

void EncryStream::SetFilekey(const std::string& keyStr) {
  key_ = keyStr;
}

int EncryStream::SetFileIdWithoutFile(const char* fileId) {
  if (offset_ == 0) {
    // 记录文件头
    file_pos_ += sizeof(FileHeader);
  }

  memcpy(file_header_.identification, fileId, 32);

  return 0;
}

int EncryStream::SetFileID(const char* fileId) {
  memcpy(file_header_.identification, fileId, 32);
  return 0;
}

std::string EncryStream::GetFileID() {
  return std::string(file_header_.identification, 32);
}

int EncryStream::setKeyType(uint16_t value) {
  file_header_.keytype = value;
  return 0;
}

int EncryStream::Write(char* buffer, uint64_t length) {
  // 判断文件是否打开
  if (!IsOpen()) {
    std::cout << "logger: file is not opened" << std::endl;
    return -1;
  }

  // 检验参数是否为空
  if (buffer == NULL || key_.size() != KEY_SIZE || length == 0) {
    std::cout << "logger: buffer is null or key is invalid" << std::endl;
    return -1;
  }
  try {
    // 处理待加密数据
    int left = length % 16;

    std::vector<unsigned char> sourceData(length + 16 - left);
    sourceData.assign((unsigned char*)buffer,
                      (unsigned char*)(buffer + length));
    sourceData.insert(sourceData.begin() + length, 16 - left, ' ');
    // 加密得到密文
    std::vector<unsigned char> out_data;

    Encryption::Aes128EcbEncrypt(sourceData, key_, out_data);

    // 创建并写入片段头
    SegmentHeader segmentHeader;
    memcpy(segmentHeader.identification, file_header_.identification,
           sizeof(segmentHeader.identification));
    segmentHeader.offet = htons(offset_);
    segmentHeader.plain_length = htonl(length);
    segmentHeader.data_length = htonl(out_data.size());

    size_t head_size = sizeof(SegmentHeader);

    if (fwrite(&segmentHeader, 1, head_size, file_handler_) != head_size) {
      return CSS_ERROR_UNKNOW;
    }

    if (fwrite(&out_data[0], 1, out_data.size(), file_handler_) !=
        out_data.size()) {
      return CSS_ERROR_UNKNOW;
    }

    // 修改偏移量及明文文件长度
    file_pos_ += head_size;
    file_pos_ += out_data.size();

    offset_++;
    plain_len_ += length;

  } catch (...) {
    std::cout << "logger: write data error, please check the key" << std::endl;
    return -1;
  }

  return 0;
}

int EncryStream::Write(char* buffer,
                       uint64_t length,
                       std::vector<unsigned char>& out_data) {
  // 检验参数是否为空
  if (buffer == NULL || key_.size() != KEY_SIZE || length == 0) {
    std::cout << "logger: buffer is null or key is invalid" << std::endl;
    return -1;
  }
  try {
    // 处理待加密数据
    uint64_t left = length % 16;

    std::vector<unsigned char> sourceData(length + 16 - left);
    sourceData.assign((unsigned char*)buffer,
                      (unsigned char*)(buffer + length));
    sourceData.insert(sourceData.begin() + length, 16 - left, ' ');

    std::vector<unsigned char> encry_data;
    // 加密得到密文

    Encryption::Aes128EcbEncrypt(sourceData, key_, encry_data);

    // 创建并写入片段头
    SegmentHeader segmentHeader;
    segmentHeader.offet = htons(offset_);
    memcpy(segmentHeader.identification, file_header_.identification,
           sizeof(segmentHeader.identification));
    segmentHeader.data_length = htonl(encry_data.size());
    segmentHeader.plain_length = htonl(length);
    file_pos_ += sizeof(SegmentHeader);

    file_pos_ += encry_data.size();

    out_data.resize(sizeof(SegmentHeader) + encry_data.size());
    out_data.assign((unsigned char*)&segmentHeader,
                    (unsigned char*)(&segmentHeader + sizeof(SegmentHeader)));
    out_data.insert(out_data.begin() + sizeof(SegmentHeader),
                    encry_data.begin(), encry_data.end());

    // 修改偏移量及明文文件长度
    offset_++;
    plain_len_ += length;

  } catch (...) {
    std::cout << "logger: write data error, please check the key" << std::endl;
    return -1;
  }

  return 0;
}

void EncryStream::Close() {
  // 修正文件头

  if (file_handler_) {
    fseek(file_handler_, 0, SEEK_SET);

    size_t head_size = sizeof(FileHeader);

    file_header_.plain_length = plain_len_;
#ifdef _WINDOWS
    file_header_.data_length = htonl(file_pos_ - head_size);
#else
    file_header_.data_length = htonq(file_pos_ - head_size);
#endif  // _WINDOWS
    file_header_.checksum = htons(GenChecksum(file_header_));

    fwrite(&file_header_, 1, head_size, file_handler_);

    // 调用父类的关闭函数
    BaseStream::Close();

    // 修正file_pos_及offset_,并释放文件头
    file_pos_ = 0;
    offset_ = 0;
  }
}

void EncryStream::CloseNormal() {
  BaseStream::Close();
}

EncryStream::~EncryStream() {}

void EncryStream::Open(const std::string& path,
                       const std::string& openMode,
                       FileType fileType) {
  // 调用父类的打开
  BaseStream::Open(path, openMode, fileType);

  if (fseek(file_handler_, 0, SEEK_SET)) {
    return;
  }

  file_pos_ = fwrite(&file_header_, 1, sizeof(FileHeader), file_handler_);
}
void EncryStream::OpenNormal(const std::string& path,
                             const std::string& openMode,
                             FileType fileType) {
  BaseStream::Open(path, openMode, fileType);
}

int EncryStream::WriteNormal(char* buffer, uint64_t length) {
  // 判断文件是否打开
  if (!IsOpen()) {
    std::cout << "logger: file is not opened" << std::endl;
    return -1;
  }

  // 检验参数是否为空
  if (buffer == NULL || length == 0) {
    std::cout << "logger: buffer is null or key is invalid" << std::endl;
    return -1;
  }
  try {
    size_t size = fwrite(buffer, 1, length, file_handler_);

    // 修改偏移量及明文文件长度
    file_pos_ += size;
    offset_++;
    plain_len_ += size;

  } catch (...) {
    std::cout << "logger: write data error, please check the key" << std::endl;
    return -1;
  }

  return 0;
}

}  // namespace css
