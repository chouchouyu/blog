//
// Created by admin on 2019-05-23.
//
#include "decry_stream.h"
#include "encryption.h"

namespace css {

DecryStream::DecryStream(FileType fileType) : BaseStream(fileType) {
  FilePosition position;
  position.splitIndex = 0;
  position.plainOffset = 0;

  file_pos_ = position;
  read_plain_len_ = 0;
}

void DecryStream::Open(const std::string& path,
                       const std::string& openMode,
                       FileType fileType) {
  // 调用父类的打开
  BaseStream::Open(path, openMode, fileType);

  // 设置文件的起始位置及读取文件头
  if (IsOpen()) {
    if (fseek(file_handler_, 0, SEEK_SET) != 0) {
      return;
    }

    size_t size = fread(&file_header_, 1, sizeof(FileHeader), file_handler_);

    if (size != sizeof(FileHeader)) {
      return;
    }
  }

  file_pos_.splitIndex = 0;
  file_pos_.plainOffset = 0;
}

bool DecryStream::OpenBuffer(char* head_buffer, uint64_t length) {
  if (length < sizeof(FileHeader)) {
    return false;
  }

  memcpy((char*)&file_header_, head_buffer, sizeof(FileHeader));

  return true;
}

int DecryStream::ReadOneSegment(std::vector<unsigned char>& out_buffer) {
  // 校验参数是否合法
  if (!IsOpen()) {
    std::cout << "file is not open" << std::endl;
    return CSS_ERROR_UNKNOW;
  }

  try {
    // 读取片段头
    SegmentHeader segmentHeader;

    size_t size =
        fread(&segmentHeader, 1, sizeof(SegmentHeader), file_handler_);

    if (IsEnd()) {
      return CSS_FILE_END;
    }

    if (size != sizeof(SegmentHeader)) {
      return CSS_ERROR_UNKNOW;
    }

    uint64_t data_len = ntohl(segmentHeader.data_length);
    uint64_t plain_len = ntohl(segmentHeader.plain_length);

    // 读取片段payload
    std::vector<char> payload_buffer(data_len, 0);

    size = fread(&payload_buffer[0], 1, data_len, file_handler_);

    if (size != data_len) {
      return -1;
    }

    // 解密片段
    if (Decrypt(&payload_buffer[0], data_len, plain_len, out_buffer) !=
        CSS_SUCCEEDED) {
      return -1;
    }

  } catch (...) {
    return -1;
  }

  return 0;
}

bool DecryStream::IsEnd() {
  if (!file_handler_)
    return true;

  return feof(file_handler_) != 0;
}

std::string DecryStream::GetFileID() {
  return std::string(file_header_.identification, 32);
}

void DecryStream::SetFilekey(std::string key) {
  key_ = key;
}

uint64_t DecryStream::EncodeLength() {
  uint64_t count = PlainLength() / CHIP_SIZE;

  if (PlainLength() % CHIP_SIZE != 0) {
    count++;
  }

  uint64_t mode = 16 - (PlainLength() % 16);

  return sizeof(FileHeader) + count * sizeof(SegmentHeader) + PlainLength() +
         mode;
}

uint16_t DecryStream::GetKeyType() {
  return file_header_.keytype;
}

int DecryStream::ReadSegment(const char* rev_buf,
                             uint64_t rev_len,
                             uint64_t& offset,
                             std::vector<unsigned char>& out_buf) {
  std::string key = key_;

  // 校验参数是否合法
  if (rev_buf == NULL || rev_len == 0 || key.size() == 0) {
    std::cout << "logger: buffer is null or key is invalid" << std::endl;
    return -1;
  }

  if (sizeof(SegmentHeader) > rev_len) {
    return -1;
  }

  int off_set = 0;
  // 读取片段头
  SegmentHeader segmentHeader;

  memcpy(&segmentHeader, rev_buf, sizeof(SegmentHeader));
  uint64_t data_len = ntohl(segmentHeader.data_length);
  uint64_t plain_len = ntohl(segmentHeader.plain_length);

  if ((data_len + sizeof(SegmentHeader)) > rev_len) {
    return -1;
  }

  // 读取片段payload
  std::vector<char> payload_buffer(data_len);
  off_set += sizeof(SegmentHeader);
  payload_buffer.assign(rev_buf + offset, rev_buf + offset + data_len);

  // 解密片段
  std::vector<unsigned char> decode_data;
  if (Decrypt(&payload_buffer[0], data_len, plain_len, out_buf) !=
      CSS_SUCCEEDED) {
    return -1;
  }

  off_set += data_len;
  offset = off_set;
  return 0;
}

int DecryStream::Read(char* buffer, uint64_t length) {
  std::string key = key_;
  // 判断文件是否打开
  if (!IsOpen()) {
    std::cout << "logger: file is not opened" << std::endl;
    return -1;
  }

  // 校验参数是否合法
  if (buffer == NULL || length == 0 || key.size() == 0) {
    std::cout << "logger: buffer is null or key is invalid" << std::endl;
    return -1;
  }

  // 记录属性
  char* bufferPointer = buffer;
  uint64_t currentSplitIndex = 0;  // 当前读取到的分段索引
  uint64_t currentPlainOffset = 0;  // 当前读取到的分段，其明文的偏移量

  // 读取数据
  SegmentHeader segmentHeader;
  std::vector<char> payload_buffer;
  std::vector<unsigned char> resultData;
  unsigned int head_size = sizeof(SegmentHeader);

  while (length) {
    // 读取片段头
    if (fread(&segmentHeader, 1, head_size, file_handler_) != head_size) {
      return -1;
    }

    uint64_t dataLength = ntohl(segmentHeader.data_length);
    uint64_t plainLength = ntohl(segmentHeader.plain_length);
    currentSplitIndex = ntohs(segmentHeader.offet);

    // 读取片段payload
    payload_buffer.resize(dataLength, 0);

    if (fread(&payload_buffer[0], 1, dataLength, file_handler_) != dataLength) {
      break;
    }

    // 解密片段
    Decrypt(&payload_buffer[0], dataLength, plainLength, resultData);

    char* resultBuffer = (char*)&resultData[0];
    uint64_t availableLength = resultData.size();

    // 判断文件偏移量
    if (currentSplitIndex == file_pos_.splitIndex) {
      if (file_pos_.plainOffset >= resultData.size())
        continue;

      resultBuffer += file_pos_.plainOffset;
      availableLength = resultData.size() - file_pos_.plainOffset;
    }

    // 判断读取的文件是否满足要求
    if (availableLength > length) {
      memcpy(bufferPointer, resultBuffer, length);
      bufferPointer += length;
      currentPlainOffset = file_pos_.plainOffset + length;
      length = 0;
    } else {
      memcpy(bufferPointer, resultBuffer, availableLength);
      bufferPointer += availableLength;
      length = length - availableLength;
      if (currentSplitIndex == file_pos_.splitIndex) {
        currentPlainOffset = file_pos_.plainOffset + availableLength;
      } else {
        currentPlainOffset = availableLength;
      }
    }

    payload_buffer.clear();
    resultData.clear();
  }

  read_plain_len_ = bufferPointer - buffer;

  // 保存当前读取位置,并充值文件指针
  file_pos_.splitIndex = currentSplitIndex;
  file_pos_.plainOffset = currentPlainOffset;
  Seek(file_pos_);

  return 0;
}

uint64_t DecryStream::Gcount() {
  return read_plain_len_;
}

uint64_t DecryStream::PlainLength() {
  return file_header_.plain_length;
}

uint64_t DecryStream::DataLength() {
  return file_header_.data_length;
}

FileType DecryStream::GetFileType() {
  FileType fileType = file_type_unknow;
  if (file_header_.file_type == 0x01)
    fileType = file_type_doc;
  else if (file_header_.file_type == 0x02)
    fileType = file_type_docx;
  else if (file_header_.file_type == 0x03)
    fileType = file_type_wps;
  else if (file_header_.file_type == 0x04)
    fileType = file_type_txt;
  else if (file_header_.file_type == 0x05)
    fileType = file_type_xls;
  else if (file_header_.file_type == 0x06)
    fileType = file_type_xlsx;
  else if (file_header_.file_type == 0x07)
    fileType = file_type_ppt;
  else if (file_header_.file_type == 0x08)
    fileType = file_type_pptx;
  else if (file_header_.file_type == 0x09)
    fileType = file_type_pdf;
  else
    fileType = file_type_unknow;
  return fileType;
}

void DecryStream::Seek(FilePosition file_pos_) {
  // 判断文件是否打开
  if (!IsOpen())
    return;

  // 校验文件合法性
  if (!Validate())
    return;

  // 复制
  file_pos_.plainOffset = file_pos_.plainOffset;
  file_pos_.splitIndex = file_pos_.splitIndex;

  // 读取文件，移动文件指针至分片的起点
  uint64_t splitIndex = file_pos_.splitIndex;
  uint64_t position = sizeof(FileHeader);

  while (1) {
    // 移动文件位置
    if (fseek(file_handler_, position, SEEK_SET)) {
      break;
    }

    // 读取分段头
    SegmentHeader segmentHeader;
    memset((void*)&segmentHeader, 0, sizeof(SegmentHeader));

    if (fread(&segmentHeader, 1, sizeof(SegmentHeader), file_handler_) !=
        sizeof(SegmentHeader)) {
      break;
    }

    // 读取当前分段索引/分段数据长度/分段明文长度
    uint64_t index = ntohs(segmentHeader.offet);
    uint64_t dataLength = ntohl(segmentHeader.data_length);
    //        uint64_t plainLength = ntohl(segmentHeader.plain_length);

    if (index == splitIndex) {
      break;
    }

    position += sizeof(SegmentHeader) + dataLength;
  }

  // 设置文件位置
  fseek(file_handler_, position, SEEK_SET);
}

bool DecryStream::Validate() {
  // 判断文件是否打开、判断文件句柄是否存在
  if (!IsOpen())
    return false;

  // 判断校验码
  uint16_t originCheck = ntohs(file_header_.checksum);
  file_header_.checksum = 0x0000;
  uint16_t calCheck = GenChecksum(file_header_);
  file_header_.checksum = htons(originCheck);

  return (originCheck == calCheck);
}

/// 根据版本号对密文进行解密
int DecryStream::Decrypt(const char* buffer,
                         const uint64_t length,
                         const uint64_t plain_length,
                         std::vector<unsigned char>& encry_data) {
  // 判断
  if (buffer == NULL || length == 0 || key_.size() == 0)
    return CSS_ERROR_UNKNOW;

  // 取出版本号
  uint8_t version = file_header_.version;

  // 处理密文
  std::vector<unsigned char> source(length, 0);
  source.assign((unsigned char*)buffer, (unsigned char*)(buffer + length));
  // 根据版本号解密
  if (version == 0x01) {
    return Encryption::Aes128EcbDecrypt(source, key_, plain_length, encry_data);
  }

  return CSS_ERROR_UNKNOW;
}

DecryStream::~DecryStream() {}

}  // namespace css
