//
// Created by admin on 2019-05-22.
//

#include "base_stream.h"
#include <bitset>
#include <fstream>
#include <iomanip>
#include <sstream>

static uint16_t checksum(void* dataptr, uint16_t len);

css::BaseStream::BaseStream(FileType fileType)
        :file_handler_(NULL),
         file_type_(fileType) {
}

css::BaseStream::BaseStream(const std::string& path,
                            const std::string& openMode,
                            FileType fileType) {
    file_type_ = fileType;

    Open(path, openMode, fileType);
}

void css::BaseStream::Open(const std::string& path,
                           const std::string& openMode,
                           FileType fileType) {

    if(!file_handler_){
        #ifdef _WINDOWS
        errno_t error = fopen_s(&file_handler_, path.data(), openMode.data());
        #elseif
        file_handler_ = fopen(path.data(), openMode.data());
        #endif
    }

    ResetHeader();
}

bool css::BaseStream::IsOpen() {
    return file_handler_ != NULL;
}

bool css::BaseStream::IsSecurityFile(std::string path) {
    if (path.size() == 0)
        return false;
    std::fstream fin(path, std::ios::in | std::ios::binary);
    if (!fin.is_open())
        return false;
    FileHeader header;
    fin.read((char*)&header, sizeof(FileHeader));
    if (fin.gcount() != sizeof(FileHeader))
        return false;

    uint16_t checksum = ntohs(header.checksum);
    header.checksum = 0x0000;
    uint16_t standard = GenChecksum(header);
    header.checksum = htons(checksum);
    fin.close();
    return (checksum == standard);
}

bool css::BaseStream::IsSecurityFileData(char* buf, uint64_t& off_set) {
    FileHeader header;
    memcpy((char*)&header, buf, sizeof(FileHeader));
    uint16_t checksum = ntohs(header.checksum);
    header.checksum = 0x0000;
    uint16_t standard = GenChecksum(header);
    header.checksum = htons(checksum);
    off_set = sizeof(FileHeader);
    return (checksum == standard);
}

void css::BaseStream::Close() {

    if(file_handler_){
        fclose(file_handler_);
        file_handler_ = NULL;
    }
}

css::BaseStream::~BaseStream() {
    Close();
}

// todo
uint16_t css::BaseStream::GenFileId() {
    return 0;
}

uint16_t css::BaseStream::GenChecksum(FileHeader header) {
    // 校验码置为0
    header.checksum = 0x0000;

    // 计算校验码
    header.checksum = 0x0000;
    uint16_t result = checksum(&header, sizeof(FileHeader));
    return result;
}

void css::BaseStream::ResetHeader() {
    // 创建
    file_header_.version = CURRENT_VERSION;
    file_header_.file_type = file_type_;
    file_header_.keytype = htons(RESERVE_FIELD);
    memset(file_header_.identification, 'A', sizeof(file_header_.identification));

    // 默认未赋值，需要后续修正
    file_header_.plain_length = 0;
    file_header_.data_length = 0;
    file_header_.checksum = 0;
}

int css::BaseStream::GetError() {
    return errno;
}

static uint16_t checksum(void* dataptr, uint16_t len) {
    uint32_t acc = 0;
    uint16_t src;
    uint8_t* octetptr = (uint8_t*)dataptr;
    while (len > 1) {
        src = (*octetptr) << 8;
        octetptr++;
        src |= (*octetptr);
        octetptr++;
        acc += src;
        len -= 2;
    }
    if (len > 0) {
        src = (*octetptr) << 8;
        acc += src;
    }

    acc = static_cast<uint32_t>((acc >> 16) + (acc & 0x0000ffffUL));
    if ((acc & 0xffff0000UL) != 0) {
        acc = static_cast<uint32_t>((acc >> 16) + (acc & 0x0000ffffUL));
    }

    src = (uint16_t)acc;
    return ~src;
}
