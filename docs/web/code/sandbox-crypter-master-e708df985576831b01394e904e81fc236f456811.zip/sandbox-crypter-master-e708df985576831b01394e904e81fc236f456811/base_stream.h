//
// Created by admin on 2019-05-22.
//

#ifndef SANDBOX_CRYPTER_SFSTREAM_H
#define SANDBOX_CRYPTER_SFSTREAM_H

#include <fstream>
#include <iostream>
#include <vector>
#include "file_header.h"

namespace css {

    class BaseStream {
    public:
        BaseStream(FileType fileType = file_type_unknow);
        BaseStream(const std::string& path,
                   const std::string& openMode,
                   FileType fileType = file_type_unknow);

        virtual ~BaseStream();

        virtual void Open(const std::string& path,
                          const std::string& openMode,
                          FileType fileType = file_type_unknow);
        bool IsOpen();

        int GetError();

        // 判断指定文件是否为安全文件
        bool IsSecurityFile(std::string path);
        bool IsSecurityFileData(char* buf, uint64_t& off_set);
        virtual void Close();

    public:
        // todo
        uint16_t GenFileId();

        uint16_t GenChecksum(FileHeader header);
        FileHeader* GetFileHeader() { return &file_header_; }

        void ResetHeader();

    protected:
        FileType file_type_;          // 文件类
        FILE* file_handler_;  // 文件句柄
        FileHeader file_header_;     // 当前的文件头
    };

}  // namespace css

#endif  // SANDBOX_CRYPTER_SFSTREAM_H
