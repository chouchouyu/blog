#ifndef SANDBOX_DEFINE_H
#define SANDBOX_DEFINE_H

#ifdef _WINDOWS
#include <Winsock2.h>
#pragma comment(lib, "Ws2_32.lib")
#include <winsock2.h>
#endif


#endif