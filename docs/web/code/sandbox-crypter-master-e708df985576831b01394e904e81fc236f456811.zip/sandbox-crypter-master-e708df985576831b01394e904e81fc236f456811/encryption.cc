//
// Created by admin on 2019-05-22.
//

#include "encryption.h"
#include <string.h>
#include <cassert>
#include "sm4.h"
#include "session.h"

#ifdef ANDROID
#include <endian.h>
#endif

#ifdef _WINDOWS
#include <stdint.h>
#include "define.h"
#endif

using namespace css;
constexpr auto CRY_ENCODE_SIZE = 4096;
constexpr unsigned int KEY_SIZE = 16;
/*
 * openssl aes 128 ecb pkcs5padding 加密
 */
int Encryption::Aes128EcbEncrypt(const std::vector<unsigned char>& data,
                                 std::string& key,
                                 std::vector<unsigned char>& encry_data) {
  // check parameter
  if (key.size() < KEY_SIZE)
    return -1;

  try {
    sm4_context ctx;
    sm4_setkey_enc(&ctx, (unsigned char*)key.data());

    if (data.size() > CRY_ENCODE_SIZE) {
      std::vector<unsigned char> result(CRY_ENCODE_SIZE, 0);

      std::vector<unsigned char> sourcePart1(CRY_ENCODE_SIZE, 0);
      sourcePart1.assign(data.begin(), data.begin() + CRY_ENCODE_SIZE);

      sm4_crypt_ecb(&ctx, SM4_ENCRYPT, CRY_ENCODE_SIZE, &sourcePart1[0],
                    &result[0]);

      encry_data.resize(data.size(), 0);
      encry_data.assign(result.begin(), result.begin() + CRY_ENCODE_SIZE);
      encry_data.insert(encry_data.begin() + CRY_ENCODE_SIZE,
                        data.begin() + CRY_ENCODE_SIZE, data.end());
    } else {
      std::vector<unsigned char> result(data.size(), 0);

      sm4_crypt_ecb(&ctx, SM4_ENCRYPT, data.size(), (unsigned char*)&data[0],
                    &result[0]);
      encry_data.resize(result.size());
      encry_data.assign(result.begin(), result.end());
    }
  } catch (...) {
    printf("error.");
    return 0;
  }

  return 0;
}

/*
 * openssl aes 128 ecb pkcs5padding 解密
 */
int Encryption::Aes128EcbDecrypt(const std::vector<unsigned char>& data,
                                 std::string& key,
                                 const uint64_t plain_length,
                                 std::vector<unsigned char>& decry_data) {
  // check parameter
  if (key.size() < KEY_SIZE)
    return -1;

  try {
    sm4_context ctx;
    sm4_setkey_dec(&ctx, (unsigned char*)key.data());

    if (data.size() > CRY_ENCODE_SIZE) {
      std::vector<unsigned char> result(CRY_ENCODE_SIZE, 0);
      int end_offset = data.size() - plain_length;

      sm4_crypt_ecb(&ctx, SM4_DECRYPT, CRY_ENCODE_SIZE,
                    const_cast<unsigned char*>(&data[0]), &result[0]);
      decry_data.resize(plain_length, 0);
      decry_data.assign(result.begin(), result.begin() + result.size());
      decry_data.insert(decry_data.begin() + result.size(),
                        data.begin() + result.size(), data.end() - end_offset);
    } else {
      std::vector<unsigned char> result(data.size(), 0);

      sm4_crypt_ecb(&ctx, SM4_DECRYPT, data.size(),
                    const_cast<unsigned char*>(&data[0]), &result[0]);
      decry_data.resize(plain_length);
      decry_data.assign(result.begin(), result.begin() + plain_length);
    }
  } catch (...) {
    return -1;
  }

  return 0;
}

int css::Encryption::FullEncrypt(const std::vector<unsigned char>& input,
                                 const std::string& key,
                                 std::vector<unsigned char>& output) {

  if (input.empty()) {
    return -1;
  }

  sm4_context ctx;
  sm4_setkey_enc(&ctx, (unsigned char*)key.data());

  unsigned char iv[16] = {0};
  int mod = input.size() % 16;
  int fill_len = mod == 0 ? 0 : 16 - mod;
  std::vector<unsigned char> buffer;
  buffer.resize(input.size() + fill_len);
  output.resize(buffer.size() + sizeof(Session));
  sm4_crypt_cbc(&ctx, SM4_ENCRYPT, input.size(), iv,
                (unsigned char*)(&input[0]), &buffer[0]);

  Session session;
  session.length = htons(input.size());
  memcpy(&output[0], &session, sizeof(Session));
  memcpy(&output[sizeof(Session)], &buffer[0], buffer.size());

  return 0;
}

int css::Encryption::FullDecrypt(const std::vector<unsigned char>& input,
                                 const std::string& key,
                                 std::vector<unsigned char>& output) {
  if (input.empty()) {
    return -1;
  }

  sm4_context ctx;
  sm4_setkey_dec(&ctx, (unsigned char*)key.data());

  unsigned char iv[16] = {0};
  std::vector<unsigned char> buffer;
  buffer.resize(input.size() - sizeof(Session));

  sm4_crypt_cbc(&ctx, SM4_DECRYPT, buffer.size(), iv,
                const_cast<unsigned char*>(&input[sizeof(Session)]),
                &buffer[0]);

  Session session;
  memcpy(&session, &input[0], sizeof(Session));

  unsigned short plain_len = ntohs(session.length);

  output.resize(plain_len);
  output.assign(buffer.begin(), buffer.begin() + plain_len);

  return 0;
}
