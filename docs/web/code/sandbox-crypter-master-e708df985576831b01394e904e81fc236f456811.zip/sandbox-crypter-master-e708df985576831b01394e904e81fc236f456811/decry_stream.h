//
// Created by admin on 2019-05-23.
//

#ifndef SANDBOX_CRYPTER_ISFSTREAM_H
#define SANDBOX_CRYPTER_ISFSTREAM_H

#include "base_stream.h"

namespace css {

struct FilePosition {
  uint64_t splitIndex;   // 分片索引
  uint64_t plainOffset;  // 分片对应的明文的偏移量
};

class DecryStream : public BaseStream {
 public:
  DecryStream(FileType fileType = file_type_unknow);
  ~DecryStream();

 public:
    virtual void Open(const std::string& path,
            const std::string& openMode,
            FileType fileType = file_type_unknow) override;
  bool OpenBuffer(char* head_buffer, uint64_t length);

  int ReadOneSegment(std::vector<unsigned char>& out_buffer);

  bool IsEnd();

  int ReadSegment(const char* res_buf,
                  uint64_t res_len,
                  uint64_t& offset,
                  std::vector<unsigned char>& out_buf);
  int Read(char* buffer, uint64_t length);

  void Seek(FilePosition file_pos_);
  uint64_t Gcount();
  uint64_t PlainLength();
  uint64_t DataLength();
  FileType GetFileType();
  std::string GetFileID();
  uint16_t GetKeyType();
  void SetFilekey(std::string keyStr);

  uint64_t EncodeLength();
  

 private:
  // 校验文件有效性
  bool Validate();
  // 解密
  int Decrypt(const char* buffer,
              const uint64_t length,
	          const uint64_t plain_length,
              std::vector<unsigned char>& out_data);

 private:
  FilePosition file_pos_;        // 当前的文件位置
  uint64_t read_plain_len_;       // 当次实际读取的明文数据长度
  std::string key_;
};
}  // namespace css

#endif  // SANDBOX_CRYPTER_ISFSTREAM_H
